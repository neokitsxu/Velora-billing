'use client';

import { useState, useEffect } from 'react';
import {
  Globe,
  Plus,
  Edit2,
  Trash2,
  Search,
  FileCode,
  Loader2,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface ServerLocation {
  id: string;
  name: string;
  country: string;
  city: string;
  flag: string;
  nodeCount: number;
  status: string;
  latency: string;
}

export default function AdminLocations() {
  const [locations, setLocations] = useState<ServerLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const loadData = async () => {
      await new Promise((r) => setTimeout(r, 500));
      setLocations([
        { id: '1', name: 'Mumbai', country: 'India', city: 'Mumbai', flag: '🇮🇳', nodeCount: 3, status: 'active', latency: '12ms' },
        { id: '2', name: 'Singapore', country: 'Singapore', city: 'Singapore', flag: '🇸🇬', nodeCount: 2, status: 'active', latency: '45ms' },
        { id: '3', name: 'Frankfurt', country: 'Germany', city: 'Frankfurt', flag: '🇩🇪', nodeCount: 1, status: 'active', latency: '120ms' },
        { id: '4', name: 'US East', country: 'United States', city: 'New York', flag: '🇺🇸', nodeCount: 2, status: 'maintenance', latency: '180ms' },
      ]);
      setLoading(false);
    };
    loadData();
  }, []);

  const filtered = locations.filter((l) =>
    l.name.toLowerCase().includes(search.toLowerCase()) || l.country.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Server Locations</h1>
          <p className="text-[#64748b] mt-1">Manage server locations & regions</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Add Location
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#6366f1]/10"><Globe size={18} className="text-[#6366f1]" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Total Locations</p>
              <p className="text-xl font-bold text-[#e2e8f0]">{locations.length}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/10"><FileCode size={18} className="text-green-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Active Nodes</p>
              <p className="text-xl font-bold text-[#e2e8f0]">{locations.reduce((a, l) => a + l.nodeCount, 0)}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-yellow-500/10"><Globe size={18} className="text-yellow-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Avg Latency</p>
              <p className="text-xl font-bold text-[#e2e8f0]">89ms</p>
            </div>
          </div>
        </div>
      </div>

      {showAdd && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Add New Location</h3>
          <div className="grid grid-cols-2 gap-4 max-w-2xl">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Location Name</label>
              <input type="text" className="velora-input w-full" placeholder="e.g., Mumbai" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Country</label>
              <input type="text" className="velora-input w-full" placeholder="e.g., India" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">City</label>
              <input type="text" className="velora-input w-full" placeholder="e.g., Mumbai" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Flag Emoji</label>
              <input type="text" className="velora-input w-full" placeholder="e.g., 🇮🇳" />
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={() => { toast.success('Location added!'); setShowAdd(false); }} className="velora-btn-primary">Add Location</button>
            <button onClick={() => setShowAdd(false)} className="velora-btn-secondary">Cancel</button>
          </div>
        </div>
      )}

      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
        <input type="text" placeholder="Search locations..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input w-full pl-10" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((loc) => (
          <div key={loc.id} className="velora-card p-5 hover:border-[#6366f1]/30 transition-colors">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{loc.flag}</span>
                <div>
                  <h3 className="text-sm font-semibold text-[#e2e8f0]">{loc.name}</h3>
                  <p className="text-xs text-[#64748b]">{loc.city}, {loc.country}</p>
                </div>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full ${loc.status === 'active' ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'}`}>{loc.status}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex gap-4 text-xs text-[#64748b]">
                <span>{loc.nodeCount} Nodes</span>
                <span>Latency: {loc.latency}</span>
              </div>
              <div className="flex gap-1">
                <button className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0]"><Edit2 size={14} /></button>
                <button className="p-1.5 rounded-lg hover:bg-red-500/10 text-[#64748b] hover:text-red-400"><Trash2 size={14} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
