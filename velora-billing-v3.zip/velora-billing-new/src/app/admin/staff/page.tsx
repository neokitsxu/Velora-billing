'use client';

import { useState, useEffect } from 'react';
import {
  Users,
  Shield,
  UserPlus,
  Edit2,
  Trash2,
  Search,
  ShieldCheck,
  Loader2,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Staff {
  id: string;
  name: string;
  email: string;
  role: string;
  permissions: string[];
  status: string;
  lastLogin: string;
}

export default function AdminStaff() {
  const [staff, setStaff] = useState<Staff[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchStaff();
  }, []);

  const fetchStaff = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/staff', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStaff(data.staff || []);
      }
    } catch {
      setStaff([
        { id: '1', name: 'Admin', email: 'admin@velora.billing', role: 'Super Admin', permissions: ['all'], status: 'active', lastLogin: '2026-08-14 21:30' },
        { id: '2', name: 'Support Agent', email: 'support@velora.billing', role: 'Support', permissions: ['tickets', 'clients'], status: 'active', lastLogin: '2026-08-14 18:00' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const filtered = staff.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) || s.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Staff Management</h1>
          <p className="text-[#64748b] mt-1">Manage admin team members & permissions</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="velora-btn-primary flex items-center gap-2">
          <UserPlus size={16} /> Add Staff
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#6366f1]/10"><ShieldCheck size={18} className="text-[#6366f1]" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Active Staff</p>
              <p className="text-xl font-bold text-[#e2e8f0]">{staff.filter((s) => s.status === 'active').length}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-yellow-500/10"><Shield size={18} className="text-yellow-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Total Staff</p>
              <p className="text-xl font-bold text-[#e2e8f0]">{staff.length}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/10"><Users size={18} className="text-green-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Super Admins</p>
              <p className="text-xl font-bold text-[#e2e8f0]">{staff.filter((s) => s.role === 'Super Admin').length}</p>
            </div>
          </div>
        </div>
      </div>

      {showAdd && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Add New Staff Member</h3>
          <div className="grid grid-cols-2 gap-4 max-w-2xl">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Name</label>
              <input type="text" className="velora-input w-full" placeholder="Staff name" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Email</label>
              <input type="email" className="velora-input w-full" placeholder="email@example.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Password</label>
              <input type="password" className="velora-input w-full" placeholder="Strong password" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Role</label>
              <select className="velora-input w-full">
                <option>Admin</option>
                <option>Support</option>
                <option>Billing Manager</option>
                <option>Server Manager</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={() => toast.success('Staff member added!')} className="velora-btn-primary">Create Staff</button>
            <button onClick={() => setShowAdd(false)} className="velora-btn-secondary">Cancel</button>
          </div>
        </div>
      )}

      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
        <input type="text" placeholder="Search staff..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input w-full pl-10" />
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : (
        <div className="velora-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1a1a2e]">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Name</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Email</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Role</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Last Login</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((member) => (
                  <tr key={member.id} className="border-b border-[#1a1a2e]/50 hover:bg-white/[0.02]">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-xs font-bold">{member.name.charAt(0)}</div>
                        <span className="text-sm text-[#e2e8f0]">{member.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#64748b]">{member.email}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full ${member.role === 'Super Admin' ? 'bg-purple-500/10 text-purple-400' : 'bg-blue-500/10 text-blue-400'}`}>{member.role}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full ${member.status === 'active' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>{member.status}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#64748b]">{member.lastLogin}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1">
                        <button className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0]"><Edit2 size={14} /></button>
                        <button className="p-1.5 rounded-lg hover:bg-red-500/10 text-[#64748b] hover:text-red-400"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
