'use client';

import { useState, useEffect } from 'react';
import {
  Server,
  RefreshCw,
  Search,
  Power,
  PowerOff,
  HardDrive,
  Cpu,
  Wifi,
  MapPin,
  Loader2,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface PteroServer {
  id: string;
  name: string;
  status: string;
  node: string;
  ip: string;
  port: number;
  cpu: number;
  ram: number;
  disk: number;
  client: string;
  createdAt: string;
}

export default function AdminServers() {
  const [servers, setServers] = useState<PteroServer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    fetchServers();
  }, []);

  const fetchServers = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/servers', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setServers(data.servers || []);
      }
    } catch {
      setServers([
        { id: 'srv_1', name: 'MC-001', status: 'running', node: 'Node 1', ip: '192.168.1.10', port: 25565, cpu: 25, ram: 2048, disk: 10240, client: 'client@velora.billing', createdAt: '2026-08-01' },
        { id: 'srv_2', name: 'VPS-001', status: 'running', node: 'Node 2', ip: '192.168.1.20', port: 22, cpu: 15, ram: 4096, disk: 40960, client: 'demo@velora.billing', createdAt: '2026-08-05' },
        { id: 'srv_3', name: 'MC-002', status: 'stopped', node: 'Node 1', ip: '192.168.1.11', port: 25566, cpu: 0, ram: 0, disk: 20480, client: 'client@velora.billing', createdAt: '2026-08-10' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const filtered = servers.filter((s) => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.client.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const stats = {
    total: servers.length,
    running: servers.filter((s) => s.status === 'running').length,
    stopped: servers.filter((s) => s.status === 'stopped').length,
    totalRam: servers.reduce((a, s) => a + s.ram, 0),
    totalDisk: servers.reduce((a, s) => a + s.disk, 0),
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Servers</h1>
          <p className="text-[#64748b] mt-1">Manage provisioned servers</p>
        </div>
        <button onClick={fetchServers} className="velora-btn-primary flex items-center gap-2">
          <RefreshCw size={16} /> Refresh
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { label: 'Total Servers', value: stats.total, icon: Server },
          { label: 'Running', value: stats.running, icon: Power },
          { label: 'Stopped', value: stats.stopped, icon: PowerOff },
          { label: 'Total RAM', value: `${(stats.totalRam / 1024).toFixed(1)} GB`, icon: Cpu },
          { label: 'Total Disk', value: `${(stats.totalDisk / 1024).toFixed(1)} GB`, icon: HardDrive },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="velora-card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-[#6366f1]/10"><Icon size={18} className="text-[#6366f1]" /></div>
                <div>
                  <p className="text-xs text-[#64748b]">{stat.label}</p>
                  <p className="text-xl font-bold text-[#e2e8f0]">{stat.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input type="text" placeholder="Search servers..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input w-full pl-10" />
        </div>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="velora-input">
          <option value="all">All Status</option>
          <option value="running">Running</option>
          <option value="stopped">Stopped</option>
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : filtered.length === 0 ? (
        <div className="velora-card p-12 text-center">
          <Server size={48} className="mx-auto text-[#64748b] mb-4" />
          <p className="text-[#64748b]">No servers found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((server) => (
            <div key={server.id} className="velora-card p-4 flex items-center justify-between hover:border-[#6366f1]/30 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${server.status === 'running' ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                  <Server size={18} className={server.status === 'running' ? 'text-green-400' : 'text-red-400'} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-[#e2e8f0]">{server.name}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${server.status === 'running' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                      {server.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs text-[#64748b]">
                    <span className="flex items-center gap-1"><MapPin size={12} /> {server.node}</span>
                    <span className="flex items-center gap-1"><Wifi size={12} /> {server.ip}:{server.port}</span>
                    <span className="flex items-center gap-1"><Cpu size={12} /> {server.cpu}% CPU</span>
                    <span className="flex items-center gap-1"><HardDrive size={12} /> {(server.ram / 1024).toFixed(1)}GB RAM</span>
                  </div>
                </div>
              </div>
              <span className="text-xs text-[#64748b]">{server.client}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
