'use client';

import { useState, useEffect } from 'react';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Search,
  Loader2,
  Clock,
  CheckCircle2,
  XCircle,
  CreditCard,
} from 'lucide-react';

interface Transaction {
  id: string;
  type: 'credit' | 'debit' | 'refund';
  amount: number;
  description: string;
  user: string;
  status: 'completed' | 'pending' | 'failed';
  method: string;
  date: string;
}

export default function AdminFinance() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    const loadData = async () => {
      await new Promise((r) => setTimeout(r, 600));
      setTransactions([
        { id: 'TXN001', type: 'credit', amount: 99, description: 'Order payment - Starter Minecraft', user: 'client@velora.billing', status: 'completed', method: 'UPI', date: '2026-08-14 21:30' },
        { id: 'TXN002', type: 'credit', amount: 299, description: 'Order payment - Premium VPS', user: 'demo@velora.billing', status: 'completed', method: 'UPI', date: '2026-08-14 20:15' },
        { id: 'TXN003', type: 'credit', amount: 500, description: 'Wallet top-up', user: 'client@velora.billing', status: 'completed', method: 'UPI', date: '2026-08-14 18:00' },
        { id: 'TXN004', type: 'debit', amount: 99, description: 'Service renewal - MC-001', user: 'client@velora.billing', status: 'completed', method: 'Wallet', date: '2026-08-13 10:00' },
        { id: 'TXN005', type: 'refund', amount: 149, description: 'Refund - VPS cancellation', user: 'demo@velora.billing', status: 'completed', method: 'Wallet', date: '2026-08-12 15:30' },
        { id: 'TXN006', type: 'credit', amount: 199, description: 'Order payment - Ultimate MC', user: 'newuser@email.com', status: 'pending', method: 'UPI', date: '2026-08-14 22:00' },
      ]);
      setLoading(false);
    };
    loadData();
  }, []);

  const filtered = transactions.filter((t) => {
    const matchSearch = t.description.toLowerCase().includes(search.toLowerCase()) || t.user.toLowerCase().includes(search.toLowerCase()) || t.id.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === 'all' || t.type === typeFilter;
    return matchSearch && matchType;
  });

  const totalRevenue = transactions.filter((t) => t.type === 'credit' && t.status === 'completed').reduce((a, t) => a + t.amount, 0);
  const totalRefunds = transactions.filter((t) => t.type === 'refund').reduce((a, t) => a + t.amount, 0);
  const pendingAmount = transactions.filter((t) => t.status === 'pending').reduce((a, t) => a + t.amount, 0);

  const typeIcon = (type: string) => {
    switch (type) {
      case 'credit': return <ArrowDownLeft size={16} className="text-green-400" />;
      case 'debit': return <ArrowUpRight size={16} className="text-red-400" />;
      case 'refund': return <Wallet size={16} className="text-yellow-400" />;
      default: return <CreditCard size={16} className="text-[#64748b]" />;
    }
  };

  const statusBadge = (status: string) => {
    switch (status) {
      case 'completed': return <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 flex items-center gap-1"><CheckCircle2 size={10} /> Completed</span>;
      case 'pending': return <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/10 text-yellow-400 flex items-center gap-1"><Clock size={10} /> Pending</span>;
      case 'failed': return <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/10 text-red-400 flex items-center gap-1"><XCircle size={10} /> Failed</span>;
      default: return null;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Finance</h1>
        <p className="text-[#64748b] mt-1">Transactions, revenue & payment management</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/10"><ArrowDownLeft size={18} className="text-green-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Total Revenue</p>
              <p className="text-xl font-bold text-[#e2e8f0]">₹{totalRevenue.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-yellow-500/10"><Wallet size={18} className="text-yellow-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Total Refunds</p>
              <p className="text-xl font-bold text-[#e2e8f0]">₹{totalRefunds.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-500/10"><Clock size={18} className="text-blue-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Pending</p>
              <p className="text-xl font-bold text-[#e2e8f0]">₹{pendingAmount.toLocaleString()}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/10"><CreditCard size={18} className="text-purple-400" /></div>
            <div>
              <p className="text-xs text-[#64748b]">Transactions</p>
              <p className="text-xl font-bold text-[#e2e8f0]">{transactions.length}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input type="text" placeholder="Search transactions..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input w-full pl-10" />
        </div>
        <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="velora-input">
          <option value="all">All Types</option>
          <option value="credit">Credit</option>
          <option value="debit">Debit</option>
          <option value="refund">Refund</option>
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : (
        <div className="velora-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1a1a2e]">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">ID</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Type</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Description</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">User</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Amount</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Method</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Date</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((txn) => (
                  <tr key={txn.id} className="border-b border-[#1a1a2e]/50 hover:bg-white/[0.02]">
                    <td className="px-4 py-3 text-sm font-mono text-[#64748b]">{txn.id}</td>
                    <td className="px-4 py-3">{typeIcon(txn.type)}</td>
                    <td className="px-4 py-3 text-sm text-[#e2e8f0] max-w-[200px] truncate">{txn.description}</td>
                    <td className="px-4 py-3 text-sm text-[#64748b]">{txn.user}</td>
                    <td className={`px-4 py-3 text-sm font-medium ${txn.type === 'credit' ? 'text-green-400' : txn.type === 'refund' ? 'text-yellow-400' : 'text-red-400'}`}>
                      {txn.type === 'credit' ? '+' : txn.type === 'refund' ? '-' : '-'}₹{txn.amount}
                    </td>
                    <td className="px-4 py-3 text-sm text-[#64748b]">{txn.method}</td>
                    <td className="px-4 py-3">{statusBadge(txn.status)}</td>
                    <td className="px-4 py-3 text-sm text-[#64748b]">{txn.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
