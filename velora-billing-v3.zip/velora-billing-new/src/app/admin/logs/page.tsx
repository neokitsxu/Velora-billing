'use client';

import { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Info,
  XCircle,
  RefreshCw,
  Trash2,
  Clock,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface LogEntry {
  id: string;
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
  source: string;
  timestamp: string;
  details?: string;
}

export default function AdminLogs() {
  const [logs] = useState<LogEntry[]>([
    { id: '1', level: 'info', message: 'Application started successfully', source: 'system', timestamp: '2026-08-14 22:00:01', details: 'Node.js 20.x | Next.js 15 | Port 3000' },
    { id: '2', level: 'success', message: 'Database connected', source: 'prisma', timestamp: '2026-08-14 22:00:02', details: 'SQLite database at ./prisma/dev.db' },
    { id: '3', level: 'info', message: 'Admin login successful', source: 'auth', timestamp: '2026-08-14 22:05:15', details: 'admin@velora.billing from 192.168.1.100' },
    { id: '4', level: 'warning', message: 'Payment timeout - order #ORD-0042', source: 'payment', timestamp: '2026-08-14 22:10:00', details: 'UPI payment expired after 900 seconds' },
    { id: '5', level: 'error', message: 'Pterodactyl API connection failed', source: 'pterodactyl', timestamp: '2026-08-14 22:15:30', details: 'ECONNREFUSED: Connection refused' },
    { id: '6', level: 'success', message: 'Server provisioned successfully', source: 'pterodactyl', timestamp: '2026-08-14 22:20:00', details: 'MC-003 on Node 1' },
    { id: '7', level: 'info', message: 'New user registered', source: 'auth', timestamp: '2026-08-14 22:25:45', details: 'newuser@email.com' },
    { id: '8', level: 'warning', message: 'High memory usage detected', source: 'system', timestamp: '2026-08-14 22:30:00', details: 'Memory usage at 85%' },
    { id: '9', level: 'success', message: 'Settings updated', source: 'admin', timestamp: '2026-08-14 22:35:10', details: 'Payment settings saved' },
    { id: '10', level: 'error', message: 'Email sending failed', source: 'email', timestamp: '2026-08-14 22:40:00', details: 'SMTP auth failed' },
  ]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const filtered = logs.filter((l) => {
    const matchFilter = filter === 'all' || l.level === filter;
    const matchSearch = l.message.toLowerCase().includes(search.toLowerCase()) || l.source.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const levelIcon = (level: string) => {
    switch (level) {
      case 'info': return <Info size={14} className="text-blue-400" />;
      case 'warning': return <AlertTriangle size={14} className="text-yellow-400" />;
      case 'error': return <XCircle size={14} className="text-red-400" />;
      case 'success': return <CheckCircle2 size={14} className="text-green-400" />;
      default: return <Info size={14} />;
    }
  };

  const levelColor = (level: string) => {
    switch (level) {
      case 'info': return 'border-l-blue-500';
      case 'warning': return 'border-l-yellow-500';
      case 'error': return 'border-l-red-500';
      case 'success': return 'border-l-green-500';
      default: return '';
    }
  };

  const stats = {
    info: logs.filter((l) => l.level === 'info').length,
    warning: logs.filter((l) => l.level === 'warning').length,
    error: logs.filter((l) => l.level === 'error').length,
    success: logs.filter((l) => l.level === 'success').length,
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">System Logs</h1>
          <p className="text-[#64748b] mt-1">Application logs & error tracking</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => toast.success('Logs cleared!')} className="velora-btn-secondary flex items-center gap-2">
            <Trash2 size={14} /> Clear Logs
          </button>
          <button className="velora-btn-primary flex items-center gap-2">
            <RefreshCw size={14} /> Refresh
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Info', count: stats.info, color: 'text-blue-400' },
          { label: 'Warnings', count: stats.warning, color: 'text-yellow-400' },
          { label: 'Errors', count: stats.error, color: 'text-red-400' },
          { label: 'Success', count: stats.success, color: 'text-green-400' },
        ].map((s) => (
          <div key={s.label} className="velora-card p-4">
            <div>
              <p className="text-xs text-[#64748b]">{s.label}</p>
              <p className={`text-xl font-bold ${s.color}`}>{s.count}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-3">
        <input type="text" placeholder="Search logs..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input flex-1" />
        <div className="flex gap-1">
          {['all', 'info', 'warning', 'error', 'success'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 text-xs rounded-lg font-medium transition-colors capitalize ${filter === f ? 'bg-[#6366f1] text-white' : 'bg-[#0c0c14] text-[#64748b] hover:text-[#e2e8f0]'}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        {filtered.map((log) => (
          <div key={log.id} className={`velora-card p-4 border-l-2 ${levelColor(log.level)}`}>
            <div className="flex items-start gap-3">
              <div className="mt-0.5">{levelIcon(log.level)}</div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-[#e2e8f0]">{log.message}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-0.5 rounded bg-[#0c0c14] text-[#64748b]">{log.source}</span>
                    <span className="text-xs text-[#64748b] flex items-center gap-1"><Clock size={10} />{log.timestamp}</span>
                  </div>
                </div>
                {log.details && <p className="text-xs text-[#64748b] mt-1">{log.details}</p>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
