'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Users,
  DollarSign,
  Activity,
  Clock,
  HelpCircle,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Package,
  ShoppingCart,
  Plus,
} from 'lucide-react';
import toast from 'react-hot-toast';

const demoStats = {
  totalClients: 1247,
  totalRevenue: 485600,
  activeServices: 892,
  pendingOrders: 34,
  openTickets: 18,
  monthlyRevenue: 72400,
};

const demoOrders = [
  { id: 'ORD-1041', client: 'Rahul Sharma', product: 'Minecraft Pro', amount: 599, status: 'paid', date: '2025-01-15' },
  { id: 'ORD-1040', client: 'Priya Patel', product: 'VPS Starter', amount: 1299, status: 'pending', date: '2025-01-15' },
  { id: 'ORD-1039', client: 'Amit Kumar', product: 'Domain .com', amount: 799, status: 'paid', date: '2025-01-14' },
  { id: 'ORD-1038', client: 'Sneha Reddy', product: 'Minecraft Lite', amount: 299, status: 'paid', date: '2025-01-14' },
  { id: 'ORD-1037', client: 'Vikram Singh', product: 'Dedicated 32GB', amount: 4999, status: 'refunded', date: '2025-01-14' },
  { id: 'ORD-1036', client: 'Anjali Gupta', product: 'VPS Pro', amount: 2499, status: 'paid', date: '2025-01-13' },
  { id: 'ORD-1035', client: 'Rohan Das', product: 'Minecraft Pro', amount: 599, status: 'cancelled', date: '2025-01-13' },
  { id: 'ORD-1034', client: 'Meera Iyer', product: 'Domain .in', amount: 399, status: 'paid', date: '2025-01-12' },
  { id: 'ORD-1033', client: 'Arjun Nair', product: 'VPS Starter', amount: 1299, status: 'pending', date: '2025-01-12' },
  { id: 'ORD-1032', client: 'Kavya Joshi', product: 'Minecraft Lite', amount: 299, status: 'paid', date: '2025-01-11' },
];

const monthlyData = [42, 55, 48, 62, 58, 71, 65, 78, 72, 85, 80, 92];

const statCards = [
  { label: 'Total Clients', key: 'totalClients', icon: Users, prefix: '', suffix: '', change: '+12.5%', up: true },
  { label: 'Total Revenue', key: 'totalRevenue', icon: DollarSign, prefix: '₹', suffix: '', change: '+8.2%', up: true },
  { label: 'Active Services', key: 'activeServices', icon: Activity, prefix: '', suffix: '', change: '+5.1%', up: true },
  { label: 'Pending Orders', key: 'pendingOrders', icon: Clock, prefix: '', suffix: '', change: '-3.2%', up: false },
  { label: 'Open Tickets', key: 'openTickets', icon: HelpCircle, prefix: '', suffix: '', change: '+2', up: true },
  { label: 'Monthly Revenue', key: 'monthlyRevenue', icon: TrendingUp, prefix: '₹', suffix: '', change: '+15.3%', up: true },
];

export default function AdminDashboard() {
  const [stats, setStats] = useState(demoStats);
  const [orders, setOrders] = useState(demoOrders);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/stats', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.stats) setStats(data.stats);
          if (data.recentOrders) setOrders(data.recentOrders);
        }
      } catch {
        // use demo data
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const statusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'velora-badge-success';
      case 'pending': return 'velora-badge-warning';
      case 'refunded': return 'velora-badge-info';
      case 'cancelled': return 'velora-badge-danger';
      default: return 'velora-badge';
    }
  };

  const maxVal = Math.max(...monthlyData);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="velora-card p-6 animate-pulse">
              <div className="h-4 bg-[#1a1a2e] rounded w-24 mb-4" />
              <div className="h-8 bg-[#1a1a2e] rounded w-32" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Dashboard</h1>
        <p className="text-[#64748b] mt-1">Welcome back, Admin. Here is your overview.</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 stagger-children">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.key} className="velora-card p-6 hover-lift hover-glow">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2.5 rounded-lg bg-[#6366f1]/10">
                  <Icon size={20} className="text-[#6366f1]" />
                </div>
                <span className={`flex items-center gap-1 text-xs font-medium ${card.up ? 'text-[#10b981]' : 'text-[#ef4444]'}`}>
                  {card.up ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                  {card.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-[#e2e8f0]">
                {card.prefix}{(stats as any)[card.key]?.toLocaleString()}{card.suffix}
              </p>
              <p className="text-sm text-[#64748b] mt-1">{card.label}</p>
            </div>
          );
        })}
      </div>

      {/* Revenue Chart Placeholder */}
      <div className="velora-card p-6 animate-fade-in-up">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-[#e2e8f0]">Revenue Overview</h3>
            <p className="text-sm text-[#64748b]">Monthly revenue for the past year (in ₹K)</p>
          </div>
          <div className="flex gap-2">
            {['1M', '3M', '6M', '1Y'].map((f) => (
              <button key={f} className={`px-3 py-1 text-xs rounded-lg transition-colors ${f === '1Y' ? 'bg-[#6366f1]/10 text-[#6366f1]' : 'text-[#64748b] hover:text-[#e2e8f0]'}`}>
                {f}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-end gap-3 h-48">
          {monthlyData.map((val, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-2">
              <span className="text-xs text-[#64748b]">₹{val}K</span>
              <div
                className="w-full rounded-t-md bg-gradient-to-t from-[#6366f1] to-[#8b5cf6] hover:from-[#818cf8] hover:to-[#a855f7] transition-all duration-500 hover:shadow-lg hover:shadow-[#6366f1]/20 cursor-pointer"
                style={{ height: `${(val / maxVal) * 140}px`, animation: `fadeInUp 0.5s ease-out ${i * 0.05}s both` }}
              />
              <span className="text-xs text-[#64748b]">{['J','F','M','A','M','J','J','A','S','O','N','D'][i]}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Orders */}
      <div className="velora-card p-6 animate-fade-in-up">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-[#e2e8f0]">Recent Orders</h3>
          <Link href="/admin/orders" className="velora-link text-sm">View All</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Order #</th>
                <th>Client</th>
                <th>Product</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td className="font-mono text-sm text-[#6366f1]">{order.id}</td>
                  <td className="text-[#e2e8f0]">{order.client}</td>
                  <td className="text-[#64748b]">{order.product}</td>
                  <td className="text-[#e2e8f0]">₹{order.amount.toLocaleString()}</td>
                  <td><span className={statusColor(order.status)}>{order.status}</span></td>
                  <td className="text-[#64748b]">{order.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 stagger-children">
        <Link
          href="/admin/products/create"
          className="velora-card p-5 flex items-center gap-4 hover:border-[#6366f1]/50 transition-all group hover-lift hover-glow"
        >
          <div className="p-3 rounded-lg bg-[#6366f1]/10 group-hover:bg-[#6366f1]/20 group-hover:scale-110 transition-all">
            <Plus size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <p className="font-medium text-[#e2e8f0]">Create Product</p>
            <p className="text-sm text-[#64748b]">Add a new product or service</p>
          </div>
        </Link>
        <Link
          href="/admin/clients"
          className="velora-card p-5 flex items-center gap-4 hover:border-[#6366f1]/50 transition-all group"
        >
          <div className="p-3 rounded-lg bg-[#10b981]/10 group-hover:bg-[#10b981]/20 transition-colors">
            <Users size={20} className="text-[#10b981]" />
          </div>
          <div>
            <p className="font-medium text-[#e2e8f0]">View All Clients</p>
            <p className="text-sm text-[#64748b]">Manage your client base</p>
          </div>
        </Link>
        <Link
          href="/admin/tickets"
          className="velora-card p-5 flex items-center gap-4 hover:border-[#6366f1]/50 transition-all group"
        >
          <div className="p-3 rounded-lg bg-[#f59e0b]/10 group-hover:bg-[#f59e0b]/20 transition-colors">
            <ShoppingCart size={20} className="text-[#f59e0b]" />
          </div>
          <div>
            <p className="font-medium text-[#e2e8f0]">Manage Tickets</p>
            <p className="text-sm text-[#64748b]">Respond to support requests</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
