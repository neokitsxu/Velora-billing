{{-- Syntro theme editor — embedded into Blueprint's admin layout --}}
<div class="sy-editor-shell">
<style>
        @font-face { font-family: 'Monocraft'; src: url('/extensions/syntro/fonts/Monocraft.ttf') format('truetype'); font-weight: 400; font-display: swap; }
        @font-face { font-family: 'Monocraft'; src: url('/extensions/syntro/fonts/Monocraft-Bold.ttf') format('truetype'); font-weight: 700; font-display: swap; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --p: #f97316; --sec: #a78bfa; --acc: #fbbf24;
            --bg: #0d0a18; --surf: #141021; --surf2: #1a1429; --bord: #2c2344;
            --txt: #f3eefe; --mut: #9b93b5; --ok: #34d399; --err: #f87171;
        }
        .sy-editor-shell {
            font-family: 'Monocraft', ui-monospace, monospace;
            background:
                linear-gradient(180deg, rgba(13,10,24,0.72), rgba(13,10,24,0.86)),
                url('/extensions/syntro/img/bg.jpg') center / cover fixed no-repeat, var(--bg);
            color: var(--txt); font-size: 13px; line-height: 1.65; min-height: 100vh;
            border-radius: 12px; overflow: hidden;
        }
        a { color: #f0a868; }
        ::selection { background: rgba(249,115,22,.45); }
        ::-webkit-scrollbar { width: 10px; height: 10px; }
        ::-webkit-scrollbar-track { background: rgba(10,8,20,.8); }
        ::-webkit-scrollbar-thumb { background: #322a4c; border-radius: 6px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--p); }

        .sy-editor-shell { display: flex; flex-direction: column; min-height: 100vh; }
        .sy-editor-head {
            display: flex; align-items: center; gap: 14px; flex-wrap: wrap;
            padding: 14px 22px; border-bottom: 1px solid var(--bord);
            background: rgba(20,16,33,.9); backdrop-filter: blur(10px);
            position: sticky; top: 0; z-index: 50;
        }
        .sy-editor-head img { height: 38px; image-rendering: pixelated; filter: drop-shadow(0 0 10px rgba(249,115,22,.5)); }
        .sy-editor-head h1 { font-size: 16px; letter-spacing: 1px; }
        .sy-editor-head h1 small { color: var(--mut); font-size: 10px; display: block; letter-spacing: 2px; }
        .sy-editor-head .spacer { flex: 1; }
        .sy-btn {
            font-family: inherit; font-size: 12px; font-weight: 700; letter-spacing: 1px;
            padding: 10px 18px; border-radius: 6px; border: 1px solid var(--bord);
            background: rgba(50,42,76,.6); color: var(--txt); cursor: pointer;
            transition: transform .15s ease, filter .15s ease;
        }
        .sy-btn:hover { transform: translateY(-2px); filter: brightness(1.15); }
        .sy-btn.primary { background: linear-gradient(120deg, var(--p), var(--acc)); color: #140b02; border: none; }
        .sy-btn.small { padding: 7px 12px; font-size: 11px; }
        .sy-dirty { width: 9px; height: 9px; border-radius: 50%; background: var(--acc); display: inline-block; margin-left: 8px; box-shadow: 0 0 8px var(--acc); opacity: 0; transition: opacity .2s; }
        .sy-dirty.on { opacity: 1; animation: blink 1.2s steps(2) infinite; }
        @keyframes blink { 50% { opacity: .25; } }

        .sy-editor-body { display: flex; flex: 1; min-height: 0; }
        .sy-editor-nav {
            width: 230px; flex: none; padding: 18px 12px; border-right: 1px solid var(--bord);
            background: rgba(16,12,32,.82); backdrop-filter: blur(8px);
        }
        .sy-editor-nav button {
            display: flex; align-items: center; gap: 10px; width: 100%; text-align: left;
            background: transparent; border: none; color: var(--mut); font-family: inherit;
            font-size: 12px; padding: 10px 12px; border-radius: 8px; cursor: pointer;
            border-left: 3px solid transparent; transition: all .16s ease;
        }
        .sy-editor-nav button:hover { color: var(--txt); background: rgba(249,115,22,.07); transform: translateX(3px); }
        .sy-editor-nav button.active { color: var(--txt); background: rgba(249,115,22,.13); border-left-color: var(--p); }
        .sy-editor-nav .sy-emoji { width: 18px; height: 18px; flex: none; }
        .sy-editor-nav .count { margin-left: auto; font-size: 9px; color: var(--mut); opacity: .7; }

        .sy-editor-main { flex: 1; padding: 22px; min-width: 0; }
        .sy-editor-search {
            width: 100%; max-width: 460px; padding: 10px 14px; margin-bottom: 18px;
            background: rgba(16,12,32,.85); border: 1px solid var(--bord); border-radius: 8px;
            color: var(--txt); font-family: inherit; font-size: 12px; outline: none;
        }
        .sy-editor-search:focus { border-color: var(--p); box-shadow: 0 0 0 3px rgba(249,115,22,.16); }

        .sy-editor-panel { display: none; max-width: 760px; }
        .sy-editor-panel.active { display: block; animation: pin .35s cubic-bezier(.22,1,.36,1); }
        @keyframes pin { from { opacity: 0; transform: translateY(8px); } }
        .sy-editor-panel h2 { font-size: 15px; display: flex; align-items: center; gap: 10px; margin-bottom: 4px; }
        .sy-editor-panel h2 .sy-emoji { width: 22px; height: 22px; }
        .sy-editor-panel .desc { color: var(--mut); font-size: 11px; margin-bottom: 16px; }

        .sy-field { margin-bottom: 16px; padding: 13px 15px; border: 1px solid var(--bord); border-radius: 10px; background: rgba(20,16,33,.85); }
        .sy-field.hidden { display: none; }
        .sy-field label { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--txt); margin-bottom: 6px; font-weight: 700; }
        .sy-field .hint { font-size: 10px; color: var(--mut); margin-top: 6px; line-height: 1.55; }
        .sy-field input[type=text], .sy-field input[type=number], .sy-field input[type=password], .sy-field textarea, .sy-field select {
            width: 100%; background: rgba(16,12,32,.85); border: 1px solid var(--bord); border-radius: 6px;
            color: var(--txt); font-family: inherit; font-size: 12px; padding: 9px 11px; outline: none;
        }
        .sy-field textarea { min-height: 84px; resize: vertical; line-height: 1.6; }
        .sy-field input:focus, .sy-field textarea:focus, .sy-field select:focus { border-color: var(--p); box-shadow: 0 0 0 3px rgba(249,115,22,.15); }
        .sy-field .row { display: flex; gap: 10px; align-items: center; }
        .sy-field input[type=color] { width: 46px; height: 34px; border: 1px solid var(--bord); border-radius: 6px; background: rgba(16,12,32,.85); padding: 2px; cursor: pointer; }
        .sy-field input[type=range] { flex: 1; accent-color: var(--p); }
        .sy-field .val { min-width: 92px; text-align: right; font-size: 11px; color: var(--mut); }
        .sy-switch { position: relative; width: 44px; height: 24px; flex: none; cursor: pointer; }
        .sy-switch input { opacity: 0; width: 0; height: 0; }
        .sy-switch .track { position: absolute; inset: 0; background: #322a4c; border-radius: 24px; transition: .18s; }
        .sy-switch .track::after { content: ''; position: absolute; top: 3px; left: 3px; width: 18px; height: 18px; border-radius: 50%; background: var(--mut); transition: .18s; }
        .sy-switch input:checked + .track { background: linear-gradient(120deg, var(--p), var(--acc)); }
        .sy-switch input:checked + .track::after { left: 23px; background: #140b02; }

        .sy-moji-grid { display: flex; flex-wrap: wrap; gap: 14px; }
        .sy-moji-cell { text-align: center; padding: 10px; border: 1px solid var(--bord); border-radius: 10px; background: rgba(16,12,32,.85); width: 92px; }
        .sy-moji-cell .sy-emoji { width: 34px; height: 34px; margin: 0 auto 6px; }
        .sy-moji-cell span { font-size: 9px; color: var(--mut); }

        /* preview widgets */
        .sy-cta { display: flex; align-items: center; gap: 14px; padding: 14px 16px; border: 1px solid var(--bord); }
        .sy-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .sy-stat { padding: 12px 14px; border: 1px solid var(--bord); }
        .sy-emoji { display: inline-block; width: 20px; height: 20px; vertical-align: -0.25em; line-height: 1; }
        .sy-emoji svg { width: 100%; height: 100%; display: block; }
        .sy-gradient-text {
            background: linear-gradient(120deg, var(--p), var(--acc), var(--sec));
            background-size: 220% 220%;
            -webkit-background-clip: text; background-clip: text; color: transparent;
            animation: grad 6s ease infinite;
        }
        @keyframes grad { 0%,100% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } }
        .sy-e-pulse { animation: ePulse 1.6s ease-in-out infinite; }
        .sy-e-shake { animation: eShake .9s ease-in-out infinite; }
        .sy-e-blink { animation: eBlink 1.5s steps(2, jump-none) infinite; }
        .sy-e-spin { animation: eSpin 3.2s linear infinite; }
        .sy-e-twinkle { animation: eTwinkle 1.8s ease-in-out infinite; }
        .sy-e-bob { animation: eBob 2.4s ease-in-out infinite; }
        .sy-e-beat { animation: eBeat 1.1s ease-in-out infinite; }
        .sy-e-flip { animation: eFlip 2.2s ease-in-out infinite; }
        .sy-e-flicker { animation: eFlicker 1.3s steps(3, jump-none) infinite; }
        .sy-e-flash { animation: eFlash 1.4s steps(2, jump-none) infinite; }
        .sy-e-launch { animation: eLaunch 2s ease-in-out infinite; }
        .sy-e-bounceface { animation: eBob 2.4s ease-in-out infinite; }
        .sy-e-blinkface { animation: eBlinkface 3.4s ease-in-out infinite; }
        @keyframes ePulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.18); } }
        @keyframes eShake { 0%,100% { transform: rotate(0); } 25% { transform: rotate(-11deg); } 75% { transform: rotate(11deg); } }
        @keyframes eBlink { 0%,60%,100% { opacity: 1; } 30% { opacity: .25; } }
        @keyframes eSpin { to { transform: rotate(360deg); } }
        @keyframes eTwinkle { 0%,100% { transform: scale(1) rotate(0); } 50% { transform: scale(.78) rotate(24deg); } }
        @keyframes eBob { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
        @keyframes eBeat { 0%,100% { transform: scale(1); } 22% { transform: scale(1.28); } 40% { transform: scale(1); } 60% { transform: scale(1.16); } }
        @keyframes eFlip { 0%,100% { transform: rotateY(0); } 50% { transform: rotateY(180deg); } }
        @keyframes eFlicker { 0% { transform: scale(1); filter: brightness(1); } 33% { transform: scale(1.06); filter: brightness(1.25); } 66% { transform: scale(.97); filter: brightness(.85); } }
        @keyframes eFlash { 0%,55%,100% { filter: brightness(1); opacity: 1; } 28% { filter: brightness(1.6); opacity: .85; } }
        @keyframes eLaunch { 0%,100% { transform: translateY(0) rotate(-4deg); } 50% { transform: translateY(-5px) rotate(4deg); } }
        @keyframes eBlinkface { 0%,88%,100% { transform: scaleY(1); } 92%,96% { transform: scaleY(.08); } }

        .sy-preview-rail { width: 320px; flex: none; padding: 22px 22px 22px 0; }
        .sy-preview-sticky { position: sticky; top: 86px; }
        .sy-preview { border: 1px solid var(--bord); border-radius: 14px; overflow: hidden; background: rgba(13,10,24,.9); }
        .sy-preview .bar { padding: 8px 12px; font-size: 9px; letter-spacing: 2px; color: var(--mut); border-bottom: 1px solid var(--bord); background: rgba(20,16,33,.9); }
        .sy-preview .inner { padding: 16px; }

        .sy-toast {
            position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%) translateY(80px);
            padding: 12px 22px; border-radius: 10px; font-size: 12px; z-index: 100;
            border: 1px solid var(--bord); background: rgba(20,16,33,.97); transition: transform .25s cubic-bezier(.22,1,.36,1);
        }
        .sy-toast.show { transform: translateX(-50%) translateY(0); }
        .sy-toast.ok { border-color: rgba(52,211,153,.5); color: var(--ok); }
        .sy-toast.err { border-color: rgba(248,113,113,.5); color: var(--err); }

        @media (max-width: 980px) { .sy-preview-rail { display: none; } }
        @media (max-width: 720px) { .sy-editor-nav { width: 64px; } .sy-editor-nav button span.txt { display: none; } }
    </style>
    <header class="sy-editor-head">
        <img src="/extensions/syntro/img/logo-mark.png" alt="Syntro"/>
        <h1>
            SYNTRO THEME — EDITOR
            <small>SYNTRO THEME V1.0.0 • BY NEOKITSXU_ • SPECTROCLOUD</small>
        </h1>
        <span class="spacer"></span>
        <a class="sy-btn small" href="/admin" style="text-decoration:none">← ADMIN</a>
        <button class="sy-btn" id="sy-reset">RESET ALL</button>
        <button class="sy-btn primary" id="sy-save">SAVE CHANGES<span class="sy-dirty" id="sy-dirty"></span></button>
    </header>

    <div class="sy-editor-body">
        <nav class="sy-editor-nav" id="sy-nav"></nav>

        <main class="sy-editor-main">
            <input class="sy-editor-search" id="sy-search" type="text" placeholder="Search 120+ options..."/>
            <div id="sy-panels"></div>
        </main>

        <aside class="sy-preview-rail">
            <div class="sy-preview-sticky">
                <div class="sy-preview">
                    <div class="bar">LIVE PREVIEW</div>
                    <div class="inner" id="sy-preview"></div>
                </div>
            </div>
        </aside>
    </div>
</div>

<div class="sy-toast" id="sy-toast"></div>

<script>
    var SYNTRO_SAVED = @json($settings);
    var SYNTRO_HAS_PTLA = @json($has_ptla);
    var DEFAULTS = /* __SYNTRO_DEFAULTS__ */ {"brand": {"name": "SpectroCloud", "tagline": "Best Minecraft Server Hosting", "footer_text": "Branding made by Neokitsxu_ • SpectroCloud — Best Minecraft Server Hosting", "website_url": "", "logo_url": "/extensions/syntro/img/logo.png", "logo_mark_url": "/extensions/syntro/img/logo-mark.png", "logo_height": 34, "show_logo_in_nav": "true"}, "seo": {"title_suffix": "SpectroCloud", "title_mode": "append", "favicon_url": "/extensions/syntro/img/favicon.png", "theme_color": "#f97316", "meta_description": "SpectroCloud — Best Minecraft Server Hosting. Powered by Syntro theme.", "og_image": ""}, "background": {"enabled": "true", "url": "/extensions/syntro/img/bg.jpg", "overlay": "72", "blur": "0", "vignette": "true", "fixed": "true", "scanlines": "true", "scanline_opacity": "4"}, "colors": {"primary": "#f97316", "secondary": "#a78bfa", "accent": "#fbbf24", "surface": "#141021", "surface_opacity": "88", "surface_border": "#2c2344", "text": "#f3eefe", "text_muted": "#9b93b5", "success": "#34d399", "warning": "#fbbf24", "danger": "#f87171", "info": "#38bdf8", "link": "#f0a868", "bg_tint": "#0d0a18"}, "typography": {"font": "Monocraft", "body_size": 14, "heading_size": 20, "letter_spacing": "0.5", "line_height": "1.7", "text_glow": "true", "glow_color": "rgba(249,115,22,0.35)", "uppercase_headings": "true", "heading_weight": "700"}, "corners": {"radius": 8, "radius_btn": 6, "radius_input": 6, "radius_card": 12, "container_width": 1200}, "effects": {"glass_blur": 10, "glow_strength": 30, "shadow_strength": 60, "gradient_enabled": "true", "animated_gradient": "true", "border_glow": "true", "noise": "false", "hover_lift": "true", "focus_glow": "true", "image_rendering": "pixelated"}, "animations": {"enabled": "true", "page_entrance": "true", "letters_enabled": "true", "letters_speed": "480", "letters_stagger": "28", "hover_anims": "true", "button_pulse": "false", "sidebar_anims": "true", "card_entrance": "true"}, "emoji": {"enabled": "true", "size": 20, "style": "pixel", "idle_anim": "true", "map_check": "true", "map_warn": "true", "map_faces": "true", "map_misc": "true"}, "servericons": {"enabled": "true", "style": "glow", "size": 34, "default_icon": "egg", "animation": "bob", "show_in_list": "true"}, "console": {"ufo_enabled": "true", "ufo_count": 3, "ufo_speed": "normal", "aliens": "true", "alien_count": 2, "stars": "true", "star_density": "40", "beam": "true", "pause_hidden": "true", "mini_ufo_dashboard": "true", "mini_ufo_admin": "true", "mini_ufo_auth": "true"}, "authpages": {"logo": "true", "welcome_title": "WELCOME BACK", "welcome_text": "Log in to manage your servers", "card_glass": "true", "gradient_border": "true", "blur_bg": "true", "anims": "true"}, "createserver": {"enabled": "true", "admin_quick_actions": "true", "button_text": "CREATE SERVER", "page_title": "Create a new server", "page_desc": "Spin up your own server in seconds. Pick a game, choose your resources and deploy.", "max_servers": 2, "max_memory": 4096, "max_cpu": 200, "max_disk": 10240, "backups": 2, "databases": 1, "ptla_key": "", "panel_url": "", "catalog": "[{\"name\":\"Minecraft Java\",\"egg\":null,\"icon\":\"minecraft\",\"docker\":\"ghcr.io/pterodactyl/yolks:java_17\",\"startup\":\"java -Xms128M -XX:MaxRAMPercentage=95.0 -jar {{SERVER_JARFILE}}\",\"env\":{\"SERVER_JARFILE\":\"server.jar\"},\"mem\":2048,\"cpu\":100,\"disk\":4096},{\"name\":\"Minecraft Bedrock\",\"egg\":null,\"icon\":\"minecraft\",\"docker\":\"ghcr.io/pterodactyl/yolks:java_17\",\"startup\":\"./bedrock_server\",\"env\":{},\"mem\":1024,\"cpu\":100,\"disk\":2048},{\"name\":\"Discord Bot (Node.js)\",\"egg\":null,\"icon\":\"discordbot\",\"docker\":\"ghcr.io/pterodactyl/yolks:nodejs_20\",\"startup\":\"if [[ -f package.json ]]; then npm install --omit=dev; fi; if [[ ! -z ${JS_FILE} ]]; then node /app/home/${JS_FILE}; else node index.js; fi\",\"env\":{},\"mem\":512,\"cpu\":50,\"disk\":1024}]"}, "layout": {"sidebar_style": "glass", "sidebar_compact": "false", "topbar_blur": "true", "footer": "true", "footer_pos": "fixed", "stats_cards": "true", "container_padding": 24, "server_sidebar": "true", "sidebar_ext_category": "MINECRAFT"}, "advanced": {"custom_css": "", "admin_emoji": "true", "debug": "false", "uninstall_note": "Removing this extension also removes the theme automatically."}} /* __SYNTRO_DEFAULTS_END__ */;
    var SPRITES = /* __SYNTRO_EMOJI__ */ {"check": {"grid": ["........", "......gg", ".....ggg", "g...ggg.", "gg.ggg..", "ggggg...", ".ggg....", "..g....."], "palette": {"g": "#34d399"}, "anim": "pulse"}, "cross": {"grid": ["rr....rr", ".rr..rr.", "..rrrr..", "...rr...", "..rrrr..", ".rr..rr.", "rr....rr", "........"], "palette": {"r": "#f87171"}, "anim": "shake"}, "warn": {"grid": ["...yy...", "...yy...", "..yyyy..", "..yywy..", ".yyyywy.", ".yywwyy.", "yyyyyyyy", "yyyyyyyy"], "palette": {"y": "#fbbf24", "w": "#141021"}, "anim": "blink"}, "info": {"grid": ["..cccc..", "..cccc..", "....cc..", "....cc..", "....cc..", "....cc..", "..cccc..", "..cccc.."], "palette": {"c": "#38bdf8"}, "anim": "spin"}, "spark": {"grid": ["...ss...", "...ss...", ".ssssss.", "ss.ss.ss", "..ssss..", "...ss...", "...ss...", "........"], "palette": {"s": "#fbbf24"}, "anim": "twinkle"}, "card": {"grid": ["cccccccc", "c......c", "mmmmmmmc", "c......c", "c..cc..c", "c......c", "cccccccc", "........"], "palette": {"c": "#a78bfa", "m": "#fbbf24"}, "anim": "bob"}, "face": {"grid": ["..ffff..", ".ffffff.", "ffffffff", "f.ffff.f", "ffffffff", "ff....ff", ".ffffff.", "..ffff.."], "palette": {"f": "#f3eefe"}, "anim": "blinkface"}, "happy": {"grid": ["..ffff..", ".ffffff.", "f.ffff.f", "ffffffff", "f.ffff.f", "ff.ww.ff", ".ffffff.", "..ffff.."], "palette": {"f": "#f3eefe", "w": "#f3eefe"}, "anim": "bounceface"}, "sad": {"grid": ["..ffff..", ".ffffff.", "f.ffff.f", "ffffffff", "ffffffff", "f.wwww.f", "ffffffff", "..ffff.."], "palette": {"f": "#9b93b5", "w": "#141021"}, "anim": "bounceface"}, "rocket": {"grid": ["...ww...", "..wwww..", "..woow..", "..woow..", "..wwww..", ".ww..ww.", ".f....f.", "..f..f.."], "palette": {"w": "#e8ecf5", "o": "#f97316", "f": "#fbbf24"}, "anim": "launch"}, "gear": {"grid": [".g..g..g", ".gggggg.", "..gggg..", "gg.gg.gg", "gg.gg.gg", "..gggg..", ".gggggg.", ".g..g..g"], "palette": {"g": "#9b93b5"}, "anim": "spin"}, "heart": {"grid": [".rr..rr.", "rrrrrrrr", "rrrrrrrr", "rrrrrrrr", ".rrrrrr.", "..rrrr..", "...rr...", "........"], "palette": {"r": "#f472b6"}, "anim": "beat"}, "coin": {"grid": ["..yyyy..", ".yyyyyy.", "yyoyyoyy", "yyyyyyyy", "yyoyyoyy", "yyyyyyyy", ".yyyyyy.", "..yyyy.."], "palette": {"y": "#fbbf24", "o": "#b78103"}, "anim": "flip"}, "fire": {"grid": ["....o...", "...oo...", "..ooo.y.", "..ooooo.", ".ooyoooy", ".oyyyyo.", "o.oooo.o", "...oo..."], "palette": {"o": "#f97316", "y": "#fbbf24"}, "anim": "flicker"}, "zap": {"grid": ["....yy..", "...yy...", "..yyyy..", "....yy..", "...yy...", "..yy....", ".yy.....", "y......."], "palette": {"y": "#fde047"}, "anim": "flash"}, "star": {"grid": ["...s....", "...s....", "ssssssss", ".ssssss.", "..ssss..", ".ss..ss.", "........", "........"], "palette": {"s": "#fde047"}, "anim": "twinkle"}, "cube": {"grid": ["..ssss..", ".s....s.", "s..ss..s", "s..ss..s", "s..ss..s", "s..ss..s", ".s....s.", "..ssss.."], "palette": {"s": "#a78bfa"}, "anim": "spin"}, "shield": {"grid": [".cccccc.", "cccccccc", "cccccccc", "cc.cc.cc", "cccccccc", ".cccccc.", "..cccc..", "....cc.."], "palette": {"c": "#38bdf8"}, "anim": "pulse"}} /* __SYNTRO_EMOJI_END__ */;
    var SCHEMA = /* __SYNTRO_SCHEMA__ */ [{"section": "brand", "title": "Branding", "desc": "Your hosting brand: name, tagline, footer text and logos.", "icon": "star", "anim": "bob", "fields": [{"key": "name", "label": "Brand name", "type": "text"}, {"key": "tagline", "label": "Tagline", "type": "text"}, {"key": "footer_text", "label": "Footer text", "type": "textarea", "hint": "Shown in the bottom bar of every page."}, {"key": "website_url", "label": "Website URL", "type": "text"}, {"key": "logo_url", "label": "Logo (horizontal) URL", "type": "text"}, {"key": "logo_mark_url", "label": "Logo (square mark) URL", "type": "text"}, {"key": "logo_height", "label": "Nav logo height", "type": "range", "min": 20, "max": 64, "step": 2, "unit": "px"}, {"key": "show_logo_in_nav", "label": "Show logo in navigation", "type": "toggle"}]}, {"section": "seo", "title": "SEO & Browser", "desc": "Browser tab title, favicon and social preview.", "icon": "zap", "anim": "flash", "fields": [{"key": "title_suffix", "label": "Title suffix", "type": "text", "hint": "Shown in the browser tab next to the page name."}, {"key": "title_mode", "label": "Title mode", "type": "select", "options": [["append", "Append — \"Panel | Suffix\""], ["prefix", "Prefix — \"Suffix | Panel\""], ["replace", "Replace"]]}, {"key": "favicon_url", "label": "Favicon URL", "type": "text"}, {"key": "theme_color", "label": "Browser theme color", "type": "color"}, {"key": "meta_description", "label": "Meta description", "type": "textarea"}, {"key": "og_image", "label": "OG image URL", "type": "text"}]}, {"section": "background", "title": "Background", "desc": "The page background image — applied to every page.", "icon": "fire", "anim": "flicker", "fields": [{"key": "url", "label": "Background image URL", "type": "text", "hint": "Default: the bundled SpectroCloud artwork. Paste any image URL to override it."}, {"key": "overlay", "label": "Dark overlay", "type": "range", "min": 0, "max": 95, "step": 1, "unit": "%"}, {"key": "blur", "label": "Background blur", "type": "range", "min": 0, "max": 20, "step": 1, "unit": "px"}, {"key": "scanline_opacity", "label": "Scanline opacity", "type": "range", "min": 0, "max": 15, "step": 1, "unit": "%"}, {"key": "enabled", "label": "Enable background image", "type": "toggle"}, {"key": "vignette", "label": "Vignette edges", "type": "toggle"}, {"key": "fixed", "label": "Fixed (parallax) background", "type": "toggle"}, {"key": "scanlines", "label": "CRT scanlines", "type": "toggle"}]}, {"section": "colors", "title": "Colors", "desc": "The full Syntro palette.", "icon": "heart", "anim": "beat", "fields": [{"key": "primary", "label": "Primary", "type": "color"}, {"key": "secondary", "label": "Secondary", "type": "color"}, {"key": "accent", "label": "Accent", "type": "color"}, {"key": "surface", "label": "Surface", "type": "color"}, {"key": "surface_opacity", "label": "Surface Opacity", "type": "range", "min": 40, "max": 100, "step": 1, "unit": "%"}, {"key": "surface_border", "label": "Surface Border", "type": "color"}, {"key": "text", "label": "Text", "type": "color"}, {"key": "text_muted", "label": "Text Muted", "type": "color"}, {"key": "success", "label": "Success", "type": "color"}, {"key": "warning", "label": "Warning", "type": "color"}, {"key": "danger", "label": "Danger", "type": "color"}, {"key": "info", "label": "Info", "type": "color"}, {"key": "link", "label": "Link", "type": "color"}, {"key": "bg_tint", "label": "Bg Tint", "type": "color"}]}, {"section": "typography", "title": "Typography", "desc": "Pixel font, sizes, spacing and glow.", "icon": "info", "anim": "spin", "fields": [{"key": "font", "label": "Pixel font", "type": "text"}, {"key": "body_size", "label": "Body Size", "type": "range", "min": 11, "max": 18, "step": 1, "unit": "px"}, {"key": "heading_size", "label": "Heading Size", "type": "range", "min": 14, "max": 32, "step": 1, "unit": "px"}, {"key": "letter_spacing", "label": "Letter Spacing", "type": "range", "min": 0, "max": 3, "step": 0.1, "unit": "px"}, {"key": "line_height", "label": "Line Height", "type": "range", "min": 1.3, "max": 2.2, "step": 0.05, "unit": ""}, {"key": "glow_color", "label": "Glow color", "type": "text"}, {"key": "heading_weight", "label": "Heading weight", "type": "select", "options": [["400", "Regular"], ["700", "Bold"]]}, {"key": "text_glow", "label": "Heading glow", "type": "toggle"}, {"key": "uppercase_headings", "label": "Uppercase headings", "type": "toggle"}]}, {"section": "corners", "title": "Corners & Layout Width", "desc": "Border radii and content width.", "icon": "gear", "anim": "spin", "fields": [{"key": "radius", "label": "Radius", "type": "range", "min": 0, "max": 24, "step": 1, "unit": "px"}, {"key": "radius_btn", "label": "Radius Btn", "type": "range", "min": 0, "max": 24, "step": 1, "unit": "px"}, {"key": "radius_input", "label": "Radius Input", "type": "range", "min": 0, "max": 24, "step": 1, "unit": "px"}, {"key": "radius_card", "label": "Radius Card", "type": "range", "min": 0, "max": 28, "step": 1, "unit": "px"}, {"key": "container_width", "label": "Container Width", "type": "range", "min": 900, "max": 1600, "step": 50, "unit": "px"}]}, {"section": "effects", "title": "Effects", "desc": "Glass, glow, shadows and gradients.", "icon": "spark", "anim": "twinkle", "fields": [{"key": "glass_blur", "label": "Glass Blur", "type": "range", "min": 0, "max": 30, "step": 1, "unit": "px"}, {"key": "glow_strength", "label": "Glow Strength", "type": "range", "min": 0, "max": 100, "step": 1, "unit": "%"}, {"key": "shadow_strength", "label": "Shadow Strength", "type": "range", "min": 0, "max": 100, "step": 1, "unit": "%"}, {"key": "image_rendering", "label": "Image rendering", "type": "select", "options": [["pixelated", "Pixelated"], ["auto", "Smooth"]]}, {"key": "gradient_enabled", "label": "Gradient Enabled", "type": "toggle"}, {"key": "animated_gradient", "label": "Animated Gradient", "type": "toggle"}, {"key": "border_glow", "label": "Border Glow", "type": "toggle"}, {"key": "noise", "label": "Noise", "type": "toggle"}, {"key": "hover_lift", "label": "Hover Lift", "type": "toggle"}, {"key": "focus_glow", "label": "Focus Glow", "type": "toggle"}]}, {"section": "animations", "title": "Animations", "desc": "Global motion controls — all GPU friendly.", "icon": "rocket", "anim": "launch", "fields": [{"key": "letters_speed", "label": "Letters Speed", "type": "range", "min": 100, "max": 1500, "step": 20, "unit": "ms"}, {"key": "letters_stagger", "label": "Letters Stagger", "type": "range", "min": 0, "max": 120, "step": 2, "unit": "ms"}, {"key": "enabled", "label": "Enabled", "type": "toggle"}, {"key": "page_entrance", "label": "Page Entrance", "type": "toggle"}, {"key": "letters_enabled", "label": "Letters Enabled", "type": "toggle"}, {"key": "hover_anims", "label": "Hover Anims", "type": "toggle"}, {"key": "button_pulse", "label": "Button Pulse", "type": "toggle"}, {"key": "sidebar_anims", "label": "Sidebar Anims", "type": "toggle"}, {"key": "card_entrance", "label": "Card Entrance", "type": "toggle"}]}, {"section": "emoji", "title": "SyntroMoji", "desc": "Custom animated pixel emojis replace Unicode emojis panel-wide.", "icon": "happy", "anim": "bounceface", "fields": [{"key": "size", "label": "Size", "type": "range", "min": 14, "max": 36, "step": 1, "unit": "px"}, {"key": "style", "label": "Style", "type": "text"}, {"key": "enabled", "label": "Enabled", "type": "toggle", "hint": "Replaces Unicode emojis (like check marks and faces) with animated SyntroMoji sprites."}, {"key": "idle_anim", "label": "Idle Anim", "type": "toggle"}, {"key": "map_check", "label": "Map Check", "type": "toggle"}, {"key": "map_warn", "label": "Map Warn", "type": "toggle"}, {"key": "map_faces", "label": "Map Faces", "type": "toggle"}, {"key": "map_misc", "label": "Map Misc", "type": "toggle"}]}, {"section": "servericons", "title": "Server Icons", "desc": "Auto pixel icons matched to each server’s egg.", "icon": "cube", "anim": "spin", "fields": [{"key": "style", "label": "Style", "type": "select", "options": [["flat", "Flat"], ["glow", "Glow"], ["pixel", "Pixel (scaled up)"]]}, {"key": "size", "label": "Size", "type": "range", "min": 20, "max": 60, "step": 1, "unit": "px"}, {"key": "default_icon", "label": "Default Icon", "type": "select", "options": [["egg", "egg"], ["minecraft", "minecraft"], ["paper", "paper"], ["fabric", "fabric"], ["forge", "forge"], ["proxy", "proxy"], ["nodejs", "nodejs"], ["python", "python"], ["discordbot", "discordbot"], ["rust", "rust"], ["source", "source"], ["terraria", "terraria"], ["valheim", "valheim"], ["ark", "ark"], ["database", "database"], ["generic", "generic"]]}, {"key": "animation", "label": "Animation", "type": "select", "options": [["none", "None"], ["bob", "Bob"], ["spin", "Spin"]]}, {"key": "enabled", "label": "Enabled", "type": "toggle"}, {"key": "show_in_list", "label": "Show In List", "type": "toggle"}]}, {"section": "console", "title": "Console FX", "desc": "UFOs, aliens and stars — console, dashboard, admin panel and auth pages.", "icon": "zap", "anim": "flash", "fields": [{"key": "ufo_count", "label": "UFO count", "type": "range", "min": 1, "max": 6, "step": 1, "unit": "", "hint": "How many UFOs fly over the console. Keep it low for slower machines."}, {"key": "ufo_speed", "label": "UFO speed", "type": "select", "options": [["slow", "Slow"], ["normal", "Normal"], ["fast", "Fast"]]}, {"key": "alien_count", "label": "Alien count", "type": "range", "min": 1, "max": 5, "step": 1, "unit": ""}, {"key": "star_density", "label": "Star density", "type": "range", "min": 0, "max": 100, "step": 5, "unit": "%"}, {"key": "ufo_enabled", "label": "UFOs & aliens", "type": "toggle"}, {"key": "aliens", "label": "Walking aliens", "type": "toggle"}, {"key": "stars", "label": "Twinkling stars", "type": "toggle"}, {"key": "beam", "label": "UFO tractor beams", "type": "toggle"}, {"key": "pause_hidden", "label": "Pause when tab hidden", "type": "toggle"}, {"key": "mini_ufo_dashboard", "label": "Mini UFOs on client dashboard", "type": "toggle", "hint": "Small, subtle UFOs flying over the client area dashboard."}, {"key": "mini_ufo_admin", "label": "Mini UFOs in admin panel", "type": "toggle", "hint": "Small UFOs across the admin panel pages."}, {"key": "mini_ufo_auth", "label": "Mini UFOs on auth pages", "type": "toggle", "hint": "Small UFOs on the login and register pages."}]}, {"section": "authpages", "title": "Login & Register", "desc": "The authentication page makeover.", "icon": "shield", "anim": "pulse", "fields": [{"key": "welcome_title", "label": "Welcome Title", "type": "text"}, {"key": "welcome_text", "label": "Welcome Text", "type": "text"}, {"key": "logo", "label": "Logo", "type": "toggle"}, {"key": "card_glass", "label": "Card Glass", "type": "toggle"}, {"key": "gradient_border", "label": "Gradient Border", "type": "toggle"}, {"key": "blur_bg", "label": "Blur Bg", "type": "toggle"}, {"key": "anims", "label": "Anims", "type": "toggle"}]}, {"section": "createserver", "title": "Create Server (Admin)", "desc": "Admin panel quick actions: create servers and open the console dashboard. Client areas stay clean, Nebula-style.", "icon": "rocket", "anim": "launch", "fields": [{"key": "button_text", "label": "Button text", "type": "text"}, {"key": "page_title", "label": "Page title", "type": "text"}, {"key": "page_desc", "label": "Page description", "type": "textarea"}, {"key": "max_servers", "label": "Max servers per user", "type": "range", "min": 1, "max": 10, "step": 1, "unit": ""}, {"key": "max_memory", "label": "Max memory per server", "type": "range", "min": 512, "max": 65536, "step": 256, "unit": " MB"}, {"key": "max_cpu", "label": "Max CPU per server", "type": "range", "min": 25, "max": 800, "step": 25, "unit": "%"}, {"key": "max_disk", "label": "Max disk per server", "type": "range", "min": 1024, "max": 102400, "step": 1024, "unit": " MB"}, {"key": "backups", "label": "Backup slots", "type": "range", "min": 0, "max": 10, "step": 1, "unit": ""}, {"key": "databases", "label": "Database slots", "type": "range", "min": 0, "max": 10, "step": 1, "unit": ""}, {"key": "ptla_key", "label": "Application API key", "type": "password", "hint": "Create a key in Admin Area -> Application API (read+write for Servers, Nodes, Locations). Stored server-side only, never sent to users."}, {"key": "panel_url", "label": "Panel URL", "type": "text", "hint": "Usually your own panel URL, e.g. https://panel.spectrocloud.gg"}, {"key": "catalog", "label": "Egg catalog (JSON)", "type": "json", "hint": "Each entry: {\"name\":\"Minecraft Java\",\"egg\":3,\"icon\":\"minecraft\",\"docker\":\"ghcr.io/pterodactyl/yolks:java_17\",\"startup\":\"java -jar server.jar\",\"env\":{},\"mem\":2048,\"cpu\":100,\"disk\":4096,\"node\":1}. Egg = egg ID (URL in Admin -> Nests); node OR location picks the deployment target."}, {"key": "enabled", "label": "Show admin Create Server card", "type": "toggle", "hint": "Nebula-style: Create Server lives ONLY in the admin panel. Shows the Create Server card on the admin dashboard."}, {"key": "admin_quick_actions", "label": "Admin dashboard quick actions", "type": "toggle", "hint": "Adds Syntro quick action cards to the admin dashboard (Create Server / Console Dashboard / Nodes)."}]}, {"section": "layout", "title": "Layout & Navigation", "desc": "Sidebar, footer, spacing and the server-page navigation sidebar.", "icon": "card", "anim": "bob", "fields": [{"key": "sidebar_style", "label": "Sidebar Style", "type": "text"}, {"key": "footer_pos", "label": "Footer position", "type": "select", "options": [["fixed", "Fixed bottom bar"], ["inline", "Inline (end of page)"]]}, {"key": "container_padding", "label": "Container Padding", "type": "range", "min": 8, "max": 48, "step": 2, "unit": "px"}, {"key": "sidebar_ext_category", "label": "Extension category name", "type": "text", "hint": "Category heading for extension tools in the server sidebar (e.g. Version Changer, Player Manager). Only shows when such extensions are installed."}, {"key": "sidebar_compact", "label": "Compact sidebar", "type": "toggle"}, {"key": "topbar_blur", "label": "Blur topbar", "type": "toggle"}, {"key": "footer", "label": "Show footer branding", "type": "toggle"}, {"key": "stats_cards", "label": "Dashboard stats cards", "type": "toggle"}, {"key": "server_sidebar", "label": "Console sidebar (server pages)", "type": "toggle", "hint": "Turns the server top-bar navigation into a sidebar: default pages first (Console, Files, Databases, Settings...), extension tools last."}]}, {"section": "advanced", "title": "Advanced", "desc": "Custom CSS and developer switches.", "icon": "gear", "anim": "spin", "fields": [{"key": "custom_css", "label": "Custom CSS", "type": "textarea"}, {"key": "uninstall_note", "label": "Uninstall Note", "type": "textarea"}, {"key": "admin_emoji", "label": "Animated emojis in admin area", "type": "toggle"}, {"key": "debug", "label": "Debug logging (console)", "type": "toggle"}]}] /* __SYNTRO_SCHEMA_END__ */;
</script>
<script>
(function () {
    'use strict';

    /* ---------------------------------------------------------- state */
    function deepMerge(base, over) {
        var out = JSON.parse(JSON.stringify(base));
        Object.keys(over || {}).forEach(function (s) {
            if (!out[s]) out[s] = {};
            Object.keys(over[s]).forEach(function (k) { out[s][k] = over[s][k]; });
        });
        return out;
    }
    var state = deepMerge(DEFAULTS, SYNTRO_SAVED);
    var dirty = false;

    function spriteSvg(name) {
        var sp = SPRITES[name];
        if (!sp) return '';
        var r = '';
        for (var y = 0; y < sp.grid.length; y++) {
            for (var x = 0; x < sp.grid[y].length; x++) {
                var ch = sp.grid[y][x];
                if (ch === '.' || ch === ' ') continue;
                var c = sp.palette[ch];
                if (!c) continue;
                r += '<rect x="' + x + '" y="' + y + '" width="1" height="1" fill="' + c + '"/>';
            }
        }
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges">' + r + '</svg>';
    }
    function emojiSpan(name, anim) {
        return '<span class="sy-emoji sy-e-' + anim + '">' + spriteSvg(name) + '</span>';
    }

    /* ---------------------------------------------------------- render */
    var nav = document.getElementById('sy-nav');
    var panels = document.getElementById('sy-panels');
    var dirtyDot = document.getElementById('sy-dirty');

    function val(section, key) {
        return (state[section] && typeof state[section][key] !== 'undefined') ? state[section][key] : '';
    }

    function fieldHtml(section, f) {
        var v = val(section, f.key);
        var id = 'f_' + section + '_' + f.key;
        var h = '<div class="sy-field" data-sec="' + section + '" data-key="' + f.key + '" data-search="' + (f.label + ' ' + f.key).toLowerCase() + '">';
        h += '<label>' + (f.icon ? emojiSpan(f.icon, 'bob') : '') + f.label + '</label>';
        if (f.type === 'toggle') {
            h += '<div class="sy-switch"><input type="checkbox" id="' + id + '"' + (String(v) === 'true' ? ' checked' : '') + ' data-sec="' + section + '" data-key="' + f.key + '"><span class="track"></span></div>';
        } else if (f.type === 'color') {
            h += '<div class="row"><input type="color" id="' + id + '" value="' + v + '" data-sec="' + section + '" data-key="' + f.key + '"><input type="text" id="' + id + '_t" value="' + v + '" data-colorsync="' + id + '"></div>';
        } else if (f.type === 'range') {
            h += '<div class="row"><input type="range" id="' + id + '" min="' + f.min + '" max="' + f.max + '" step="' + (f.step || 1) + '" value="' + v + '" data-sec="' + section + '" data-key="' + f.key + '"><span class="val" id="' + id + '_v">' + v + (f.unit || '') + '</span></div>';
        } else if (f.type === 'select') {
            h += '<select id="' + id + '" data-sec="' + section + '" data-key="' + f.key + '">';
            (f.options || []).forEach(function (o) { h += '<option value="' + o[0] + '"' + (String(v) === String(o[0]) ? ' selected' : '') + '>' + o[1] + '</option>'; });
            h += '</select>';
        } else if (f.type === 'textarea' || f.type === 'json') {
            h += '<textarea id="' + id + '" data-sec="' + section + '" data-key="' + f.key + '" data-json="' + (f.type === 'json' ? '1' : '') + '">' + escHtml(v) + '</textarea>';
        } else if (f.type === 'password') {
            h += '<input type="password" id="' + id + '" placeholder="' + (SYNTRO_HAS_PTLA ? '•••••••• (saved — leave empty to keep)' : 'ptla_...') + '" data-ptla="1">';
        } else {
            h += '<input type="text" id="' + id + '" value="' + escAttr(v) + '" data-sec="' + section + '" data-key="' + f.key + '">';
        }
        if (f.hint) h += '<div class="hint">' + f.hint + '</div>';
        h += '</div>';
        return h;
    }

    function escAttr(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
    function escHtml(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

    SCHEMA.forEach(function (sec, i) {
        var b = document.createElement('button');
        b.innerHTML = emojiSpan(sec.icon, sec.icon === 'rocket' ? 'launch' : 'bob') + '<span class="txt">' + sec.title + '</span><span class="count">' + sec.fields.length + '</span>';
        b.dataset.target = sec.section;
        if (i === 0) b.classList.add('active');
        b.addEventListener('click', function () {
            nav.querySelectorAll('button').forEach(function (x) { x.classList.remove('active'); });
            b.classList.add('active');
            panels.querySelectorAll('.sy-editor-panel').forEach(function (p) { p.classList.remove('active'); });
            var el = document.getElementById('panel_' + sec.section);
            if (el) el.classList.add('active');
        });
        nav.appendChild(b);

        var panel = document.createElement('div');
        panel.className = 'sy-editor-panel' + (i === 0 ? ' active' : '');
        panel.id = 'panel_' + sec.section;
        var html = '<h2>' + emojiSpan(sec.icon, 'bob') + ' ' + sec.title + '</h2><div class="desc">' + (sec.desc || '') + '</div>';
        if (sec.section === 'emoji') {
            html += '<div class="sy-moji-grid" style="margin-bottom:16px">';
            Object.keys(SPRITES).forEach(function (k) {
                html += '<div class="sy-moji-cell">' + emojiSpan(k, SPRITES[k].anim) + '<span>' + k + '</span></div>';
            });
            html += '</div>';
        }
        sec.fields.forEach(function (f) { html += fieldHtml(sec.section, f); });
        panel.innerHTML = html;
        panels.appendChild(panel);
    });

    /* ---------------------------------------------------------- events */
    function markDirty() {
        dirty = true;
        dirtyDot.classList.add('on');
    }

    document.addEventListener('input', function (e) {
        var t = e.target;
        if (t.dataset && t.dataset.sec && t.dataset.key) {
            var v = t.type === 'checkbox' ? (t.checked ? 'true' : 'false') : t.value;
            if (!state[t.dataset.sec]) state[t.dataset.sec] = {};
            state[t.dataset.sec][t.dataset.key] = v;
            if (t.type === 'range') {
                var f = findField(t.dataset.sec, t.dataset.key);
                var lab = document.getElementById(t.id + '_v');
                if (lab) lab.textContent = v + (f && f.unit ? f.unit : '');
            }
            if (t.type === 'color') {
                var tx = document.getElementById(t.id + '_t');
                if (tx) tx.value = t.value;
            }
            markDirty();
            renderPreview();
        }
        if (t.dataset && t.dataset.colorsync) {
            var colorEl = document.getElementById(t.dataset.colorsync);
            if (colorEl && /^#[0-9a-fA-F]{6}$/.test(t.value)) colorEl.value = t.value;
        }
    });
    document.addEventListener('change', function (e) {
        var t = e.target;
        if (t.dataset && t.dataset.sec && t.dataset.key) {
            var v = t.type === 'checkbox' ? (t.checked ? 'true' : 'false') : t.value;
            if (!state[t.dataset.sec]) state[t.dataset.sec] = {};
            state[t.dataset.sec][t.dataset.key] = v;
            markDirty();
            renderPreview();
        }
    });

    function findField(sec, key) {
        for (var i = 0; i < SCHEMA.length; i++) {
            if (SCHEMA[i].section === sec) {
                for (var j = 0; j < SCHEMA[i].fields.length; j++) {
                    if (SCHEMA[i].fields[j].key === key) return SCHEMA[i].fields[j];
                }
            }
        }
        return null;
    }

    /* ---------------------------------------------------------- preview */
    var preview = document.getElementById('sy-preview');
    function renderPreview() {
        var c = state.colors || {}, t = state.typography || {}, k = state.corners || {}, fx = state.effects || {};
        var op = (parseFloat(c.surface_opacity) || 88) / 100;
        var glow = (parseFloat(fx.glow_strength) || 30) / 100;
        preview.innerHTML =
            '<div class="sy-cta" style="border-radius:' + (k.radius_card || 12) + 'px;border-color:' + (c.surface_border || '#2c2344') + ';background:' + hexA(c.surface || '#141021', op) + ';backdrop-filter:blur(' + (fx.glass_blur || 10) + 'px)">' +
              '<img src="/extensions/syntro/img/logo-mark.png" style="width:40px;height:40px;image-rendering:pixelated"/>' +
              '<div style="flex:1"><div style="font-weight:700;color:' + (c.text || '#f3eefe') + '">DEPLOY A SERVER</div>' +
              '<div style="font-size:10px;color:' + (c.text_muted || '#9b93b5') + '">preview of your new style</div></div>' +
              '<span style="padding:8px 14px;border-radius:' + (k.radius_btn || 6) + 'px;background:linear-gradient(120deg,' + (c.primary || '#f97316') + ',' + (c.accent || '#fbbf24') + ');color:#140b02;font-weight:700;font-size:11px">CREATE</span>' +
            '</div>' +
            '<h2 class="sy-gradient-text" style="font-size:17px;margin:16px 0 10px;letter-spacing:' + (t.letter_spacing || 0.5) + 'px;' + (String(t.uppercase_headings) !== 'false' ? 'text-transform:uppercase;' : '') + (String(t.text_glow) !== 'false' ? 'text-shadow:0 0 ' + Math.round(20 * glow) + 'px ' + hexA(c.primary || '#f97316', glow) + ';' : '') + '">SpectroCloud</h2>' +
            '<div class="sy-stats"><div class="sy-stat" style="border-radius:' + (k.radius_card || 12) + 'px;border-color:' + (c.surface_border || '#2c2344') + ';background:' + hexA(c.surface || '#141021', op) + '">' +
              '<div style="font-size:9px;color:' + (c.text_muted || '#9b93b5') + ';letter-spacing:1px">SERVERS</div>' +
              '<div style="font-size:15px;color:' + (c.text || '#f3eefe') + '">3 / 5</div></div>' +
              '<div class="sy-stat" style="border-radius:' + (k.radius_card || 12) + 'px;border-color:' + (c.surface_border || '#2c2344') + ';background:' + hexA(c.surface || '#141021', op) + '">' +
              '<div style="font-size:9px;color:' + (c.text_muted || '#9b93b5') + ';letter-spacing:1px">STATUS</div>' +
              '<div style="font-size:15px;color:' + (c.success || '#34d399') + '">ONLINE</div></div></div>' +
            '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center" class="sy-moji-grid">' +
              ['check', 'warn', 'rocket', 'heart', 'spark', 'fire'].map(function (n) { return emojiSpan(n, SPRITES[n] ? SPRITES[n].anim : 'bob'); }).join('') +
            '</div>';
    }
    function hexA(hex, a) {
        try {
            var h = String(hex || '').replace('#', '');
            if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
            var r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return hex;
            return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
        } catch (e) { return hex; }
    }
    renderPreview();

    /* ---------------------------------------------------------- search */
    document.getElementById('sy-search').addEventListener('input', function (e) {
        var q = e.target.value.toLowerCase().trim();
        panels.querySelectorAll('.sy-field').forEach(function (f) {
            f.classList.toggle('hidden', q !== '' && (f.dataset.search || '').indexOf(q) === -1);
        });
        if (q !== '') {
            panels.querySelectorAll('.sy-editor-panel').forEach(function (p) { p.classList.add('active'); });
            panels.style.maxHeight = 'none';
        } else {
            var first = nav.querySelector('button.active');
            panels.querySelectorAll('.sy-editor-panel').forEach(function (p) { p.classList.remove('active'); });
            if (first) {
                var el = document.getElementById('panel_' + first.dataset.target);
                if (el) el.classList.add('active');
            }
        }
    });

    /* ---------------------------------------------------------- toast */
    var toast = document.getElementById('sy-toast');
    var toastT;
    function showToast(msg, ok) {
        toast.textContent = msg;
        toast.className = 'sy-toast show ' + (ok ? 'ok' : 'err');
        clearTimeout(toastT);
        toastT = setTimeout(function () { toast.className = 'sy-toast'; }, 3400);
    }

    /* ---------------------------------------------------------- save */
    document.getElementById('sy-save').addEventListener('click', function () {
        var btn = this;
        btn.disabled = true;
        var ptlaInput = document.querySelector('input[data-ptla]');
        fetch(window.location.pathname, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'X-CSRF-Token': document.querySelector('meta[name=_token]').content,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ settings: state, ptla_key: ptlaInput ? ptlaInput.value : '' })
        }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
          .then(function (res) {
              if (res.ok && res.j.ok) {
                  dirty = false;
                  dirtyDot.classList.remove('on');
                  if (ptlaInput) ptlaInput.value = '';
                  showToast('Saved! Reload your panel pages to see the new look.', true);
              } else {
                  showToast(res.j.error || 'Save failed.', false);
              }
          })
          .catch(function () { showToast('Network error while saving.', false); })
          .finally(function () { btn.disabled = false; });
    });

    /* ---------------------------------------------------------- reset */
    document.getElementById('sy-reset').addEventListener('click', function () {
        if (!confirm('Reset ALL options to defaults? You still need to press SAVE.')) return;
        state = JSON.parse(JSON.stringify(DEFAULTS));
        location.reload();
    });

    /* ---------------------------------------------------------- ptla test */
    var ptlaField = document.querySelector('.sy-field[data-key="ptla_key"]');
    if (ptlaField) {
        var testBtn = document.createElement('button');
        testBtn.className = 'sy-btn small';
        testBtn.style.marginTop = '8px';
        testBtn.textContent = 'TEST CONNECTION';
        testBtn.addEventListener('click', function () {
            testBtn.disabled = true;
            testBtn.textContent = 'TESTING...';
            fetch(window.location.pathname, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRF-Token': document.querySelector('meta[name=_token]').content,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ action: 'test_ptla' })
            }).then(function (r) { return r.json(); }).then(function (j) {
                showToast(j.ok ? ('PTLA works! ' + (j.total_servers || 0) + ' server(s) visible.') : (j.error || 'Test failed.'), j.ok);
            }).catch(function () { showToast('Network error.', false); })
              .finally(function () { testBtn.disabled = false; testBtn.textContent = 'TEST CONNECTION'; });
        });
        ptlaField.appendChild(testBtn);
    }
})();
</script>
</div>
