<?php

/*
 * Syntro theme — admin controller.
 * Renders the theme editor page and persists its settings (single JSON blob)
 * plus the Application API key (stored separately, never sent to browsers).
 */

namespace Pterodactyl\Http\Controllers\Admin\Extensions\syntro;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\View\View;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\BlueprintFramework\Libraries\ExtensionLibrary\Admin\BlueprintAdminLibrary as BlueprintExtensionLibrary;

class SyntroExtensionController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private BlueprintExtensionLibrary $blueprint,
        private SettingsRepositoryInterface $settings,
    ) {
    }

    /** Editor page. */
    public function index(): View
    {
        $raw = $this->settings->get('syntro::settings');
        $settings = $raw ? json_decode($raw, true) : [];
        if (!is_array($settings)) {
            $settings = [];
        }

        return $this->view->make('admin.extensions.syntro.index', [
            'settings' => $settings,
            'has_ptla' => (bool) $this->settings->get('syntro::ptla'),
            'root' => '/admin/extensions/syntro',
            'blueprint' => $this->blueprint,
        ]);
    }

    /** Save editor payload (POST). */
    public function post(Request $request): JsonResponse
    {
        if ($request->input('action') === 'test_ptla') {
            return $this->testPtla();
        }

        $payload = $request->input('settings');
        if (!is_array($payload)) {
            return response()->json(['ok' => false, 'error' => 'Invalid settings payload.'], 422);
        }

        // Sanitize: sections+keys must match [a-z0-9_]+ and values stay strings.
        $clean = [];
        foreach ($payload as $section => $values) {
            if (!is_string($section) || !preg_match('/^[a-z0-9_]+$/', $section) || !is_array($values)) {
                continue;
            }
            foreach ($values as $key => $value) {
                if (!is_string($key) || !preg_match('/^[a-z0-9_]+$/', $key)) {
                    continue;
                }
                if (is_array($value)) {
                    $value = json_encode($value);
                }
                if (!is_scalar($value)) {
                    continue;
                }
                $value = (string) $value;
                if (mb_strlen($value) > 12000) {
                    $value = mb_substr($value, 0, 12000);
                }
                $clean[$section][$key] = $value;
            }
        }

        // Validate the catalog JSON before accepting it.
        if (isset($clean['createserver']['catalog'])) {
            $entries = json_decode($clean['createserver']['catalog'], true);
            if (!is_array($entries)) {
                return response()->json(['ok' => false, 'error' => 'Catalog is not valid JSON.'], 422);
            }
            $clean['createserver']['catalog'] = json_encode(array_values($entries));
        }

        // Application API key lives in its own record — never in the JSON blob
        // that gets injected into client pages.
        unset($clean['createserver']['ptla_key']);
        $ptla = $request->input('ptla_key');
        if (is_string($ptla) && $ptla !== '' && str_starts_with($ptla, 'ptla_')) {
            $this->settings->set('syntro::ptla', $ptla);
        }

        $this->settings->set('syntro::settings', json_encode($clean));

        return response()->json(['ok' => true, 'saved' => count($clean, COUNT_RECURSIVE) - count($clean)]);
    }

    /** PATCH alias. */
    public function update(Request $request): JsonResponse
    {
        return $this->post($request);
    }

    /** Quick Application API key check. */
    private function testPtla(): JsonResponse
    {
        $ptla = $this->settings->get('syntro::ptla');
        $cfg = json_decode($this->settings->get('syntro::settings') ?: '[]', true) ?: [];
        $base = rtrim(($cfg['createserver']['panel_url'] ?? '') ?: config('app.url'), '/');

        if (!$ptla || !$base) {
            return response()->json(['ok' => false, 'error' => 'Save an Application API key (and panel URL) first.'], 422);
        }

        try {
            $resp = Http::withHeaders([
                'Authorization' => 'Bearer ' . $ptla,
                'Accept' => 'application/json',
            ])->timeout(12)->get($base . '/api/application/servers', ['per_page' => 1]);

            if ($resp->failed()) {
                $detail = $resp->json('errors.0.detail');

                return response()->json(['ok' => false, 'error' => 'Panel replied HTTP ' . $resp->status() . ($detail ? ' — ' . $detail : '')]);
            }

            return response()->json([
                'ok' => true,
                'total_servers' => $resp->json('meta.pagination.total') ?? '?',
            ]);
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'error' => 'Could not reach the panel API.']);
        }
    }
}
