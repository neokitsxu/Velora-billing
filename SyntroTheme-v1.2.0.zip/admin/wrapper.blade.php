<?php
/* Syntro theme — admin wrapper. Injected into every admin panel page. */
$syntroAdminEmoji = 'true';
$syntroAdminName = 'Syntro theme';
$syntroAdminCfg = [
    'brand' => ['name' => 'SpectroCloud'],
    'console' => ['ufo_enabled' => 'true', 'ufo_count' => '3', 'ufo_speed' => 'normal',
        'aliens' => 'true', 'alien_count' => '2', 'stars' => 'true', 'star_density' => '40',
        'beam' => 'true', 'pause_hidden' => 'true',
        'mini_ufo_admin' => 'true'],
    'createserver' => ['enabled' => 'true', 'admin_quick_actions' => 'true', 'button_text' => 'CREATE SERVER'],
    'advanced' => ['admin_emoji' => 'true', 'debug' => 'false'],
];
try {
    $syntroRepo = app()->make('Pterodactyl\Contracts\Repository\SettingsRepositoryInterface');
    $syntroRaw = $syntroRepo->get('syntro::settings');
    if ($syntroRaw) {
        $syntroCfg = json_decode($syntroRaw, true);
        if (is_array($syntroCfg)) {
            foreach ($syntroAdminCfg as $sec => $vals) {
                if (isset($syntroCfg[$sec]) && is_array($syntroCfg[$sec])) {
                    $syntroAdminCfg[$sec] = array_merge($vals, $syntroCfg[$sec]);
                }
            }
        }
    }
} catch (\Throwable $e) { /* defaults */ }

/* Security: never expose secrets to the browser. */
unset($syntroAdminCfg['createserver']['ptla_key']);
$syntroAdminEmoji = $syntroAdminCfg['advanced']['admin_emoji'];
$syntroAdminName = $syntroAdminCfg['brand']['name'];
?>
<!-- v1.2.0: pixel font loaded as a RUNTIME style (never in admin.css —
     that file must stay free of absolute urls so rebuilds never break). -->
<style data-syntro-fonts>
    @font-face {
      font-family: 'Monocraft';
      src: url('/extensions/syntro/fonts/Monocraft.ttf') format('truetype');
      font-weight: 400;
      font-style: normal;
      font-display: swap;
    }
    @font-face {
      font-family: 'Monocraft';
      src: url('/extensions/syntro/fonts/Monocraft-Bold.ttf') format('truetype');
      font-weight: 700;
      font-style: normal;
      font-display: swap;
    }
    :root {
      --sy-admin-bg: url('/extensions/syntro/img/bg.jpg') center / cover fixed no-repeat;
    }
</style>
<script>
    window.SyntroAdminCfg = @json($syntroAdminCfg);
    window.Syntro = window.Syntro || window.SyntroAdminCfg;
</script>
@if($syntroAdminEmoji === 'true' || $syntroAdminEmoji === true || $syntroAdminEmoji === '1')
    <script src="/extensions/syntro/js/syntro-admin.js?v=1.2.0" defer></script>
@endif
