/* ============================================================================
   SYNTRO THEME — syntro-admin.js
   Admin-side runtime: SyntroMoji emoji replacement + pixel heading letters +
   mini UFO flybys on every admin page + admin dashboard quick actions
   (Create Server / Console Dashboard — Nebula-style, admin only).
   ========================================================================== */
(function () {
  'use strict';
  if (window.__SYNTRO_ADMIN__) return;
  window.__SYNTRO_ADMIN__ = true;

  var CFG = (window.SyntroAdminCfg || window.Syntro || {});
  function get(section, key, fallback) {
    try {
      var s = CFG[section] || {};
      var v = s[key];
      return (v === undefined || v === null) ? fallback : v;
    } catch (e) { return fallback; }
  }
  function isOn(section, key, def) {
    var v = get(section, key, def === undefined ? 'true' : def);
    return String(v) !== 'false' && v !== false && v !== '0';
  }

  var SPRITES = /* __SYNTRO_EMOJI__ */ {"check": {"grid": ["........", "......gg", ".....ggg", "g...ggg.", "gg.ggg..", "ggggg...", ".ggg....", "..g....."], "palette": {"g": "#34d399"}, "anim": "pulse"}, "cross": {"grid": ["rr....rr", ".rr..rr.", "..rrrr..", "...rr...", "..rrrr..", ".rr..rr.", "rr....rr", "........"], "palette": {"r": "#f87171"}, "anim": "shake"}, "warn": {"grid": ["...yy...", "...yy...", "..yyyy..", "..yywy..", ".yyyywy.", ".yywwyy.", "yyyyyyyy", "yyyyyyyy"], "palette": {"y": "#fbbf24", "w": "#141021"}, "anim": "blink"}, "info": {"grid": ["..cccc..", "..cccc..", "....cc..", "....cc..", "....cc..", "....cc..", "..cccc..", "..cccc.."], "palette": {"c": "#38bdf8"}, "anim": "spin"}, "spark": {"grid": ["...ss...", "...ss...", ".ssssss.", "ss.ss.ss", "..ssss..", "...ss...", "...ss...", "........"], "palette": {"s": "#fbbf24"}, "anim": "twinkle"}, "card": {"grid": ["cccccccc", "c......c", "mmmmmmmc", "c......c", "c..cc..c", "c......c", "cccccccc", "........"], "palette": {"c": "#a78bfa", "m": "#fbbf24"}, "anim": "bob"}, "face": {"grid": ["..ffff..", ".ffffff.", "ffffffff", "f.ffff.f", "ffffffff", "ff....ff", ".ffffff.", "..ffff.."], "palette": {"f": "#f3eefe"}, "anim": "blinkface"}, "happy": {"grid": ["..ffff..", ".ffffff.", "f.ffff.f", "ffffffff", "f.ffff.f", "ff.ww.ff", ".ffffff.", "..ffff.."], "palette": {"f": "#f3eefe", "w": "#f3eefe"}, "anim": "bounceface"}, "sad": {"grid": ["..ffff..", ".ffffff.", "f.ffff.f", "ffffffff", "ffffffff", "f.wwww.f", "ffffffff", "..ffff.."], "palette": {"f": "#9b93b5", "w": "#141021"}, "anim": "bounceface"}, "rocket": {"grid": ["...ww...", "..wwww..", "..woow..", "..woow..", "..wwww..", ".ww..ww.", ".f....f.", "..f..f.."], "palette": {"w": "#e8ecf5", "o": "#f97316", "f": "#fbbf24"}, "anim": "launch"}, "gear": {"grid": [".g..g..g", ".gggggg.", "..gggg..", "gg.gg.gg", "gg.gg.gg", "..gggg..", ".gggggg.", ".g..g..g"], "palette": {"g": "#9b93b5"}, "anim": "spin"}, "heart": {"grid": [".rr..rr.", "rrrrrrrr", "rrrrrrrr", "rrrrrrrr", ".rrrrrr.", "..rrrr..", "...rr...", "........"], "palette": {"r": "#f472b6"}, "anim": "beat"}, "coin": {"grid": ["..yyyy..", ".yyyyyy.", "yyoyyoyy", "yyyyyyyy", "yyoyyoyy", "yyyyyyyy", ".yyyyyy.", "..yyyy.."], "palette": {"y": "#fbbf24", "o": "#b78103"}, "anim": "flip"}, "fire": {"grid": ["....o...", "...oo...", "..ooo.y.", "..ooooo.", ".ooyoooy", ".oyyyyo.", "o.oooo.o", "...oo..."], "palette": {"o": "#f97316", "y": "#fbbf24"}, "anim": "flicker"}, "zap": {"grid": ["....yy..", "...yy...", "..yyyy..", "....yy..", "...yy...", "..yy....", ".yy.....", "y......."], "palette": {"y": "#fde047"}, "anim": "flash"}, "star": {"grid": ["...s....", "...s....", "ssssssss", ".ssssss.", "..ssss..", ".ss..ss.", "........", "........"], "palette": {"s": "#fde047"}, "anim": "twinkle"}, "cube": {"grid": ["..ssss..", ".s....s.", "s..ss..s", "s..ss..s", "s..ss..s", "s..ss..s", ".s....s.", "..ssss.."], "palette": {"s": "#a78bfa"}, "anim": "spin"}, "shield": {"grid": [".cccccc.", "cccccccc", "cccccccc", "cc.cc.cc", "cccccccc", ".cccccc.", "..cccc..", "....cc.."], "palette": {"c": "#38bdf8"}, "anim": "pulse"}} /* __SYNTRO_EMOJI_END__ */;
  var spriteCache = {};

  function spriteSvg(name) {
    if (spriteCache[name]) return spriteCache[name];
    var sp = SPRITES[name];
    if (!sp) return null;
    var rects = '';
    for (var y = 0; y < sp.grid.length; y++) {
      for (var x = 0; x < sp.grid[y].length; x++) {
        var ch = sp.grid[y][x];
        if (ch === '.' || ch === ' ') continue;
        var c = sp.palette[ch];
        if (!c) continue;
        rects += '<rect x="' + x + '" y="' + y + '" width="1" height="1" fill="' + c + '"/>';
      }
    }
    spriteCache[name] = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges">' + rects + '</svg>';
    return spriteCache[name];
  }

  var MAP = [
    { re: /✅|✔️|✔|☑️|☑/g, sprite: 'check', anim: 'pulse' },
    { re: /❌|✖️|✖|⛔|🚫/g, sprite: 'cross', anim: 'shake' },
    { re: /⚠️|⚠/g, sprite: 'warn', anim: 'blink' },
    { re: /ℹ️|ℹ/g, sprite: 'info', anim: 'spin' },
    { re: /🙂|😊|😀|😄|😁|🥳/g, sprite: 'happy', anim: 'bounceface' },
    { re: /😶|😐|😑/g, sprite: 'face', anim: 'blinkface' },
    { re: /😢|😭|😩|😫/g, sprite: 'sad', anim: 'bounceface' },
    { re: /🚀/g, sprite: 'rocket', anim: 'launch' },
    { re: /⚙️|⚙/g, sprite: 'gear', anim: 'spin' },
    { re: /❤️|❤|♥️|♥|💜|🧡|💚|💙/g, sprite: 'heart', anim: 'beat' },
    { re: /💰|🪙|💎|💵/g, sprite: 'coin', anim: 'flip' },
    { re: /🔥/g, sprite: 'fire', anim: 'flicker' },
    { re: /⚡/g, sprite: 'zap', anim: 'flash' },
    { re: /⭐|🌟|💫/g, sprite: 'star', anim: 'twinkle' },
    { re: /✨|🎉|🎊/g, sprite: 'spark', anim: 'twinkle' },
    { re: /💳/g, sprite: 'card', anim: 'bob' }
  ];

  function pass() {
    if (document.body.getAttribute('data-sy-admin-emoji') !== '1') return;
    var walker;
    try { walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false); } catch (e) { return; }
    var nodes = [], n, c = 0;
    while ((n = walker.nextNode()) && c < 160) {
      var t = n.nodeValue;
      if (!t || t.length < 2 || t.length > 500) continue;
      if (n.parentElement && n.parentElement.closest('.sy-emoji,script,style,textarea,input')) continue;
      MAP.forEach(function (m) { m.re.lastIndex = 0; });
      var hit = MAP.some(function (m) { return m.re.test(t); });
      if (hit) { nodes.push(n); c++; }
    }
    nodes.forEach(function (node) {
      var t = node.nodeValue, matches = [];
      MAP.forEach(function (m) {
        m.re.lastIndex = 0;
        var mm;
        while ((mm = m.re.exec(t))) {
          matches.push({ i: mm.index, len: mm[0].length, sprite: m.sprite, anim: m.anim });
          if (!mm[0].length) m.re.lastIndex++;
        }
      });
      if (!matches.length) return;
      matches.sort(function (a, b) { return a.i - b.i; });
      var frag = document.createDocumentFragment(), last = 0;
      var lastEnd = -1, clean = [];
      matches.forEach(function (m) { if (m.i > lastEnd) { clean.push(m); lastEnd = m.i + m.len; } });
      clean.forEach(function (m) {
        if (m.i > last) frag.appendChild(document.createTextNode(t.slice(last, m.i)));
        var sp = document.createElement('span');
        sp.className = 'sy-emoji sy-e-' + m.anim;
        sp.innerHTML = spriteSvg(m.sprite) || '';
        frag.appendChild(sp);
        last = m.i + m.len;
      });
      if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
      try { node.parentNode.replaceChild(frag, node); } catch (e) {}
    });
  }

  /* ------------------------------------------------ mini UFO engine (admin) */
  function startAdminUfos(layer) {
    if (layer.getAttribute('data-sy-ufo')) return;
    if (!isOn('console', 'ufo_enabled')) return;
    if (!isOn('console', 'mini_ufo_admin')) return;
    layer.setAttribute('data-sy-ufo', '1');
    try {
      var canvas = document.createElement('canvas');
      layer.appendChild(canvas);
      var ctx = canvas.getContext('2d');
      var W = 0, H = 0, PX = 7;
      var mul = ({ slow: 0.55, normal: 1, fast: 1.7 }[String(get('console', 'ufo_speed', 'normal'))] || 1) * 0.7;
      var ufoCount = Math.max(1, Math.min(2, Math.round(parseInt(String(get('console', 'ufo_count', '3')), 10) / 2) || 1));
      var starsOn = isOn('console', 'stars');
      var pauseOn = isOn('console', 'pause_hidden');
      var alive = true, frame = 0, visible = true;

      function resize() {
        var r = layer.getBoundingClientRect();
        W = Math.max(80, Math.floor(r.width)); H = Math.max(60, Math.floor(r.height));
        canvas.width = Math.floor(W / PX); canvas.height = Math.floor(H / PX);
        ctx.imageSmoothingEnabled = false;
      }
      resize();

      function mkUfo() {
        return {
          x: Math.random(), y: 0.15 + Math.random() * 0.45,
          vx: (0.0013 + Math.random() * 0.0016) * (Math.random() > 0.5 ? 1 : -1) * mul,
          ph: Math.random() * 6.28, light: 0
        };
      }
      var ufos = []; for (var i = 0; i < ufoCount; i++) ufos.push(mkUfo());
      var stars = [];
      for (var k = 0; k < 26; k++) stars.push({ x: Math.random(), y: Math.random() * 0.8, tw: Math.random() * 6.28 });

      function px(x, y, c) { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); }

      function drawUfo(u) {
        var bx = u.x * canvas.width;
        var by = (u.y + Math.sin(u.ph + frame * 0.04) * 0.012) * canvas.height;
        if (bx < -10 || bx > canvas.width + 10) return;
        var flip = u.vx > 0 ? function (d) { return d; } : function (d) { return 6 - d; };
        px(bx + flip(3), by - 1, '#7de3ff');
        px(bx + flip(2), by, '#7de3ff'); px(bx + flip(3), by, '#a5f0ff'); px(bx + flip(4), by, '#7de3ff');
        for (var dx = 0; dx < 7; dx++) px(bx + flip(dx), by + 1, '#5a5178');
        px(bx + flip(1), by + 1, '#6f669a'); px(bx + flip(5), by + 1, '#6f669a');
        u.light = (u.light + 1) % 30;
        var lc = u.light < 15 ? '#f97316' : '#fbbf24';
        px(bx + flip(1), by + 2, lc); px(bx + flip(3), by + 2, lc); px(bx + flip(5), by + 2, lc);
      }

      function tick() {
        if (!alive || !document.body.contains(layer)) { alive = false; return; }
        requestAnimationFrame(tick);
        if (pauseOn && (document.hidden || !visible)) return;
        frame++;
        if (frame % 2 !== 0) return;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (starsOn) {
          stars.forEach(function (s) {
            s.tw += 0.06;
            var b = 0.45 + 0.55 * Math.abs(Math.sin(s.tw));
            px(s.x * canvas.width, s.y * canvas.height, 'rgba(255,255,255,' + (b * 0.5).toFixed(2) + ')');
          });
        }
        ufos.forEach(function (u) {
          u.x += u.vx * (W / PX) / canvas.width;
          if (u.x > 1.06) { u.x = -0.06; u.y = 0.15 + Math.random() * 0.45; }
          if (u.x < -0.06) { u.x = 1.06; u.y = 0.15 + Math.random() * 0.45; }
          drawUfo(u);
        });
      }
      tick();
      window.addEventListener('resize', function () { try { resize(); } catch (e) {} });
      try {
        var io = new IntersectionObserver(function (es) { visible = es[0].isIntersecting; }, { threshold: 0.05 });
        io.observe(layer);
      } catch (e) {}
    } catch (e) {}
  }

  function ensureAdminUfos() {
    if (!/^\/admin/.test(location.pathname)) return;
    if (!isOn('console', 'ufo_enabled') || !isOn('console', 'mini_ufo_admin')) return;
    var layer = document.getElementById('syAdmUfoLayer');
    if (layer) { startAdminUfos(layer); return; }
    layer = document.createElement('div');
    layer.id = 'syAdmUfoLayer';
    layer.className = 'sy-ufo-layer sy-ufo-mini sy-adm-ufo';
    layer.setAttribute('data-sy-ufo-mode', 'mini');
    document.body.appendChild(layer);
    startAdminUfos(layer);
  }

  /* ------------------------------------- admin dashboard quick action cards */
  var QA_ICONS = {
    create: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges"><rect x="3" y="1" width="2" height="6" fill="#f97316"/><rect x="1" y="3" width="6" height="2" fill="#f97316"/><rect x="3" y="3" width="2" height="2" fill="#fbbf24"/></svg>',
    console: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges"><rect x="0" y="1" width="8" height="6" fill="#141021" stroke="#a78bfa" stroke-width="0"/><rect x="0" y="1" width="8" height="1" fill="#a78bfa"/><rect x="1" y="3" width="1" height="1" fill="#4ade80"/><rect x="2" y="4" width="1" height="1" fill="#4ade80"/><rect x="4" y="4" width="2" height="1" fill="#e8ecf5"/></svg>',
    nodes: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges"><rect x="1" y="1" width="2" height="2" fill="#38bdf8"/><rect x="5" y="1" width="2" height="2" fill="#38bdf8"/><rect x="1" y="5" width="2" height="2" fill="#38bdf8"/><rect x="5" y="5" width="2" height="2" fill="#38bdf8"/><rect x="3" y="2" width="2" height="1" fill="#6f669a"/><rect x="3" y="5" width="2" height="1" fill="#6f669a"/></svg>'
  };

  function buildAdminQA() {
    if (!/^\/admin\/?$/.test(location.pathname)) return;
    if (!isOn('createserver', 'enabled') || !isOn('createserver', 'admin_quick_actions')) return;
    if (document.getElementById('syAdmQA')) return;
    var anchor = document.querySelector('.content-wrapper') || document.querySelector('main') || document.body;
    var ref = anchor.querySelector('.content-header, .content, main > div');
    var box = document.createElement('div');
    box.id = 'syAdmQA';
    var btn = String(get('createserver', 'button_text', 'CREATE SERVER')) || 'CREATE SERVER';
    box.innerHTML =
      '<style>' +
      '#syAdmQA{margin:14px 18px 4px;font-family:inherit}' +
      '#syAdmQA .sy-qa-head{font-size:10px;letter-spacing:2.5px;color:#9b93b5;margin:0 2px 8px;display:flex;align-items:center;gap:8px}' +
      '#syAdmQA .sy-qa-head:before{content:"";width:7px;height:7px;background:#f97316;box-shadow:0 0 8px #f97316;display:inline-block;animation:syAdmBlink 2.2s ease-in-out infinite}' +
      '@keyframes syAdmBlink{0%,60%,100%{opacity:1}30%{opacity:.3}}' +
      '#syAdmQA .sy-qa-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}' +
      '#syAdmQA .sy-qa-card{display:flex;flex-direction:column;gap:6px;padding:14px 16px;border-radius:12px;text-decoration:none!important;' +
      'background:linear-gradient(160deg,rgba(20,16,33,.92),rgba(13,10,24,.94));border:1px solid #2c2344;color:#f3eefe!important;' +
      'transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease;position:relative;overflow:hidden}' +
      '#syAdmQA .sy-qa-card:hover{transform:translateY(-3px);border-color:#f97316;box-shadow:0 14px 30px rgba(0,0,0,.5),0 0 18px rgba(249,115,22,.22)}' +
      '#syAdmQA .sy-qa-card.is-purple:hover{border-color:#a78bfa;box-shadow:0 14px 30px rgba(0,0,0,.5),0 0 18px rgba(167,139,250,.25)}' +
      '#syAdmQA .sy-qa-card.is-blue:hover{border-color:#38bdf8;box-shadow:0 14px 30px rgba(0,0,0,.5),0 0 18px rgba(56,189,248,.25)}' +
      '#syAdmQA .sy-qa-ico{width:26px;height:26px;image-rendering:pixelated}' +
      '#syAdmQA .sy-qa-ico svg{width:100%;height:100%;display:block}' +
      '#syAdmQA .sy-qa-t{font-size:13px;font-weight:700;letter-spacing:1.5px}' +
      '#syAdmQA .sy-qa-d{font-size:11px;color:#9b93b5;line-height:1.5}' +
      '</style>' +
      '<div class="sy-qa-head">SYNTRO QUICK ACTIONS</div>' +
      '<div class="sy-qa-row">' +
      '<a class="sy-qa-card" href="/admin/servers/new"><span class="sy-qa-ico">' + QA_ICONS.create + '</span><span class="sy-qa-t">' + btn + '</span><span class="sy-qa-d">Nebula-style: create servers right from the admin panel.</span></a>' +
      '<a class="sy-qa-card is-purple" href="/admin/servers"><span class="sy-qa-ico">' + QA_ICONS.console + '</span><span class="sy-qa-t">CONSOLE DASHBOARD</span><span class="sy-qa-d">Jump into any server and manage it.</span></a>' +
      '<a class="sy-qa-card is-blue" href="/admin/nodes"><span class="sy-qa-ico">' + QA_ICONS.nodes + '</span><span class="sy-qa-t">NODES</span><span class="sy-qa-d">Check node health, capacity and allocation.</span></a>' +
      '</div>';
    if (ref && ref.parentElement === anchor) ref.insertAdjacentElement('afterend', box);
    else anchor.insertBefore(box, anchor.firstChild);
  }

  /* ----------------------------------------------------------------- boot */
  function boot() {
    try { document.body.setAttribute('data-sy-admin-emoji', '1'); } catch (e) {}
    try { ensureAdminUfos(); } catch (e) {}
    try { buildAdminQA(); } catch (e) {}
    pass();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  window.addEventListener('load', boot);

  var t;
  var mo = new MutationObserver(function () {
    clearTimeout(t);
    t = setTimeout(function () { pass(); buildAdminQA(); ensureAdminUfos(); }, 160);
  });
  try { mo.observe(document.body, { childList: true, subtree: true }); } catch (e) {}
})();
