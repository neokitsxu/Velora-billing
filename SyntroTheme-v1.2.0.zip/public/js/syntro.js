/* ============================================================================
   SYNTRO THEME — syntro.js (client runtime)
   Settings applier • SEO • branding • SyntroMoji animated emojis • pixel
   letters • auto egg icons • console UFO & alien FX. Idempotent + guarded.
   ========================================================================== */
(function () {
  'use strict';
  if (window.__SYNTRO_BOOTED__) return;
  window.__SYNTRO_BOOTED__ = true;

  /* ------------------------------------------------------------ settings */
  var DEFAULTS = /* __SYNTRO_DEFAULTS__ */ {"brand": {"name": "SpectroCloud", "tagline": "Best Minecraft Server Hosting", "footer_text": "Branding made by Neokitsxu_ • SpectroCloud — Best Minecraft Server Hosting", "website_url": "", "logo_url": "/extensions/syntro/img/logo.png", "logo_mark_url": "/extensions/syntro/img/logo-mark.png", "logo_height": 34, "show_logo_in_nav": "true"}, "seo": {"title_suffix": "SpectroCloud", "title_mode": "append", "favicon_url": "/extensions/syntro/img/favicon.png", "theme_color": "#f97316", "meta_description": "SpectroCloud — Best Minecraft Server Hosting. Powered by Syntro theme.", "og_image": ""}, "background": {"enabled": "true", "url": "/extensions/syntro/img/bg.jpg", "overlay": "72", "blur": "0", "vignette": "true", "fixed": "true", "scanlines": "true", "scanline_opacity": "4"}, "colors": {"primary": "#f97316", "secondary": "#a78bfa", "accent": "#fbbf24", "surface": "#141021", "surface_opacity": "88", "surface_border": "#2c2344", "text": "#f3eefe", "text_muted": "#9b93b5", "success": "#34d399", "warning": "#fbbf24", "danger": "#f87171", "info": "#38bdf8", "link": "#f0a868", "bg_tint": "#0d0a18"}, "typography": {"font": "Monocraft", "body_size": 14, "heading_size": 20, "letter_spacing": "0.5", "line_height": "1.7", "text_glow": "true", "glow_color": "rgba(249,115,22,0.35)", "uppercase_headings": "true", "heading_weight": "700"}, "corners": {"radius": 8, "radius_btn": 6, "radius_input": 6, "radius_card": 12, "container_width": 1200}, "effects": {"glass_blur": 10, "glow_strength": 30, "shadow_strength": 60, "gradient_enabled": "true", "animated_gradient": "true", "border_glow": "true", "noise": "false", "hover_lift": "true", "focus_glow": "true", "image_rendering": "pixelated"}, "animations": {"enabled": "true", "page_entrance": "true", "letters_enabled": "true", "letters_speed": "480", "letters_stagger": "28", "hover_anims": "true", "button_pulse": "false", "sidebar_anims": "true", "card_entrance": "true"}, "emoji": {"enabled": "true", "size": 20, "style": "pixel", "idle_anim": "true", "map_check": "true", "map_warn": "true", "map_faces": "true", "map_misc": "true"}, "servericons": {"enabled": "true", "style": "glow", "size": 34, "default_icon": "egg", "animation": "bob", "show_in_list": "true"}, "console": {"ufo_enabled": "true", "ufo_count": 3, "ufo_speed": "normal", "aliens": "true", "alien_count": 2, "stars": "true", "star_density": "40", "beam": "true", "pause_hidden": "true", "mini_ufo_dashboard": "true", "mini_ufo_admin": "true", "mini_ufo_auth": "true"}, "authpages": {"logo": "true", "welcome_title": "WELCOME BACK", "welcome_text": "Log in to manage your servers", "card_glass": "true", "gradient_border": "true", "blur_bg": "true", "anims": "true"}, "createserver": {"enabled": "true", "admin_quick_actions": "true", "button_text": "CREATE SERVER", "page_title": "Create a new server", "page_desc": "Spin up your own server in seconds. Pick a game, choose your resources and deploy.", "max_servers": 2, "max_memory": 4096, "max_cpu": 200, "max_disk": 10240, "backups": 2, "databases": 1, "ptla_key": "", "panel_url": "", "catalog": "[{\"name\":\"Minecraft Java\",\"egg\":null,\"icon\":\"minecraft\",\"docker\":\"ghcr.io/pterodactyl/yolks:java_17\",\"startup\":\"java -Xms128M -XX:MaxRAMPercentage=95.0 -jar {{SERVER_JARFILE}}\",\"env\":{\"SERVER_JARFILE\":\"server.jar\"},\"mem\":2048,\"cpu\":100,\"disk\":4096},{\"name\":\"Minecraft Bedrock\",\"egg\":null,\"icon\":\"minecraft\",\"docker\":\"ghcr.io/pterodactyl/yolks:java_17\",\"startup\":\"./bedrock_server\",\"env\":{},\"mem\":1024,\"cpu\":100,\"disk\":2048},{\"name\":\"Discord Bot (Node.js)\",\"egg\":null,\"icon\":\"discordbot\",\"docker\":\"ghcr.io/pterodactyl/yolks:nodejs_20\",\"startup\":\"if [[ -f package.json ]]; then npm install --omit=dev; fi; if [[ ! -z ${JS_FILE} ]]; then node /app/home/${JS_FILE}; else node index.js; fi\",\"env\":{},\"mem\":512,\"cpu\":50,\"disk\":1024}]"}, "layout": {"sidebar_style": "glass", "sidebar_compact": "false", "topbar_blur": "true", "footer": "true", "footer_pos": "fixed", "stats_cards": "true", "container_padding": 24, "server_sidebar": "true", "sidebar_ext_category": "MINECRAFT"}, "advanced": {"custom_css": "", "admin_emoji": "true", "debug": "false", "uninstall_note": "Removing this extension also removes the theme automatically."}} /* __SYNTRO_DEFAULTS_END__ */;
  var SPRITES = /* __SYNTRO_EMOJI__ */ {"check": {"grid": ["........", "......gg", ".....ggg", "g...ggg.", "gg.ggg..", "ggggg...", ".ggg....", "..g....."], "palette": {"g": "#34d399"}, "anim": "pulse"}, "cross": {"grid": ["rr....rr", ".rr..rr.", "..rrrr..", "...rr...", "..rrrr..", ".rr..rr.", "rr....rr", "........"], "palette": {"r": "#f87171"}, "anim": "shake"}, "warn": {"grid": ["...yy...", "...yy...", "..yyyy..", "..yywy..", ".yyyywy.", ".yywwyy.", "yyyyyyyy", "yyyyyyyy"], "palette": {"y": "#fbbf24", "w": "#141021"}, "anim": "blink"}, "info": {"grid": ["..cccc..", "..cccc..", "....cc..", "....cc..", "....cc..", "....cc..", "..cccc..", "..cccc.."], "palette": {"c": "#38bdf8"}, "anim": "spin"}, "spark": {"grid": ["...ss...", "...ss...", ".ssssss.", "ss.ss.ss", "..ssss..", "...ss...", "...ss...", "........"], "palette": {"s": "#fbbf24"}, "anim": "twinkle"}, "card": {"grid": ["cccccccc", "c......c", "mmmmmmmc", "c......c", "c..cc..c", "c......c", "cccccccc", "........"], "palette": {"c": "#a78bfa", "m": "#fbbf24"}, "anim": "bob"}, "face": {"grid": ["..ffff..", ".ffffff.", "ffffffff", "f.ffff.f", "ffffffff", "ff....ff", ".ffffff.", "..ffff.."], "palette": {"f": "#f3eefe"}, "anim": "blinkface"}, "happy": {"grid": ["..ffff..", ".ffffff.", "f.ffff.f", "ffffffff", "f.ffff.f", "ff.ww.ff", ".ffffff.", "..ffff.."], "palette": {"f": "#f3eefe", "w": "#f3eefe"}, "anim": "bounceface"}, "sad": {"grid": ["..ffff..", ".ffffff.", "f.ffff.f", "ffffffff", "ffffffff", "f.wwww.f", "ffffffff", "..ffff.."], "palette": {"f": "#9b93b5", "w": "#141021"}, "anim": "bounceface"}, "rocket": {"grid": ["...ww...", "..wwww..", "..woow..", "..woow..", "..wwww..", ".ww..ww.", ".f....f.", "..f..f.."], "palette": {"w": "#e8ecf5", "o": "#f97316", "f": "#fbbf24"}, "anim": "launch"}, "gear": {"grid": [".g..g..g", ".gggggg.", "..gggg..", "gg.gg.gg", "gg.gg.gg", "..gggg..", ".gggggg.", ".g..g..g"], "palette": {"g": "#9b93b5"}, "anim": "spin"}, "heart": {"grid": [".rr..rr.", "rrrrrrrr", "rrrrrrrr", "rrrrrrrr", ".rrrrrr.", "..rrrr..", "...rr...", "........"], "palette": {"r": "#f472b6"}, "anim": "beat"}, "coin": {"grid": ["..yyyy..", ".yyyyyy.", "yyoyyoyy", "yyyyyyyy", "yyoyyoyy", "yyyyyyyy", ".yyyyyy.", "..yyyy.."], "palette": {"y": "#fbbf24", "o": "#b78103"}, "anim": "flip"}, "fire": {"grid": ["....o...", "...oo...", "..ooo.y.", "..ooooo.", ".ooyoooy", ".oyyyyo.", "o.oooo.o", "...oo..."], "palette": {"o": "#f97316", "y": "#fbbf24"}, "anim": "flicker"}, "zap": {"grid": ["....yy..", "...yy...", "..yyyy..", "....yy..", "...yy...", "..yy....", ".yy.....", "y......."], "palette": {"y": "#fde047"}, "anim": "flash"}, "star": {"grid": ["...s....", "...s....", "ssssssss", ".ssssss.", "..ssss..", ".ss..ss.", "........", "........"], "palette": {"s": "#fde047"}, "anim": "twinkle"}, "cube": {"grid": ["..ssss..", ".s....s.", "s..ss..s", "s..ss..s", "s..ss..s", "s..ss..s", ".s....s.", "..ssss.."], "palette": {"s": "#a78bfa"}, "anim": "spin"}, "shield": {"grid": [".cccccc.", "cccccccc", "cccccccc", "cc.cc.cc", "cccccccc", ".cccccc.", "..cccc..", "....cc.."], "palette": {"c": "#38bdf8"}, "anim": "pulse"}} /* __SYNTRO_EMOJI_END__ */;

  function merge(a, b) {
    var out = {};
    Object.keys(a).forEach(function (k) {
      out[k] = Object.assign({}, a[k]);
      if (b && b[k]) Object.keys(b[k]).forEach(function (k2) { out[k][k2] = b[k][k2]; });
    });
    return out;
  }
  var S = merge(DEFAULTS, window.Syntro || {});
  window.SyntroSettings = S;

  function get(section, key, fallback) {
    try {
      if (S[section] && typeof S[section][key] !== 'undefined' && S[section][key] !== '') return S[section][key];
    } catch (e) {}
    return fallback;
  }
  function isOn(section, key, def) {
    var v = get(section, key, def === undefined ? 'true' : def);
    return v === true || v === 'true' || v === 1 || v === '1';
  }
  function num(section, key, def) {
    var v = parseFloat(get(section, key, def));
    return isNaN(v) ? def : v;
  }

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var REDUCED = false;
  try { REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}
  var MOTION_ON = isOn('animations', 'enabled') && !REDUCED;

  function safe(fn) { try { fn(); } catch (e) { dbg('err', e && e.message); } }
  function dbg() {
    if (!isOn('advanced', 'debug', 'false')) return;
    try { console.log.apply(console, ['[syntro]'].concat([].slice.call(arguments))); } catch (e) {}
  }

  /* ------------------------------------------------- 1. apply settings/CSS */
  var spriteCache = {};

  function spriteSvg(name) {
    if (spriteCache[name]) return spriteCache[name];
    var sp = SPRITES[name];
    if (!sp) return null;
    var rects = '';
    for (var y = 0; y < sp.grid.length; y++) {
      var row = sp.grid[y];
      for (var x = 0; x < row.length; x++) {
        var ch = row[x];
        if (ch === '.' || ch === ' ') continue;
        var c = sp.palette[ch];
        if (!c) continue;
        rects += '<rect x="' + x + '" y="' + y + '" width="1" height="1" fill="' + c + '"/>';
      }
    }
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges">' + rects + '</svg>';
    spriteCache[name] = svg;
    return svg;
  }

  function hexA(hex, a) {
    try {
      var h = hex.replace('#', '');
      if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
      var r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
      return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
    } catch (e) { return hex; }
  }

  function applyCssVars() {
    var st = document.documentElement.style;
    var C = S.colors || {}, T = S.typography || {}, K = S.corners || {}, F = S.effects || {}, A = S.animations || {};
    var pairs = {
      '--sy-primary': C.primary, '--sy-secondary': C.secondary, '--sy-accent': C.accent,
      '--sy-surface': C.surface, '--sy-border': C.surface_border, '--sy-text': C.text,
      '--sy-muted': C.text_muted, '--sy-success': C.success, '--sy-warning': C.warning,
      '--sy-danger': C.danger, '--sy-info': C.info, '--sy-link': C.link, '--sy-tint': C.bg_tint,
      '--sy-radius': (K.radius || 8) + 'px', '--sy-radius-btn': (K.radius_btn || 6) + 'px',
      '--sy-radius-input': (K.radius_input || 6) + 'px', '--sy-radius-card': (K.radius_card || 12) + 'px',
      '--sy-container': (K.container_width || 1200) + 'px',
      '--sy-glass': (F.glass_blur || 10) + 'px',
      '--sy-glow': (num('effects', 'glow_strength', 30) / 100),
      '--sy-shadow': (num('effects', 'shadow_strength', 60) / 100),
      '--sy-ls': (T.letter_spacing || 0.5) + 'px',
      '--sy-lh': T.line_height || 1.7,
      '--sy-body-size': (T.body_size || 14) + 'px',
      '--sy-heading-size': (T.heading_size || 20) + 'px',
      '--sy-pad': (get('layout', 'container_padding', 24)) + 'px',
      '--sy-emoji-size': (num('emoji', 'size', 20)) + 'px',
      '--sy-egg-size': (num('servericons', 'size', 34)) + 'px',
      '--sy-ls-speed': (A.letters_speed || 480) + 'ms',
      '--sy-ls-stagger': (A.letters_stagger || 28) + 'ms'
    };
    Object.keys(pairs).forEach(function (k) { if (pairs[k]) st.setProperty(k, pairs[k]); });

    st.setProperty('--sy-surface-op', num('colors', 'surface_opacity', 88) / 100);
    st.setProperty('--sy-bgov', num('background', 'overlay', 72));
    st.setProperty('--sy-bgblur', num('background', 'blur', 0) + 'px');
    st.setProperty('--sy-scan-op', num('background', 'scanline_opacity', 4) / 100);
    st.setProperty('--sy-noise-op', isOn('effects', 'noise', 'false') ? '0.05' : '0');
    st.setProperty('--sy-imgrender', get('effects', 'image_rendering', 'pixelated'));
    st.setProperty('--sy-headw', get('typography', 'heading_weight', '700'));
    st.setProperty('--sy-gradient', isOn('effects', 'gradient_enabled') ? '1' : '0');

    if (isOn('background', 'enabled')) {
      var u = get('background', 'url', '/extensions/syntro/img/bg.jpg');
      if (u) st.setProperty('--sy-bg', 'url("' + u + '")');
    } else {
      st.setProperty('--sy-bg', 'none');
    }
    if (get('typography', 'font', 'Monocraft') !== 'Monocraft') {
      st.setProperty('--sy-font', get('typography', 'font', 'Monocraft') + ', ui-monospace, monospace');
    }
  }

  function applyBodyClasses() {
    var b = document.body;
    b.classList.add('sy-theme');
    b.classList.toggle('sy-glass-on', true);
    b.classList.toggle('sy-glow-h', isOn('typography', 'text_glow'));
    b.classList.toggle('sy-up-h', isOn('typography', 'uppercase_headings'));
    b.classList.toggle('sy-hover-anims', MOTION_ON && isOn('animations', 'hover_anims'));
    b.classList.toggle('sy-btn-pulse', MOTION_ON && isOn('animations', 'button_pulse'));
    b.classList.toggle('sy-sidebar-anims', MOTION_ON && isOn('animations', 'sidebar_anims'));
    b.classList.toggle('sy-hover-lift', MOTION_ON && isOn('effects', 'hover_lift'));
    b.classList.toggle('sy-focus-glow', isOn('effects', 'focus_glow'));
    b.classList.toggle('sy-card-entrance', MOTION_ON && isOn('animations', 'card_entrance'));
    b.classList.toggle('sy-page-in', MOTION_ON && isOn('animations', 'page_entrance'));
    b.classList.toggle('sy-anim-gradient', MOTION_ON && isOn('effects', 'animated_gradient'));
    b.classList.toggle('sy-auth-anim', MOTION_ON && isOn('authpages', 'anims'));
    b.classList.toggle('sy-motion-off', !MOTION_ON);
    b.classList.toggle('sy-auth-page', /^\/(auth|login|register)/.test(location.pathname));
    b.classList.toggle('sy-server-page', /^\/server\//.test(location.pathname));
  }

  function applyOverlays() {
    $$('.sy-scanlines,.sy-noise').forEach(function (n) { n.remove(); });
    if (isOn('background', 'scanlines')) {
      var sc = document.createElement('div');
      sc.className = 'sy-scanlines';
      document.body.appendChild(sc);
    }
    if (isOn('effects', 'noise', 'false')) {
      var nz = document.createElement('div');
      nz.className = 'sy-noise';
      document.body.appendChild(nz);
    }
  }

  /* --------------------------------------------------------- 2. SEO/brand */
  function applySeo() {
    var mode = get('seo', 'title_mode', 'append');
    var suffix = get('seo', 'title_suffix', '');
    var base = (document.title || '').replace(/\s*[|\-–—]\s*.*$/, '');
    if (suffix) {
      if (mode === 'replace') document.title = suffix;
      else if (mode === 'prefix') document.title = suffix + ' | ' + (document.title || '');
      else document.title = (document.title || '') + ' | ' + suffix;
    }
    var fav = get('seo', 'favicon_url', '');
    if (fav) {
      var links = $$('link[rel*="icon"]');
      if (links.length === 0) {
        var l = document.createElement('link');
        l.rel = 'icon';
        document.head.appendChild(l);
        links = [l];
      }
      links.forEach(function (l) { l.href = fav; });
    }
    var tc = get('seo', 'theme_color', '');
    if (tc) {
      var m = $('meta[name="theme-color"]');
      if (!m) { m = document.createElement('meta'); m.name = 'theme-color'; document.head.appendChild(m); }
      m.content = tc;
    }
    var md = get('seo', 'meta_description', '');
    if (md) {
      var d = $('meta[name="description"]');
      if (!d) { d = document.createElement('meta'); d.name = 'description'; document.head.appendChild(d); }
      d.content = md;
    }
    var og = get('seo', 'og_image', '');
    if (og) {
      var o = $('meta[property="og:image"]');
      if (!o) { o = document.createElement('meta'); o.setAttribute('property', 'og:image'); document.head.appendChild(o); }
      o.content = og;
    }
  }

  function applyNavBrand() {
    var nav = $('[id*="avigation" i]') || $('nav');
    if (!nav) return;
    if (!isOn('brand', 'show_logo_in_nav')) return;
    if ($('.sy-nav-logo', nav)) return;
    var mark = get('brand', 'logo_mark_url', '') || get('brand', 'logo_url', '');
    if (!mark) return;
    var img = document.createElement('img');
    img.src = mark;
    img.alt = get('brand', 'name', '');
    img.className = 'sy-nav-logo';
    img.style.cssText = 'height:' + num('brand', 'logo_height', 34) + 'px;width:auto;object-fit:contain;margin-right:10px;image-rendering:pixelated;filter:drop-shadow(0 0 8px ' + hexA(get('colors', 'primary', '#f97316'), 0.45) + ');';
    nav.insertBefore(img, nav.firstChild);
  }

  /* ------------------------------------------------------------- 3. footer */
  function applyFooter() {
    if (!isOn('layout', 'footer')) return;
    if ($('.sy-footer')) return;
    var f = document.createElement('div');
    f.className = 'sy-footer ' + (get('layout', 'footer_pos', 'fixed') === 'fixed' ? 'sy-footer-fixed' : '');
    var mark = get('brand', 'logo_mark_url', '');
    var name = get('brand', 'name', '');
    var txt = get('brand', 'footer_text', '');
    var url = get('brand', 'website_url', '');
    f.innerHTML =
      (mark ? '<img src="' + mark + '" alt=""/>' : '') +
      '<span>' + (url ? '<a href="' + url + '" target="_blank" rel="noopener">' : '') + name + (url ? '</a>' : '') + '</span>' +
      '<span>•</span>' +
      '<span>' + txt + '</span>';
    document.body.appendChild(f);
    if (f.classList.contains('sy-footer-fixed')) {
      var st = document.createElement('style');
      st.textContent = 'body{padding-bottom:44px!important}';
      document.head.appendChild(st);
    }
  }

  /* --------------------------------------------------------- 4. SyntroMoji */
  var EMOJI_MAP = [
    { re: /✅|✔️|✔|☑️|☑/g, sprite: 'check', group: 'map_check' },
    { re: /❌|✖️|✖|⛔|🚫/g, sprite: 'cross', group: 'map_check' },
    { re: /⚠️|⚠/g, sprite: 'warn', group: 'map_warn' },
    { re: /ℹ️|ℹ/g, sprite: 'info', group: 'map_warn' },
    { re: /🙂|😊|😀|😄|😁|😌|🥳/g, sprite: 'happy', group: 'map_faces' },
    { re: /😶|😐|😑|🫤/g, sprite: 'face', group: 'map_faces' },
    { re: /😢|😭|😩|😫|😿/g, sprite: 'sad', group: 'map_faces' },
    { re: /🚀/g, sprite: 'rocket', group: 'map_misc' },
    { re: /⚙️|⚙/g, sprite: 'gear', group: 'map_misc' },
    { re: /❤️|❤|♥️|♥|💜|🧡|💚|💙/g, sprite: 'heart', group: 'map_misc' },
    { re: /💰|🪙|💎|💵/g, sprite: 'coin', group: 'map_misc' },
    { re: /🔥/g, sprite: 'fire', group: 'map_misc' },
    { re: /⚡/g, sprite: 'zap', group: 'map_misc' },
    { re: /⭐|🌟|💫/g, sprite: 'star', group: 'map_misc' },
    { re: /✨|🎉|🎊/g, sprite: 'spark', group: 'map_misc' },
    { re: /💳|💶|💴/g, sprite: 'card', group: 'map_misc' }
  ];

  function replaceEmojis(root) {
    if (!isOn('emoji', 'enabled')) return;
    var walker;
    try {
      walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
    } catch (e) { return; }
    var nodes = [], n, count = 0;
    while ((n = walker.nextNode())) {
      if (count >= 220) break;
      var t = n.nodeValue;
      if (!t || t.length < 2 || t.length > 900) continue;
      var hit = false;
      for (var i = 0; i < EMOJI_MAP.length; i++) {
        if (EMOJI_MAP[i].re.test(t)) { hit = true; break; }
      }
      EMOJI_MAP.forEach(function (m) { m.re.lastIndex = 0; });
      if (hit) { nodes.push(n); count++; }
    }
    nodes.forEach(function (node) {
      var t = node.nodeValue;
      var frag = document.createDocumentFragment();
      var last = 0, any = false;
      var matches = [];
      EMOJI_MAP.forEach(function (m) {
        if (isOn('emoji', m.group, 'true') === false) return;
        m.re.lastIndex = 0;
        var mm;
        while ((mm = m.re.exec(t))) {
          matches.push({ i: mm.index, len: mm[0].length, sprite: m.sprite, anim: (SPRITES[m.sprite] || {}).anim || 'bob' });
          if (mm[0].length === 0) m.re.lastIndex++;
        }
      });
      if (!matches.length) return;
      matches.sort(function (a, b) { return a.i - b.i; });
      var cleaned = [];
      var lastEnd = -1;
      matches.forEach(function (m) { if (m.i > lastEnd) { cleaned.push(m); lastEnd = m.i + m.len; } });
      cleaned.forEach(function (m) {
        if (m.i > last) frag.appendChild(document.createTextNode(t.slice(last, m.i)));
        var sp = document.createElement('span');
        sp.className = 'sy-emoji sy-e-' + m.anim;
        sp.innerHTML = spriteSvg(m.sprite) || '';
        frag.appendChild(sp);
        last = m.i + m.len;
        any = true;
      });
      if (!any) return;
      if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
      try { node.parentNode.replaceChild(frag, node); } catch (e) {}
    });
  }

  /* ---------------------------------------------------- 5. pixel letters */
  function splitLetters(el) {
    if (el.getAttribute('data-sy-split')) return;
    if (el.children.length > 0) return;
    var txt = el.textContent;
    if (!txt || txt.length < 2 || txt.length > 80) return;
    if (!/[A-Za-z0-9]/.test(txt)) return;
    el.setAttribute('data-sy-split', '1');
    var frag = document.createDocumentFragment();
    for (var i = 0; i < txt.length; i++) {
      var sp = document.createElement('span');
      sp.className = 'sy-letter';
      sp.style.setProperty('--sy-letter-i', i);
      sp.textContent = txt[i];
      frag.appendChild(sp);
    }
    el.textContent = '';
    el.appendChild(frag);
  }

  function scanLetters(root) {
    if (!MOTION_ON || !isOn('animations', 'letters_enabled')) return;
    safe(function () {
      $$('h1,h2,h3', root).slice(0, 24).forEach(function (el) {
        if (el.closest('.sy-editor-panel')) return;
        splitLetters(el);
      });
    });
  }

  /* ------------------------------------------------------- 6. egg icons */
  var serverMap = null, serverMapTried = false;

  function loadServerMap() {
    if (serverMapTried) return;
    serverMapTried = true;
    safe(function () {
      fetch('/api/client/extensions/syntro/servers', {
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
        serverMap = {};
        if (j && j.data) {
          j.data.forEach(function (s) { serverMap[s.uuid] = s.icon || get('servericons', 'default_icon', 'egg'); });
        }
        // reset markers rendered before the map arrived, then re-scan
        $$('[data-sy-done]').forEach(function (m) { m.removeAttribute('data-sy-done'); m.innerHTML = ''; });
        scanIcons(document);
      }).catch(function () { serverMap = {}; });
    });
  }

  function scanIcons(root) {
    if (!isOn('servericons', 'enabled')) return;
    loadServerMap();
    safe(function () {
      $$('[data-syntro-server-icon]', root).forEach(function (marker) {
        if (marker.getAttribute('data-sy-done')) return;
        var row = marker.closest('a[href*="/server/"]');
        var icon = get('servericons', 'default_icon', 'egg');
        if (row && serverMap) {
          var uuid = (row.getAttribute('href') || '').split('/server/')[1] || '';
          uuid = uuid.split('/')[0];
          if (serverMap[uuid]) icon = serverMap[uuid];
        }
        marker.setAttribute('data-sy-done', '1');
        marker.innerHTML = '';
        var wrap = document.createElement('span');
        wrap.className = 'sy-egg-icon sy-st-' + get('servericons', 'style', 'glow') + ' sy-anim-' + get('servericons', 'animation', 'bob');
        var img = document.createElement('img');
        img.src = '/extensions/syntro/icons/' + icon + '.svg';
        img.alt = '';
        img.onerror = function () { img.src = '/extensions/syntro/icons/egg.svg'; };
        wrap.appendChild(img);
        marker.appendChild(wrap);
      });
    });
  }

  /* ------------------------------------------------------- 7. UFO engine */
  function startUfos(layer) {
    if (layer.getAttribute('data-sy-ufo')) return;
    if (!isOn('console', 'ufo_enabled')) return;
    layer.setAttribute('data-sy-ufo', '1');
    safe(function () {
      var mini = layer.getAttribute('data-sy-ufo-mode') === 'mini';
      var canvas = document.createElement('canvas');
      layer.appendChild(canvas);
      var ctx = canvas.getContext('2d');
      var W = 0, H = 0, PX = mini ? 7 : 4;
      var speedMul = ({ slow: 0.55, normal: 1, fast: 1.7 }[get('console', 'ufo_speed', 'normal')] || 1) * (mini ? 0.75 : 1);
      var ufoCount = Math.max(1, Math.min(6, num('console', 'ufo_count', 3)));
      if (mini) ufoCount = Math.max(1, Math.min(2, Math.round(ufoCount / 2)));
      var alienCount = (!mini && isOn('console', 'aliens')) ? Math.max(1, Math.min(5, num('console', 'alien_count', 2))) : 0;
      var starsOn = isOn('console', 'stars');
      var starDensity = num('console', 'star_density', 40) * (mini ? 0.5 : 1);
      var beamOn = isOn('console', 'beam') && !mini;
      var pauseOn = isOn('console', 'pause_hidden');
      var alive = true, frame = 0, visible = true;

      function resize() {
        var r = layer.getBoundingClientRect();
        W = Math.max(80, Math.floor(r.width)); H = Math.max(60, Math.floor(r.height));
        canvas.width = Math.floor(W / PX); canvas.height = Math.floor(H / PX);
        ctx.imageSmoothingEnabled = false;
        ctx.setTransform(1, 0, 0, 1, 0, 0);
      }
      resize();

      function mkUfo(seed) {
        return {
          x: Math.random(), y: 0.08 + Math.random() * 0.5,
          vx: (0.0016 + Math.random() * 0.0022) * (Math.random() > 0.5 ? 1 : -1) * speedMul,
          ph: Math.random() * 6.28, light: 0, beam: 0, beamT: 0
        };
      }
      function mkAlien() {
        return { x: Math.random(), dir: Math.random() > 0.5 ? 1 : -1, ph: Math.random() * 6.28, sp: (0.0012 + Math.random() * 0.001) * speedMul };
      }
      var ufos = [], aliens = [], stars = [];
      for (var i = 0; i < ufoCount; i++) ufos.push(mkUfo());
      for (var j = 0; j < alienCount; j++) aliens.push(mkAlien());
      var starN = Math.floor((W * H) / 26000 * (starDensity / 40));
      for (var k = 0; k < Math.min(90, starN); k++) {
        stars.push({ x: Math.random(), y: Math.random() * 0.8, tw: Math.random() * 6.28 });
      }

      function px(x, y, c) {
        ctx.fillStyle = c;
        ctx.fillRect(Math.round(x), Math.round(y), 1, 1);
      }
      // 7x4 UFO sprite, dome + saucer
      function drawUfo(u) {
        var bx = u.x * (W / PX), by = (u.y + Math.sin(u.ph + frame * 0.04) * 0.012) * (H / PX);
        if (bx < -10 || bx > canvas.width + 10) return;
        var dom = u.vx > 0 ? 0 : 1;
        var flip = dom ? function (dx) { return 6 - dx; } : function (dx) { return dx; };
        // dome
        px(bx + flip(3), by - 1, '#7de3ff');
        px(bx + flip(2), by, '#7de3ff'); px(bx + flip(3), by, '#a5f0ff'); px(bx + flip(4), by, '#7de3ff');
        // saucer
        for (var dx = 0; dx < 7; dx++) px(bx + flip(dx), by + 1, '#5a5178');
        px(bx + flip(1), by + 1, '#6f669a'); px(bx + flip(5), by + 1, '#6f669a');
        // lights blink
        u.light = (u.light + 1) % 30;
        var lc = u.light < 15 ? '#f97316' : '#fbbf24';
        px(bx + flip(1), by + 2, lc); px(bx + flip(3), by + 2, lc); px(bx + flip(5), by + 2, lc);
        // beam
        if (beamOn && u.beamT > 0) {
          var w = Math.floor(u.beamT / 2) + 1;
          for (var yy = by + 3; yy < Math.min(canvas.height, by + 14); yy++) {
            var ww = Math.floor((yy - by) * 0.45) + w;
            for (var xx = -ww; xx <= ww; xx++) {
              if (Math.random() < 0.5) px(bx + 3 + xx, yy, 'rgba(125,227,255,0.18)');
            }
          }
          u.beamT--;
        } else if (beamOn && Math.random() < 0.0022) {
          u.beamT = 40;
        }
      }
      function drawAlien(a) {
        var ax = a.x * (W / PX), ay = canvas.height - 4 + Math.round(Math.sin(a.ph + frame * 0.1) * 1.2);
        var g1 = '#4ade80', g2 = '#15803d', e = '#141021';
        px(ax + 1, ay, g1); px(ax + 2, ay, g1); px(ax + 3, ay, g1);
        px(ax, ay + 1, g1); px(ax + 4, ay + 1, g1);
        px(ax, ay + 2, g1); px(ax + 4, ay + 2, g1);
        px(ax + 1, ay + 2, e); px(ax + 3, ay + 2, e);
        px(ax + 1, ay + 3, g2); px(ax + 2, ay + 3, g2); px(ax + 3, ay + 3, g2);
        a.x += a.sp * a.dir;
        if (a.x > 0.98) a.dir = -1;
        if (a.x < 0.02) a.dir = 1;
      }
      function tick() {
        if (!alive || !document.body.contains(layer)) { alive = false; return; }
        requestAnimationFrame(tick);
        if (pauseOn && (document.hidden || !visible)) return;
        frame++;
        if (frame % 2 !== 0) return; // 30fps
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (starsOn) {
          stars.forEach(function (s) {
            s.tw += 0.06;
            var b = 0.45 + 0.55 * Math.abs(Math.sin(s.tw));
            px(s.x * canvas.width, s.y * canvas.height, 'rgba(255,255,255,' + (b * 0.5).toFixed(2) + ')');
          });
        }
        ufos.forEach(function (u) {
          u.x += u.vx * (W / PX) / canvas.width;
          if (u.x > 1.06) { u.x = -0.06; u.y = 0.08 + Math.random() * 0.5; }
          if (u.x < -0.06) { u.x = 1.06; u.y = 0.08 + Math.random() * 0.5; }
          drawUfo(u);
        });
        aliens.forEach(drawAlien);
      }
      tick();

      window.addEventListener('resize', function () { safe(resize); });
      document.addEventListener('visibilitychange', function () { });
      try {
        var io = new IntersectionObserver(function (es) { visible = es[0].isIntersecting; }, { threshold: 0.05 });
        io.observe(layer);
      } catch (e) {}
    });
  }

  function scanUfoLayers(root) {
    safe(function () { $$('.sy-ufo-layer', root).forEach(startUfos); });
  }

  /* -------------------------------------------- 7b. mini UFO page layers */
  /* Small, subtle UFOs on the client dashboard and the auth pages.
     (Admin panel mini UFOs live in syntro-admin.js.) Idempotent per route:
     stale layers are removed on every route change. */
  var syMiniPath = null;
  function ensureMiniUfos() {
    safe(function () {
      var path = location.pathname;
      if (syMiniPath === path) return; // already handled for this route
      syMiniPath = path;
      $$('.sy-ufo-layer.sy-ufo-mini[data-sy-page-layer]').forEach(function (n) { n.remove(); });
      var authPage = /^\/(auth|login|register)/.test(path);
      var dashPage = path === '/' || path === '';
      if (/^\/server\//.test(path)) return;
      var want = null;
      if (authPage && isOn('console', 'mini_ufo_auth')) want = 'auth';
      if (dashPage && isOn('console', 'mini_ufo_dashboard')) want = 'dash';
      if (!want) return;
      var layer = document.createElement('div');
      layer.className = 'sy-ufo-layer sy-ufo-mini';
      layer.setAttribute('data-sy-ufo-mode', 'mini');
      layer.setAttribute('data-sy-page-layer', want);
      document.body.appendChild(layer);
      startUfos(layer);
    });
  }

  /* ------------------------------------------- 7c. server pages sidebar */
  /* Nebula-style server navigation: the old horizontal sub-navigation bar
     becomes a left sidebar. Default Pterodactyl pages (Console, Files,
     Databases, Settings...) come FIRST, extension tools (Version Changer,
     Player Manager, ...) are grouped under a category heading at the very
     BOTTOM — and only appear when those extensions are actually installed. */
  var SY_SUBNAV_ORDER = ['console', 'files', 'databases', 'schedules', 'users', 'backups', 'network', 'startup', 'settings', 'admin'];
  var SY_SUBNAV_LABELS = { console: 'Console', files: 'Files', databases: 'Databases', schedules: 'Schedules', users: 'Users', backups: 'Backups', network: 'Network', startup: 'Startup', settings: 'Settings', admin: 'Admin' };

  function syRevertServerSidebar() {
    safe(function () {
      $$('[data-sy-ss-host]').forEach(function (host) {
        host.classList.remove('sy-ss-host');
        host.style.display = host.getAttribute('data-sy-ss-display') || '';
        host.removeAttribute('data-sy-ss-host');
        if (host.getAttribute('data-sy-ss-style')) {
          host.setAttribute('style', host.getAttribute('data-sy-ss-style') || '');
          host.removeAttribute('data-sy-ss-style');
        }
      });
      var side = document.getElementById('syServerSide');
      if (side) side.remove();
      document.body.classList.remove('sy-has-server-side');
    });
  }

  function commonAncestor(els) {
    if (!els.length) return null;
    function containsAll(el) { return els.every(function (e) { return el.contains(e); }); }
    var node = els[0];
    while (node && node !== document.body) {
      if (containsAll(node)) return node;
      node = node.parentElement;
    }
    return document.body;
  }

  var sySidebarPath = null;
  function buildServerSidebar() {
    safe(function () {
      var path = location.pathname;
      var existing = document.getElementById('syServerSide');
      if (sySidebarPath === path) {
        if (existing) {
          /* cheap re-assert: React may reset our inline style on re-render */
          var host0 = $('[data-sy-ss-host]');
          if (host0 && host0.style.display !== 'none') host0.style.display = 'none';
          return;
        }
        if (!$('[data-sy-ss-host]')) return; /* nothing to do on this route */
      }
      sySidebarPath = path;
      syRevertServerSidebar();
      if (!isOn('layout', 'server_sidebar')) return;
      if (window.innerWidth < 1024) return; // keep the native responsive bar on small screens
      var m = location.pathname.match(/^\/server\/([a-z0-9-]{8,})/i);
      if (!m) return;
      var base = '/server/' + m[1] + '/';

      /* collect the sub-navigation links for this server */
      var links = $$('a[href^="' + base + '"]').filter(function (a) {
        var sub = a.getAttribute('href').slice(base.length).replace(/[?#].*$/, '').replace(/\/$/, '');
        return sub.length > 0 && SY_SUBNAV_ORDER.indexOf(sub) !== -1;
      });
      var allLinks = $$('a[href^="' + base + '"]');
      /* extension links = same prefix but a sub-path we don't know */
      var extLinks = allLinks.filter(function (a) {
        var sub = a.getAttribute('href').slice(base.length).replace(/[?#].*$/, '').replace(/\/$/, '');
        if (!sub || SY_SUBNAV_ORDER.indexOf(sub) !== -1) return false;
        /* must sit inside the same nav strip as the known links to count */
        var r = a.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.top < 260;
      });

      var host = commonAncestor(links);
      if (!host || host === document.body || links.length < 4) return;

      /* remember + hide the original horizontal bar */
      host.setAttribute('data-sy-ss-host', '1');
      host.setAttribute('data-sy-ss-display', host.style.display || '');
      host.classList.add('sy-ss-host');
      host.style.display = 'none';

      /* measure the client sidebar + topbar so our rail sits neatly inside */
      var left = 20, top = 64;
      var navEl = $('nav');
      if (navEl) {
        var nr = navEl.getBoundingClientRect();
        if (nr.width > 40 && nr.width < 420) left = Math.ceil(nr.right + 14);
        else if (nr.left <= 0 && nr.width < 420) left = Math.ceil(nr.width + 14);
        if (nr.bottom > 30 && nr.bottom < 140) top = Math.ceil(nr.bottom + 14);
      }
      var bar = $('[id*="avigation" i]');
      if (bar) {
        var br = bar.getBoundingClientRect();
        if (br.bottom > 30 && br.bottom < 160) top = Math.ceil(br.bottom + 14);
      }
      var foot = document.querySelector('.sy-footer-fixed');
      var bottom = foot ? 58 : 20;

      /* build the sidebar */
      var side = document.createElement('aside');
      side.id = 'syServerSide';
      side.className = 'sy-server-side' + (MOTION_ON && isOn('animations', 'sidebar_anims') ? ' sy-ss-anims' : '');
      var html = '<div class="sy-ss-head">' +
        '<span class="sy-ss-dot"></span>' + 'SERVER' + '</div>';

      function item(a, sub) {
        var label = (a.textContent || '').trim() || SY_SUBNAV_LABELS[sub] || sub;
        var active = location.pathname.replace(/\/+$/, '') === a.getAttribute('href').replace(/\/+$/, '');
        return '<a class="sy-ss-item' + (active ? ' is-active' : '') + '" data-sy-ss-href="' + a.getAttribute('href') + '">' +
          '<span class="sy-ss-ico sy-ss-ico-' + sub + '"></span><span>' + label + '</span></a>';
      }

      /* 1) default Pterodactyl pages first, in the classic order */
      var done = {};
      html += '<div class="sy-ss-cat">MANAGE</div>';
      SY_SUBNAV_ORDER.forEach(function (sub) {
        var hit = null;
        links.forEach(function (a) {
          if (hit) return;
          var s = a.getAttribute('href').slice(base.length).replace(/[?#].*$/, '').replace(/\/$/, '');
          if (s === sub) hit = a;
        });
        if (hit) { html += item(hit, sub); done[sub] = true; }
      });
      links.forEach(function (a) {
        var s = a.getAttribute('href').slice(base.length).replace(/[?#].*$/, '').replace(/\/$/, '');
        if (!done[s]) { html += item(a, s); done[s] = true; }
      });

      /* 2) extension tools LAST, under their own category — only when
            such extensions are actually installed on this panel */
      if (extLinks.length) {
        var cat = (get('layout', 'sidebar_ext_category', 'MINECRAFT') || 'MINECRAFT').toUpperCase();
        html += '<div class="sy-ss-cat sy-ss-cat-ext"><span class="sy-ss-extline"></span>' + cat + '</div>';
        extLinks.forEach(function (a) {
          var sub = a.getAttribute('href').slice(base.length).replace(/[?#].*$/, '').replace(/\/$/, '');
          html += item(a, 'ext-' + (sub || 'tool'));
        });
      }

      side.innerHTML = html;
      side.style.top = top + 'px';
      side.style.left = left + 'px';
      side.style.bottom = bottom + 'px';
      document.body.appendChild(side);

      /* SPA-friendly: clicking a sidebar item re-clicks the hidden original link */
      side.addEventListener('click', function (ev) {
        var a = ev.target && ev.target.closest ? ev.target.closest('.sy-ss-item') : null;
        if (!a) return;
        ev.preventDefault();
        var href = a.getAttribute('data-sy-ss-href');
        var orig = $$('a[href="' + href + '"]').filter(function (x) { return !x.closest('#syServerSide'); })[0];
        if (orig) { orig.click(); }
        else { location.href = href; }
        $$('.sy-ss-item', side).forEach(function (x) { x.classList.remove('is-active'); });
        a.classList.add('is-active');
      });

      /* shift the page content right so nothing hides under the rail */
      var parent = host.parentElement;
      if (parent && parent !== document.body) {
        parent.setAttribute('data-sy-ss-style', parent.getAttribute('style') || '');
        parent.style.setProperty('padding-left', '216px', 'important');
      }
      document.body.classList.add('sy-has-server-side');
    });
  }

  /* ------------------------------------------------------- 8. observer */
  var pending = false;
  function schedulePass() {
    if (pending) return;
    pending = true;
    setTimeout(function () {
      pending = false;
      safe(function () { scanPass(document); });
    }, 120);
  }

  function scanPass(root) {
    replaceEmojis(root);
    scanLetters(root);
    scanIcons(root);
    scanUfoLayers(root);
    applyNavBrand();
    ensureMiniUfos();
    buildServerSidebar();
  }

  function startObserver() {
    var t;
    try {
      var mo = new MutationObserver(function () {
        clearTimeout(t);
        t = setTimeout(schedulePass, 90);
      });
      mo.observe(document.body, { childList: true, subtree: true });
    } catch (e) {}
    // route change watcher (SPA)
    var lastPath = location.pathname;
    setInterval(function () {
      if (location.pathname !== lastPath) {
        lastPath = location.pathname;
        setTimeout(function () { safe(function () { boot(true); }); }, 60);
      }
      scanUfoLayers(document);
    }, 700);
  }

  /* ------------------------------------------------------------ 9. boot */
  function boot(soft) {
    safe(applyCssVars);
    safe(applyBodyClasses);
    safe(applyOverlays);
    if (!soft) { safe(applySeo); }
    safe(scanPass(document));
    safe(applyFooter);
    safe(loadServerMap);
    dbg('boot', soft ? 'soft' : 'full');
  }

  // load egg icons map lazily (only when server list visible)
  if (/^\/($|\/?$|server|admin)/.test(location.pathname) || true) { /* cheap; guarded by fetch fail */ }

  boot(false);
  startObserver();
})();
