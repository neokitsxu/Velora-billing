import React, { useEffect } from 'react';

interface SyntroSettings {
  brand?: { name?: string; logo_url?: string; logo_mark_url?: string };
  authpages?: {
    logo?: string | boolean;
    welcome_title?: string;
    welcome_text?: string;
    card_glass?: string | boolean;
    gradient_border?: string | boolean;
  };
  [key: string]: any;
}

const cfg: SyntroSettings = (window as any).Syntro || {};

const showLogo = String(cfg?.authpages?.logo ?? 'true') !== 'false';
const title = cfg?.authpages?.welcome_title || 'WELCOME BACK';
const text = cfg?.authpages?.welcome_text || 'Log in to manage your servers';
const logo = cfg?.brand?.logo_mark_url || cfg?.brand?.logo_url || '/extensions/syntro/img/logo-mark.png';

/** Apply glass + gradient classes to the auth card (DOM-level, re-applied). */
function decorateCard() {
  try {
    const forms = document.querySelectorAll('form');
    for (let i = 0; i < forms.length; i++) {
      const form = forms[i];
      if (!form.closest('main') && !form.closest('#app')) continue;
      let card: HTMLElement | null = form.parentElement;
      while (card && card !== document.body) {
        const cls = card.className || '';
        if (typeof cls === 'string' && cls.includes('bg-')) {
          card.classList.add('sy-auth-card');
          if (String(cfg?.authpages?.card_glass ?? 'true') !== 'false') card.classList.add('sy-auth-glass');
          if (String(cfg?.authpages?.gradient_border ?? 'true') !== 'false') card.classList.add('sy-auth-gradient');
          return;
        }
        card = card.parentElement;
      }
    }
  } catch (e) {
    /* decorative only */
  }
}

/**
 * Syntro theme — branding block above the login / register form.
 */
export default () => {
  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    for (let i = 0; i < 12; i++) {
      timers.push(setTimeout(decorateCard, 150 * i));
    }
    return () => timers.forEach(clearTimeout);
  }, []);

  if (!showLogo) return null;

  return (
    <div className={'sy-auth-brand'}>
      <img src={logo} alt={cfg?.brand?.name || 'logo'} />
      <div className={'sy-auth-title'}>{title}</div>
      <div className={'sy-auth-sub'}>{text}</div>
    </div>
  );
};
