import React, { useEffect, useRef } from 'react';

interface ConsoleCfg {
  ufo_enabled?: string | boolean;
  ufo_count?: number;
  ufo_speed?: string;
  aliens?: string | boolean;
  alien_count?: number;
  stars?: string | boolean;
  star_density?: number;
  beam?: string | boolean;
  pause_hidden?: string | boolean;
  [key: string]: any;
}

const cfg: ConsoleCfg = ((window as any).Syntro?.console || {}) as ConsoleCfg;
const on = (v: string | boolean | undefined, dflt = true) =>
  v === undefined ? dflt : String(v) !== 'false';
const nOr = (v: any, d: number) => {
  const n = parseFloat(String(v));
  return isNaN(n) ? d : n;
};

interface Ufo { x: number; y: number; vx: number; ph: number; light: number; beamT: number; }
interface Alien { x: number; dir: number; ph: number; sp: number; }
interface Star { x: number; y: number; tw: number; }

/**
 * Syntro theme — console FX: pixel UFOs flying over the server console,
 * little aliens walking along the bottom edge, twinkling stars.
 */
export default () => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const layer = ref.current;
    if (!layer) return;
    if (!on(cfg.ufo_enabled)) return;

    const canvas = document.createElement('canvas');
    layer.appendChild(canvas);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let W = 0, H = 0;
    const PX = 4;
    const speedMul: Record<string, number> = { slow: 0.55, normal: 1, fast: 1.7 };
    const mul = speedMul[cfg.ufo_speed || 'normal'] || 1;
    const ufoCount = Math.max(1, Math.min(6, nOr(cfg.ufo_count, 3)));
    const alienCount = on(cfg.aliens) ? Math.max(1, Math.min(5, nOr(cfg.alien_count, 2))) : 0;
    const starsOn = on(cfg.stars);
    const density = nOr(cfg.star_density, 40);
    const beamOn = on(cfg.beam);
    const pauseOn = on(cfg.pause_hidden);

    let alive = true;
    let visible = true;
    let frame = 0;

    const resize = () => {
      const r = layer.getBoundingClientRect();
      W = Math.max(80, Math.floor(r.width));
      H = Math.max(60, Math.floor(r.height));
      canvas.width = Math.max(10, Math.floor(W / PX));
      canvas.height = Math.max(10, Math.floor(H / PX));
      ctx.imageSmoothingEnabled = false;
    };
    resize();

    const mkUfo = (): Ufo => ({
      x: Math.random(), y: 0.08 + Math.random() * 0.5,
      vx: (0.0016 + Math.random() * 0.0022) * (Math.random() > 0.5 ? 1 : -1) * mul,
      ph: Math.random() * 6.28, light: 0, beamT: 0,
    });
    const mkAlien = (): Alien => ({
      x: Math.random(), dir: Math.random() > 0.5 ? 1 : -1,
      ph: Math.random() * 6.28, sp: (0.0012 + Math.random() * 0.001) * mul,
    });

    const ufos: Ufo[] = [];
    for (let i = 0; i < ufoCount; i++) ufos.push(mkUfo());
    const aliens: Alien[] = [];
    for (let j = 0; j < alienCount; j++) aliens.push(mkAlien());
    const stars: Star[] = [];
    const starN = Math.min(90, Math.floor((W * H) / 26000 * (density / 40)));
    for (let k = 0; k < starN; k++) {
      stars.push({ x: Math.random(), y: Math.random() * 0.8, tw: Math.random() * 6.28 });
    }

    const px = (x: number, y: number, c: string) => {
      ctx!.fillStyle = c;
      ctx!.fillRect(Math.round(x), Math.round(y), 1, 1);
    };

    const drawUfo = (u: Ufo) => {
      const bx = u.x * canvas.width;
      const by = (u.y + Math.sin(u.ph + frame * 0.04) * 0.012) * canvas.height;
      if (bx < -10 || bx > canvas.width + 10) return;
      const flip = (dx: number) => (u.vx > 0 ? dx : 6 - dx);
      px(bx + flip(3), by - 1, '#7de3ff');
      px(bx + flip(2), by, '#7de3ff');
      px(bx + flip(3), by, '#a5f0ff');
      px(bx + flip(4), by, '#7de3ff');
      for (let dx = 0; dx < 7; dx++) px(bx + flip(dx), by + 1, '#5a5178');
      px(bx + flip(1), by + 1, '#6f669a');
      px(bx + flip(5), by + 1, '#6f669a');
      u.light = (u.light + 1) % 30;
      const lc = u.light < 15 ? '#f97316' : '#fbbf24';
      px(bx + flip(1), by + 2, lc);
      px(bx + flip(3), by + 2, lc);
      px(bx + flip(5), by + 2, lc);
      if (beamOn && u.beamT > 0) {
        const w = Math.floor(u.beamT / 2) + 1;
        for (let yy = by + 3; yy < Math.min(canvas.height, by + 14); yy++) {
          const ww = Math.floor((yy - by) * 0.45) + w;
          for (let xx = -ww; xx <= ww; xx++) {
            if (Math.random() < 0.5) px(bx + 3 + xx, yy, 'rgba(125,227,255,0.18)');
          }
        }
        u.beamT--;
      } else if (beamOn && Math.random() < 0.0022) {
        u.beamT = 40;
      }
    };

    const drawAlien = (a: Alien) => {
      const ax = a.x * canvas.width;
      const ay = canvas.height - 4 + Math.round(Math.sin(a.ph + frame * 0.1) * 1.2);
      const g1 = '#4ade80', g2 = '#15803d', e = '#141021';
      px(ax + 1, ay, g1); px(ax + 2, ay, g1); px(ax + 3, ay, g1);
      px(ax, ay + 1, g1); px(ax + 4, ay + 1, g1);
      px(ax, ay + 2, g1); px(ax + 4, ay + 2, g1);
      px(ax + 1, ay + 2, e); px(ax + 3, ay + 2, e);
      px(ax + 1, ay + 3, g2); px(ax + 2, ay + 3, g2); px(ax + 3, ay + 3, g2);
      a.x += a.sp * a.dir;
      if (a.x > 0.98) a.dir = -1;
      if (a.x < 0.02) a.dir = 1;
    };

    const tick = () => {
      if (!alive || !document.body.contains(layer)) { alive = false; return; }
      requestAnimationFrame(tick);
      if (pauseOn && (document.hidden || !visible)) return;
      frame++;
      if (frame % 2 !== 0) return;
      ctx!.clearRect(0, 0, canvas.width, canvas.height);
      if (starsOn) {
        for (const s of stars) {
          s.tw += 0.06;
          const b = 0.45 + 0.55 * Math.abs(Math.sin(s.tw));
          px(s.x * canvas.width, s.y * canvas.height, `rgba(255,255,255,${(b * 0.5).toFixed(2)})`);
        }
      }
      for (const u of ufos) {
        u.x += u.vx;
        if (u.x > 1.06) { u.x = -0.06; u.y = 0.08 + Math.random() * 0.5; }
        if (u.x < -0.06) { u.x = 1.06; u.y = 0.08 + Math.random() * 0.5; }
        drawUfo(u);
      }
      for (const a of aliens) drawAlien(a);
    };
    tick();

    const onVis = () => { visible = !document.hidden; };
    const onResize = () => resize();
    let io: IntersectionObserver | null = null;
    try {
      io = new IntersectionObserver((es) => { visible = es[0].isIntersecting; }, { threshold: 0.05 });
      io.observe(layer);
    } catch { /* optional */ }
    window.addEventListener('resize', onResize);
    document.addEventListener('visibilitychange', onVis);

    return () => {
      alive = false;
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVis);
      if (io) io.disconnect();
      try { canvas.remove(); } catch { /* ok */ }
    };
  }, []);

  if (!on(cfg.ufo_enabled)) return null;
  return <div className={'sy-ufo-layer'} ref={ref} />;
};
