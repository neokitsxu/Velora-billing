import React from 'react';

/**
 * Syntro theme — auto server icon marker.
 * Renders a slot marker inside each server row; the Syntro runtime
 * (syntro.js) fills it with the pixel icon matching the server's egg.
 */
export default () => {
  return (
    <span
      data-syntro-server-icon={'1'}
      style={{ display: 'inline-flex', verticalAlign: 'middle' }}
    />
  );
};
