import React from 'react';

interface SyntroSettings {
  brand?: { name?: string; logo_mark_url?: string };
  createserver?: { enabled?: string | boolean; button_text?: string };
  [key: string]: any;
}

const cfg: SyntroSettings = (window as any).Syntro || {};

const enabled = String(cfg?.createserver?.enabled ?? 'true') !== 'false';
const buttonText = cfg?.createserver?.button_text || 'CREATE SERVER';
const logo = cfg?.brand?.logo_mark_url || '/extensions/syntro/img/logo-mark.png';

/**
 * Syntro theme — "Create Server" banner shown above the server list.
 */
export default () => {
  if (!enabled) return null;
  return (
    <a
      href={'/account/create'}
      className={'sy-cta'}
      style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 16 }}
    >
      <img src={logo} alt={''} />
      <div style={{ flex: '1 1 auto', minWidth: 0 }}>
        <div className={'sy-cta-title'}>Deploy a fresh server</div>
        <div className={'sy-cta-sub'}>
          Pick a game, choose your resources and go live in under a minute.
        </div>
      </div>
      <span className={'sy-cta-btn'}>{buttonText}</span>
    </a>
  );
};
