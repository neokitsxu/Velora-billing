import React, { useEffect, useMemo, useState } from 'react';
import PageContentBlock from '@/components/elements/PageContentBlock';
import http from '@/api/http';

interface CatalogEntry {
  name: string;
  egg: number | null;
  icon: string;
  docker: string;
  startup: string;
  env: Record<string, string>;
  mem: number;
  cpu: number;
  disk: number;
}

interface CatalogResponse {
  enabled: boolean;
  page_title: string;
  page_desc: string;
  max_servers: number;
  max_memory: number;
  max_cpu: number;
  max_disk: number;
  backups: number;
  databases: number;
  server_count: number;
  catalog: CatalogEntry[];
}

interface CreateResponse {
  identifier: string;
  name: string;
}

interface SyntroWindow {
  brand?: { logo_mark_url?: string };
  [key: string]: any;
}

const logo = ((window as any).Syntro as SyntroWindow | undefined)?.brand?.logo_mark_url
  || '/extensions/syntro/img/logo-mark.png';

const iconUrl = (key: string) => `/extensions/syntro/icons/${key || 'egg'}.svg`;

const memLabel = (mb: number) => (mb >= 1024 ? `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} GB` : `${mb} MB`);

/**
 * Syntro theme — Create Server page (client area self-service deployment).
 */
export default () => {
  const [loading, setLoading] = useState(true);
  const [catalog, setCatalog] = useState<CatalogResponse | null>(null);
  const [selected, setSelected] = useState(0);
  const [nameStr, setName] = useState('');
  const [mem, setMem] = useState(1024);
  const [cpu, setCpu] = useState(100);
  const [disk, setDisk] = useState(2048);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState<CreateResponse | null>(null);

  useEffect(() => {
    http
      .get('/extensions/syntro/catalog')
      .then(({ data }) => {
        const c = data as CatalogResponse;
        setCatalog(c);
        if (c.catalog && c.catalog.length > 0) {
          setMem(Math.min(c.catalog[0].mem, c.max_memory));
          setCpu(Math.min(c.catalog[0].cpu, c.max_cpu));
          setDisk(Math.min(c.catalog[0].disk, c.max_disk));
        }
      })
      .catch(() => setError('Could not load the server catalog. Ask an administrator to check the Syntro theme settings.'))
      .finally(() => setLoading(false));
  }, []);

  const pick = (i: number) => {
    if (!catalog) return;
    setSelected(i);
    const e = catalog.catalog[i];
    setMem(Math.min(e.mem, catalog.max_memory));
    setCpu(Math.min(e.cpu, catalog.max_cpu));
    setDisk(Math.min(e.disk, catalog.max_disk));
  };

  const limitReached = useMemo(() => {
    if (!catalog) return false;
    return catalog.server_count >= catalog.max_servers;
  }, [catalog]);

  const submit = () => {
    if (!catalog) return;
    const entry = catalog.catalog[selected];
    if (!entry) return;
    setError('');
    if (!nameStr.trim()) { setError('Give your server a name first.'); return; }
    if (entry.egg === null || entry.egg === undefined) {
      setError('This catalog entry has no Egg ID configured yet. An administrator needs to set it in the Syntro theme editor (Admin → Extensions → Syntro theme → Create Server).');
      return;
    }
    setSubmitting(true);
    http
      .post('/extensions/syntro/createserver', {
        name: nameStr.trim(),
        egg: entry.egg,
        mem,
        cpu,
        disk,
        docker: entry.docker,
        startup: entry.startup,
        env: entry.env || {},
      })
      .then(({ data }) => setDone(data as CreateResponse))
      .catch((err: any) => {
        const msg =
          err?.response?.data?.errors?.[0]?.detail ||
          err?.response?.data?.error ||
          'Server creation failed. Try again or contact support.';
        setError(String(msg));
      })
      .finally(() => setSubmitting(false));
  };

  if (done) {
    return (
      <PageContentBlock title={'Server created'}>
        <div className={'sy-cs-wrap'}>
          <div className={'sy-cs-panel sy-cs-success'}>
            <span
              className={'sy-emoji sy-e-pulse'}
              dangerouslySetInnerHTML={{
                __html:
                  "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8' shape-rendering='crispEdges'><rect x='6' y='1' width='2' height='1' fill='#34d399'/><rect x='5' y='2' width='1' height='1' fill='#34d399'/><rect x='0' y='3' width='1' height='1' fill='#34d399'/><rect x='1' y='4' width='1' height='1' fill='#34d399'/><rect x='2' y='5' width='1' height='1' fill='#34d399'/><rect x='3' y='4' width='1' height='1' fill='#34d399'/><rect x='4' y='3' width='1' height='1' fill='#34d399'/><rect x='5' y='2' width='1' height='1' fill='#34d399'/><rect x='3' y='3' width='2' height='1' fill='#34d399'/><rect x='2' y='2' width='1' height='1' fill='#34d399'/></svg>",
              }}
            />
            <h2 style={{ marginTop: 8 }}>{done.name} is deploying</h2>
            <p style={{ color: 'var(--sy-muted, #9b93b5)', marginTop: 6, fontSize: 12.5 }}>
              Your server is being installed. It will appear in your server list shortly.
            </p>
            <a className={'sy-cs-submit'} href={'/'} style={{ display: 'inline-block', maxWidth: 260, textDecoration: 'none', textAlign: 'center' }}>
              BACK TO SERVERS
            </a>
          </div>
        </div>
      </PageContentBlock>
    );
  }

  return (
    <PageContentBlock title={'Create Server'}>
      <div className={'sy-cs-wrap'}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 6 }}>
          <img src={logo} alt={''} style={{ height: 40, imageRendering: 'pixelated' }} />
          <div>
            <h1 style={{ fontSize: 19, margin: 0 }}>
              {catalog?.page_title || 'Create a new server'}
            </h1>
            <p style={{ color: 'var(--sy-muted, #9b93b5)', fontSize: 12, margin: '4px 0 0' }}>
              {catalog?.page_desc || 'Pick a game, choose your resources and deploy.'}
            </p>
          </div>
        </div>

        {loading && <div className={'sy-cs-panel'}>LOADING CATALOG...</div>}

        {!loading && catalog && (
          <>
            {limitReached && (
              <div className={'sy-cs-error'}>
                You already have {catalog.server_count} of {catalog.max_servers} allowed servers. Delete one or ask an
                administrator to raise your limit.
              </div>
            )}

            <div className={'sy-cs-grid'} style={{ marginTop: 14 }}>
              {catalog.catalog.map((entry, i) => (
                <div
                  key={`${entry.name}-${i}`}
                  className={`sy-cs-card ${i === selected ? 'sy-cs-selected' : ''}`}
                  onClick={() => pick(i)}
                  role={'button'}
                  tabIndex={0}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') pick(i); }}
                >
                  <span className={'sy-cs-check'}>✓</span>
                  <img src={iconUrl(entry.icon)} alt={''} />
                  <h3>{entry.name}</h3>
                  <div className={'sy-cs-specs'}>
                    <span className={'sy-cs-chip'}>{memLabel(entry.mem)}</span>
                    <span className={'sy-cs-chip'}>{entry.cpu}% CPU</span>
                    <span className={'sy-cs-chip'}>{memLabel(entry.disk)} disk</span>
                    {entry.egg === null && <span className={'sy-cs-chip'}>egg not set</span>}
                  </div>
                </div>
              ))}
            </div>

            <div className={'sy-cs-panel'}>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 11, color: 'var(--sy-muted, #9b93b5)', textTransform: 'uppercase', letterSpacing: 1 }}>
                  Server name
                </label>
                <input
                  type={'text'}
                  value={nameStr}
                  maxLength={40}
                  placeholder={'My awesome server'}
                  onChange={(e) => setName(e.target.value)}
                  style={{ width: '100%', padding: '10px 12px', marginTop: 6, fontSize: 13 }}
                />
              </div>

              <div className={'sy-cs-slider-row'}>
                <label>{'MEMORY'}</label>
                <input
                  type={'range'}
                  min={256}
                  max={catalog.max_memory}
                  step={256}
                  value={mem}
                  onChange={(e) => setMem(parseInt(e.target.value, 10))}
                />
                <span className={'sy-cs-val'}>{memLabel(mem)}</span>
              </div>
              <div className={'sy-cs-slider-row'}>
                <label>{'CPU'}</label>
                <input
                  type={'range'}
                  min={25}
                  max={catalog.max_cpu}
                  step={25}
                  value={cpu}
                  onChange={(e) => setCpu(parseInt(e.target.value, 10))}
                />
                <span className={'sy-cs-val'}>{cpu}%</span>
              </div>
              <div className={'sy-cs-slider-row'}>
                <label>{'DISK'}</label>
                <input
                  type={'range'}
                  min={1024}
                  max={catalog.max_disk}
                  step={1024}
                  value={disk}
                  onChange={(e) => setDisk(parseInt(e.target.value, 10))}
                />
                <span className={'sy-cs-val'}>{memLabel(disk)}</span>
              </div>

              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 10 }}>
                <span className={'sy-cs-chip'}>{catalog.backups} backups</span>
                <span className={'sy-cs-chip'}>{catalog.databases} database{catalog.databases === 1 ? '' : 's'}</span>
              </div>

              {error && <div className={'sy-cs-error'}>{error}</div>}

              <button className={'sy-cs-submit'} onClick={submit} disabled={submitting || limitReached || loading}>
                {submitting ? 'DEPLOYING...' : 'DEPLOY SERVER'}
              </button>
            </div>
          </>
        )}
      </div>
    </PageContentBlock>
  );
};
