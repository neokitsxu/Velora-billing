<?php
/* Syntro theme — dashboard wrapper. Injected into every client + auth page. */
use Illuminate\Support\Facades\Route;

$syntroSettings = null;
try {
    $syntroRepo = app()->make('Pterodactyl\Contracts\Repository\SettingsRepositoryInterface');
    $syntroRaw = $syntroRepo->get('syntro::settings');
    if ($syntroRaw) {
        $syntroSettings = json_decode($syntroRaw, true);
    }
} catch (\Throwable $e) {
    $syntroSettings = null;
}

/* Default inline CSS variables (mirror of defaults.json) — only the ones the
   client needs. Secrets (the Application API key) are never sent to the browser. */
$syntroDefaults = [
    'brand' => ['name' => 'SpectroCloud', 'tagline' => 'Best Minecraft Server Hosting',
        'footer_text' => 'Branding made by Neokitsxu_ • SpectroCloud — Best Minecraft Server Hosting',
        'website_url' => '', 'logo_url' => '/extensions/syntro/img/logo.png',
        'logo_mark_url' => '/extensions/syntro/img/logo-mark.png', 'logo_height' => '34', 'show_logo_in_nav' => 'true'],
    'seo' => ['title_suffix' => 'SpectroCloud', 'title_mode' => 'append',
        'favicon_url' => '/extensions/syntro/img/favicon.png', 'theme_color' => '#f97316',
        'meta_description' => 'SpectroCloud — Best Minecraft Server Hosting. Powered by Syntro theme.', 'og_image' => ''],
    'background' => ['enabled' => 'true', 'url' => '/extensions/syntro/img/bg.jpg', 'overlay' => '72',
        'blur' => '0', 'vignette' => 'true', 'fixed' => 'true', 'scanlines' => 'true', 'scanline_opacity' => '4'],
    'colors' => ['primary' => '#f97316', 'secondary' => '#a78bfa', 'accent' => '#fbbf24',
        'surface' => '#141021', 'surface_opacity' => '88', 'surface_border' => '#2c2344',
        'text' => '#f3eefe', 'text_muted' => '#9b93b5', 'success' => '#34d399', 'warning' => '#fbbf24',
        'danger' => '#f87171', 'info' => '#38bdf8', 'link' => '#f0a868', 'bg_tint' => '#0d0a18'],
    'typography' => ['font' => 'Monocraft', 'body_size' => '14', 'heading_size' => '20',
        'letter_spacing' => '0.5', 'line_height' => '1.7', 'text_glow' => 'true',
        'glow_color' => 'rgba(249,115,22,0.35)', 'uppercase_headings' => 'true', 'heading_weight' => '700'],
    'corners' => ['radius' => '8', 'radius_btn' => '6', 'radius_input' => '6', 'radius_card' => '12', 'container_width' => '1200'],
    'effects' => ['glass_blur' => '10', 'glow_strength' => '30', 'shadow_strength' => '60',
        'gradient_enabled' => 'true', 'animated_gradient' => 'true', 'border_glow' => 'true',
        'noise' => 'false', 'hover_lift' => 'true', 'focus_glow' => 'true', 'image_rendering' => 'pixelated'],
    'animations' => ['enabled' => 'true', 'page_entrance' => 'true', 'letters_enabled' => 'true',
        'letters_speed' => '480', 'letters_stagger' => '28', 'hover_anims' => 'true',
        'button_pulse' => 'false', 'sidebar_anims' => 'true', 'card_entrance' => 'true'],
    'emoji' => ['enabled' => 'true', 'size' => '20', 'style' => 'pixel', 'idle_anim' => 'true',
        'map_check' => 'true', 'map_warn' => 'true', 'map_faces' => 'true', 'map_misc' => 'true'],
    'servericons' => ['enabled' => 'true', 'style' => 'glow', 'size' => '34', 'default_icon' => 'egg',
        'animation' => 'bob', 'show_in_list' => 'true'],
    'console' => ['ufo_enabled' => 'true', 'ufo_count' => '3', 'ufo_speed' => 'normal', 'aliens' => 'true',
        'alien_count' => '2', 'stars' => 'true', 'star_density' => '40', 'beam' => 'true', 'pause_hidden' => 'true',
        'mini_ufo_dashboard' => 'true', 'mini_ufo_admin' => 'true', 'mini_ufo_auth' => 'true'],
    'authpages' => ['logo' => 'true', 'welcome_title' => 'WELCOME BACK',
        'welcome_text' => 'Log in to manage your servers', 'card_glass' => 'true',
        'gradient_border' => 'true', 'blur_bg' => 'true', 'anims' => 'true'],
    'createserver' => ['enabled' => 'true', 'admin_quick_actions' => 'true', 'button_text' => 'CREATE SERVER',
        'page_title' => 'Create a new server',
        'page_desc' => 'Spin up your own server in seconds. Pick a game, choose your resources and deploy.',
        'max_servers' => '2', 'max_memory' => '4096', 'max_cpu' => '200', 'max_disk' => '10240',
        'backups' => '2', 'databases' => '1'],
    'layout' => ['sidebar_style' => 'glass', 'sidebar_compact' => 'false', 'topbar_blur' => 'true',
        'footer' => 'true', 'footer_pos' => 'fixed', 'stats_cards' => 'true', 'container_padding' => '24',
        'server_sidebar' => 'true', 'sidebar_ext_category' => 'MINECRAFT'],
    'advanced' => ['custom_css' => '', 'admin_emoji' => 'true', 'debug' => 'false'],
];

$syntroMerged = $syntroDefaults;
if (is_array($syntroSettings)) {
    foreach ($syntroSettings as $sec => $vals) {
        if (isset($syntroMerged[$sec]) && is_array($vals)) {
            $syntroMerged[$sec] = array_merge($syntroMerged[$sec], $vals);
        }
    }
}
$syntroMerged['meta'] = ['path' => '/extensions/syntro', 'version' => '1.2.0'];

/* Security: never expose server-side secrets to the browser. */
unset($syntroMerged['createserver']['ptla_key']);
?>
<!-- v1.2.0: fonts + default background are injected here as RUNTIME styles.
     They must NEVER go into dashboard.css — that file is compiled by the
     panel's webpack build, which cannot resolve absolute /extensions/ urls. -->
<style data-syntro-fonts>
    @font-face {
      font-family: 'Monocraft';
      src: url('/extensions/syntro/fonts/Monocraft.ttf') format('truetype');
      font-weight: 400;
      font-style: normal;
      font-display: swap;
    }
    @font-face {
      font-family: 'Monocraft';
      src: url('/extensions/syntro/fonts/Monocraft-Bold.ttf') format('truetype');
      font-weight: 700;
      font-style: normal;
      font-display: swap;
    }
    :root { --sy-bg: url('/extensions/syntro/img/bg.jpg'); }
</style>
<script>
    window.Syntro = @json($syntroMerged);
</script>
<script src="/extensions/syntro/js/syntro.js?v=1.2.0" defer></script>
@if(!empty($syntroMerged['advanced']['custom_css']))
    <style data-syntro-custom>{!! $syntroMerged['advanced']['custom_css'] !!}</style>
@endif
