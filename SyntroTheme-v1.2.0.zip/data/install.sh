#!/bin/bash

# Syntro theme — install script
# Blueprint runs this as the webserver user. The theme needs no core file
# edits: everything is wired through Blueprint's official extension APIs
# (dashboard.css, wrappers, components, client router). We only refresh
# caches so Blade views and config are picked up immediately.

set -u

echo "[Syntro] Finishing installation..."

if command -v php >/dev/null 2>&1; then
  php artisan view:clear >/dev/null 2>&1 || true
  php artisan config:clear >/dev/null 2>&1 || true
else
  echo "[Syntro] php not found in PATH — skipped cache refresh (run 'php artisan view:clear' manually)."
fi

# Make sure the public asset tree is web-readable
if [ -d "{root/public}" ]; then
  chmod -R a+rX "{root/public}" 2>/dev/null || true
fi

echo "[Syntro] Done! Open Admin Area -> Extensions -> Syntro theme to configure your panel."
