#!/bin/bash

# Syntro theme — remove script
# Blueprint unbinds the extension's files, wrappers, components and routes
# automatically. We only clear caches so the stock look returns instantly.

set -u

echo "[Syntro] Removing theme leftovers..."

if command -v php >/dev/null 2>&1; then
  php artisan view:clear >/dev/null 2>&1 || true
  php artisan config:clear >/dev/null 2>&1 || true
fi

echo "[Syntro] Theme removed. Your panel is back to the stock look."
