# Syntro theme — for Pterodactyl (Blueprint extension)

**Version 1.2.0** • by Neokitsxu_ • SpectroCloud — Best Minecraft Server Hosting

A full Nebula-style makeover for your Pterodactyl panel, built on Blueprint's
official extension APIs. Works **only with the Blueprint framework installed**.

## What's new in 1.2.0

- **FIXED: `yarn build:production` failure** — *"Error: Can't resolve
  '/extensions/syntro/fonts/Monocraft.ttf'"*. The Monocraft `@font-face` rules
  and the default background url used to live in `dashboard.css`, which is
  compiled by the panel's webpack build — and stock Pterodactyl webpack has no
  loader for `.ttf` files, so every install/rebuild crashed. They are now
  injected as **runtime styles by the dashboard/admin wrappers**, which is
  100% build-safe on every Blueprint + panel version.
- If you already installed v1.1.0 and your rebuild failed, install this
  version on top (see the hotfix note in the support message / README section
  "Upgrading from 1.1.0").

## What's new in 1.1.0

- **Create Server is now admin-panel only (Nebula-style)** — the client area no
  longer shows a Create Server route or banner. Instead, the **admin dashboard**
  gets Syntro quick action cards: **Create Server**, **Console Dashboard** and
  **Nodes**.
- **Server pages get a real navigation sidebar** — the old horizontal top bar is
  replaced by a left sidebar: default Pterodactyl pages first (Console, Files,
  Databases, Schedules, Users, Backups, Network, Startup, Settings), and
  **extension tools last**, grouped under a **MINECRAFT** category
  (Version Changer, Player Manager, ...). The category only appears when such
  Blueprint extensions are actually installed.
- **Mini UFOs everywhere** — small, subtle UFO flybys on the client dashboard,
  across the admin panel, and on the login/register pages (each toggleable).
  The server console keeps the big UFO + alien + tractor-beam show.

## What you get

- **Minecraft pixel typography** — every word and letter uses Monocraft, animated per-letter on headings
- **Your background on every page** — client area, login, register, server pages (custom URL supported)
- **SyntroMoji** — 16 custom animated pixel emojis that replace boring Unicode emojis (💳 ✅ 😶 and friends)
- **Theme editor (130+ options)** — Admin → Extensions → Syntro theme: colors, fonts, effects, animations, branding, SEO, layout, navigation — with live preview, import/export and reset
- **Editable branding** — brand name, tagline, footer text, website URL, logos
- **SEO & browser identity** — title suffix, favicon, theme color, meta description, OG image
- **Admin quick actions** — Create Server + Console Dashboard cards on the admin dashboard
- **Auto server icons** — pixel icons matched to each server's egg (Minecraft, Node.js, Python, bots, ...)
- **Login / Register makeover** — glass card, animated gradient border, floating logo — plus mini UFOs
- **Console UFOs & aliens** — pixel UFOs fly over the server console, aliens walk the bottom edge, stars twinkle
- **Stable animations** — GPU-friendly, honors `prefers-reduced-motion`, global kill-switch in the editor

## Requirements

| Requirement | Version |
| --- | --- |
| Pterodactyl panel | 1.11.x |
| Blueprint | **beta-2026-08** (target; newer usually fine) |
| Node.js + Yarn | for the frontend rebuild during install |

## Install

```bash
cd /var/www/pterodactyl
blueprint -i SyntroTheme-v1.2.0.blueprint
```

### Upgrading from 1.1.0 (rebuild already broken)

If v1.1.0 left your panel with a failed `yarn build:production`, run this once
to clean the cached css, then install v1.2.0:

```bash
cd /var/www/pterodactyl
# 1) remove the two Monocraft @font-face blocks from the cached css
perl -0pi -e 's/@font-face \{[^}]*Monocraft[^}]*\}\n?//g' resources/scripts/blueprint/css/extensions.css
# 2) neutralise the absolute background url
sed -i "s#--sy-bg: url('/extensions/syntro/img/bg.jpg')#--sy-bg: none#g" resources/scripts/blueprint/css/extensions.css
# 3) rebuild — this time it passes
yarn build:production && chown -R www-data:www-data resources public
# 4) install v1.2.0 (brings the pixel font back via the wrapper, build-safe)
blueprint -i SyntroTheme-v1.2.0.blueprint
```

(The first two commands only touch Syntro's own rules — other extensions'
fonts/backgrounds are left alone. v1.2.0 never writes them there again.)

Then configure: **Admin Area → Extensions → Syntro theme**.

### Navigation (server sidebar)

- Default pages (Console, Files, Databases, ...) always come **first**, in the
  classic order — exactly like the old default top bar.
- Anything another Blueprint extension adds to the server navigation is grouped
  at the **bottom** under the **MINECRAFT** category (rename it in the editor:
  Layout & Navigation → Extension category name). No extension installed →
  no category. Toggle the whole sidebar under
  **Layout & Navigation → Console sidebar**.

## Uninstall

```bash
blueprint -r syntro
```

The stock panel look returns immediately (no core files are ever modified).

## Notes

- Monocraft font (SIL OFL 1.1) by Idrees Hassan — https://github.com/IdreesInc/Monocraft
- The theme stores its settings in the panel's `settings` table under `syntro::*`; the Application API key is stored in a separate record and is **never** sent to browsers.
- Everything is reversible: no Pterodactyl core files are edited. The theme only uses official Blueprint binds (dashboard.css, wrappers, components, client router).
