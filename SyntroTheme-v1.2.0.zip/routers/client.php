<?php

/* Syntro theme — client API routes.
   Prefixed by Blueprint with /api/client/extensions/syntro */

use Illuminate\Support\Facades\Route;
use {appcontext}\SyntroApiController;

Route::get('/catalog', [SyntroApiController::class, 'catalog']);
Route::get('/servers', [SyntroApiController::class, 'servers']);
Route::post('/createserver', [SyntroApiController::class, 'createserver']);
