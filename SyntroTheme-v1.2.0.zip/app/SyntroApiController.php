<?php

/*
 * Syntro theme — client API controller.
 * Handles the Create Server self-service deployment, the egg catalog and
 * the server-icon mapping used by the dashboard.
 */

namespace {appcontext};

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\Egg;

class SyntroApiController extends ClientApiController
{
    /** Map an egg name/identifier to a pixel icon key. */
    public static function eggIcon(?string $name, ?string $identifier): string
    {
        $h = strtolower(($name ?: '') . ' ' . ($identifier ?: ''));
        $map = [
            'paper' => 'paper',
            'fabric' => 'fabric',
            'forge' => 'forge',
            'quilt' => 'fabric',
            'bungee' => 'proxy',
            'velocity' => 'proxy',
            'waterfall' => 'proxy',
            'proxy' => 'proxy',
            'nodejs' => 'nodejs',
            'node js' => 'nodejs',
            'node ' => 'nodejs',
            'discord' => 'discordbot',
            'bot' => 'discordbot',
            'python' => 'python',
            'rust' => 'rust',
            'source' => 'source',
            'cs16' => 'source',
            'csgo' => 'source',
            'counter' => 'source',
            'gmod' => 'source',
            'garrysmod' => 'source',
            'terraria' => 'terraria',
            'valheim' => 'valheim',
            'ark' => 'ark',
            'database' => 'database',
            'mongodb' => 'database',
            'mysql' => 'database',
            'postgres' => 'database',
            'redis' => 'database',
            'minecraft' => 'minecraft',
            'vanilla' => 'minecraft',
            'spigot' => 'minecraft',
            'purpur' => 'minecraft',
            'bukkit' => 'minecraft',
            'sponge' => 'minecraft',
            'bedrock' => 'minecraft',
            'ftb' => 'minecraft',
            'modpack' => 'minecraft',
        ];
        foreach ($map as $needle => $icon) {
            if (str_contains($h, $needle)) {
                return $icon;
            }
        }

        return 'egg';
    }

    private function settings(): SettingsRepositoryInterface
    {
        return app()->make(SettingsRepositoryInterface::class);
    }

    private function cfg(): array
    {
        $raw = $this->settings()->get('syntro::settings');
        $cfg = $raw ? json_decode($raw, true) : null;

        return is_array($cfg) ? $cfg : [];
    }

    private function catalogEntries(array $cfg): array
    {
        $entries = json_decode($cfg['createserver']['catalog'] ?? '[]', true);

        return is_array($entries) ? $entries : [];
    }

    /** Public catalog (no secrets). */
    public function catalog(Request $request): JsonResponse
    {
        $cfg = $this->cfg();
        $cs = $cfg['createserver'] ?? [];
        $enabled = ($cs['enabled'] ?? 'true') !== 'false';

        return response()->json([
            'enabled' => $enabled,
            'page_title' => $cs['page_title'] ?? 'Create a new server',
            'page_desc' => $cs['page_desc'] ?? 'Pick a game, choose your resources and deploy.',
            'max_servers' => (int) ($cs['max_servers'] ?? 2),
            'max_memory' => (int) ($cs['max_memory'] ?? 4096),
            'max_cpu' => (int) ($cs['max_cpu'] ?? 200),
            'max_disk' => (int) ($cs['max_disk'] ?? 10240),
            'backups' => (int) ($cs['backups'] ?? 2),
            'databases' => (int) ($cs['databases'] ?? 1),
            'server_count' => Server::query()->where('owner_id', $request->user()->id)->count(),
            'catalog' => $this->catalogEntries($cfg),
        ]);
    }

    /** Current user's servers + icon key (for auto server icons). */
    public function servers(Request $request): JsonResponse
    {
        $out = [];
        $servers = Server::query()
            ->where('owner_id', $request->user()->id)
            ->with('egg:id,uuid,name,identifier')
            ->get(['id', 'uuid', 'name', 'egg_id']);

        foreach ($servers as $server) {
            $egg = $server->egg;
            $out[] = [
                'uuid' => $server->uuid,
                'name' => $server->name,
                'icon' => self::eggIcon($egg->name ?? null, $egg->identifier ?? null),
            ];
        }

        return response()->json(['data' => $out]);
    }

    /** Create a server through the Application API using the stored key. */
    public function createserver(Request $request): JsonResponse
    {
        $cfg = $this->cfg();
        $cs = $cfg['createserver'] ?? [];

        if (($cs['enabled'] ?? 'true') === 'false') {
            return response()->json(['error' => 'Server creation is disabled.'], 403);
        }

        $data = $request->validate([
            'name' => 'required|string|min:1|max:60',
            'egg' => 'required|integer',
            'mem' => 'required|integer|min:128|max:262144',
            'cpu' => 'required|integer|min:5|max:1600',
            'disk' => 'required|integer|min:512|max:1048576',
            'docker' => 'required|string|max:250',
            'startup' => 'nullable|string|max:500',
            'env' => 'nullable|array',
            'env.*' => 'string|max:500',
        ]);

        // Policy: per-user server limit
        $maxServers = (int) ($cs['max_servers'] ?? 2);
        $count = Server::query()->where('owner_id', $request->user()->id)->count();
        if ($count >= $maxServers) {
            return response()->json(['error' => "You already have $count of $max_servers allowed servers."], 422);
        }

        // Policy: resource caps
        $mem = min($data['mem'], (int) ($cs['max_memory'] ?? 4096));
        $cpu = min($data['cpu'], (int) ($cs['max_cpu'] ?? 200));
        $disk = min($data['disk'], (int) ($cs['max_disk'] ?? 10240));

        // Find the matching catalog entry (node/location + env defaults)
        $entry = null;
        foreach ($this->catalogEntries($cfg) as $e) {
            if ((int) ($e['egg'] ?? -1) === (int) $data['egg']) {
                $entry = $e;
                break;
            }
        }

        $ptla = $cs['ptla_key'] ?? '';
        $baseUrl = rtrim($cs['panel_url'] ?: config('app.url') ?: '', '/');
        if (!$ptla || !$baseUrl) {
            return response()->json(['error' => 'The administrator has not finished configuring server creation (missing Application API key).'], 503);
        }

        $payload = [
            'name' => $data['name'],
            'user' => $request->user()->id,
            'egg' => (int) $data['egg'],
            'docker_image' => $data['docker'],
            'startup' => $data['startup'] ?? ($entry['startup'] ?? ''),
            'environment' => array_merge($entry['env'] ?? [], $data['env'] ?? []),
            'skip_scripts' => false,
            'oom_disabled' => false,
            'start_on_completion' => true,
            'limits' => [
                'memory' => $mem,
                'swap' => 0,
                'disk' => $disk,
                'io' => 500,
                'cpu' => $cpu,
            ],
            'feature_limits' => [
                'databases' => (int) ($cs['databases'] ?? 1),
                'allocations' => 1,
                'backups' => (int) ($cs['backups'] ?? 2),
            ],
        ];

        // Allocation strategy: explicit node -> free allocation; else location deploy
        $node = (int) ($entry['node'] ?? 0);
        $location = (int) ($entry['location'] ?? 0);
        try {
            if ($node > 0) {
                $alloc = Http::withHeaders($this->headers($ptla))
                    ->timeout(15)
                    ->get($baseUrl . '/api/application/nodes/' . $node . '/allocations', ['per_page' => 100]);
                $free = null;
                foreach (($alloc->json('data') ?: []) as $a) {
                    if (empty($a['attributes']['server_id']) && !empty($a['attributes']['id'])) {
                        $free = (int) $a['attributes']['id'];
                        break;
                    }
                }
                if (!$free) {
                    return response()->json(['error' => 'No free allocations are available on the target node right now.'], 422);
                }
                $payload['allocation_id'] = $free;
            } elseif ($location > 0) {
                $payload['deploy'] = [
                    'locations' => [$location],
                    'dedicated_ip' => false,
                    'port_range' => [],
                ];
            } else {
                return response()->json(['error' => 'This catalog entry has no node or location configured yet.'], 422);
            }

            $resp = Http::withHeaders($this->headers($ptla))
                ->timeout(30)
                ->post($baseUrl . '/api/application/servers', $payload);

            if ($resp->failed()) {
                Log::warning('Syntro create server failed', ['status' => $resp->status(), 'body' => mb_substr($resp->body(), 0, 500)]);
                $detail = $resp->json('errors.0.detail') ?: 'The panel rejected the deployment (HTTP ' . $resp->status() . ').';
                return response()->json(['error' => $detail], 502);
            }

            $server = $resp->json('attributes') ?: [];

            return response()->json([
                'identifier' => $server['identifier'] ?? '',
                'name' => $server['name'] ?? $data['name'],
            ]);
        } catch (\Throwable $e) {
            Log::warning('Syntro create server exception', ['msg' => $e->getMessage()]);

            return response()->json(['error' => 'Could not reach the panel API to deploy your server.'], 502);
        }
    }

    private function headers(string $ptla): array
    {
        return [
            'Authorization' => 'Bearer ' . $ptla,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ];
    }
}
