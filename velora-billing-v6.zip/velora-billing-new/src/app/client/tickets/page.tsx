'use client';

import { useState, useEffect } from 'react';
import {
  HelpCircle,
  Plus,
  ChevronDown,
  ChevronUp,
  Send,
  X,
  Clock,
  MessageSquare,
  AlertCircle,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface TicketReply {
  id: string;
  userId: string;
  userName: string;
  message: string;
  createdAt: string;
  isAdmin: boolean;
}

interface Ticket {
  id: string;
  subject: string;
  department: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'answered' | 'closed';
  lastUpdated: string;
  messageCount: number;
  replies?: TicketReply[];
}

const fallbackTickets: Ticket[] = [
  {
    id: 'TKT-001',
    subject: 'Server not starting after update',
    department: 'Technical',
    priority: 'high',
    status: 'open',
    lastUpdated: '2025-01-12T14:30:00Z',
    messageCount: 3,
    replies: [
      { id: 'r1', userId: 'u1', userName: 'You', message: 'My Minecraft server is not starting after the latest update. Please help.', createdAt: '2025-01-12T10:00:00Z', isAdmin: false },
      { id: 'r2', userId: 'a1', userName: 'Support Team', message: 'We are looking into this. Can you share your server logs?', createdAt: '2025-01-12T12:00:00Z', isAdmin: true },
      { id: 'r3', userId: 'u1', userName: 'You', message: 'Here are the logs: [Error] Failed to start - port already in use', createdAt: '2025-01-12T14:30:00Z', isAdmin: false },
    ],
  },
  {
    id: 'TKT-002',
    subject: 'Billing discrepancy on last invoice',
    department: 'Billing',
    priority: 'medium',
    status: 'answered',
    lastUpdated: '2025-01-11T09:00:00Z',
    messageCount: 2,
    replies: [
      { id: 'r4', userId: 'u1', userName: 'You', message: 'I was charged double for my VPS order. Please check.', createdAt: '2025-01-10T08:00:00Z', isAdmin: false },
      { id: 'r5', userId: 'a1', userName: 'Support Team', message: 'We have verified and the extra charge has been refunded to your wallet.', createdAt: '2025-01-11T09:00:00Z', isAdmin: true },
    ],
  },
  {
    id: 'TKT-003',
    subject: 'Request for additional IP address',
    department: 'Sales',
    priority: 'low',
    status: 'closed',
    lastUpdated: '2025-01-05T16:00:00Z',
    messageCount: 4,
  },
];

const statusBadge: Record<string, string> = {
  open: 'velora-badge-success',
  answered: 'velora-badge-info',
  closed: 'velora-badge',
};

const priorityBadge: Record<string, string> = {
  low: 'velora-badge',
  medium: 'velora-badge-warning',
  high: 'velora-badge-danger',
  critical: 'velora-badge-danger',
};

const departments = ['Technical', 'Billing', 'Sales', 'General'];
const priorities = ['low', 'medium', 'high', 'critical'];

export default function TicketsPage() {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  // Form state
  const [subject, setSubject] = useState('');
  const [department, setDepartment] = useState('General');
  const [priority, setPriority] = useState('medium');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/tickets', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setTickets(data);
          else if (Array.isArray(data.tickets)) setTickets(data.tickets);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };
    fetchTickets();
  }, []);

  const handleCreateTicket = async () => {
    if (!subject.trim() || !message.trim()) {
      toast.error('Please fill in subject and message');
      return;
    }
    setSubmitting(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ subject, department, priority, message }),
      });
      if (res.ok) {
        toast.success('Ticket created successfully');
        setShowForm(false);
        setSubject('');
        setDepartment('General');
        setPriority('medium');
        setMessage('');
      } else {
        toast.error('Failed to create ticket');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReply = async (ticketId: string) => {
    if (!replyText.trim()) return;
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/tickets/${ticketId}/replies`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ message: replyText }),
      });
      if (res.ok) {
        toast.success('Reply sent');
        setReplyText('');
      }
    } catch {
      toast.error('Failed to send reply');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const displayTickets = tickets.length > 0 ? tickets : fallbackTickets;

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#e2e8f0]">Support Tickets</h2>
          <p className="text-[#64748b] mt-1">Get help from our support team.</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="velora-btn-primary inline-flex items-center gap-2">
          {showForm ? <X size={16} /> : <Plus size={16} />}
          {showForm ? 'Cancel' : 'Create Ticket'}
        </button>
      </div>

      {/* Create Ticket Form */}
      {showForm && (
        <div className="velora-card animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Create New Ticket</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="md:col-span-2">
              <label className="block text-sm text-[#64748b] mb-1">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Brief description of your issue"
                className="velora-input w-full"
              />
            </div>
            <div>
              <label className="block text-sm text-[#64748b] mb-1">Department</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="velora-input w-full"
              >
                {departments.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-[#64748b] mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="velora-input w-full"
              >
                {priorities.map((p) => (
                  <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm text-[#64748b] mb-1">Message</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Describe your issue in detail..."
                rows={4}
                className="velora-input w-full resize-none"
              />
            </div>
          </div>
          <button
            onClick={handleCreateTicket}
            disabled={submitting}
            className="velora-btn-primary inline-flex items-center gap-2"
          >
            <Send size={16} />
            {submitting ? 'Submitting...' : 'Submit Ticket'}
          </button>
        </div>
      )}

      {/* Ticket List */}
      {displayTickets.length === 0 ? (
        <div className="velora-card text-center py-16">
          <HelpCircle className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Tickets</h3>
          <p className="text-[#64748b]">You haven&apos;t created any support tickets yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {displayTickets.map((ticket) => {
            const isExpanded = expandedId === ticket.id;
            return (
              <div key={ticket.id} className="velora-card">
                <button
                  onClick={() => setExpandedId(isExpanded ? null : ticket.id)}
                  className="w-full flex items-center justify-between text-left"
                >
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <MessageSquare size={18} className="text-[#64748b] flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-[#e2e8f0] truncate">{ticket.subject}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="velora-badge text-xs">{ticket.department}</span>
                        <span className={priorityBadge[ticket.priority]}>{ticket.priority}</span>
                        <span className={statusBadge[ticket.status]}>{ticket.status}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0 ml-4">
                    <div className="hidden sm:flex items-center gap-1 text-xs text-[#64748b]">
                      <Clock size={12} />
                      {new Date(ticket.lastUpdated).toLocaleDateString()}
                    </div>
                    <span className="text-xs text-[#64748b]">{ticket.messageCount} msgs</span>
                    {isExpanded ? <ChevronUp size={16} className="text-[#64748b]" /> : <ChevronDown size={16} className="text-[#64748b]" />}
                  </div>
                </button>

                {/* Expanded Replies */}
                {isExpanded && (
                  <div className="mt-4 border-t border-[#1a1a2e] pt-4 space-y-3 animate-fade-in">
                    {ticket.replies && ticket.replies.length > 0 ? (
                      ticket.replies.map((reply) => (
                        <div
                          key={reply.id}
                          className={`p-3 rounded-lg ${reply.isAdmin ? 'bg-[#6366f1]/5 border border-[#6366f1]/20' : 'bg-[#09090b]'}`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className={`text-sm font-medium ${reply.isAdmin ? 'text-[#6366f1]' : 'text-[#e2e8f0]'}`}>
                              {reply.userName}
                              {reply.isAdmin && <span className="velora-badge-info text-xs ml-2">Staff</span>}
                            </span>
                            <span className="text-xs text-[#64748b]">
                              {new Date(reply.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-sm text-[#e2e8f0] whitespace-pre-wrap">{reply.message}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-[#64748b] text-center py-2">No replies yet. Be the first to reply!</p>
                    )}

                  {ticket.status !== 'closed' && (
                    <div className="flex gap-2 mt-3">
                      <input
                        type="text"
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Type a reply..."
                        className="velora-input flex-1"
                      />
                      <button
                        onClick={() => handleReply(ticket.id)}
                        className="velora-btn-primary inline-flex items-center gap-2"
                      >
                        <Send size={14} />
                        Send
                      </button>
                    </div>
                  )}
                </div>
              )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
