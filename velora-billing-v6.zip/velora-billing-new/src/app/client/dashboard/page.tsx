'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Server,
  ShoppingCart,
  Wallet,
  HelpCircle,
  Plus,
  Package,
  MessageSquarePlus,
  TrendingUp,
  Clock,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface StatCard {
  label: string;
  value: number;
  icon: React.ElementType;
  color: string;
  bgColor: string;
}

interface Order {
  id: string;
  product: string;
  amount: number;
  status: 'active' | 'pending' | 'cancelled' | 'completed';
  date: string;
}

const fallbackStats: StatCard[] = [
  { label: 'Active Services', value: 3, icon: Server, color: 'text-[#10b981]', bgColor: 'bg-[#10b981]/10' },
  { label: 'Pending Orders', value: 1, icon: ShoppingCart, color: 'text-[#f59e0b]', bgColor: 'bg-[#f59e0b]/10' },
  { label: 'Wallet Balance', value: 1250.0, icon: Wallet, color: 'text-[#6366f1]', bgColor: 'bg-[#6366f1]/10' },
  { label: 'Open Tickets', value: 2, icon: HelpCircle, color: 'text-[#8b5cf6]', bgColor: 'bg-[#8b5cf6]/10' },
];

const fallbackOrders: Order[] = [
  { id: 'ORD-001', product: 'Minecraft Premium', amount: 299, status: 'active', date: '2025-01-10' },
  { id: 'ORD-002', product: 'VPS Starter', amount: 499, status: 'pending', date: '2025-01-12' },
  { id: 'ORD-003', product: 'Dedicated 32GB', amount: 2499, status: 'active', date: '2025-01-08' },
  { id: 'ORD-004', product: 'Minecraft Basic', amount: 149, status: 'completed', date: '2025-01-05' },
  { id: 'ORD-005', product: 'VPS Pro', amount: 899, status: 'cancelled', date: '2025-01-03' },
];

const statusBadge: Record<string, string> = {
  active: 'velora-badge-success',
  pending: 'velora-badge-warning',
  cancelled: 'velora-badge-danger',
  completed: 'velora-badge-info',
};

export default function ClientDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<StatCard[]>(fallbackStats);
  const [orders, setOrders] = useState<Order[]>(fallbackOrders);
  const [userName, setUserName] = useState('User');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/dashboard', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.stats) setStats(data.stats);
          if (data.orders) setOrders(data.orders);
          if (data.user?.name) setUserName(data.user.name);
        }
      } catch {
        // Use fallback data
      } finally {
        setLoading(false);
      }
    };

    try {
      const stored = localStorage.getItem('user');
      if (stored) setUserName(JSON.parse(stored).name || 'User');
    } catch {
      // ignore
    }

    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Welcome */}
      <div>
        <h2 className="text-2xl font-bold text-[#e2e8f0]">Welcome back, {userName}!</h2>
        <p className="text-[#64748b] mt-1">Here is an overview of your account.</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="velora-card p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#64748b]">{stat.label}</p>
                  <p className="text-2xl font-bold text-[#e2e8f0] mt-1">
                    {stat.label === 'Wallet Balance' ? `₹${stat.value.toLocaleString()}` : stat.value}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-xl ${stat.bgColor} flex items-center justify-center`}>
                  <Icon size={22} className={stat.color} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Orders */}
      <div className="velora-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#e2e8f0]">Recent Orders</h3>
          <Link href="/client/orders" className="velora-link text-sm">
            View All
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="velora-table w-full">
            <thead>
              <tr>
                <th>Order #</th>
                <th>Product</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {orders.slice(0, 5).map((order) => (
                <tr key={order.id}>
                  <td className="font-mono text-sm">{order.id}</td>
                  <td className="text-[#e2e8f0]">{order.product}</td>
                  <td className="text-[#e2e8f0]">₹{order.amount.toLocaleString()}</td>
                  <td>
                    <span className={statusBadge[order.status] || 'velora-badge'}>{order.status}</span>
                  </td>
                  <td className="text-[#64748b]">{new Date(order.date).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Quick Actions</h3>
        <div className="flex flex-wrap gap-3">
          <Link href="/client/wallet" className="velora-btn-primary inline-flex items-center gap-2">
            <Plus size={16} />
            Add Funds
          </Link>
          <Link href="/client/products" className="velora-btn-secondary inline-flex items-center gap-2">
            <Package size={16} />
            View Products
          </Link>
          <Link href="/client/tickets" className="velora-btn-secondary inline-flex items-center gap-2">
            <MessageSquarePlus size={16} />
            Create Ticket
          </Link>
        </div>
      </div>
    </div>
  );
}
