'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Package, Check, ArrowRight, Zap, Star, TrendingUp, Shield, Cpu, HardDrive } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  billingCycle: string;
  category: string;
  features: string[];
  stock: number;
}

const fallbackProducts: Product[] = [
  {
    id: '1',
    name: 'Minecraft Basic',
    description: 'Perfect for small servers with friends. 2GB RAM, 20 player slots.',
    price: 149,
    billingCycle: 'Monthly',
    category: 'Minecraft',
    features: ['2 GB RAM', '20 Player Slots', '10 GB SSD', 'DDoS Protection', '1 MySQL DB'],
    stock: 15,
  },
  {
    id: '2',
    name: 'Minecraft Premium',
    description: 'Ideal for growing communities. 4GB RAM, 50 player slots.',
    price: 299,
    billingCycle: 'Monthly',
    category: 'Minecraft',
    features: ['4 GB RAM', '50 Player Slots', '25 GB SSD', 'DDoS Protection', '3 MySQL DBs', 'Dedicated IP'],
    stock: 8,
  },
  {
    id: '3',
    name: 'VPS Starter',
    description: 'Entry-level virtual private server with 2 vCPU and 2GB RAM.',
    price: 499,
    billingCycle: 'Monthly',
    category: 'VPS',
    features: ['2 vCPU', '2 GB RAM', '40 GB NVMe', '2 TB Bandwidth', 'Full Root Access'],
    stock: 20,
  },
  {
    id: '4',
    name: 'VPS Pro',
    description: 'High-performance VPS with 4 vCPU and 8GB RAM for demanding workloads.',
    price: 899,
    billingCycle: 'Monthly',
    category: 'VPS',
    features: ['4 vCPU', '8 GB RAM', '100 GB NVMe', '4 TB Bandwidth', 'Full Root Access', 'IPv6 Support'],
    stock: 12,
  },
  {
    id: '5',
    name: 'Dedicated 32GB',
    description: 'Full dedicated server with Intel Xeon E-2236, 32GB DDR4.',
    price: 2499,
    billingCycle: 'Monthly',
    category: 'Dedicated',
    features: ['Intel Xeon E-2236', '32 GB DDR4', '500 GB NVMe SSD', '20 TB Bandwidth', 'IPMI Access', '/29 IPv4 Block'],
    stock: 3,
  },
  {
    id: '6',
    name: 'Dedicated 64GB',
    description: 'Enterprise-grade dedicated server with AMD Ryzen 9, 64GB DDR4.',
    price: 4999,
    billingCycle: 'Monthly',
    category: 'Dedicated',
    features: ['AMD Ryzen 9 5900X', '64 GB DDR4', '1 TB NVMe SSD', 'Unmetered Bandwidth', 'IPMI Access', '/28 IPv4 Block', 'Hardware RAID'],
    stock: 1,
  },
];

const categories = ['All', 'Minecraft', 'VPS', 'Dedicated'];

const categoryIcons: Record<string, any> = {
  All: Zap,
  Minecraft: Star,
  VPS: Cpu,
  Dedicated: HardDrive,
};

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCategory, setActiveCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/products', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setProducts(data);
          else if (Array.isArray(data.products)) setProducts(data.products);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const displayProducts = products.length > 0 ? products : fallbackProducts;
  const filtered =
    activeCategory === 'All'
      ? displayProducts
      : displayProducts.filter((p) => p.category === activeCategory);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center mx-auto animate-pulse-glow">
            <Package size={20} className="text-white animate-pulse" />
          </div>
          <p className="text-[#64748b] text-sm">Loading products...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
            <Zap size={18} className="text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#e2e8f0]">Hosting Plans</h2>
            <p className="text-sm text-[#64748b]">Premium hosting solutions for every need</p>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => {
          const Icon = categoryIcons[cat] || Zap;
          return (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                activeCategory === cat
                  ? 'bg-[#6366f1] text-white shadow-lg shadow-[#6366f1]/20 velora-glow'
                  : 'bg-[#0c0c0f] border border-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] hover:border-[#6366f1]/30'
              }`}
            >
              <Icon size={14} />
              {cat}
            </button>
          );
        })}
      </div>

      {/* Product Grid */}
      {filtered.length === 0 ? (
        <div className="velora-card text-center py-20">
          <Package className="mx-auto text-[#475569] mb-4" size={48} />
          <p className="text-[#64748b]">No products found in this category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 stagger-children">
          {filtered.map((product) => (
            <div key={product.id} className="velora-card flex flex-col hover-lift hover-glow group overflow-hidden">
              {/* Card top accent */}
              <div className="h-1 bg-gradient-to-r from-[#6366f1] via-[#8b5cf6] to-[#a855f7] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="flex-1 p-5">
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <h3 className="text-lg font-bold text-[#e2e8f0] group-hover:text-[#6366f1] transition-colors">{product.name}</h3>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-[#6366f1]/10 text-[#6366f1] text-[10px] font-medium border border-[#6366f1]/20">
                      {product.category}
                    </span>
                  </div>
                  {product.stock <= 5 && product.stock > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-[#f59e0b]/10 text-[#f59e0b] text-[10px] font-medium border border-[#f59e0b]/20 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#f59e0b] animate-pulse" />
                      {product.stock} left
                    </span>
                  )}
                </div>

                <p className="text-sm text-[#64748b] mb-4 leading-relaxed">{product.description}</p>

                {/* Price */}
                <div className="flex items-baseline gap-2 mb-5">
                  <span className="text-3xl font-extrabold bg-gradient-to-r from-[#6366f1] to-[#8b5cf6] bg-clip-text text-transparent">
                    ₹{product.price.toLocaleString()}
                  </span>
                  <span className="text-xs text-[#475569] font-medium">/{product.billingCycle.toLowerCase()}</span>
                </div>

                {/* Features */}
                <ul className="space-y-2 mb-5">
                  {product.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-[#c8ccd0]">
                      <div className="w-4 h-4 rounded bg-[#10b981]/10 flex items-center justify-center flex-shrink-0">
                        <Check size={8} className="text-[#10b981]" strokeWidth={3} />
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {/* CTA */}
              <div className="px-5 pb-5">
                <Link
                  href={`/client/checkout?id=${product.id}`}
                  className={`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all duration-300 active:scale-[0.97] ${
                    product.stock <= 0
                      ? 'bg-[#1a1a2e] text-[#475569] cursor-not-allowed'
                      : 'gradient-animate text-white velora-glow hover:shadow-[0_0_30px_rgba(99,102,241,0.3)]'
                  }`}
                  onClick={(e) => product.stock <= 0 && e.preventDefault()}
                >
                  {product.stock <= 0 ? (
                    'Out of Stock'
                  ) : (
                    <>
                      Order Now
                      <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Trust Bar */}
      <div className="flex items-center justify-center gap-8 py-4">
        {[
          { icon: Shield, text: 'DDoS Protection' },
          { icon: TrendingUp, text: '99.9% Uptime' },
          { icon: Cpu, text: 'Instant Setup' },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-2 text-[#475569]">
            <item.icon size={14} />
            <span className="text-xs">{item.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
