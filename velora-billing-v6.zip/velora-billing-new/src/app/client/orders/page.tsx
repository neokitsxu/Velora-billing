'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Eye, ShoppingCart, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

interface Order {
  id: string;
  productName: string;
  amount: number;
  status: 'active' | 'pending' | 'cancelled' | 'completed' | 'refunded';
  paymentMethod: string;
  date: string;
}

const fallbackOrders: Order[] = [
  { id: 'ORD-001', productName: 'Minecraft Premium', amount: 299, status: 'active', paymentMethod: 'UPI', date: '2025-01-10' },
  { id: 'ORD-002', productName: 'VPS Starter', amount: 499, status: 'pending', paymentMethod: 'Wallet', date: '2025-01-12' },
  { id: 'ORD-003', productName: 'Dedicated 32GB', amount: 2499, status: 'active', paymentMethod: 'UPI', date: '2025-01-08' },
  { id: 'ORD-004', productName: 'Minecraft Basic', amount: 149, status: 'completed', paymentMethod: 'UPI', date: '2025-01-05' },
  { id: 'ORD-005', productName: 'VPS Pro', amount: 899, status: 'cancelled', paymentMethod: 'Wallet', date: '2025-01-03' },
  { id: 'ORD-006', productName: 'Minecraft Premium', amount: 299, status: 'refunded', paymentMethod: 'UPI', date: '2024-12-28' },
];

const statusBadge: Record<string, string> = {
  active: 'velora-badge-success',
  pending: 'velora-badge-warning',
  cancelled: 'velora-badge-danger',
  completed: 'velora-badge-info',
  refunded: 'velora-badge',
};

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/orders', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setOrders(data);
          else if (Array.isArray(data.orders)) setOrders(data.orders);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const displayOrders = orders.length > 0 ? orders : fallbackOrders;

  return (
    <div className="space-y-6 animate-slide-up">
      <div>
        <h2 className="text-2xl font-bold text-[#e2e8f0]">My Orders</h2>
        <p className="text-[#64748b] mt-1">View and manage all your orders.</p>
      </div>

      {displayOrders.length === 0 ? (
        <div className="velora-card text-center py-16">
          <ShoppingCart className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Orders Yet</h3>
          <p className="text-[#64748b] mb-4">You haven&apos;t placed any orders yet.</p>
          <Link href="/client/products" className="velora-btn-primary inline-flex items-center gap-2">
            Browse Products
          </Link>
        </div>
      ) : (
        <div className="velora-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="velora-table w-full">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Product</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Payment</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {displayOrders.map((order) => (
                  <tr key={order.id}>
                    <td className="font-mono text-sm">{order.id}</td>
                    <td className="text-[#e2e8f0] font-medium">{order.productName}</td>
                    <td className="text-[#e2e8f0]">₹{order.amount.toLocaleString()}</td>
                    <td>
                      <span className={statusBadge[order.status] || 'velora-badge'}>{order.status}</span>
                    </td>
                    <td className="text-[#64748b]">{order.paymentMethod}</td>
                    <td className="text-[#64748b]">{new Date(order.date).toLocaleDateString()}</td>
                    <td>
                      <button
                        onClick={() => toast.success(`Viewing order ${order.id}`)}
                        className="inline-flex items-center gap-1 text-sm text-[#6366f1] hover:text-[#818cf8] transition-colors"
                      >
                        <Eye size={14} />
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
