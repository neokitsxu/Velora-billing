'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { FileText, Download, CreditCard, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

interface Invoice {
  id: string;
  amount: number;
  tax: number;
  total: number;
  status: 'paid' | 'unpaid' | 'overdue' | 'cancelled';
  dueDate: string;
  paidDate?: string;
  orderId: string;
}

const fallbackInvoices: Invoice[] = [
  { id: 'INV-001', amount: 299, tax: 53.82, total: 352.82, status: 'paid', dueDate: '2025-01-15', paidDate: '2025-01-10', orderId: 'ORD-001' },
  { id: 'INV-002', amount: 499, tax: 89.82, total: 588.82, status: 'unpaid', dueDate: '2025-01-20', orderId: 'ORD-002' },
  { id: 'INV-003', amount: 2499, tax: 449.82, total: 2948.82, status: 'paid', dueDate: '2025-01-12', paidDate: '2025-01-08', orderId: 'ORD-003' },
  { id: 'INV-004', amount: 149, tax: 26.82, total: 175.82, status: 'overdue', dueDate: '2024-12-30', orderId: 'ORD-004' },
  { id: 'INV-005', amount: 899, tax: 161.82, total: 1060.82, status: 'cancelled', dueDate: '2025-01-10', orderId: 'ORD-005' },
];

const statusBadge: Record<string, string> = {
  paid: 'velora-badge-success',
  unpaid: 'velora-badge-warning',
  overdue: 'velora-badge-danger',
  cancelled: 'velora-badge',
};

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/invoices', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setInvoices(data);
          else if (Array.isArray(data.invoices)) setInvoices(data.invoices);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };
    fetchInvoices();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const displayInvoices = invoices.length > 0 ? invoices : fallbackInvoices;

  return (
    <div className="space-y-6 animate-slide-up">
      <div>
        <h2 className="text-2xl font-bold text-[#e2e8f0]">My Invoices</h2>
        <p className="text-[#64748b] mt-1">View and manage all your invoices.</p>
      </div>

      {displayInvoices.length === 0 ? (
        <div className="velora-card text-center py-16">
          <FileText className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Invoices</h3>
          <p className="text-[#64748b]">You don&apos;t have any invoices yet.</p>
        </div>
      ) : (
        <div className="velora-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="velora-table w-full">
              <thead>
                <tr>
                  <th>Invoice #</th>
                  <th>Amount</th>
                  <th>Tax</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Due Date</th>
                  <th>Paid Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {displayInvoices.map((inv) => (
                  <tr key={inv.id}>
                    <td className="font-mono text-sm">{inv.id}</td>
                    <td className="text-[#e2e8f0]">₹{inv.amount.toLocaleString()}</td>
                    <td className="text-[#64748b]">₹{inv.tax.toFixed(2)}</td>
                    <td className="text-[#e2e8f0] font-medium">₹{inv.total.toFixed(2)}</td>
                    <td>
                      <span className={statusBadge[inv.status] || 'velora-badge'}>{inv.status}</span>
                    </td>
                    <td className="text-[#64748b]">{new Date(inv.dueDate).toLocaleDateString()}</td>
                    <td className="text-[#64748b]">
                      {inv.paidDate ? new Date(inv.paidDate).toLocaleDateString() : '—'}
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        {(inv.status === 'unpaid' || inv.status === 'overdue') && (
                          <Link
                            href={`/client/payment?invoice=${inv.id}`}
                            className="inline-flex items-center gap-1 text-sm text-[#6366f1] hover:text-[#818cf8] transition-colors"
                          >
                            <CreditCard size={14} />
                            Pay
                          </Link>
                        )}
                        <button
                          onClick={() => toast.success('Invoice downloaded')}
                          className="inline-flex items-center gap-1 text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors"
                        >
                          <Download size={14} />
                          Download
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
