'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  User,
  Mail,
  Calendar,
  Shield,
  Save,
  Key,
  Trash2,
  Loader2,
  Copy,
  AlertTriangle,
  Camera,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface UserProfile {
  name: string;
  email: string;
  role: string;
  avatar: string;
  createdAt: string;
}

interface ApiKey {
  id: string;
  name: string;
  key: string;
  createdAt: string;
}

const fallbackProfile: UserProfile = {
  name: 'John Doe',
  email: 'john@example.com',
  role: 'Client',
  avatar: '',
  createdAt: '2024-06-15T00:00:00Z',
};

export default function ProfilePage() {
  const router = useRouter();
  const [profile, setProfile] = useState<UserProfile>(fallbackProfile);
  const [loading, setLoading] = useState(true);

  // Edit profile
  const [editName, setEditName] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  // Change password
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);

  // API Keys
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);

  // Close account
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.name) {
            setProfile(data);
            setEditName(data.name);
            setEditAvatar(data.avatar || '');
          }
        }
      } catch {
        // fallback
        try {
          const stored = localStorage.getItem('user');
          if (stored) {
            const u = JSON.parse(stored);
            setProfile((prev) => ({ ...prev, name: u.name || profile.name, email: u.email || prev.email }));
            setEditName(u.name || profile.name);
          }
        } catch {
          // ignore
        }
      } finally {
        setLoading(false);
      }
    };

    const fetchApiKeys = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/api-keys', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setApiKeys(data);
          else if (Array.isArray(data.keys)) setApiKeys(data.keys);
        }
      } catch {
        // no api keys
      }
    };

    fetchProfile();
    fetchApiKeys();
  }, []);

  const handleSaveProfile = async () => {
 if (!editName.trim()) {
      toast.error('Name is required');
      return;
    }
    setSavingProfile(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name: editName, avatar: editAvatar }),
      });
      if (res.ok) {
        setProfile((prev) => ({ ...prev, name: editName, avatar: editAvatar }));
        // Update localStorage
        try {
          const stored = localStorage.getItem('user');
          const u = stored ? JSON.parse(stored) : {};
          u.name = editName;
          localStorage.setItem('user', JSON.stringify(u));
        } catch { /* ignore */ }
        toast.success('Profile updated successfully');
      } else {
        toast.error('Failed to update profile');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('All password fields are required');
      return;
    }
    if (newPassword.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    setSavingPassword(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile/password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (res.ok) {
        toast.success('Password changed successfully');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        const data = await res.json();
        toast.error(data.message || 'Failed to change password');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSavingPassword(false);
    }
  };

  const handleCloseAccount = async () => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile/close', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        toast.success('Account closed successfully');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        router.push('/auth/login');
      } else {
        toast.error('Failed to close account');
      }
    } catch {
      toast.error('Network error');
    }
    setShowCloseConfirm(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-slide-up max-w-4xl">
      {/* Profile Card */}
      <div className="velora-card">
        <div className="flex flex-col sm:flex-row items-center gap-5">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-2xl font-bold overflow-hidden flex-shrink-0">
            {profile.avatar ? (
              <img src={profile.avatar} alt={profile.name} className="w-full h-full object-cover" />
            ) : (
              profile.name.charAt(0).toUpperCase()
            )}
          </div>
          <div className="text-center sm:text-left">
            <h3 className="text-xl font-bold text-[#e2e8f0]">{profile.name}</h3>
            <div className="flex items-center justify-center sm:justify-start gap-2 mt-1">
              <Mail size={14} className="text-[#64748b]" />
              <span className="text-sm text-[#64748b]">{profile.email}</span>
            </div>
            <div className="flex items-center justify-center sm:justify-start gap-3 mt-2">
              <span className="velora-badge-info">{profile.role}</span>
              <span className="flex items-center gap-1 text-xs text-[#64748b]">
                <Calendar size={12} />
                Member since {new Date(profile.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
          <User size={18} className="text-[#6366f1]" />
          Edit Profile
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-[#64748b] mb-1">Name</label>
            <input
              type="text"
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              className="velora-input w-full"
              placeholder="Your name"
            />
          </div>
          <div>
            <label className="block text-sm text-[#64748b] mb-1">Avatar URL</label>
            <div className="flex items-center gap-2">
              <Camera size={14} className="text-[#64748b]" />
              <input
                type="text"
                value={editAvatar}
                onChange={(e) => setEditAvatar(e.target.value)}
                className="velora-input flex-1"
                placeholder="https://example.com/avatar.png"
              />
            </div>
          </div>
          <button
            onClick={handleSaveProfile}
            disabled={savingProfile}
            className="velora-btn-primary inline-flex items-center gap-2"
          >
            {savingProfile ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
            {savingProfile ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Change Password */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
          <Shield size={18} className="text-[#8b5cf6]" />
          Security
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-[#64748b] mb-1">Current Password</label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="velora-input w-full"
              placeholder="Enter current password"
            />
          </div>
          <div>
            <label className="block text-sm text-[#64748b] mb-1">New Password</label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="velora-input w-full"
              placeholder="Enter new password"
            />
          </div>
          <div>
            <label className="block text-sm text-[#64748b] mb-1">Confirm New Password</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="velora-input w-full"
              placeholder="Confirm new password"
            />
          </div>
          <button
            onClick={handleChangePassword}
            disabled={savingPassword}
            className="velora-btn-secondary inline-flex items-center gap-2"
          >
            {savingPassword ? <Loader2 size={16} className="animate-spin" /> : <Key size={16} />}
            {savingPassword ? 'Changing...' : 'Change Password'}
          </button>
        </div>
      </div>

      {/* API Keys */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
          <Key size={18} className="text-[#f59e0b]" />
          API Keys
        </h3>
        {apiKeys.length === 0 ? (
          <p className="text-sm text-[#64748b]">No API keys configured. Contact support if you need API access.</p>
        ) : (
          <div className="space-y-3">
            {apiKeys.map((apiKey) => (
              <div key={apiKey.id} className="flex items-center justify-between p-3 rounded-lg bg-[#09090b]">
                <div>
                  <p className="text-sm font-medium text-[#e2e8f0]">{apiKey.name}</p>
                  <p className="text-xs text-[#64748b] font-mono mt-0.5">
                    {apiKey.key.slice(0, 8)}...{apiKey.key.slice(-4)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => copyToClipboard(apiKey.key)}
                    className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors"
                  >
                    <Copy size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Close Account */}
      <div className="velora-card border-[#ef4444]/20">
        <h3 className="text-lg font-semibold text-[#ef4444] mb-2 flex items-center gap-2">
          <AlertTriangle size={18} />
          Danger Zone
        </h3>
        <p className="text-sm text-[#64748b] mb-4">
          Once you close your account, all data will be permanently deleted and cannot be recovered.
        </p>
        {!showCloseConfirm ? (
          <button
            onClick={() => setShowCloseConfirm(true)}
            className="velora-btn-danger inline-flex items-center gap-2"
          >
            <Trash2 size={16} />
            Close Account
          </button>
        ) : (
          <div className="flex items-center gap-3">
            <p className="text-sm text-[#ef4444] font-medium">Are you sure? This action is irreversible.</p>
            <button
              onClick={handleCloseAccount}
              className="velora-btn-danger inline-flex items-center gap-2"
            >
              <Trash2 size={16} />
              Yes, Close My Account
            </button>
            <button
              onClick={() => setShowCloseConfirm(false)}
              className="velora-btn-secondary"
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
