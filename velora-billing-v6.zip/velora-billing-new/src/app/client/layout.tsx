'use client';

import { useState, useEffect, ReactNode } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  FileText,
  Server,
  HelpCircle,
  Wallet,
  User,
  LogOut,
  Menu,
  X,
  Bell,
  ChevronDown,
  Settings,
  Search,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { CommandPalette } from '@/components/ui/command-palette';
import { NotificationCenter } from '@/components/ui/notification-center';
import { ScrollToTop } from '@/hooks/scroll-to-top';

const navItems = [
  { label: 'Dashboard', href: '/client/dashboard', icon: LayoutDashboard },
  { label: 'Products', href: '/client/products', icon: Package },
  { label: 'Orders', href: '/client/orders', icon: ShoppingCart },
  { label: 'Invoices', href: '/client/invoices', icon: FileText },
  { label: 'Services', href: '/client/services', icon: Server },
  { label: 'Tickets', href: '/client/tickets', icon: HelpCircle },
  { label: 'Wallet', href: '/client/wallet', icon: Wallet },
  { label: 'Profile', href: '/client/profile', icon: User },
];

export default function ClientLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const token = localStorage.getItem('velora_token');
    if (!token) {
      router.push('/auth/login');
      return;
    }
    try {
      const stored = localStorage.getItem('velora_user');
      if (stored) setUser(JSON.parse(stored));
    } catch {
      // ignore
    }
  }, [router]);

  useEffect(() => {
    const handleClick = () => setUserDropdownOpen(false);
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('velora_token');
    localStorage.removeItem('velora_user');
    toast.success('Logged out successfully');
    router.push('/auth/login');
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b] grid-bg">
      {/* Sidebar Overlay (mobile) */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-50 h-full w-64 bg-[#0c0c14] border-r border-[#1a1a2e] transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 md:z-30`}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-[#1a1a2e]">
          <Link href="/client/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
              <span className="text-white font-bold text-sm">V</span>
            </div>
            <span className="text-lg font-bold velora-gradient">Velora Billing</span>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="mt-6 px-3 flex-1">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
              const Icon = item.icon;
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={() => setSidebarOpen(false)}
                    className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 border-l-2 ${
                      isActive
                        ? 'bg-[#6366f1]/10 text-[#6366f1] border-l-[#6366f1]'
                        : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 border-l-transparent'
                    }`}
                  >
                    <Icon size={18} />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Logout */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-[#1a1a2e]">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-[#ef4444] hover:bg-[#ef4444]/10 transition-all duration-200 w-full"
          >
            <LogOut size={18} />
            Logout
          </button>
        </div>
      </aside>

      {/* Topbar */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-[#09090b]/80 backdrop-blur-xl border-b border-[#1a1a2e] z-20 flex items-center px-4 md:px-6">
        {/* Mobile menu toggle */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="md:hidden mr-4 p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors"
        >
          {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>

        {/* Page title */}
        <div className="flex-1">
          <h1 className="text-lg font-semibold text-[#e2e8f0]">
            {navItems.find((item) => pathname === item.href || pathname.startsWith(item.href + '/'))?.label || 'Dashboard'}
          </h1>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3">
          {/* Notification bell */}
          <button
            onClick={() => {}}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1a1a2e] text-[#475569] hover:text-[#64748b] text-xs transition-colors"
          >
            <Search size={12} /> Search... <kbd className="ml-4 px-1.5 py-0.5 rounded bg-[#0c0c14] text-[9px] font-mono">Ctrl+K</kbd>
          </button>
          <NotificationCenter />

          {/* User dropdown */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setUserDropdownOpen(!userDropdownOpen);
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-[#1a1a2e]/50 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-sm font-medium">
                {user?.name?.charAt(0)?.toUpperCase() || 'U'}
              </div>
              <span className="hidden md:block text-sm text-[#e2e8f0]">{user?.name || 'User'}</span>
              <ChevronDown size={14} className="text-[#64748b]" />
            </button>

            {userDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-48 bg-[#0c0c0f] border border-[#1a1a2e] rounded-lg shadow-xl py-1 z-50 animate-fade-in">
                <Link
                  href="/client/profile"
                  onClick={() => setUserDropdownOpen(false)}
                  className="flex items-center gap-2 px-4 py-2 text-sm text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors"
                >
                  <User size={16} />
                  Profile
                </Link>
                <Link
                  href="/client/profile"
                  onClick={() => setUserDropdownOpen(false)}
                  className="flex items-center gap-2 px-4 py-2 text-sm text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors"
                >
                  <Settings size={16} />
                  Settings
                </Link>
                <hr className="my-1 border-[#1a1a2e]" />
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-4 py-2 text-sm text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors w-full text-left"
                >
                  <LogOut size={16} />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="md:ml-64 mt-16 p-4 md:p-6 min-h-screen">
        <ScrollToTop />
        <div className="animate-fade-in">{children}</div>
      </main>
      <CommandPalette />
    </div>
  );
}
