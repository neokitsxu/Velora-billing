'use client';

import { useState, useEffect } from 'react';
import { Wallet, Plus, ArrowUpRight, ArrowDownLeft, RotateCcw, Loader2, CreditCard } from 'lucide-react';
import toast from 'react-hot-toast';

interface Transaction {
  id: string;
  date: string;
  type: 'credit' | 'debit' | 'refund';
  amount: number;
  balance: number;
  description: string;
  reference: string;
}

const fallbackTransactions: Transaction[] = [
  { id: 'TXN-001', date: '2025-01-12T14:30:00Z', type: 'credit', amount: 500, balance: 1750, description: 'Wallet top-up via UPI', reference: 'UPI_REF_001' },
  { id: 'TXN-002', date: '2025-01-10T10:00:00Z', type: 'debit', amount: 299, balance: 1250, description: 'Payment for ORD-001', reference: 'ORD-001' },
  { id: 'TXN-003', date: '2025-01-08T09:00:00Z', type: 'refund', amount: 899, balance: 1549, description: 'Refund for ORD-005', reference: 'REF_001' },
  { id: 'TXN-004', date: '2025-01-05T16:00:00Z', type: 'credit', amount: 1000, balance: 650, description: 'Wallet top-up via UPI', reference: 'UPI_REF_002' },
  { id: 'TXN-005', date: '2025-01-03T11:00:00Z', type: 'debit', amount: 149, balance: -350, description: 'Payment for ORD-004', reference: 'ORD-004' },
  { id: 'TXN-006', date: '2024-12-28T08:00:00Z', type: 'credit', amount: 200, balance: -201, description: 'Wallet top-up via UPI', reference: 'UPI_REF_003' },
];

const typeBadge: Record<string, string> = {
  credit: 'velora-badge-success',
  debit: 'velora-badge-danger',
  refund: 'velora-badge-info',
};

const typeIcon: Record<string, React.ElementType> = {
  credit: ArrowDownLeft,
  debit: ArrowUpRight,
  refund: RotateCcw,
};

export default function WalletPage() {
  const [balance, setBalance] = useState(1250);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [topUpAmount, setTopUpAmount] = useState('');
  const [topUpUpiId, setTopUpUpiId] = useState('');
  const [topUpLoading, setTopUpLoading] = useState(false);

  useEffect(() => {
    const fetchWallet = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/wallet', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.balance !== undefined) setBalance(data.balance);
          if (Array.isArray(data.transactions)) setTransactions(data.transactions);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };
    fetchWallet();
  }, []);

  const handleTopUp = async () => {
    const amount = parseFloat(topUpAmount);
    if (!amount || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (!topUpUpiId.trim()) {
      toast.error('Please enter your UPI ID');
      return;
    }

    setTopUpLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/wallet/topup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ amount, upiId: topUpUpiId }),
      });
      if (res.ok) {
        toast.success(`Top-up request of ₹${amount} submitted!`);
        setTopUpAmount('');
        setTopUpUpiId('');
      } else {
        toast.error('Failed to initiate top-up');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setTopUpLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const displayTransactions = transactions.length > 0 ? transactions : fallbackTransactions;

  return (
    <div className="space-y-6 animate-slide-up">
      <div>
        <h2 className="text-2xl font-bold text-[#e2e8f0]">Wallet</h2>
        <p className="text-[#64748b] mt-1">Manage your wallet balance and view transactions.</p>
      </div>

      {/* Balance Card */}
      <div className="velora-card p-6 border-2 border-transparent bg-gradient-to-br from-[#6366f1]/20 via-[#0c0c0f] to-[#8b5cf6]/20">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
            <Wallet size={20} className="text-white" />
          </div>
          <span className="text-sm text-[#64748b]">Available Balance</span>
        </div>
        <p className="text-4xl font-bold velora-gradient">₹{balance.toLocaleString()}</p>
      </div>

      {/* Add Funds */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Add Funds</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-[#64748b] mb-1">Amount (₹)</label>
            <input
              type="number"
              value={topUpAmount}
              onChange={(e) => setTopUpAmount(e.target.value)}
              placeholder="Enter amount"
              min="1"
              className="velora-input w-full"
            />
          </div>
          <div>
            <label className="block text-sm text-[#64748b] mb-1">UPI ID</label>
            <input
              type="text"
              value={topUpUpiId}
              onChange={(e) => setTopUpUpiId(e.target.value)}
              placeholder="yourname@upi"
              className="velora-input w-full"
            />
          </div>
        </div>
        <button
          onClick={handleTopUp}
          disabled={topUpLoading}
          className="velora-btn-primary mt-4 inline-flex items-center gap-2"
        >
          {topUpLoading ? <Loader2 size={16} className="animate-spin" /> : <CreditCard size={16} />}
          {topUpLoading ? 'Processing...' : 'Pay via UPI'}
        </button>
      </div>

      {/* Transaction History */}
      <div className="velora-card overflow-hidden">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Transaction History</h3>
        <div className="overflow-x-auto">
          <table className="velora-table w-full">
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Balance</th>
                <th>Description</th>
                <th>Reference</th>
              </tr>
            </thead>
            <tbody>
              {displayTransactions.map((tx) => {
                const Icon = typeIcon[tx.type] || ArrowUpRight;
                return (
                  <tr key={tx.id}>
                    <td className="text-[#64748b]">{new Date(tx.date).toLocaleDateString()}</td>
                    <td>
                      <div className="flex items-center gap-1.5">
                        <Icon size={14} />
                        <span className={typeBadge[tx.type] || 'velora-badge'}>{tx.type}</span>
                      </div>
                    </td>
                    <td className={`font-medium ${tx.type === 'debit' ? 'text-[#ef4444]' : 'text-[#10b981]'}`}>
                      {tx.type === 'debit' ? '-' : '+'}₹{tx.amount.toLocaleString()}
                    </td>
                    <td className="text-[#e2e8f0]">₹{tx.balance.toLocaleString()}</td>
                    <td className="text-[#e2e8f0] max-w-[200px] truncate">{tx.description}</td>
                    <td className="font-mono text-xs text-[#64748b]">{tx.reference}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
