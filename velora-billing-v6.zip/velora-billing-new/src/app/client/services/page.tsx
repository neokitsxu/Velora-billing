'use client';

import { useState, useEffect } from 'react';
import { Server, ExternalLink, PauseCircle, Trash2, Globe, AlertCircle, Box } from 'lucide-react';
import toast from 'react-hot-toast';

interface Service {
  id: string;
  name: string;
  productType: string;
  status: 'active' | 'suspended' | 'terminated' | 'pending';
  ip: string;
  port: number;
  serverId?: string;
  panelUrl?: string;
  nextDueDate: string;
}

const fallbackServices: Service[] = [
  {
    id: 'SVC-001',
    name: 'Minecraft Premium Server',
    productType: 'Minecraft',
    status: 'active',
    ip: '103.45.67.89',
    port: 25565,
    serverId: 'srv_minecraft_001',
    panelUrl: 'https://panel.example.com/server/srv_minecraft_001',
    nextDueDate: '2025-02-10',
  },
  {
    id: 'SVC-002',
    name: 'VPS Starter',
    productType: 'VPS',
    status: 'active',
    ip: '103.45.67.90',
    port: 22,
    serverId: 'vps_starter_002',
    panelUrl: 'https://panel.example.com/server/vps_starter_002',
    nextDueDate: '2025-02-12',
  },
  {
    id: 'SVC-003',
    name: 'Dedicated 32GB',
    productType: 'Dedicated',
    status: 'active',
    ip: '103.45.67.91',
    port: 22,
    serverId: 'dedi_32gb_003',
    panelUrl: 'https://panel.example.com/server/dedi_32gb_003',
    nextDueDate: '2025-02-08',
  },
  {
    id: 'SVC-004',
    name: 'Minecraft Basic Server',
    productType: 'Minecraft',
    status: 'suspended',
    ip: '103.45.67.92',
    port: 25565,
    nextDueDate: '2025-01-15',
  },
];

const statusBadge: Record<string, string> = {
  active: 'velora-badge-success',
  suspended: 'velora-badge-warning',
  terminated: 'velora-badge-danger',
  pending: 'velora-badge-info',
};

const typeIcons: Record<string, React.ElementType> = {
  Minecraft: Box,
  VPS: Server,
  Dedicated: Server,
};

export default function ServicesPage() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmAction, setConfirmAction] = useState<{ serviceId: string; action: string } | null>(null);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/services', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setServices(data);
          else if (Array.isArray(data.services)) setServices(data.services);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };
    fetchServices();
  }, []);

  const handleAction = async (serviceId: string, action: string) => {
    if (!confirmAction || confirmAction.serviceId !== serviceId || confirmAction.action !== action) {
      setConfirmAction({ serviceId, action });
      return;
    }

    setConfirmAction(null);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/services/${serviceId}/${action}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        toast.success(`${action.charAt(0).toUpperCase() + action.slice(1)} request submitted`);
      } else {
        toast.error('Failed to submit request');
      }
    } catch {
      toast.error('Network error');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const displayServices = services.length > 0 ? services : fallbackServices;

  return (
    <div className="space-y-6 animate-slide-up">
      <div>
        <h2 className="text-2xl font-bold text-[#e2e8f0]">My Services</h2>
        <p className="text-[#64748b] mt-1">Manage your active services and servers.</p>
      </div>

      {displayServices.length === 0 ? (
        <div className="velora-card text-center py-16">
          <Server className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Services</h3>
          <p className="text-[#64748b]">You don&apos;t have any active services.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {displayServices.map((service) => {
            const TypeIcon = typeIcons[service.productType] || Server;
            return (
              <div key={service.id} className="velora-card">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
                      <TypeIcon size={20} className="text-[#6366f1]" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-[#e2e8f0]">{service.name}</h3>
                      <span className="velora-badge text-xs mt-0.5">{service.productType}</span>
                    </div>
                  </div>
                  <span className={statusBadge[service.status] || 'velora-badge'}>{service.status}</span>
                </div>

                {/* Server Info */}
                <div className="bg-[#09090b] rounded-lg p-3 mb-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Server IP</span>
                    <span className="text-[#e2e8f0] font-mono">{service.ip}:{service.port}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Service ID</span>
                    <span className="text-[#e2e8f0] font-mono">{service.id}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Next Due</span>
                    <span className="text-[#e2e8f0]">{new Date(service.nextDueDate).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-2">
                  {service.panelUrl && service.serverId && (
                    <a
                      href={service.panelUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="velora-btn-primary inline-flex items-center gap-2 text-sm"
                    >
                      <ExternalLink size={14} />
                      Manage
                    </a>
                  )}
                  {service.status === 'active' && (
                    <>
                      <button
                        onClick={() => handleAction(service.id, 'suspend')}
                        className={`velora-btn-secondary inline-flex items-center gap-2 text-sm ${
                          confirmAction?.serviceId === service.id && confirmAction.action === 'suspend'
                            ? '!border-[#f59e0b] !text-[#f59e0b]'
                            : ''
                        }`}
                      >
                        <PauseCircle size={14} />
                        {confirmAction?.serviceId === service.id && confirmAction.action === 'suspend'
                          ? 'Confirm Suspend?'
                          : 'Suspend Request'}
                      </button>
                      <button
                        onClick={() => handleAction(service.id, 'terminate')}
                        className={`velora-btn-danger inline-flex items-center gap-2 text-sm ${
                          confirmAction?.serviceId === service.id && confirmAction.action === 'terminate'
                            ? '!border-[#ef4444] !bg-[#ef4444]/20'
                            : ''
                        }`}
                      >
                        <Trash2 size={14} />
                        {confirmAction?.serviceId === service.id && confirmAction.action === 'terminate'
                          ? 'Confirm Terminate?'
                          : 'Terminate Request'}
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
