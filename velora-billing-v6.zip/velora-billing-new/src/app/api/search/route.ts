import { PrismaClient } from '@prisma/client';
import { NextRequest, NextResponse } from 'next/server';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const q = req.nextUrl.searchParams.get('q') || '';
    const type = req.nextUrl.searchParams.get('type') || 'all';

    if (!q || q.length < 2) return NextResponse.json({ results: {}, query: q, total: 0 });

    const results: any = { clients: [], products: [], orders: [], tickets: [], invoices: [] };

    if (type === 'all' || type === 'clients') {
      results.clients = await prisma.user.findMany({ where: { OR: [{ name: { contains: q } }, { email: { contains: q } }] }, take: 10 });
    }
    if (type === 'all' || type === 'products') {
      results.products = await prisma.product.findMany({ where: { OR: [{ name: { contains: q } }, { description: { contains: q } }] }, take: 10 });
    }
    if (type === 'all' || type === 'orders') {
      results.orders = await prisma.order.findMany({ where: { OR: [{ id: { contains: q } }, { orderNumber: { contains: q } }] }, take: 10, include: { user: { select: { name: true } } } });
    }
    if (type === 'all' || type === 'tickets') {
      results.tickets = await prisma.ticket.findMany({ where: { OR: [{ subject: { contains: q } }] }, take: 10 });
    }
    if (type === 'all' || type === 'invoices') {
      results.invoices = await prisma.invoice.findMany({ where: { OR: [{ id: { contains: q } }] }, take: 10 });
    }

    const totalResults = Object.values(results).reduce((sum: number, arr: any[]) => sum + arr.length, 0);
    return NextResponse.json({ results, query: q, total: totalResults });
  } catch (error) {
    return NextResponse.json({ results: {}, query: '', total: 0 });
  }
}
