'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Package,
  Plus,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
  Search,
} from 'lucide-react';
import toast from 'react-hot-toast';

const demoProducts = [
  { id: 1, name: 'Minecraft Lite', slug: 'minecraft-lite', type: 'minecraft', category: 'gaming', price: 299, cycle: 'monthly', stock: -1, status: 'active' },
  { id: 2, name: 'Minecraft Pro', slug: 'minecraft-pro', type: 'minecraft', category: 'gaming', price: 599, cycle: 'monthly', stock: -1, status: 'active' },
  { id: 3, name: 'VPS Starter', slug: 'vps-starter', type: 'vps', category: 'hosting', price: 1299, cycle: 'monthly', stock: 25, status: 'active' },
  { id: 4, name: 'VPS Pro', slug: 'vps-pro', type: 'vps', category: 'hosting', price: 2499, cycle: 'monthly', stock: 15, status: 'active' },
  { id: 5, name: 'Dedicated 32GB', slug: 'dedicated-32gb', type: 'dedicated', category: 'hosting', price: 4999, cycle: 'monthly', stock: 5, status: 'active' },
  { id: 6, name: 'Dedicated 64GB', slug: 'dedicated-64gb', type: 'dedicated', category: 'hosting', price: 8999, cycle: 'monthly', stock: 2, status: 'active' },
  { id: 7, name: 'Domain .com', slug: 'domain-com', type: 'domain', category: 'domains', price: 799, cycle: 'yearly', stock: -1, status: 'active' },
  { id: 8, name: 'Domain .in', slug: 'domain-in', type: 'domain', category: 'domains', price: 399, cycle: 'yearly', stock: -1, status: 'active' },
  { id: 9, name: 'VPS Ultimate', slug: 'vps-ultimate', type: 'vps', category: 'hosting', price: 4999, cycle: 'monthly', stock: 0, status: 'draft' },
  { id: 10, name: 'Minecraft Premium', slug: 'minecraft-premium', type: 'minecraft', category: 'gaming', price: 999, cycle: 'monthly', stock: -1, status: 'inactive' },
];

type Product = typeof demoProducts[0];

const categories = ['all', 'gaming', 'hosting', 'domains'];

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>(demoProducts);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/products', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.products) setProducts(data.products);
        }
      } catch {
        // use demo data
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const filtered = products.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchCat = category === 'all' || p.category === category;
    return matchSearch && matchCat;
  });

  const statusColor = (status: string) => {
    switch (status) {
      case 'active': return 'velora-badge-success';
      case 'inactive': return 'velora-badge-danger';
      case 'draft': return 'velora-badge-warning';
      default: return 'velora-badge';
    }
  };

  const toggleStatus = (product: Product) => {
    const newStatus = product.status === 'active' ? 'inactive' : 'active';
    setProducts((prev) => prev.map((p) => (p.id === product.id ? { ...p, status: newStatus } : p)));
    toast.success(`Product ${newStatus === 'active' ? 'activated' : 'deactivated'}`);
  };

  const deleteProduct = (product: Product) => {
    if (!confirm(`Delete ${product.name}?`)) return;
    setProducts((prev) => prev.filter((p) => p.id !== product.id));
    toast.success('Product deleted');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse">
          <div className="h-64 bg-[#1a1a2e] rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Products</h1>
          <p className="text-[#64748b] mt-1">Manage your products and services</p>
        </div>
        <Link href="/admin/products/create" className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Create Product
        </Link>
      </div>

      {/* Category Tabs & Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="velora-input pl-10 w-full"
          />
        </div>
        <div className="flex gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-3 py-2 text-xs rounded-lg font-medium transition-colors capitalize ${
                category === c
                  ? 'bg-[#6366f1]/10 text-[#6366f1]'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Price</th>
                <th>Billing</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((product) => (
                <tr key={product.id}>
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-[#6366f1]/10 flex items-center justify-center shrink-0">
                        <Package size={16} className="text-[#6366f1]" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-[#e2e8f0]">{product.name}</p>
                        <p className="text-xs text-[#64748b]">{product.slug}</p>
                      </div>
                    </div>
                  </td>
                  <td className="text-[#64748b] capitalize">{product.type}</td>
                  <td className="text-[#e2e8f0] font-medium">₹{product.price.toLocaleString()}</td>
                  <td className="text-[#64748b] capitalize">{product.cycle}</td>
                  <td className="text-[#e2e8f0]">{product.stock === -1 ? 'Unlimited' : product.stock}</td>
                  <td><span className={statusColor(product.status)}>{product.status}</span></td>
                  <td>
                    <div className="flex items-center gap-1">
                      <Link href={`/admin/products/create?edit=${product.id}`} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#6366f1]/10 transition-colors" title="Edit">
                        <Edit3 size={14} />
                      </Link>
                      <button onClick={() => toggleStatus(product)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 transition-colors" title="Toggle Status">
                        {product.status === 'active' ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                      <button onClick={() => deleteProduct(product)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors" title="Delete">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-[#64748b]">
            <Package size={40} className="mx-auto mb-3 opacity-50" />
            <p>No products found</p>
          </div>
        )}
      </div>
    </div>
  );
}
