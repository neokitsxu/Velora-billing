'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Users,
  DollarSign,
  Activity,
  Clock,
  HelpCircle,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Package,
  ShoppingCart,
  Plus,
  BarChart3,
  Loader2,
} from 'lucide-react';

interface Stats {
  totalClients?: number;
  totalRevenue?: number;
  activeServices?: number;
  pendingOrders?: number;
  openTickets?: number;
  monthlyRevenue?: number;
}

interface Order {
  id: string;
  client: string;
  product: string;
  amount: number;
  status: string;
  date: string;
}

const statCards = [
  { label: 'Total Clients', key: 'totalClients', icon: Users, prefix: '', suffix: '' },
  { label: 'Total Revenue', key: 'totalRevenue', icon: DollarSign, prefix: '₹', suffix: '' },
  { label: 'Active Services', key: 'activeServices', icon: Activity, prefix: '', suffix: '' },
  { label: 'Pending Orders', key: 'pendingOrders', icon: Clock, prefix: '', suffix: '' },
  { label: 'Open Tickets', key: 'openTickets', icon: HelpCircle, prefix: '', suffix: '' },
  { label: 'Monthly Revenue', key: 'monthlyRevenue', icon: TrendingUp, prefix: '₹', suffix: '' },
];

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({});
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/stats', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.stats) setStats(data.stats);
          if (data.recentOrders) setOrders(data.recentOrders);
        }
      } catch {
        // No data
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const statusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'velora-badge-success';
      case 'pending': return 'velora-badge-warning';
      case 'refunded': return 'velora-badge-info';
      case 'cancelled': return 'velora-badge-danger';
      default: return 'velora-badge';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="velora-card p-6 animate-pulse">
              <div className="h-4 bg-[#1a1a2e] rounded w-24 mb-4" />
              <div className="h-8 bg-[#1a1a2e] rounded w-32" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const hasData = Object.keys(stats).length > 0;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Dashboard</h1>
        <p className="text-[#64748b] mt-1">Welcome back, Admin. Here is your overview.</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 stagger-children">
        {statCards.map((card) => {
          const Icon = card.icon;
          const value = (stats as any)[card.key];
          return (
            <div key={card.key} className="velora-card p-6 hover-lift hover-glow">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2.5 rounded-lg bg-[#6366f1]/10">
                  <Icon size={20} className="text-[#6366f1]" />
                </div>
              </div>
              <p className="text-2xl font-bold text-[#e2e8f0]">
                {card.prefix}{value !== undefined ? value.toLocaleString() : '0'}{card.suffix}
              </p>
              <p className="text-sm text-[#64748b] mt-1">{card.label}</p>
            </div>
          );
        })}
      </div>

      {/* Revenue Chart Placeholder */}
      <div className="velora-card p-6 animate-fade-in-up">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-[#e2e8f0]">Revenue Overview</h3>
            <p className="text-sm text-[#64748b]">Monthly revenue for the past year</p>
          </div>
        </div>
        {!hasData ? (
          <div className="flex flex-col items-center justify-center h-48 text-[#64748b]">
            <BarChart3 size={48} className="mb-3 text-[#1a1a2e]" />
            <p className="text-sm">Revenue data will appear as orders come in</p>
          </div>
        ) : (
          <div className="flex items-end gap-3 h-48">
            {['J','F','M','A','M','J','J','A','S','O','N','D'].map((m, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                <div
                  className="w-full rounded-t-md bg-gradient-to-t from-[#6366f1]/20 to-[#8b5cf6]/20 hover:from-[#6366f1]/40 hover:to-[#8b5cf6]/40 transition-all duration-500 min-h-[4px]"
                  style={{ height: `${Math.max(4, Math.random() * 80)}px`, animation: `fadeInUp 0.5s ease-out ${i * 0.05}s both` }}
                />
                <span className="text-xs text-[#64748b]">{m}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent Orders */}
      <div className="velora-card p-6 animate-fade-in-up">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-[#e2e8f0]">Recent Orders</h3>
          <Link href="/admin/orders" className="velora-link text-sm">View All</Link>
        </div>
        {orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-[#64748b]">
            <ShoppingCart size={48} className="mb-3 text-[#1a1a2e]" />
            <p className="text-sm">No orders yet</p>
            <p className="text-xs text-[#475569] mt-1">Orders will appear here when clients make purchases</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="velora-table">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Client</th>
                  <th>Product</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id}>
                    <td className="font-mono text-sm text-[#6366f1]">{order.id}</td>
                    <td className="text-[#e2e8f0]">{order.client}</td>
                    <td className="text-[#64748b]">{order.product}</td>
                    <td className="text-[#e2e8f0]">₹{order.amount.toLocaleString()}</td>
                    <td><span className={statusColor(order.status)}>{order.status}</span></td>
                    <td className="text-[#64748b]">{order.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 stagger-children">
        <Link
          href="/admin/products/create"
          className="velora-card p-5 flex items-center gap-4 hover:border-[#6366f1]/50 transition-all group hover-lift hover-glow"
        >
          <div className="p-3 rounded-lg bg-[#6366f1]/10 group-hover:bg-[#6366f1]/20 group-hover:scale-110 transition-all">
            <Plus size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <p className="font-medium text-[#e2e8f0]">Create Product</p>
            <p className="text-sm text-[#64748b]">Add a new product or service</p>
          </div>
        </Link>
        <Link
          href="/admin/clients"
          className="velora-card p-5 flex items-center gap-4 hover:border-[#6366f1]/50 transition-all group"
        >
          <div className="p-3 rounded-lg bg-[#10b981]/10 group-hover:bg-[#10b981]/20 transition-colors">
            <Users size={20} className="text-[#10b981]" />
          </div>
          <div>
            <p className="font-medium text-[#e2e8f0]">View All Clients</p>
            <p className="text-sm text-[#64748b]">Manage your client base</p>
          </div>
        </Link>
        <Link
          href="/admin/tickets"
          className="velora-card p-5 flex items-center gap-4 hover:border-[#6366f1]/50 transition-all group"
        >
          <div className="p-3 rounded-lg bg-[#f59e0b]/10 group-hover:bg-[#f59e0b]/20 transition-colors">
            <ShoppingCart size={20} className="text-[#f59e0b]" />
          </div>
          <div>
            <p className="font-medium text-[#e2e8f0]">Manage Tickets</p>
            <p className="text-sm text-[#64748b]">Respond to support requests</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
