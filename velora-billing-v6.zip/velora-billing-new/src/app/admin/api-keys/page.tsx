'use client';

import { useState, useEffect } from 'react';
import { Key, Plus, Copy, Trash2, RefreshCw, Shield, Eye, EyeOff, Loader2, Clock, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

interface ApiKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  lastUsed: string;
  createdAt: string;
  expiresAt?: string;
  active: boolean;
}

export default function AdminApiKeys() {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [newKey, setNewKey] = useState({ name: '', permissions: ['read'], expiry: '30' });

  useEffect(() => { fetchKeys(); }, []);

  const fetchKeys = async () => {
    setLoading(true);
    try {
      // API keys stored in settings
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/settings', { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        const apiKeys = data.settings?.api?.keys || [];
        setKeys(apiKeys);
      }
    } catch { setKeys([]); } finally { setLoading(false); }
  };

  const createKey = () => {
    if (!newKey.name.trim()) { toast.error('Enter a name'); return; }
    const generatedKey = `vlr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
    const key: ApiKey = {
      id: Date.now().toString(),
      name: newKey.name,
      key: generatedKey,
      permissions: newKey.permissions,
      lastUsed: '-',
      createdAt: new Date().toISOString(),
      active: true,
    };
    setKeys(prev => [...prev, key]);
    setShowCreate(false);
    setNewKey({ name: '', permissions: ['read'], expiry: '30' });
    toast.success('API key created!');
  };

  const deleteKey = (id: string) => {
    setKeys(prev => prev.filter(k => k.id !== id));
    toast.success('API key deleted');
  };

  const toggleVisibility = (id: string) => {
    setVisibleKeys(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast.success('Key copied!');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">API Keys</h1>
          <p className="text-[#64748b] mt-1">Manage API keys for external integrations</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowCreate(!showCreate)} className="velora-btn-primary flex items-center gap-2 text-sm">
            <Plus size={14} /> Create Key
          </button>
        </div>
      </div>

      {/* Info Banner */}
      <div className="flex items-center gap-3 p-4 rounded-xl bg-[#6366f1]/5 border border-[#6366f1]/20">
        <Shield size={16} className="text-[#6366f1] flex-shrink-0" />
        <p className="text-xs text-[#6366f1]">API keys allow external applications to access your Velora Billing API. Keep them secure and rotate regularly.</p>
      </div>

      {/* Create Form */}
      {showCreate && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Create New API Key</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Key Name</label>
              <input type="text" value={newKey.name} onChange={(e) => setNewKey({ ...newKey, name: e.target.value })} placeholder="e.g., Pterodactyl Integration" className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Expires In (days)</label>
              <select value={newKey.expiry} onChange={(e) => setNewKey({ ...newKey, expiry: e.target.value })} className="velora-input w-full">
                <option value="7">7 Days</option>
                <option value="30">30 Days</option>
                <option value="90">90 Days</option>
                <option value="365">1 Year</option>
                <option value="never">Never</option>
              </select>
            </div>
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-[#64748b] mb-2">Permissions</label>
            <div className="flex flex-wrap gap-2">
              {['read', 'write', 'admin'].map(perm => (
                <button key={perm} onClick={() => setNewKey({ ...newKey, permissions: newKey.permissions.includes(perm) ? newKey.permissions.filter(p => p !== perm) : [...newKey.permissions, perm] })} className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${newKey.permissions.includes(perm) ? 'bg-[#6366f1] text-white' : 'bg-[#0c0c0f] border border-[#1a1a2e] text-[#475569]'}`}>
                  {perm}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={createKey} className="velora-btn-primary text-sm">Generate Key</button>
            <button onClick={() => setShowCreate(false)} className="velora-btn-secondary text-sm">Cancel</button>
          </div>
        </div>
      )}

      {/* Keys List */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : keys.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <Key size={48} className="mx-auto text-[#1a1a2e] mb-4" />
          <p className="text-[#64748b]">No API keys yet</p>
          <p className="text-xs text-[#475569] mt-1">Create an API key to integrate with external services</p>
        </div>
      ) : (
        <div className="space-y-3">
          {keys.map((key, i) => (
            <div key={key.id} className="velora-card p-5 flex items-center justify-between hover:border-[#6366f1]/20 transition-all" style={{ animation: `fadeInUp 0.3s ease-out ${i * 0.05}s both` }}>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
                  <Key size={16} className="text-[#6366f1]" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#e2e8f0]">{key.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <code className="text-[11px] font-mono text-[#475569] bg-[#09090b] px-2 py-0.5 rounded">
                      {visibleKeys.has(key.id) ? key.key : key.key.slice(0, 12) + '••••••••'}
                    </code>
                    <span className="text-[10px] text-[#475569]">Created {new Date(key.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex gap-1.5 mt-1.5">
                    {key.permissions.map(p => (
                      <span key={p} className="px-2 py-0.5 rounded bg-[#0c0c0f] text-[9px] text-[#475569] border border-[#1a1a2e]">{p}</span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => toggleVisibility(key.id)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#e2e8f0] transition-colors">
                  {visibleKeys.has(key.id) ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
                <button onClick={() => copyKey(key.key)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#10b981] transition-colors">
                  <Copy size={14} />
                </button>
                <button onClick={() => deleteKey(key.id)} className="p-2 rounded-lg hover:bg-[#ef4444]/10 text-[#475569] hover:text-[#ef4444] transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
