'use client';

import { useState, useEffect } from 'react';
import {
  HelpCircle,
  Search,
  Eye,
  MessageSquare,
  XCircle,
  Filter,
  X,
  Send,
} from 'lucide-react';
import toast from 'react-hot-toast';

const demoTickets = [
  { id: 'TKT-501', subject: 'Server not starting', client: 'Rahul Sharma', department: 'Support', priority: 'high', status: 'open', updated: '2025-01-15 14:30' },
  { id: 'TKT-500', subject: 'Cannot connect to FTP', client: 'Priya Patel', department: 'Support', priority: 'medium', status: 'open', updated: '2025-01-15 11:20' },
  { id: 'TKT-499', subject: 'Refund request for cancelled order', client: 'Vikram Singh', department: 'Billing', priority: 'high', status: 'open', updated: '2025-01-14 18:10' },
  { id: 'TKT-498', subject: 'Upgrade to VPS Pro', client: 'Sneha Reddy', department: 'Sales', priority: 'low', status: 'in-progress', updated: '2025-01-14 16:45' },
  { id: 'TKT-497', subject: 'Domain DNS propagation issue', client: 'Meera Iyer', department: 'Support', priority: 'medium', status: 'in-progress', updated: '2025-01-14 10:00' },
  { id: 'TKT-496', subject: 'Need more RAM allocation', client: 'Amit Kumar', department: 'Sales', priority: 'low', status: 'closed', updated: '2025-01-13 22:30' },
  { id: 'TKT-495', subject: 'Payment failed but money deducted', client: 'Arjun Nair', department: 'Billing', priority: 'high', status: 'open', updated: '2025-01-13 15:15' },
  { id: 'TKT-494', subject: 'How to install plugins', client: 'Kavya Joshi', department: 'Support', priority: 'low', status: 'closed', updated: '2025-01-12 20:00' },
  { id: 'TKT-493', subject: 'Server lag spikes during peak hours', client: 'Rohan Das', department: 'Support', priority: 'high', status: 'in-progress', updated: '2025-01-12 14:30' },
  { id: 'TKT-492', subject: 'Request for custom plan', client: 'Deepak Verma', department: 'Sales', priority: 'medium', status: 'open', updated: '2025-01-11 09:00' },
];

type Ticket = typeof demoTickets[0];

export default function AdminTickets() {
  const [tickets, setTickets] = useState<Ticket[]>(demoTickets);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [replyTicket, setReplyTicket] = useState<Ticket | null>(null);
  const [replyText, setReplyText] = useState('');

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/tickets', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.tickets) setTickets(data.tickets);
        }
      } catch {
        // use demo data
      } finally {
        setLoading(false);
      }
    };
    fetchTickets();
  }, []);

  const filtered = tickets.filter((t) => {
    const matchSearch =
      t.id.toLowerCase().includes(search.toLowerCase()) ||
      t.subject.toLowerCase().includes(search.toLowerCase()) ||
      t.client.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || t.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusColor = (status: string) => {
    switch (status) {
      case 'open': return 'velora-badge-success';
      case 'in-progress': return 'velora-badge-warning';
      case 'closed': return 'velora-badge';
      default: return 'velora-badge';
    }
  };

  const priorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'velora-badge-danger';
      case 'medium': return 'velora-badge-warning';
      case 'low': return 'velora-badge-info';
      default: return 'velora-badge';
    }
  };

  const closeTicket = (ticket: Ticket) => {
    setTickets((prev) => prev.map((t) => (t.id === ticket.id ? { ...t, status: 'closed' } : t)));
    toast.success('Ticket closed');
  };

  const submitReply = () => {
    if (!replyText.trim()) {
      toast.error('Reply cannot be empty');
      return;
    }
    try {
      const token = localStorage.getItem('velora_token');
      fetch(`/api/admin/tickets/${replyTicket?.id}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ message: replyText }),
      });
    } catch {
      // demo mode
    }
    setTickets((prev) =>
      prev.map((t) => (t.id === replyTicket?.id ? { ...t, status: 'in-progress' as const, updated: new Date().toISOString().slice(0, 16).replace('T', ' ') } : t))
    );
    toast.success('Reply sent');
    setReplyTicket(null);
    setReplyText('');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse">
          <div className="h-64 bg-[#1a1a2e] rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Tickets</h1>
        <p className="text-[#64748b] mt-1">Manage support tickets</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search by ticket #, subject, or client..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="velora-input pl-10 w-full"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-[#64748b]" />
          {['all', 'open', 'in-progress', 'closed'].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-2 text-xs rounded-lg font-medium transition-colors ${
                statusFilter === s
                  ? 'bg-[#6366f1]/10 text-[#6366f1]'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'
              }`}
            >
              {s === 'in-progress' ? 'In Progress' : s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Ticket #</th>
                <th>Subject</th>
                <th>Client</th>
                <th>Department</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Updated</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((ticket) => (
                <tr key={ticket.id}>
                  <td className="font-mono text-sm text-[#6366f1]">{ticket.id}</td>
                  <td className="text-[#e2e8f0] max-w-[200px] truncate">{ticket.subject}</td>
                  <td className="text-[#e2e8f0]">{ticket.client}</td>
                  <td className="text-[#64748b]">{ticket.department}</td>
                  <td><span className={priorityColor(ticket.priority)}>{ticket.priority}</span></td>
                  <td><span className={statusColor(ticket.status)}>{ticket.status}</span></td>
                  <td className="text-[#64748b] text-sm">{ticket.updated}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#6366f1]/10 transition-colors" title="View">
                        <Eye size={14} />
                      </button>
                      {ticket.status !== 'closed' && (
                        <button onClick={() => { setReplyTicket(ticket); setReplyText(''); }} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#8b5cf6] hover:bg-[#8b5cf6]/10 transition-colors" title="Reply">
                          <MessageSquare size={14} />
                        </button>
                      )}
                      {ticket.status !== 'closed' && (
                        <button onClick={() => closeTicket(ticket)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors" title="Close">
                          <XCircle size={14} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-[#64748b]">
            <HelpCircle size={40} className="mx-auto mb-3 opacity-50" />
            <p>No tickets found</p>
          </div>
        )}
      </div>

      {/* Reply Modal */}
      {replyTicket && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="velora-card p-6 w-full max-w-lg animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-[#e2e8f0]">Reply to {replyTicket.id}</h3>
                <p className="text-sm text-[#64748b]">{replyTicket.subject}</p>
              </div>
              <button onClick={() => setReplyTicket(null)} className="p-1 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors">
                <X size={18} />
              </button>
            </div>
            <textarea
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              className="velora-input w-full h-32 resize-none mb-4"
              placeholder="Type your reply..."
              autoFocus
            />
            <div className="flex justify-end gap-3">
              <button onClick={() => setReplyTicket(null)} className="velora-btn-secondary">Cancel</button>
              <button onClick={submitReply} className="velora-btn-primary flex items-center gap-2">
                <Send size={14} /> Send Reply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
