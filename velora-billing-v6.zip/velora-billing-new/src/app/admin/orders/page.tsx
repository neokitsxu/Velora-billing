'use client';

import { useState, useEffect } from 'react';
import {
  ShoppingCart,
  Search,
  Eye,
  CheckCircle,
  RotateCcw,
  XCircle,
  Filter,
} from 'lucide-react';
import toast from 'react-hot-toast';

const demoOrders = [
  { id: 'ORD-1041', client: 'Rahul Sharma', clientId: 1, product: 'Minecraft Pro', amount: 599, tax: 0, status: 'paid', payment: 'upi', date: '2025-01-15 14:23' },
  { id: 'ORD-1040', client: 'Priya Patel', clientId: 2, product: 'VPS Starter', amount: 1299, tax: 234, status: 'pending', payment: null, date: '2025-01-15 12:10' },
  { id: 'ORD-1039', client: 'Amit Kumar', clientId: 3, product: 'Domain .com', amount: 799, tax: 144, status: 'paid', payment: 'upi', date: '2025-01-14 18:45' },
  { id: 'ORD-1038', client: 'Sneha Reddy', clientId: 4, product: 'Minecraft Lite', amount: 299, tax: 54, status: 'paid', payment: 'upi', date: '2025-01-14 10:30' },
  { id: 'ORD-1037', client: 'Vikram Singh', clientId: 5, product: 'Dedicated 32GB', amount: 4999, tax: 900, status: 'refunded', payment: 'bank', date: '2025-01-14 09:15' },
  { id: 'ORD-1036', client: 'Anjali Gupta', clientId: 6, product: 'VPS Pro', amount: 2499, tax: 450, status: 'paid', payment: 'upi', date: '2025-01-13 21:00' },
  { id: 'ORD-1035', client: 'Rohan Das', clientId: 7, product: 'Minecraft Pro', amount: 599, tax: 108, status: 'cancelled', payment: null, date: '2025-01-13 16:40' },
  { id: 'ORD-1034', client: 'Meera Iyer', clientId: 8, product: 'Domain .in', amount: 399, tax: 72, status: 'paid', payment: 'upi', date: '2025-01-12 11:20' },
  { id: 'ORD-1033', client: 'Arjun Nair', clientId: 9, product: 'VPS Starter', amount: 1299, tax: 234, status: 'pending', payment: null, date: '2025-01-12 08:55' },
  { id: 'ORD-1032', client: 'Kavya Joshi', clientId: 10, product: 'Minecraft Lite', amount: 299, tax: 54, status: 'paid', payment: 'upi', date: '2025-01-11 19:10' },
  { id: 'ORD-1031', client: 'Deepak Verma', clientId: 11, product: 'VPS Ultimate', amount: 4999, tax: 900, status: 'paid', payment: 'bank', date: '2025-01-11 15:30' },
  { id: 'ORD-1030', client: 'Pooja Sharma', clientId: 12, product: 'Domain .com', amount: 799, tax: 144, status: 'pending', payment: null, date: '2025-01-10 13:45' },
];

type Order = typeof demoOrders[0];

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>(demoOrders);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/orders', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.orders) setOrders(data.orders);
        }
      } catch {
        // use demo data
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  const filtered = orders.filter((o) => {
    const matchSearch =
      o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.client.toLowerCase().includes(search.toLowerCase()) ||
      o.product.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'velora-badge-success';
      case 'pending': return 'velora-badge-warning';
      case 'refunded': return 'velora-badge-info';
      case 'cancelled': return 'velora-badge-danger';
      default: return 'velora-badge';
    }
  };

  const markPaid = (order: Order) => {
    setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, status: 'paid', payment: 'manual' } : o)));
    toast.success('Order marked as paid');
  };

  const refundOrder = (order: Order) => {
    if (!confirm(`Refund order ${order.id}?`)) return;
    setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, status: 'refunded' } : o)));
    toast.success('Order refunded');
  };

  const cancelOrder = (order: Order) => {
    if (!confirm(`Cancel order ${order.id}?`)) return;
    setOrders((prev) => prev.map((o) => (o.id === order.id ? { ...o, status: 'cancelled' } : o)));
    toast.success('Order cancelled');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse">
          <div className="h-64 bg-[#1a1a2e] rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Orders</h1>
        <p className="text-[#64748b] mt-1">Manage all orders</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search by order ID, client, or product..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="velora-input pl-10 w-full"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-[#64748b]" />
          {['all', 'paid', 'pending', 'refunded', 'cancelled'].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-2 text-xs rounded-lg font-medium transition-colors capitalize ${
                statusFilter === s
                  ? 'bg-[#6366f1]/10 text-[#6366f1]'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Order #</th>
                <th>Client</th>
                <th>Product</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((order) => (
                <tr key={order.id}>
                  <td className="font-mono text-sm text-[#6366f1]">{order.id}</td>
                  <td className="text-[#e2e8f0]">{order.client}</td>
                  <td className="text-[#64748b]">{order.product}</td>
                  <td className="text-[#e2e8f0] font-medium">₹{order.amount.toLocaleString()}</td>
                  <td><span className={statusColor(order.status)}>{order.status}</span></td>
                  <td className="text-[#64748b] capitalize">{order.payment || '—'}</td>
                  <td className="text-[#64748b] text-sm">{order.date}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#6366f1]/10 transition-colors" title="View">
                        <Eye size={14} />
                      </button>
                      {order.status !== 'paid' && (
                        <button onClick={() => markPaid(order)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#10b981] hover:bg-[#10b981]/10 transition-colors" title="Mark Paid">
                          <CheckCircle size={14} />
                        </button>
                      )}
                      {order.status === 'paid' && (
                        <button onClick={() => refundOrder(order)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 transition-colors" title="Refund">
                          <RotateCcw size={14} />
                        </button>
                      )}
                      {order.status !== 'cancelled' && order.status !== 'refunded' && (
                        <button onClick={() => cancelOrder(order)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors" title="Cancel">
                          <XCircle size={14} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-[#64748b]">
            <ShoppingCart size={40} className="mx-auto mb-3 opacity-50" />
            <p>No orders found</p>
          </div>
        )}
      </div>
    </div>
  );
}
