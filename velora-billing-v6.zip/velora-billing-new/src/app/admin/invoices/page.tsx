'use client';

import { useState, useEffect } from 'react';
import {
  FileText,
  Search,
  CheckCircle,
  Bell,
  XCircle,
  Filter,
} from 'lucide-react';
import toast from 'react-hot-toast';

const demoInvoices = [
  { id: 'INV-2041', client: 'Rahul Sharma', amount: 599, tax: 108, total: 707, status: 'paid', dueDate: '2025-01-20', date: '2025-01-15' },
  { id: 'INV-2040', client: 'Priya Patel', amount: 1299, tax: 234, total: 1533, status: 'pending', dueDate: '2025-01-25', date: '2025-01-15' },
  { id: 'INV-2039', client: 'Amit Kumar', amount: 799, tax: 144, total: 943, status: 'paid', dueDate: '2025-01-19', date: '2025-01-14' },
  { id: 'INV-2038', client: 'Sneha Reddy', amount: 299, tax: 54, total: 353, status: 'paid', dueDate: '2025-01-19', date: '2025-01-14' },
  { id: 'INV-2037', client: 'Vikram Singh', amount: 4999, tax: 900, total: 5899, status: 'refunded', dueDate: '2025-01-19', date: '2025-01-14' },
  { id: 'INV-2036', client: 'Anjali Gupta', amount: 2499, tax: 450, total: 2949, status: 'paid', dueDate: '2025-01-18', date: '2025-01-13' },
  { id: 'INV-2035', client: 'Rohan Das', amount: 599, tax: 108, total: 707, status: 'cancelled', dueDate: '2025-01-18', date: '2025-01-13' },
  { id: 'INV-2034', client: 'Meera Iyer', amount: 399, tax: 72, total: 471, status: 'overdue', dueDate: '2025-01-10', date: '2025-01-12' },
  { id: 'INV-2033', client: 'Arjun Nair', amount: 1299, tax: 234, total: 1533, status: 'pending', dueDate: '2025-01-22', date: '2025-01-12' },
  { id: 'INV-2032', client: 'Kavya Joshi', amount: 299, tax: 54, total: 353, status: 'paid', dueDate: '2025-01-21', date: '2025-01-11' },
  { id: 'INV-2031', client: 'Deepak Verma', amount: 4999, tax: 900, total: 5899, status: 'overdue', dueDate: '2025-01-08', date: '2025-01-11' },
];

type Invoice = typeof demoInvoices[0];

export default function AdminInvoices() {
  const [invoices, setInvoices] = useState<Invoice[]>(demoInvoices);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/invoices', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.invoices) setInvoices(data.invoices);
        }
      } catch {
        // use demo data
      } finally {
        setLoading(false);
      }
    };
    fetchInvoices();
  }, []);

  const filtered = invoices.filter((inv) => {
    const matchSearch =
      inv.id.toLowerCase().includes(search.toLowerCase()) ||
      inv.client.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'velora-badge-success';
      case 'pending': return 'velora-badge-warning';
      case 'overdue': return 'velora-badge-danger';
      case 'refunded': return 'velora-badge-info';
      case 'cancelled': return 'velora-badge';
      default: return 'velora-badge';
    }
  };

  const markPaid = (inv: Invoice) => {
    setInvoices((prev) => prev.map((i) => (i.id === inv.id ? { ...i, status: 'paid' } : i)));
    toast.success('Invoice marked as paid');
  };

  const sendReminder = (inv: Invoice) => {
    toast.success(`Payment reminder sent to ${inv.client}`);
  };

  const cancelInvoice = (inv: Invoice) => {
    if (!confirm(`Cancel invoice ${inv.id}?`)) return;
    setInvoices((prev) => prev.map((i) => (i.id === inv.id ? { ...i, status: 'cancelled' } : i)));
    toast.success('Invoice cancelled');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse">
          <div className="h-64 bg-[#1a1a2e] rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Invoices</h1>
        <p className="text-[#64748b] mt-1">Manage all invoices</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search by invoice # or client..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="velora-input pl-10 w-full"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-[#64748b]" />
          {['all', 'paid', 'pending', 'overdue', 'cancelled'].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-2 text-xs rounded-lg font-medium transition-colors capitalize ${
                statusFilter === s
                  ? 'bg-[#6366f1]/10 text-[#6366f1]'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Client</th>
                <th>Amount</th>
                <th>Tax</th>
                <th>Total</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((inv) => (
                <tr key={inv.id}>
                  <td className="font-mono text-sm text-[#6366f1]">{inv.id}</td>
                  <td className="text-[#e2e8f0]">{inv.client}</td>
                  <td className="text-[#e2e8f0]">₹{inv.amount.toLocaleString()}</td>
                  <td className="text-[#64748b]">₹{inv.tax.toLocaleString()}</td>
                  <td className="text-[#e2e8f0] font-medium">₹{inv.total.toLocaleString()}</td>
                  <td><span className={statusColor(inv.status)}>{inv.status}</span></td>
                  <td className={`text-sm ${inv.status === 'overdue' ? 'text-[#ef4444] font-medium' : 'text-[#64748b]'}`}>{inv.dueDate}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      {inv.status !== 'paid' && inv.status !== 'cancelled' && (
                        <button onClick={() => markPaid(inv)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#10b981] hover:bg-[#10b981]/10 transition-colors" title="Mark Paid">
                          <CheckCircle size={14} />
                        </button>
                      )}
                      {(inv.status === 'pending' || inv.status === 'overdue') && (
                        <button onClick={() => sendReminder(inv)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 transition-colors" title="Send Reminder">
                          <Bell size={14} />
                        </button>
                      )}
                      {inv.status !== 'cancelled' && inv.status !== 'paid' && (
                        <button onClick={() => cancelInvoice(inv)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors" title="Cancel">
                          <XCircle size={14} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-[#64748b]">
            <FileText size={40} className="mx-auto mb-3 opacity-50" />
            <p>No invoices found</p>
          </div>
        )}
      </div>
    </div>
  );
}
