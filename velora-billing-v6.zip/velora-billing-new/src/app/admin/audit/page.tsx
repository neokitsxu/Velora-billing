'use client';

import { useState, useEffect } from 'react';
import {
  ScrollText,
  Search,
  Filter,
  ChevronLeft,
  ChevronRight,
  User,
  Shield,
  Edit,
  Trash2,
  Plus,
  LogIn,
  CreditCard,
} from 'lucide-react';
import toast from 'react-hot-toast';

type AuditLog = {
  id: number;
  timestamp: string;
  user: string;
  userId: number;
  action: string;
  details: string;
  ipAddress: string;
  userAgent: string;
};

const demoLogs: AuditLog[] = [
  { id: 1, timestamp: '2025-01-15 14:32:10', user: 'Admin', userId: 1, action: 'product.create', details: 'Created product "Minecraft Premium"', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 2, timestamp: '2025-01-15 14:28:05', user: 'Admin', userId: 1, action: 'client.edit', details: 'Updated client "Rahul Sharma" - changed role to admin', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 3, timestamp: '2025-01-15 14:20:33', user: 'Rahul Sharma', userId: 2, action: 'order.create', details: 'Placed order #ORD-1041 for Minecraft Pro', ipAddress: '49.207.123.45', userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/121' },
  { id: 4, timestamp: '2025-01-15 13:55:12', user: 'Priya Patel', userId: 3, action: 'ticket.create', details: 'Opened ticket #TKT-501 "Server not starting"', ipAddress: '157.49.210.33', userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2) Safari/604' },
  { id: 5, timestamp: '2025-01-15 13:40:00', user: 'Admin', userId: 1, action: 'settings.update', details: 'Updated payment settings - UPI ID changed', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 6, timestamp: '2025-01-15 12:15:44', user: 'Admin', userId: 1, action: 'node.sync', details: 'Synced node "India-Mumbai-1" successfully', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 7, timestamp: '2025-01-15 11:30:22', user: 'Amit Kumar', userId: 4, action: 'auth.login', details: 'User logged in from new device', ipAddress: '182.75.43.21', userAgent: 'Mozilla/5.0 (Linux; Android 14) Chrome/121' },
  { id: 8, timestamp: '2025-01-15 10:45:18', user: 'Admin', userId: 1, action: 'invoice.mark_paid', details: 'Manually marked invoice #INV-2034 as paid', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 9, timestamp: '2025-01-15 10:10:55', user: 'Admin', userId: 1, action: 'client.suspend', details: 'Suspended client "Amit Kumar" - reason: ToS violation', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 10, timestamp: '2025-01-15 09:30:00', user: 'Sneha Reddy', userId: 5, action: 'payment.complete', details: 'UPI payment of ₹299 for order #ORD-1038', ipAddress: '157.49.88.12', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/122' },
  { id: 11, timestamp: '2025-01-14 22:15:33', user: 'Admin', userId: 1, action: 'order.refund', details: 'Refunded order #ORD-1037 - ₹4,999', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 12, timestamp: '2025-01-14 21:00:12', user: 'Admin', userId: 1, action: 'ticket.reply', details: 'Replied to ticket #TKT-498', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 13, timestamp: '2025-01-14 20:30:45', user: 'Vikram Singh', userId: 6, action: 'auth.login', details: 'User logged in', ipAddress: '14.139.56.78', userAgent: 'Mozilla/5.0 (X11; Linux x86_64) Chrome/121' },
  { id: 14, timestamp: '2025-01-14 19:45:00', user: 'Admin', userId: 1, action: 'theme.update', details: 'Updated theme - changed primary color', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 15, timestamp: '2025-01-14 18:10:20', user: 'Meera Iyer', userId: 8, action: 'ticket.create', details: 'Opened ticket #TKT-497 "Domain DNS propagation issue"', ipAddress: '106.51.90.123', userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/17.2' },
  { id: 16, timestamp: '2025-01-14 17:30:00', user: 'Admin', userId: 1, action: 'client.delete', details: 'Deleted client "Test User" (ID: 99)', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 17, timestamp: '2025-01-14 16:00:11', user: 'Arjun Nair', userId: 9, action: 'order.create', details: 'Placed order #ORD-1033 for VPS Starter', ipAddress: '122.177.44.56', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Edge/121' },
  { id: 18, timestamp: '2025-01-14 14:20:00', user: 'Admin', userId: 1, action: 'node.create', details: 'Added new node "SG-Singapore-1" (Proxmox)', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
  { id: 19, timestamp: '2025-01-14 12:45:33', user: 'Rohan Das', userId: 7, action: 'payment.complete', details: 'UPI payment of ₹599 for order #ORD-1035', ipAddress: '49.36.210.78', userAgent: 'Mozilla/5.0 (Linux; Android 14) Chrome/121' },
  { id: 20, timestamp: '2025-01-14 11:00:00', user: 'Admin', userId: 1, action: 'product.edit', details: 'Updated product "VPS Pro" - price changed from ₹2,299 to ₹2,499', ipAddress: '103.45.67.89', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121' },
];

const actionIcons: Record<string, any> = {
  'product.create': Plus,
  'product.edit': Edit,
  'client.edit': Edit,
  'client.suspend': Shield,
  'client.delete': Trash2,
  'order.create': Plus,
  'order.refund': CreditCard,
  'ticket.create': Plus,
  'ticket.reply': Edit,
  'auth.login': LogIn,
  'settings.update': Edit,
  'node.sync': Edit,
  'node.create': Plus,
  'invoice.mark_paid': CreditCard,
  'payment.complete': CreditCard,
  'theme.update': Edit,
};

const actionTypes = ['all', 'auth', 'product', 'client', 'order', 'ticket', 'payment', 'settings', 'node', 'invoice', 'theme'];

const PER_PAGE = 10;

export default function AuditLogs() {
  const [logs, setLogs] = useState<AuditLog[]>(demoLogs);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [userFilter, setUserFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [page, setPage] = useState(1);

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/audit', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.logs) setLogs(data.logs);
        }
      } catch {
        // use demo data
      } finally {
        setLoading(false);
      }
    };
    fetchLogs();
  }, []);

  const uniqueUsers = [...new Set(logs.map((l) => l.user))];

  const filtered = logs.filter((log) => {
    const matchSearch =
      log.user.toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase()) ||
      log.details.toLowerCase().includes(search.toLowerCase());
    const matchAction = actionFilter === 'all' || log.action.startsWith(actionFilter);
    const matchUser = userFilter === 'all' || log.user === userFilter;
    const matchDateFrom = !dateFrom || log.timestamp >= dateFrom;
    const matchDateTo = !dateTo || log.timestamp <= dateTo + ' 23:59:59';
    return matchSearch && matchAction && matchUser && matchDateFrom && matchDateTo;
  });

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const getActionColor = (action: string) => {
    if (action.includes('create')) return 'text-[#10b981] bg-[#10b981]/10';
    if (action.includes('delete') || action.includes('suspend')) return 'text-[#ef4444] bg-[#ef4444]/10';
    if (action.includes('edit') || action.includes('update') || action.includes('reply') || action.includes('sync')) return 'text-[#f59e0b] bg-[#f59e0b]/10';
    if (action.includes('refund')) return 'text-[#8b5cf6] bg-[#8b5cf6]/10';
    if (action.includes('login')) return 'text-[#6366f1] bg-[#6366f1]/10';
    if (action.includes('payment') || action.includes('mark_paid')) return 'text-[#10b981] bg-[#10b981]/10';
    return 'text-[#64748b] bg-[#64748b]/10';
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse">
          <div className="h-64 bg-[#1a1a2e] rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Audit Logs</h1>
        <p className="text-[#64748b] mt-1">Track all administrative and user actions</p>
      </div>

      {/* Filters */}
      <div className="velora-card p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative sm:col-span-2 lg:col-span-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
            <input
              type="text"
              placeholder="Search logs..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="velora-input pl-9 w-full text-sm"
            />
          </div>
          <select value={userFilter} onChange={(e) => { setUserFilter(e.target.value); setPage(1); }} className="velora-input text-sm">
            <option value="all">All Users</option>
            {uniqueUsers.map((u) => (
              <option key={u} value={u}>{u}</option>
            ))}
          </select>
          <select value={actionFilter} onChange={(e) => { setActionFilter(e.target.value); setPage(1); }} className="velora-input text-sm">
            {actionTypes.map((a) => (
              <option key={a} value={a}>{a === 'all' ? 'All Actions' : a.charAt(0).toUpperCase() + a.slice(1)}</option>
            ))}
          </select>
          <input
            type="date"
            value={dateFrom}
            onChange={(e) => { setDateFrom(e.target.value); setPage(1); }}
            className="velora-input text-sm"
            placeholder="From"
          />
          <input
            type="date"
            value={dateTo}
            onChange={(e) => { setDateTo(e.target.value); setPage(1); }}
            className="velora-input text-sm"
            placeholder="To"
          />
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>User</th>
                <th>Action</th>
                <th>Details</th>
                <th>IP Address</th>
                <th>User Agent</th>
              </tr>
            </thead>
            <tbody>
              {paginated.map((log) => {
                const actionType = log.action.split('.')[0];
                const Icon = actionIcons[log.action] || Edit;
                return (
                  <tr key={log.id}>
                    <td className="text-sm text-[#64748b] whitespace-nowrap font-mono">{log.timestamp}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
                          <User size={10} className="text-white" />
                        </div>
                        <span className="text-sm text-[#e2e8f0]">{log.user}</span>
                      </div>
                    </td>
                    <td>
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium ${getActionColor(log.action)}`}>
                        <Icon size={11} />
                        {log.action}
                      </span>
                    </td>
                    <td className="text-sm text-[#64748b] max-w-[250px] truncate">{log.details}</td>
                    <td className="text-sm text-[#64748b] font-mono">{log.ipAddress}</td>
                    <td className="text-xs text-[#64748b] max-w-[150px] truncate">{log.userAgent}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-[#64748b]">
            <ScrollText size={40} className="mx-auto mb-3 opacity-50" />
            <p>No audit logs found</p>
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-[#64748b]">
            Showing {(page - 1) * PER_PAGE + 1}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length} logs
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronLeft size={16} />
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors ${
                  page === p ? 'bg-[#6366f1] text-white' : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'
                }`}
              >
                {p}
              </button>
            ))}
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
