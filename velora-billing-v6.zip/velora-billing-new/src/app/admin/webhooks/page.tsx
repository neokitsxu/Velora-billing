'use client';

import { useState, useEffect } from 'react';
import { Webhook, Plus, Copy, Trash2, RefreshCw, CheckCircle, XCircle, Clock, Loader2, Send, Globe } from 'lucide-react';
import toast from 'react-hot-toast';

interface WebhookEndpoint {
  id: string;
  url: string;
  events: string[];
  secret: string;
  active: boolean;
  lastTriggered: string;
  successCount: number;
  failCount: number;
  createdAt: string;
}

const availableEvents = [
  'order.created', 'order.paid', 'order.cancelled', 'order.refunded',
  'invoice.created', 'invoice.paid', 'invoice.overdue',
  'ticket.created', 'ticket.replied', 'ticket.closed',
  'user.registered', 'user.suspended', 'user.activated',
  'service.created', 'service.suspended', 'service.terminated',
  'payment.received', 'payment.failed',
  'wallet.topup', 'wallet.deducted',
];

export default function AdminWebhooks() {
  const [webhooks, setWebhooks] = useState<WebhookEndpoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedEvents, setSelectedEvents] = useState<string[]>([]);
  const [url, setUrl] = useState('');

  useEffect(() => { /* load webhooks */ setLoading(false); }, []);

  const createWebhook = () => {
    if (!url.trim()) { toast.error('Enter a URL'); return; }
    if (selectedEvents.length === 0) { toast.error('Select at least one event'); return; }
    const wh: WebhookEndpoint = {
      id: Date.now().toString(),
      url,
      events: selectedEvents,
      secret: `whsec_${Math.random().toString(36).slice(2, 18)}`,
      active: true,
      lastTriggered: '-',
      successCount: 0,
      failCount: 0,
      createdAt: new Date().toISOString(),
    };
    setWebhooks(prev => [...prev, wh]);
    setShowCreate(false);
    setUrl('');
    setSelectedEvents([]);
    toast.success('Webhook created!');
  };

  const deleteWebhook = (id: string) => {
    setWebhooks(prev => prev.filter(w => w.id !== id));
    toast.success('Webhook deleted');
  };

  const toggleEvent = (event: string) => {
    setSelectedEvents(prev => prev.includes(event) ? prev.filter(e => e !== event) : [...prev, event]);
  };

  const testWebhook = (id: string) => {
    toast.success('Test event sent!');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Webhooks</h1>
          <p className="text-[#64748b] mt-1">Configure webhook endpoints for real-time event notifications</p>
        </div>
        <button onClick={() => setShowCreate(!showCreate)} className="velora-btn-primary flex items-center gap-2 text-sm">
          <Plus size={14} /> Add Webhook
        </button>
      </div>

      {/* Info */}
      <div className="flex items-center gap-3 p-4 rounded-xl bg-[#8b5cf6]/5 border border-[#8b5cf6]/20">
        <Globe size={16} className="text-[#8b5cf6] flex-shrink-0" />
        <p className="text-xs text-[#8b5cf6]">Webhooks send HTTP POST requests to your server when events occur. Use them to integrate with Discord, Slack, or custom systems.</p>
      </div>

      {/* Create Form */}
      {showCreate && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Add Webhook Endpoint</h3>
          <div className="space-y-4 max-w-2xl">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Endpoint URL</label>
              <input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://your-server.com/webhook" className="velora-input w-full font-mono text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-2">Events to Listen</label>
              <div className="flex flex-wrap gap-1.5">
                {availableEvents.map(event => (
                  <button key={event} onClick={() => toggleEvent(event)} className={`px-2.5 py-1 rounded-lg text-[10px] font-mono transition-all ${selectedEvents.includes(event) ? 'bg-[#6366f1] text-white' : 'bg-[#0c0c0f] border border-[#1a1a2e] text-[#475569] hover:text-[#e2e8f0]'}`}>
                    {event}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-[#475569] mt-2">{selectedEvents.length} events selected</p>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={createWebhook} className="velora-btn-primary text-sm flex items-center gap-2">
              <Send size={14} /> Create Webhook
            </button>
            <button onClick={() => setShowCreate(false)} className="velora-btn-secondary text-sm">Cancel</button>
          </div>
        </div>
      )}

      {/* Webhook List */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : webhooks.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <Webhook size={48} className="mx-auto text-[#1a1a2e] mb-4" />
          <p className="text-[#64748b]">No webhooks configured</p>
          <p className="text-xs text-[#475569] mt-1">Add a webhook to receive real-time event notifications</p>
        </div>
      ) : (
        <div className="space-y-3">
          {webhooks.map((wh) => (
            <div key={wh.id} className="velora-card p-5 hover:border-[#6366f1]/20 transition-all">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-semibold text-[#e2e8f0] truncate">{wh.url}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${wh.active ? 'bg-[#10b981]/10 text-[#10b981]' : 'bg-[#475569]/10 text-[#475569]'}`}>
                      {wh.active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-[11px] text-[#475569]">
                    <span>Secret: <code className="font-mono">{wh.secret.slice(0, 12)}••••</code></span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {wh.events.slice(0, 5).map(e => (
                      <span key={e} className="px-2 py-0.5 rounded bg-[#0c0c0f] text-[9px] font-mono text-[#475569] border border-[#1a1a2e]">{e}</span>
                    ))}
                    {wh.events.length > 5 && <span className="text-[10px] text-[#475569]">+{wh.events.length - 5} more</span>}
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-[10px] text-[#475569]">
                    <span className="flex items-center gap-1"><CheckCircle size={10} className="text-[#10b981]" />{wh.successCount} success</span>
                    <span className="flex items-center gap-1"><XCircle size={10} className="text-[#ef4444]" />{wh.failCount} failed</span>
                    <span className="flex items-center gap-1"><Clock size={10} />Last: {wh.lastTriggered}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => testWebhook(wh.id)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#6366f1] transition-colors" title="Test">
                    <Send size={14} />
                  </button>
                  <button className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#e2e8f0] transition-colors" title="Copy URL">
                    <Copy size={14} />
                  </button>
                  <button onClick={() => deleteWebhook(wh.id)} className="p-2 rounded-lg hover:bg-[#ef4444]/10 text-[#475569] hover:text-[#ef4444] transition-colors" title="Delete">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
