'use client';

import { useState, useEffect } from 'react';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  ShoppingCart,
  Eye,
  Download,
  Loader2,
  BarChart,
} from 'lucide-react';

interface StatCard {
  label: string;
  value: string;
  change: string;
  positive: boolean;
  icon: any;
}

export default function AdminAnalytics() {
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('7d');
  const [stats, setStats] = useState<StatCard[]>([]);
  const [topProducts, setTopProducts] = useState<any[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [revenueData, setRevenueData] = useState<{ month: string; value: number }[]>([]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/stats', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.stats) {
            const s = data.stats;
            setStats([
              { label: 'Total Revenue', value: `₹${(s.totalRevenue || 0).toLocaleString()}`, change: '+0%', positive: true, icon: DollarSign },
              { label: 'Active Orders', value: String(s.activeServices || s.pendingOrders || 0), change: '+0%', positive: true, icon: ShoppingCart },
              { label: 'Total Clients', value: String(s.totalClients || 0), change: '+0%', positive: true, icon: Users },
              { label: 'Conversion Rate', value: '0%', change: '+0%', positive: true, icon: TrendingUp },
            ]);
          }
          if (data.recentOrders) {
            setTopProducts(data.recentOrders.slice(0, 5).map((o: any) => ({
              name: o.product || o.name || 'Unknown',
              orders: 1,
              revenue: `₹${(o.amount || 0).toLocaleString()}`,
              trend: o.status === 'paid' ? 'up' : 'down',
            })));
          }
        }
      } catch {
        // No data
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [period]);

  const maxRevenue = revenueData.length > 0 ? Math.max(...revenueData.map((d) => d.value)) : 1;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Analytics</h1>
          <p className="text-[#64748b] mt-1">Business insights & performance metrics</p>
        </div>
        <div className="flex gap-2">
          {['7d', '30d', '90d', '1y'].map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1.5 text-xs rounded-lg font-medium transition-colors ${period === p ? 'bg-[#6366f1] text-white' : 'bg-[#0c0c14] text-[#64748b] hover:text-[#e2e8f0]'}`}
            >
              {p === '7d' ? '7 Days' : p === '30d' ? '30 Days' : p === '90d' ? '90 Days' : '1 Year'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="velora-card p-5 animate-pulse">
              <div className="h-4 bg-[#1a1a2e] rounded w-24 mb-2" />
              <div className="h-8 bg-[#1a1a2e] rounded w-32" />
            </div>
          ))
        ) : stats.length === 0 ? (
          <div className="col-span-4 velora-card p-12 text-center">
            <BarChart3 size={48} className="mx-auto text-[#64748b] mb-4" />
            <p className="text-[#64748b]">No analytics data yet. Data will appear as orders and clients are created.</p>
          </div>
        ) : (
          stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="velora-card p-5 hover:border-[#6366f1]/30 transition-colors">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-lg bg-[#6366f1]/10"><Icon size={18} className="text-[#6366f1]" /></div>
                  <span className={`text-xs font-medium flex items-center gap-1 ${stat.positive ? 'text-green-400' : 'text-red-400'}`}>
                    {stat.positive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                    {stat.change}
                  </span>
                </div>
                <p className="text-2xl font-bold text-[#e2e8f0]">{stat.value}</p>
                <p className="text-xs text-[#64748b] mt-1">{stat.label}</p>
              </div>
            );
          })
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 velora-card p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-[#e2e8f0]">Revenue Overview</h3>
            <button className="text-xs text-[#6366f1] hover:text-[#818cf8] flex items-center gap-1">
              <Download size={12} /> Export
            </button>
          </div>
          {revenueData.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-[#64748b]">
              <BarChart size={48} className="mb-3 text-[#1a1a2e]" />
              <p className="text-sm">Revenue data will appear as orders come in</p>
            </div>
          ) : (
            <div className="flex items-end gap-3 h-48">
              {revenueData.map((d) => (
                <div key={d.month} className="flex-1 flex flex-col items-center gap-2">
                  <span className="text-xs text-[#64748b]">₹{(d.value / 1000).toFixed(0)}k</span>
                  <div
                    className="w-full bg-gradient-to-t from-[#6366f1] to-[#8b5cf6] rounded-t-lg transition-all duration-500 min-h-[4px]"
                    style={{ height: `${(d.value / maxRevenue) * 140}px` }}
                  />
                  <span className="text-xs text-[#64748b]">{d.month}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="velora-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#e2e8f0]">Recent Activity</h3>
            <Eye size={16} className="text-[#64748b]" />
          </div>
          {recentActivity.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-[#64748b]">
              <Activity size={32} className="mb-2 text-[#1a1a2e]" />
              <p className="text-sm">No recent activity</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentActivity.map((activity, i) => (
                <div key={i} className="flex items-start gap-3 p-2 rounded-lg hover:bg-white/[0.02]">
                  <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${activity.type === 'payment' ? 'bg-green-400' : activity.type === 'order' ? 'bg-blue-400' : activity.type === 'ticket' ? 'bg-yellow-400' : 'bg-[#6366f1]'}`} />
                  <div>
                    <p className="text-sm text-[#e2e8f0]">{activity.action}</p>
                    <p className="text-xs text-[#64748b]">{activity.user} · {activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="velora-card p-6">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Top Products</h3>
        {topProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-[#64748b]">
            <ShoppingCart size={32} className="mb-2 text-[#1a1a2e]" />
            <p className="text-sm">No product data yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1a1a2e]">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Product</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Orders</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Revenue</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#64748b] uppercase">Trend</th>
                </tr>
              </thead>
              <tbody>
                {topProducts.map((product) => (
                  <tr key={product.name} className="border-b border-[#1a1a2e]/50 hover:bg-white/[0.02]">
                    <td className="px-4 py-3 text-sm text-[#e2e8f0]">{product.name}</td>
                    <td className="px-4 py-3 text-sm text-[#64748b]">{product.orders}</td>
                    <td className="px-4 py-3 text-sm text-[#e2e8f0] font-medium">{product.revenue}</td>
                    <td className="px-4 py-3">
                      {product.trend === 'up' ? <TrendingUp size={14} className="text-green-400" /> : <TrendingDown size={14} className="text-red-400" />}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
