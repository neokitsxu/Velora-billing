'use client';

import { X, AlertTriangle, Info, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  type?: 'default' | 'danger' | 'success' | 'warning' | 'info';
}

const sizeMap = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', xl: 'max-w-xl' };
const iconMap = {
  default: null,
  danger: XCircle,
  success: CheckCircle,
  warning: AlertTriangle,
  info: Info,
};
const colorMap = {
  default: 'text-[#e2e8f0]',
  danger: 'text-[#ef4444]',
  success: 'text-[#10b981]',
  warning: 'text-[#f59e0b]',
  info: 'text-[#6366f1]',
};
const borderColorMap = {
  default: 'border-[#1a1a2e]',
  danger: 'border-[#ef4444]/30',
  success: 'border-[#10b981]/30',
  warning: 'border-[#f59e0b]/30',
  info: 'border-[#6366f1]/30',
};

export function Modal({ open, onClose, title, children, size = 'md', type = 'default' }: ModalProps) {
  if (!open) return null;

  const Icon = iconMap[type];

  return (
    <div className="fixed inset-0 z-[9998] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className={`relative w-full ${sizeMap[size]} bg-[#0c0c0f] border ${borderColorMap[type]} rounded-2xl shadow-2xl shadow-black/50 overflow-hidden animate-scale-in`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        {(title || type !== 'default') && (
          <div className={`flex items-center justify-between p-5 border-b ${borderMap[type]}`}>
            <div className="flex items-center gap-3">
              {Icon && (
                <div className={`w-8 h-8 rounded-lg ${type === 'danger' ? 'bg-[#ef4444]/10' : type === 'success' ? 'bg-[#10b981]/10' : type === 'warning' ? 'bg-[#f59e0b]/10' : 'bg-[#6366f1]/10'} flex items-center justify-center`}>
                  <Icon size={16} className={colorMap[type]} />
                </div>
                <h3 className={`text-base font-semibold ${colorMap[type]}`}>{title}</h3>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] transition-colors">
              <X size={16} />
            </button>
          </div>
        )}
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export function ConfirmModal({ open, onClose, onConfirm, title, message, confirmText = 'Confirm', type = 'danger' }: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  type?: 'danger' | 'warning' | 'info';
}) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm" type={type}>
      <p className="text-sm text-[#64748b] mb-6">{message}</p>
      <div className="flex gap-3 justify-end">
        <button onClick={onClose} className="velora-btn-secondary px-4 py-2 text-sm">Cancel</button>
        <button
          onClick={() => { onConfirm(); onClose(); }}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            type === 'danger' ? 'bg-[#ef4444] hover:bg-[#ef4444]/80 text-white' :
            type === 'warning' ? 'bg-[#f59e0b] hover:bg-[#f59e0b]/80 text-black' :
            'bg-[#6366f1] hover:bg-[#818cf8] text-white'
          }`}
        >
          {confirmText}
        </button>
      </div>
    </Modal>
  );
}
