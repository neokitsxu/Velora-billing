# Velora Billing - Modern Hosting Billing Platform

A full-featured Paymenter clone built with Next.js 15, Prisma, and SQLite. Designed for Minecraft hosting, VPS hosting, and general service billing with a premium dark futuristic UI.

## Features

### Client Area
- Dashboard with stats overview
- Browse & order products (Minecraft, VPS, Dedicated, Domains)
- Order management with status tracking
- Invoice viewing & payment
- Service management (Pterodactyl integration)
- Support ticket system
- Wallet system with add funds
- Profile management

### Admin Panel
- Full dashboard with revenue stats
- Client management (create, suspend, ban)
- Product management (CRUD with resource specs)
- Order management (mark paid, refund, cancel)
- Invoice management
- Ticket management with staff replies
- Server node management (Pterodactyl/Proxmox)
- Payment gateway configuration
- Settings (General, Payment, Email, Pterodactyl)
- Theme customization
- Audit logs

### UPI Payment Gateway
- QR code generation for UPI payments
- Deep link URL for direct UPI app opening
- Auto-polling payment verification
- Admin payment verification panel
- Payment expiry timer (10 minutes)
- Screen access management during payment

### Other Features
- JWT authentication
- SQLite database (zero config)
- Pterodactyl API integration
- Coupon system
- Wallet system
- Multi-role support (admin/client)
- Dark futuristic UI with glow effects
- Fully responsive design

## Quick Start

### Requirements
- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Clone or extract the project
cd velora-billing

# Install dependencies
npm install

# Copy environment file
cp .env.example .env
# Edit .env with your settings (especially UPI_ID)

# Setup database
npx prisma db push

# Seed database with demo data
npx tsx src/lib/seed.ts

# Start development server
npm run dev
```

### Default Accounts
- **Admin**: admin@velora.billing / Admin@123456
- **Demo Client**: demo@velora.billing / Demo@123456

### Configure UPI Payments
Edit `.env` file:
```
UPI_ENABLED=true
UPI_ID=yourname@paytm
UPI_MERCHANT_NAME=Your Business Name
UPI_MERCHANT_CODE=YOUR_MERCHANT_CODE
```

### Production Deployment

```bash
# Build for production
npm run build

# Start production server
npm start

# Or use PM2
pm2 start npm --name "velora-billing" -- start
pm2 save
pm2 startup
```

### Nginx Reverse Proxy

```nginx
server {
    listen 80;
    server_name billing.yourdomain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### SSL with Certbot
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d billing.yourdomain.com
```

## Tech Stack
- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Database**: SQLite + Prisma ORM
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Auth**: JWT + bcrypt
- **Payments**: UPI (QR Code)
- **Server Provisioning**: Pterodactyl API

## File Structure
```
velora-billing/
├── prisma/schema.prisma    # Database schema (30+ models)
├── src/
│   ├── app/
│   │   ├── page.tsx         # Landing page
│   │   ├── layout.tsx       # Root layout
│   │   ├── globals.css      # Global styles
│   │   ├── auth/            # Login, Register, Forgot Password
│   │   ├── client/          # Client area (10 pages)
│   │   ├── admin/           # Admin panel (12 pages)
│   │   └── api/             # API routes (20+ routes)
│   ├── lib/                 # Utilities (db, auth, upi, pterodactyl, seed)
│   └── types/               # TypeScript type definitions
├── .env.example             # Environment template
├── deploy.sh                # Quick deploy script
└── package.json
```

## UPI Payment Flow
1. Customer selects product → proceeds to checkout
2. Chooses "UPI Payment" → redirected to payment page
3. Payment page shows: QR code, UPI ID, countdown timer
4. Customer scans QR / opens UPI app and pays
5. Admin verifies payment from admin panel
6. Payment page auto-detects verification → shows "Payment Successful!"
7. Order marked as paid, service auto-provisioned
