#!/bin/bash
# Velora Billing - Quick Deploy Script
# Run this on your Ubuntu/Debian server

set -e

echo "========================================="
echo "  Velora Billing - Installation Script"
echo "========================================="

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "Installing Node.js 20.x..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

echo "Node.js version: $(node -v)"
echo "npm version: $(npm -v)"

# Install dependencies
echo ""
echo "Installing dependencies..."
npm install

# Setup database
echo ""
echo "Setting up database..."
mkdir -p db
npx prisma db push

# Seed database
echo ""
echo "Seeding database with default data..."
npx tsx src/lib/seed.ts

# Build
echo ""
echo "Building project..."
npm run build

echo ""
echo "========================================="
echo "  Installation Complete!"
echo "========================================="
echo ""
echo "  Default Admin Login:"
echo "  Email: admin@velora.billing"
echo "  Password: Admin@123456"
echo ""
echo "  Default Demo Client:"
echo "  Email: demo@velora.billing"
echo "  Password: Demo@123456"
echo ""
echo "  Start with: npm run dev"
echo "  Or production: npm start"
echo ""
echo "  Configure UPI in .env file"
echo "========================================="
