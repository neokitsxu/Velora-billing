const PTERODACTYL_URL = process.env.PTERODACTYL_URL || '';
const PTERODACTYL_API_KEY = process.env.PTERODACTYL_API_KEY || '';

interface PterodactylServer {
  id: number;
  uuid: string;
  identifier: string;
  name: string;
  status: string;
  suspended: boolean;
  relationships: {
    node: { id: number; name: string; };
    nest: { id: number; name: string; };
    egg: { id: number; name: string; };
  };
}

export async function pterodactylFetch(endpoint: string, options: RequestInit = {}) {
  if (!PTERODACTYL_URL || !PTERODACTYL_API_KEY) {
    throw new Error('Pterodactyl configuration is missing');
  }

  const url = `${PTERODACTYL_URL.replace(/\/$/, '')}/api/application${endpoint}`;
  const response = await fetch(url, {
    ...options,
    headers: {
      'Authorization': `Bearer ${PTERODACTYL_API_KEY}`,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Pterodactyl API error (${response.status}): ${error}`);
  }

  return response.json();
}

export async function createServer(params: {
  name: string;
  userId: string;
  nestId: number;
  eggId: number;
  nodeId: number;
  allocationId: number;
  memory: number;
  disk: number;
  cpu: number;
  swap: number;
  databases: number;
  backups: number;
  startup: string;
  environment: Record<string, string>;
}): Promise<PterodactylServer> {
  return pterodactylFetch('/servers', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function suspendServer(serverId: string): Promise<void> {
  await pterodactylFetch(`/servers/${serverId}/suspend`, { method: 'POST' });
}

export async function unsuspendServer(serverId: string): Promise<void> {
  await pterodactylFetch(`/servers/${serverId}/unsuspend`, { method: 'POST' });
}

export async function deleteServer(serverId: string): Promise<void> {
  await pterodactylFetch(`/servers/${serverId}`, { method: 'DELETE' });
}

export async function reinstallServer(serverId: string): Promise<void> {
  await pterodactylFetch(`/servers/${serverId}/reinstall`, { method: 'POST' });
}

export async function getServer(serverId: string): Promise<PterodactylServer> {
  return pterodactylFetch(`/servers/${serverId}`);
}

export async function getNodes(): Promise<any[]> {
  const res = await pterodactylFetch('/nodes');
  return res.data || [];
}
