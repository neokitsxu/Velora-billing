import QRCode from 'qrcode';

export function buildUpiUrl(params: {
  upiId: string;
  amount: number;
  merchantName?: string;
  merchantCode?: string;
  transactionId?: string;
  note?: string;
}): string {
  const upiUrl = new URL('upi://pay');
  upiUrl.searchParams.set('pa', params.upiId);
  upiUrl.searchParams.set('pn', params.merchantName || 'Velora Billing');
  if (params.merchantCode) upiUrl.searchParams.set('mc', params.merchantCode);
  upiUrl.searchParams.set('am', params.amount.toString());
  upiUrl.searchParams.set('cu', 'INR');
  if (params.transactionId) upiUrl.searchParams.set('tn', params.transactionId);
  if (params.note) upiUrl.searchParams.set('tn', params.note);
  return upiUrl.toString();
}

export async function generateQRCode(data: string): Promise<string> {
  try {
    const qrDataUrl = await QRCode.toDataURL(data, {
      width: 256,
      margin: 1,
      color: { dark: '#000000', light: '#ffffff' },
      errorCorrectionLevel: 'H',
    });
    return qrDataUrl;
  } catch (error) {
    console.error('QR generation error:', error);
    return '';
  }
}

export function formatCurrency(amount: number, currency: string = 'INR'): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function getBillingCycleLabel(cycle: string): string {
  const labels: Record<string, string> = {
    hourly: 'Hourly',
    daily: 'Daily',
    weekly: 'Weekly',
    monthly: 'Monthly',
    yearly: 'Yearly',
    'one-time': 'One Time',
  };
  return labels[cycle] || cycle;
}
