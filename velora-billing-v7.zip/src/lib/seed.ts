import bcrypt from 'bcryptjs';
import db from './db';
import { hashPassword } from './auth';

const defaultCategories = [
  { name: 'Minecraft Hosting', slug: 'minecraft', icon: '⛏️' },
  { name: 'VPS Hosting', slug: 'vps', icon: '🖥️' },
  { name: 'Dedicated Servers', slug: 'dedicated', icon: ' chassis' },
  { name: 'Domains', slug: 'domains', icon: '🌐' },
  { name: 'Other Services', slug: 'other', icon: '📦' },
];

const defaultProducts = [
  {
    name: 'Starter Minecraft',
    slug: 'starter-minecraft',
    type: 'minecraft',
    description: 'Perfect for small friend groups. 2GB RAM, 10 slots.',
    price: 49,
    billingCycle: 'monthly',
    cpu: 1,
    ram: 2048,
    disk: 10,
    slots: 10,
    features: JSON.stringify(['2GB RAM', '10 Player Slots', '10GB SSD', 'DDoS Protection', 'Instant Setup']),
  },
  {
    name: 'Premium Minecraft',
    slug: 'premium-minecraft',
    type: 'minecraft',
    description: 'Great for growing communities. 4GB RAM, 25 slots.',
    price: 99,
    billingCycle: 'monthly',
    cpu: 2,
    ram: 4096,
    disk: 25,
    slots: 25,
    features: JSON.stringify(['4GB RAM', '25 Player Slots', '25GB SSD', 'DDoS Protection', 'Custom Plugins', 'Mod Support']),
  },
  {
    name: 'Ultimate Minecraft',
    slug: 'ultimate-minecraft',
    type: 'minecraft',
    description: 'For large communities and networks. 8GB RAM, 50 slots.',
    price: 199,
    billingCycle: 'monthly',
    cpu: 4,
    ram: 8192,
    disk: 50,
    slots: 50,
    features: JSON.stringify(['8GB RAM', '50 Player Slots', '50GB SSD', 'DDoS Protection', 'Custom Plugins', 'Priority Support', 'Free Subdomain']),
  },
  {
    name: 'Starter VPS',
    slug: 'starter-vps',
    type: 'vps',
    description: 'Entry-level VPS for small projects. 1 vCPU, 1GB RAM.',
    price: 149,
    billingCycle: 'monthly',
    cpu: 1,
    ram: 1024,
    disk: 20,
    bandwidth: 500,
    features: JSON.stringify(['1 vCPU', '1GB RAM', '20GB SSD', '500GB Bandwidth', 'Full Root Access', 'KVM Virtualization']),
  },
  {
    name: 'Premium VPS',
    slug: 'premium-vps',
    type: 'vps',
    description: 'Balanced performance for growing projects. 2 vCPU, 4GB RAM.',
    price: 299,
    billingCycle: 'monthly',
    cpu: 2,
    ram: 4096,
    disk: 60,
    bandwidth: 1000,
    features: JSON.stringify(['2 vCPU', '4GB RAM', '60GB SSD', '1TB Bandwidth', 'Full Root Access', 'KVM Virtualization', 'DDoS Protection']),
  },
  {
    name: 'Enterprise VPS',
    slug: 'enterprise-vps',
    type: 'vps',
    description: 'High performance for demanding workloads. 4 vCPU, 8GB RAM.',
    price: 499,
    billingCycle: 'monthly',
    cpu: 4,
    ram: 8192,
    disk: 120,
    bandwidth: 2000,
    features: JSON.stringify(['4 vCPU', '8GB RAM', '120GB NVMe', '2TB Bandwidth', 'Full Root Access', 'DDoS Protection', '24/7 Support']),
  },
];

const defaultSettings = [
  { key: 'site_name', value: 'Velora Billing', group: 'general', type: 'text' },
  { key: 'site_description', value: 'Modern Hosting Billing & Provisioning Platform', group: 'general', type: 'text' },
  { key: 'site_logo', value: '', group: 'general', type: 'text' },
  { key: 'site_favicon', value: '', group: 'general', type: 'text' },
  { key: 'currency', value: 'INR', group: 'general', type: 'text' },
  { key: 'currency_symbol', value: '₹', group: 'general', type: 'text' },
  { key: 'tax_enabled', value: 'false', group: 'general', type: 'boolean' },
  { key: 'tax_rate', value: '18', group: 'general', type: 'number' },
  { key: 'upi_enabled', value: 'true', group: 'payment', type: 'boolean' },
  { key: 'upi_id', value: 'yourname@paytm', group: 'payment', type: 'text' },
  { key: 'upi_merchant_name', value: 'Velora Hosting', group: 'payment', type: 'text' },
  { key: 'upi_merchant_code', value: 'VELORA', group: 'payment', type: 'text' },
  { key: 'upi_min_amount', value: '10', group: 'payment', type: 'number' },
  { key: 'pterodactyl_url', value: '', group: 'pterodactyl', type: 'text' },
  { key: 'pterodactyl_api_key', value: '', group: 'pterodactyl', type: 'text' },
  { key: 'registration_enabled', value: 'true', group: 'general', type: 'boolean' },
  { key: 'maintenance_mode', value: 'false', group: 'general', type: 'boolean' },
];

const defaultCoupons = [
  { code: 'WELCOME10', type: 'percentage', value: 10, minAmount: 0, maxUses: 100 },
  { code: 'FIRST50', type: 'fixed', value: 50, minAmount: 200, maxUses: 50 },
  { code: 'MINECRAFT20', type: 'percentage', value: 20, minAmount: 0, maxUses: 200 },
];

export async function seed() {
  console.log('Seeding database...');

  // Create admin user
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@velora.billing';
  const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@123456';
  const adminName = process.env.ADMIN_NAME || 'Admin';

  const existingAdmin = await db.user.findUnique({ where: { email: adminEmail } });
  if (!existingAdmin) {
    const hashedPassword = await hashPassword(adminPassword);
    await db.user.create({
      data: {
        email: adminEmail,
        password: hashedPassword,
        name: adminName,
        role: 'admin',
        balance: 10000,
      },
    });
    console.log('Admin user created');
  }

  // Create categories
  for (const cat of defaultCategories) {
    const exists = await db.productCategory.findUnique({ where: { slug: cat.slug } });
    if (!exists) {
      await db.productCategory.create({ data: cat });
    }
  }

  // Create products
  for (const prod of defaultProducts) {
    const exists = await db.product.findUnique({ where: { slug: prod.slug } });
    if (!exists) {
      await db.product.create({ data: prod });
    }
  }

  // Create settings
  for (const setting of defaultSettings) {
    const exists = await db.setting.findUnique({ where: { key: setting.key } });
    if (!exists) {
      await db.setting.create({ data: setting });
    }
  }

  // Create coupons
  for (const coupon of defaultCoupons) {
    const exists = await db.coupon.findUnique({ where: { code: coupon.code } });
    if (!exists) {
      await db.coupon.create({ data: coupon });
    }
  }

  // Create demo client
  const demoClient = await db.user.findUnique({ where: { email: 'demo@velora.billing' } });
  if (!demoClient) {
    const hashedPassword = await hashPassword('Demo@123456');
    await db.user.create({
      data: {
        email: 'demo@velora.billing',
        password: hashedPassword,
        name: 'Demo User',
        role: 'client',
        balance: 500,
      },
    });
    console.log('Demo client created');
  }

  console.log('Database seeded successfully!');
}

// Run seed if called directly
if (typeof require !== 'undefined' && require.main === module) {
  seed().catch(console.error);
}
