import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function formatDateTime(date: Date | string): string {
  return new Date(date).toLocaleString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    active: 'text-[#10b981]',
    paid: 'text-[#10b981]',
    completed: 'text-[#10b981]',
    successful: 'text-[#10b981]',
    open: 'text-[#10b981]',
    pending: 'text-[#f59e0b]',
    in_progress: 'text-[#f59e0b]',
    verifying: 'text-[#f59e0b]',
    processing: 'text-[#f59e0b]',
    unpaid: 'text-[#f59e0b]',
    overdue: 'text-[#ef4444]',
    failed: 'text-[#ef4444]',
    cancelled: 'text-[#64748b]',
    suspended: 'text-[#ef4444]',
    terminated: 'text-[#64748b]',
    banned: 'text-[#ef4444]',
    resolved: 'text-[#6366f1]',
    closed: 'text-[#64748b]',
  };
  return colors[status] || 'text-[#64748b]';
}

export function getStatusBg(status: string): string {
  const bgs: Record<string, string> = {
    active: 'bg-[#10b981]/10 border-[#10b981]/20',
    paid: 'bg-[#10b981]/10 border-[#10b981]/20',
    completed: 'bg-[#10b981]/10 border-[#10b981]/20',
    successful: 'bg-[#10b981]/10 border-[#10b981]/20',
    open: 'bg-[#10b981]/10 border-[#10b981]/20',
    pending: 'bg-[#f59e0b]/10 border-[#f59e0b]/20',
    in_progress: 'bg-[#f59e0b]/10 border-[#f59e0b]/20',
    verifying: 'bg-[#f59e0b]/10 border-[#f59e0b]/20',
    processing: 'bg-[#f59e0b]/10 border-[#f59e0b]/20',
    unpaid: 'bg-[#f59e0b]/10 border-[#f59e0b]/20',
    overdue: 'bg-[#ef4444]/10 border-[#ef4444]/20',
    failed: 'bg-[#ef4444]/10 border-[#ef4444]/20',
    cancelled: 'bg-[#64748b]/10 border-[#64748b]/20',
    suspended: 'bg-[#ef4444]/10 border-[#ef4444]/20',
    terminated: 'bg-[#64748b]/10 border-[#64748b]/20',
    banned: 'bg-[#ef4444]/10 border-[#ef4444]/20',
    resolved: 'bg-[#6366f1]/10 border-[#6366f1]/20',
    closed: 'bg-[#64748b]/10 border-[#64748b]/20',
  };
  return bgs[status] || 'bg-[#64748b]/10 border-[#64748b]/20';
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.substring(0, length) + '...';
}

export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
