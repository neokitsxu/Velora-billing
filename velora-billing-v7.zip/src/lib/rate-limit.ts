import { NextRequest } from 'next/server';

// In-memory rate limiter store
interface RateLimitEntry {
  count: number;
  resetAt: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

// Cleanup expired entries every 60 seconds
const CLEANUP_INTERVAL = 60_000;
let lastCleanup = Date.now();

function cleanupExpired() {
  const now = Date.now();
  if (now - lastCleanup > CLEANUP_INTERVAL) {
    for (const [key, entry] of rateLimitStore) {
      if (entry.resetAt <= now) {
        rateLimitStore.delete(key);
      }
    }
    lastCleanup = now;
  }
}

export interface RateLimitConfig {
  /** Maximum number of requests in the window */
  maxRequests: number;
  /** Time window in milliseconds */
  windowMs: number;
  /** Custom identifier (defaults to IP) */
  identifier?: string;
}

export interface RateLimitResult {
  /** Whether the request is allowed */
  allowed: boolean;
  /** Number of requests remaining in current window */
  remaining: number;
  /** Timestamp (ms) when the rate limit resets */
  resetAt: number;
  /** Total number of requests allowed in the window */
  limit: number;
}

/**
 * Rate limit middleware helper.
 * Checks IP-based rate limits using an in-memory Map with expiry.
 */
export function rateLimit(
  request: NextRequest,
  config: RateLimitConfig
): RateLimitResult {
  cleanupExpired();

  const { maxRequests, windowMs, identifier } = config;
  const now = Date.now();

  const ip =
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    request.headers.get('x-real-ip') ||
    'unknown';
  const key = identifier || ip;

  const entry = rateLimitStore.get(key);

  if (!entry || entry.resetAt <= now) {
    const newEntry: RateLimitEntry = {
      count: 1,
      resetAt: now + windowMs,
    };
    rateLimitStore.set(key, newEntry);
    return {
      allowed: true,
      remaining: maxRequests - 1,
      resetAt: newEntry.resetAt,
      limit: maxRequests,
    };
  }

  entry.count += 1;

  if (entry.count > maxRequests) {
    return {
      allowed: false,
      remaining: 0,
      resetAt: entry.resetAt,
      limit: maxRequests,
    };
  }

  return {
    allowed: true,
    remaining: maxRequests - entry.count,
    resetAt: entry.resetAt,
    limit: maxRequests,
  };
}

export function clearRateLimits(): void {
  rateLimitStore.clear();
}

export function getRateLimitStats(): { key: string; count: number; resetAt: string }[] {
  cleanupExpired();
  return Array.from(rateLimitStore.entries()).map(([key, entry]) => ({
    key: key.substring(0, 8) + '...',
    count: entry.count,
    resetAt: new Date(entry.resetAt).toISOString(),
  }));
}
