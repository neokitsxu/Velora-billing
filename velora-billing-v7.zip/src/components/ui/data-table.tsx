'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface DataTableProps {
  columns: { key: string; label: string; sortable?: boolean; render?: (value: any, row: any) => React.ReactNode }[];
  data: any[];
  pageSize?: number;
  searchable?: boolean;
  selectable?: boolean;
  emptyMessage?: string;
  onSelectionChange?: (selected: any[]) => void;
  onSort?: (key: string, direction: 'asc' | 'desc') => void;
}

export function DataTable({
  columns,
  data,
  pageSize = 10,
  searchable = true,
  selectable = false,
  emptyMessage = 'No data found',
  onSelectionChange,
  onSort,
}: DataTableProps) {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const filtered = data.filter(row => {
    if (!search) return true;
    return columns.some(col => {
      const val = row[col.key];
      return val?.toString?.().toLowerCase().includes(search.toLowerCase());
    });
  });

  const sorted = sortKey
    ? [...filtered].sort((a, b) => {
        const aVal = a[sortKey] ?? '';
        const bVal = b[sortKey] ?? '';
        const cmp = String(aVal).localeCompare(String(bVal), undefined, { numeric: true });
        return sortDir === 'asc' ? cmp : -cmp;
      })
    : filtered;

  const totalPages = Math.ceil(sorted.length / pageSize);
  const paged = sorted.slice((page - 1) * pageSize, page * pageSize);

  const handleSort = (key: string) => {
    if (!columns.find(c => c.key === key)?.sortable) return;
    const newDir = sortKey === key && sortDir === 'asc' ? 'desc' : 'asc';
    setSortKey(key);
    setSortDir(newDir);
    onSort?.(key, newDir);
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
    onSelectionChange?.(Array.from(next));
  };

  const toggleAll = () => {
    if (selected.size === paged.length) {
      setSelected(new Set());
      onSelectionChange?.([]);
    } else {
      const next = new Set(paged.map(r => r.id));
      setSelected(next);
      onSelectionChange?.(Array.from(next));
    }
  };

  return (
    <div className="space-y-4">
      {/* Search & Actions Bar */}
      {searchable && (
        <div className="flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-sm">
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search..."
              className="velora-input w-full pl-4 text-sm"
            />
          </div>
          {selectable && selected.size > 0 && (
            <span className="text-xs text-[#6366f1] font-medium">
              {selected.size} selected
            </span>
          )}
        </div>
      )}

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#1a1a2e]">
                {selectable && (
                  <th className="px-4 py-3 w-10">
                    <input
                      type="checkbox"
                      checked={paged.length > 0 && selected.size === paged.length}
                      onChange={toggleAll}
                      className="rounded bg-[#1a1a2e] border-[#1a1a2e] text-[#6366f1] focus:ring-[#6366f1]"
                    />
                  </th>
                )}
                {columns.map(col => (
                  <th
                    key={col.key}
                    onClick={() => handleSort(col.key)}
                    className={`px-4 py-3 text-left text-xs font-semibold text-[#64748b] uppercase tracking-wider ${
                      col.sortable ? 'cursor-pointer hover:text-[#e2e8f0] select-none' : ''
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      {col.label}
                      {col.sortable && sortKey === col.key && (
                        <span className="text-[#6366f1]">{sortDir === 'asc' ? '↑' : '↓'}</span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr>
                  <td colSpan={columns.length + (selectable ? 1 : 0)} className="px-4 py-12 text-center">
                    <p className="text-[#64748b] text-sm">{emptyMessage}</p>
                  </td>
                </tr>
              ) : (
                paged.map((row, i) => (
                  <tr
                    key={row.id || i}
                    className={`border-b border-[#1a1a2e]/50 hover:bg-[#1a1a2e]/30 transition-colors ${
                      selected.has(row.id) ? 'bg-[#6366f1]/5' : ''
                    }`}
                    style={{ animation: `fadeInUp 0.3s ease-out ${i * 0.03}s both` }}
                  >
                    {selectable && (
                      <td className="px-4 py-3">
                        <input
                          type="checkbox"
                          checked={selected.has(row.id)}
                          onChange={() => toggleSelect(row.id)}
                          className="rounded bg-[#1a1a2e] border-[#1a1a2e] text-[#6366f1] focus:ring-[#6366f1]"
                        />
                      </td>
                    )}
                    {columns.map(col => (
                      <td key={col.key} className="px-4 py-3 text-sm">
                        {col.render ? col.render(row[col.key], row) : (
                          <span className="text-[#c8ccd0]">{row[col.key]}</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-xs text-[#475569]">
            Showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, sorted.length)} of {sorted.length}
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] disabled:opacity-30 transition-all"
            >
              <ChevronLeft size={14} />
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum: number;
              if (totalPages <= 5) {
                pageNum = i + 1;
              } else if (page <= 3) {
                pageNum = i + 1;
              } else if (page >= totalPages - 2) {
                pageNum = totalPages - 4 + i;
              } else {
                pageNum = page - 2 + i;
              }
              return (
                <button
                  key={pageNum}
                  onClick={() => setPage(pageNum)}
                  className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                    page === pageNum
                      ? 'bg-[#6366f1] text-white velora-glow'
                      : 'text-[#64748b] hover:bg-[#1a1a2e] hover:text-[#e2e8f0]'
                  }`}
                >
                  {pageNum}
                </button>
              );
            })}
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] disabled:opacity-30 transition-all"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
