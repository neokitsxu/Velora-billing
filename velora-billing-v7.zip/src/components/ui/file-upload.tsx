'use client';

import { useState, useRef } from 'react';
import { Upload, X, Image as ImageIcon, File, Loader2, Check } from 'lucide-react';

interface FileUploadProps {
  accept?: string;
  maxSize?: number; // in MB
  multiple?: boolean;
  onUpload?: (files: File[]) => void | Promise<void>;
  label?: string;
  compact?: boolean;
}

export function FileUpload({
  accept = 'image/*,.pdf,.doc,.docx',
  maxSize = 5,
  multiple = false,
  onUpload,
  label = 'Upload File',
  compact = false,
}: FileUploadProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploaded, setUploaded] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (newFiles: FileList | null) => {
    if (!newFiles) return;
    const valid = Array.from(newFiles).filter(f => {
      if (f.size > maxSize * 1024 * 1024) return false;
      return true;
    });
    setFiles(valid);
    setUploaded(false);
  };

  const handleUpload = async () => {
    if (files.length === 0) return;
    setUploading(true);
    try {
      await onUpload?.(files);
      setUploaded(true);
      setTimeout(() => {
        setFiles([]);
        setUploaded(false);
      }, 2000);
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setUploaded(false);
  };

  if (compact) {
    return (
      <div>
        <input ref={inputRef} type="file" accept={accept} multiple={multiple} onChange={(e) => handleFiles(e.target.files)} className="hidden" />
        <button
          onClick={() => inputRef.current?.click()}
          className="velora-btn-secondary text-xs px-3 py-1.5 flex items-center gap-1.5"
        >
          <Upload size={12} />
          {label}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300 ${
          dragging
            ? 'border-[#6366f1] bg-[#6366f1]/5'
            : files.length > 0
            ? 'border-[#10b981]/30 bg-[#10b981]/3'
            : 'border-[#1a1a2e] hover:border-[#6366f1]/30 bg-[#09090b]'
        }`}
      >
        <input ref={inputRef} type="file" accept={accept} multiple={multiple} onChange={(e) => handleFiles(e.target.files)} className="hidden" />
        {uploaded ? (
          <Check size={32} className="mx-auto text-[#10b981] mb-2 animate-scale-bounce" />
        ) : uploading ? (
          <Loader2 size={32} className="mx-auto text-[#6366f1] animate-spin mb-2" />
        ) : (
          <Upload size={32} className={`mx-auto mb-2 ${dragging ? 'text-[#6366f1]' : 'text-[#475569]'}`} />
        )}
        <p className="text-sm text-[#64748b]">
          {uploaded ? 'Uploaded!' : uploading ? 'Uploading...' : 'Drag & drop or click to upload'}
        </p>
        <p className="text-[10px] text-[#475569] mt-1">
          Max {maxSize}MB · {accept}
        </p>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="space-y-2">
          {files.map((file, i) => (
            <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-[#0c0c0f] border border-[#1a1a2e]">
              <div className="w-8 h-8 rounded-lg bg-[#1a1a2e] flex items-center justify-center">
                {file.type.startsWith('image/') ? <ImageIcon size={14} className="text-[#6366f1]" /> : <File size={14} className="text-[#64748b]" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-[#e2e8f0] truncate">{file.name}</p>
                <p className="text-[10px] text-[#475569]">{(file.size / 1024).toFixed(1)}KB</p>
              </div>
              <button onClick={() => removeFile(i)} className="p-1 rounded hover:bg-[#ef4444]/10 text-[#475569] hover:text-[#ef4444]">
                <X size={12} />
              </button>
            </div>
          ))}
          <button
            onClick={handleUpload}
            disabled={uploading}
            className="velora-btn-primary w-full py-2 text-xs flex items-center justify-center gap-2"
          >
            {uploading ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />}
            Upload {files.length} File{files.length > 1 ? 's' : ''}
          </button>
        </div>
      )}
    </div>
  );
}
