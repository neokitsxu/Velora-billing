'use client';

import { useState, useEffect, useRef } from 'react';
import { X, Search, ArrowRight, FileText, Settings, Users, Package, ShoppingCart, Ticket, Wallet, LayoutDashboard, LogOut, Bell, HelpCircle, Server, BarChart3 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { usePathname } from 'next/navigation';

interface CommandItem {
  id: string;
  label: string;
  description?: string;
  icon: any;
  action: () => void;
  category: string;
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const router = useRouter();
  const pathname = usePathname();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setOpen(true);
      }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  const isAdmin = pathname.startsWith('/admin');

  const items: CommandItem[] = [
    ...(isAdmin ? [
      { id: 'admin-dashboard', label: 'Dashboard', icon: LayoutDashboard, category: 'Admin', action: () => router.push('/admin/dashboard') },
      { id: 'admin-clients', label: 'Clients', icon: Users, category: 'Admin', action: () => router.push('/admin/clients') },
      { id: 'admin-products', label: 'Products', icon: Package, category: 'Admin', action: () => router.push('/admin/products') },
      { id: 'admin-orders', label: 'Orders', icon: ShoppingCart, category: 'Admin', action: () => router.push('/admin/orders') },
      { id: 'admin-tickets', label: 'Tickets', icon: Ticket, category: 'Admin', action: () => router.push('/admin/tickets') },
      { id: 'admin-invoices', label: 'Invoices', icon: FileText, category: 'Admin', action: () => router.push('/admin/invoices') },
      { id: 'admin-servers', label: 'Servers', icon: Server, category: 'Admin', action: () => router.push('/admin/servers') },
      { id: 'admin-analytics', label: 'Analytics', icon: BarChart3, category: 'Admin', action: () => router.push('/admin/analytics') },
      { id: 'admin-finance', label: 'Finance', icon: Wallet, category: 'Admin', action: () => router.push('/admin/finance') },
      { id: 'admin-settings', label: 'Settings', icon: Settings, category: 'Admin', action: () => router.push('/admin/settings') },
      { id: 'admin-staff', label: 'Staff', icon: Users, category: 'Admin', action: () => router.push('/admin/staff') },
      { id: 'admin-coupons', label: 'Coupons', icon: FileText, category: 'Admin', action: () => router.push('/admin/coupons') },
      { id: 'admin-announcements', label: 'Announcements', icon: Bell, category: 'Admin', action: () => router.push('/admin/announcements') },
      { id: 'admin-locations', label: 'Locations', icon: Server, category: 'Admin', action: () => router.push('/admin/locations') },
      { id: 'admin-logs', label: 'Logs', icon: FileText, category: 'Admin', action: () => router.push('/admin/logs') },
      { id: 'admin-themes', label: 'Themes', icon: Settings, category: 'Admin', action: () => router.push('/admin/themes') },
      { id: 'admin-pages', label: 'Pages', icon: FileText, category: 'Admin', action: () => router.push('/admin/pages') },
      { id: 'admin-audit', label: 'Audit Log', icon: BarChart3, category: 'Admin', action: () => router.push('/admin/audit') },
    ] : [
      { id: 'client-dashboard', label: 'Dashboard', icon: LayoutDashboard, category: 'Client', action: () => router.push('/client/dashboard') },
      { id: 'client-products', label: 'Products', icon: Package, category: 'Client', action: () => router.push('/client/products') },
      { id: 'client-orders', label: 'Orders', icon: ShoppingCart, category: 'Client', action: () => router.push('/client/orders') },
      { id: 'client-services', label: 'Services', icon: Server, category: 'Client', action: () => router.push('/client/services') },
      { id: 'client-invoices', label: 'Invoices', icon: FileText, category: 'Client', action: () => router.push('/client/invoices') },
      { id: 'client-tickets', label: 'Tickets', icon: Ticket, category: 'Client', action: () => router.push('/client/tickets') },
      { id: 'client-wallet', label: 'Wallet', icon: Wallet, category: 'Client', action: () => router.push('/client/wallet') },
      { id: 'client-profile', label: 'Profile', icon: Users, category: 'Client', action: () => router.push('/client/profile') },
    ]),
    { id: 'home', label: 'Home Page', icon: ArrowRight, category: 'Navigation', action: () => router.push('/') },
    { id: 'login', label: 'Login', icon: Users, category: 'Navigation', action: () => router.push('/auth/login') },
    { id: 'logout', label: 'Logout', icon: LogOut, category: 'Actions', action: () => { localStorage.clear(); router.push('/auth/login'); } },
  ];

  const filtered = search
    ? items.filter(i => i.label.toLowerCase().includes(search.toLowerCase()) || i.category.toLowerCase().includes(search.toLowerCase()))
    : items;

  const grouped = filtered.reduce((acc, item) => {
    if (!acc[item.category]) acc[item.category] = [];
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, CommandItem[]>);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-start justify-center pt-[15vh]" onClick={() => setOpen(false)}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg bg-[#0c0c0f] border border-[#1a1a2e] rounded-2xl shadow-2xl shadow-black/50 overflow-hidden animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[#1a1a2e]">
          <Search size={18} className="text-[#475569] flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search pages, actions..."
            className="flex-1 bg-transparent text-[#e2e8f0] text-sm placeholder:text-[#475569] outline-none"
          />
          <kbd className="px-2 py-0.5 rounded bg-[#1a1a2e] text-[10px] text-[#475569] font-mono">ESC</kbd>
        </div>

        {/* Results */}
        <div className="max-h-[400px] overflow-y-auto p-2">
          {filtered.length === 0 ? (
            <div className="text-center py-8">
              <HelpCircle size={32} className="mx-auto text-[#1a1a2e] mb-2" />
              <p className="text-sm text-[#475569]">No results found</p>
            </div>
          ) : (
            Object.entries(grouped).map(([category, catItems]) => (
              <div key={category} className="mb-2">
                <p className="px-3 py-1.5 text-[10px] uppercase tracking-wider text-[#475569] font-semibold">{category}</p>
                {catItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => { item.action(); setOpen(false); setSearch(''); }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left hover:bg-[#1a1a2e]/50 transition-colors group"
                    >
                      <div className="w-8 h-8 rounded-lg bg-[#1a1a2e] flex items-center justify-center flex-shrink-0 group-hover:bg-[#6366f1]/10 transition-colors">
                        <Icon size={14} className="text-[#64748b] group-hover:text-[#6366f1] transition-colors" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-[#e2e8f0]">{item.label}</p>
                        {item.description && <p className="text-[10px] text-[#475569]">{item.description}</p>}
                      </div>
                      <ArrowRight size={12} className="text-[#475569] opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  );
                })}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#1a1a2e]">
          <div className="flex items-center gap-3">
            <kbd className="px-1.5 py-0.5 rounded bg-[#1a1a2e] text-[9px] text-[#475569] font-mono">↑↓</kbd>
            <span className="text-[10px] text-[#475569]">Navigate</span>
            <kbd className="px-1.5 py-0.5 rounded bg-[#1a1a2e] text-[9px] text-[#475569] font-mono">↵</kbd>
            <span className="text-[10px] text-[#475569]">Open</span>
          </div>
          <button onClick={() => setOpen(false)} className="p-1 rounded hover:bg-[#1a1a2e]">
            <X size={12} className="text-[#475569]" />
          </button>
        </div>
      </div>
    </div>
  );
}
