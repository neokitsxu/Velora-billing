'use client';

import { useState, useEffect } from 'react';

interface TooltipProps {
  content: string;
  children: React.ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

export function Tooltip({ content, children, position = 'top' }: TooltipProps) {
  const [show, setShow] = useState(false);

  const posClasses = {
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 -translate-y-1/2 ml-2',
  };

  return (
    <div className="relative inline-flex" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      {show && (
        <div className={`absolute z-50 px-2.5 py-1.5 rounded-lg bg-[#1a1a2e] border border-[#2a2a3e] text-[10px] text-[#e2e8f0] whitespace-nowrap shadow-lg animate-fade-in pointer-events-none ${posClasses[position]}`}>
          {content}
        </div>
      )}
    </div>
  );
}

interface BadgeProps {
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple';
  children: React.ReactNode;
  pulse?: boolean;
  dot?: boolean;
}

export function Badge({ variant = 'default', children, pulse = false, dot = false }: BadgeProps) {
  const variants = {
    default: 'bg-[#1a1a2e] text-[#64748b] border-[#1a1a2e]',
    success: 'bg-[#10b981]/10 text-[#10b981] border-[#10b981]/20',
    warning: 'bg-[#f59e0b]/10 text-[#f59e0b] border-[#f59e0b]/20',
    danger: 'bg-[#ef4444]/10 text-[#ef4444] border-[#ef4444]/20',
    info: 'bg-[#6366f1]/10 text-[#6366f1] border-[#6366f1]/20',
    purple: 'bg-[#8b5cf6]/10 text-[#8b5cf6] border-[#8b5cf6]/20',
  };

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-medium border ${variants[variant]}`}>
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${variant === 'success' ? 'bg-[#10b981]' : variant === 'warning' ? 'bg-[#f59e0b]' : variant === 'danger' ? 'bg-[#ef4444]' : variant === 'info' ? 'bg-[#6366f1]' : variant === 'purple' ? 'bg-[#8b5cf6]' : 'bg-[#64748b]'} ${pulse ? 'animate-pulse' : ''}`} />}
      {children}
    </span>
  );
}

interface EmptyStateProps {
  icon: any;
  title: string;
  description: string;
  action?: { label: string; onClick: () => void };
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="velora-card p-16 text-center animate-fade-in">
      <div className="w-16 h-16 rounded-2xl bg-[#1a1a2e] flex items-center justify-center mx-auto mb-4">
        <Icon size={28} className="text-[#475569]" />
      </div>
      <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2">{title}</h3>
      <p className="text-sm text-[#64748b] max-w-sm mx-auto mb-6">{description}</p>
      {action && (
        <button onClick={action.onClick} className="velora-btn-primary px-6 py-2.5 text-sm">
          {action.label}
        </button>
      )}
    </div>
  );
}

export function Skeleton({ className, lines = 3 }: { className?: string; lines?: number }) {
  return (
    <div className={`space-y-3 ${className || ''}`}>
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="skeleton-shimmer rounded-lg" style={{ height: `${Math.max(12, 20 - i * 3)}px`, width: `${100 - i * 15}%` }} />
      ))}
    </div>
  );
}

export function LoadingScreen({ message = 'Loading...' }: { message?: string }) {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="relative">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center mx-auto animate-pulse-glow">
            <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          </div>
        </div>
        <p className="text-[#64748b] text-sm animate-pulse">{message}</p>
      </div>
    </div>
  );
}

export function AnimatedCounter({ value, prefix = '', suffix = '', duration = 1000 }: { value: number; prefix?: string; suffix?: string; duration?: number }) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = value;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.floor(eased * (end - start) + start));
      if (progress < 1) requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  }, [value, duration]);

  return (
    <span>
      {prefix}{display.toLocaleString()}{suffix}
    </span>
  );
}

export function Sparkline({ data, width = 100, height = 30, color = '#6366f1' }: { data: number[]; width?: number; height?: number; color?: string }) {
  if (data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - ((v - min) / range) * height}`).join(' ');

  return (
    <svg width={width} height={height} className="overflow-visible">
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  };

  return (
    <button onClick={handleCopy} className="text-xs text-[#64748b] hover:text-[#6366f1] transition-colors flex items-center gap-1">
      {copied ? (
        <><span className="text-[#10b981]">Copied!</span></>
      ) : (
        <>{label}</>
      )}
    </button>
  );
}
