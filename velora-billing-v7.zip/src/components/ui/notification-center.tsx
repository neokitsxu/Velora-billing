'use client';

import { useState, useEffect } from 'react';
import { Bell, Check, Trash2, ExternalLink, X } from 'lucide-react';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
  link?: string;
}

export function NotificationCenter() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/notifications', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch {
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  };

  const markRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const typeColor = (type: string) => {
    switch (type) {
      case 'success': return 'bg-[#10b981]/10 border-[#10b981]/20 text-[#10b981]';
      case 'warning': return 'bg-[#f59e0b]/10 border-[#f59e0b]/20 text-[#f59e0b]';
      case 'error': return 'bg-[#ef4444]/10 border-[#ef4444]/20 text-[#ef4444]';
      default: return 'bg-[#6366f1]/10 border-[#6366f1]/20 text-[#6366f1]';
    }
  };

  const timeAgo = (date: string) => {
    const now = new Date();
    const past = new Date(date);
    const diff = Math.floor((now.getTime() - past.getTime()) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="relative p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors"
      >
        <Bell size={20} />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-[#ef4444] text-white text-[10px] font-bold flex items-center justify-center px-1 animate-scale-bounce">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 w-96 max-h-[500px] bg-[#0c0c0f] border border-[#1a1a2e] rounded-2xl shadow-2xl shadow-black/50 z-50 overflow-hidden animate-scale-in">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-[#1a1a2e]">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-[#e2e8f0]">Notifications</h3>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-[#6366f1]/10 text-[#6366f1] text-[10px] font-bold">
                    {unreadCount} new
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                {unreadCount > 0 && (
                  <button onClick={markAllRead} className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#10b981] transition-colors" title="Mark all read">
                    <Check size={14} />
                  </button>
                )}
                <button onClick={() => setOpen(false)} className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                  <X size={14} />
                </button>
              </div>
            </div>

            {/* Notifications List */}
            <div className="overflow-y-auto max-h-[400px]">
              {loading ? (
                <div className="p-4 text-center">
                  <div className="w-6 h-6 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin mx-auto" />
                </div>
              ) : notifications.length === 0 ? (
                <div className="p-8 text-center">
                  <Bell size={32} className="mx-auto text-[#1a1a2e] mb-2" />
                  <p className="text-sm text-[#475569]">No notifications yet</p>
                </div>
              ) : (
                <div className="divide-y divide-[#1a1a2e]/50">
                  {notifications.map((notif) => (
                    <div
                      key={notif.id}
                      className={`p-3.5 hover:bg-[#1a1a2e]/30 transition-colors cursor-pointer ${!notif.read ? 'bg-[#6366f1]/3' : ''}`}
                      onClick={() => { markRead(notif.id); if (notif.link) window.location.href = notif.link; }}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${!notif.read ? 'bg-[#6366f1] animate-pulse' : 'bg-transparent'}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p className={`text-sm ${!notif.read ? 'font-semibold text-[#e2e8f0]' : 'text-[#c8ccd0]'}`}>
                              {notif.title}
                            </p>
                            <div className="flex items-center gap-1 flex-shrink-0">
                              <span className="text-[10px] text-[#475569]">{timeAgo(notif.createdAt)}</span>
                              <button
                                onClick={(e) => { e.stopPropagation(); deleteNotification(notif.id); }}
                                className="p-0.5 rounded hover:bg-[#ef4444]/10 text-[#475569] hover:text-[#ef4444] transition-colors opacity-0 group-hover:opacity-100"
                              >
                                <Trash2 size={10} />
                              </button>
                            </div>
                          </div>
                          <p className="text-xs text-[#64748b] mt-0.5 line-clamp-2">{notif.message}</p>
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-medium border ${typeColor(notif.type)}`}>
                              {notif.type}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-[#1a1a2e]">
              <button className="w-full text-center text-xs text-[#6366f1] hover:text-[#818cf8] transition-colors">
                View All Notifications
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
