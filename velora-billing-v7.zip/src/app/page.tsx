'use client';

import Link from 'next/link';
import {
  Zap,
  Shield,
  Headphones,
  Server,
  CreditCard,
  Globe,
  ArrowRight,
  Check,
  Menu,
  X,
  ChevronRight,
} from 'lucide-react';
import { useState } from 'react';

const features = [
  {
    icon: Zap,
    title: 'Instant Setup',
    description: 'Get your server up and running in under 60 seconds with our automated deployment system.',
  },
  {
    icon: Shield,
    title: 'DDoS Protection',
    description: 'Enterprise-grade DDoS mitigation keeps your services online and protected 24/7.',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Our expert support team is available around the clock via live chat and tickets.',
  },
  {
    icon: Server,
    title: 'Auto Provisioning',
    description: 'Fully automated provisioning with instant activation and zero manual intervention.',
  },
  {
    icon: CreditCard,
    title: 'UPI Payments',
    description: 'Seamless UPI, cards, and netbanking payments with instant invoice generation.',
  },
  {
    icon: Globe,
    title: 'Multi-location',
    description: 'Deploy across Mumbai, Bangalore, Singapore, and 10+ global data centers.',
  },
];

const plans = [
  {
    name: 'Starter',
    price: '₹49',
    period: '/mo',
    description: 'Perfect for small servers and friends',
    features: ['2 GB RAM', '2 vCPU Cores', '20 GB NVMe SSD', '1 TB Bandwidth', 'Basic DDoS Protection'],
    popular: false,
    cta: 'Get Started',
  },
  {
    name: 'Premium',
    price: '₹99',
    period: '/mo',
    description: 'Best value for growing communities',
    features: ['4 GB RAM', '4 vCPU Cores', '50 GB NVMe SSD', '3 TB Bandwidth', 'Advanced DDoS Protection', 'Priority Support'],
    popular: true,
    cta: 'Get Started',
  },
  {
    name: 'Ultimate',
    price: '₹199',
    period: '/mo',
    description: 'Maximum performance for large servers',
    features: ['8 GB RAM', '6 vCPU Cores', '100 GB NVMe SSD', 'Unlimited Bandwidth', 'Enterprise DDoS Protection', 'Priority Support', 'Dedicated IP'],
    popular: false,
    cta: 'Get Started',
  },
];

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#09090b] text-[#e2e8f0] font-['Inter'] overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-[#1a1a2e] bg-[#09090b]/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <span className="text-lg font-bold text-white">
                Velora <span className="text-[#6366f1]">Billing</span>
              </span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              <Link href="/client/products" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                Products
              </Link>
              <a href="#pricing" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                Pricing
              </a>
              <a href="#features" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                Support
              </a>
              <Link
                href="/auth/login"
                className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors"
              >
                Login
              </Link>
              <Link
                href="/auth/register"
                className="velora-btn-primary text-sm px-5 py-2 rounded-lg"
              >
                Register
              </Link>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-[#64748b] hover:text-[#e2e8f0]"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#1a1a2e] bg-[#0c0c0f] px-4 py-4 space-y-3">
            <Link href="/client/products" className="block text-sm text-[#64748b] hover:text-[#e2e8f0] py-2">
              Products
            </Link>
            <a href="#pricing" className="block text-sm text-[#64748b] hover:text-[#e2e8f0] py-2">
              Pricing
            </a>
            <a href="#features" className="block text-sm text-[#64748b] hover:text-[#e2e8f0] py-2">
              Support
            </a>
            <Link href="/auth/login" className="block text-sm text-[#64748b] hover:text-[#e2e8f0] py-2">
              Login
            </Link>
            <Link
              href="/auth/register"
              className="block text-center velora-btn-primary text-sm px-5 py-2.5 rounded-lg"
            >
              Register
            </Link>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="grid-bg absolute inset-0 opacity-30" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#6366f1]/10 rounded-full blur-[120px]" />
        <div className="absolute top-1/3 left-1/4 w-[300px] h-[300px] bg-[#8b5cf6]/10 rounded-full blur-[100px]" />

        <div className="relative max-w-5xl mx-auto text-center animate-fade-in">
          <div className="velora-badge inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium mb-8">
            <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse" />
            Now accepting UPI & all major payment methods
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-white leading-tight tracking-tight mb-6">
            Premium Game Hosting
            <br />
            <span className="velora-gradient bg-gradient-to-r from-[#6366f1] via-[#8b5cf6] to-[#a78bfa] bg-clip-text text-transparent">
              & VPS Solutions
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-[#64748b] max-w-2xl mx-auto mb-10 leading-relaxed">
            Velora Billing provides lightning-fast game servers and VPS hosting with instant setup,
            enterprise-grade DDoS protection, and seamless UPI payments — all from an intuitive
            dashboard built for modern hosting.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/auth/register"
              className="velora-btn-primary w-full sm:w-auto px-8 py-3.5 rounded-xl text-base font-semibold flex items-center justify-center gap-2 group"
            >
              Get Started
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
            <a
              href="#pricing"
              className="velora-btn-secondary w-full sm:w-auto px-8 py-3.5 rounded-xl text-base font-semibold flex items-center justify-center gap-2"
            >
              View Plans
              <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {[
              { value: '10K+', label: 'Active Users' },
              { value: '99.9%', label: 'Uptime' },
              { value: '15+', label: 'Locations' },
              { value: '< 60s', label: 'Setup Time' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-white">{stat.value}</div>
                <div className="text-sm text-[#64748b] mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-slide-up">
            <span className="velora-badge velora-badge-info inline-block px-3 py-1 rounded-full text-xs font-medium mb-4">
              Features
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Everything You Need to Host
            </h2>
            <p className="text-[#64748b] max-w-xl mx-auto">
              From instant provisioning to enterprise security, we&apos;ve got every angle covered.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className={`velora-card group p-6 rounded-2xl border border-[#1a1a2e] bg-[#0c0c0f] hover:border-[#6366f1]/50 transition-all duration-300 animate-slide-up`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-xl bg-[#6366f1]/10 flex items-center justify-center mb-4 group-hover:bg-[#6366f1]/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-[#6366f1]" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-sm text-[#64748b] leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#6366f1]/5 to-transparent" />
        <div className="relative max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-slide-up">
            <span className="velora-badge velora-badge-warning inline-block px-3 py-1 rounded-full text-xs font-medium mb-4">
              Pricing
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Minecraft Hosting Plans
            </h2>
            <p className="text-[#64748b] max-w-xl mx-auto">
              Simple, transparent pricing. No hidden fees. Cancel anytime.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <div
                key={plan.name}
                className={`relative velora-card rounded-2xl border p-8 transition-all duration-300 animate-slide-up ${
                  plan.popular
                    ? 'border-[#6366f1] bg-[#0c0c0f] velora-glow scale-105'
                    : 'border-[#1a1a2e] bg-[#0c0c0f] hover:border-[#6366f1]/50'
                }`}
                style={{ animationDelay: `${index * 150}ms` }}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="velora-badge-success px-4 py-1 rounded-full text-xs font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-white mb-1">{plan.name}</h3>
                  <p className="text-sm text-[#64748b]">{plan.description}</p>
                </div>

                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-4xl font-extrabold text-white">{plan.price}</span>
                  <span className="text-[#64748b]">{plan.period}</span>
                </div>

                <Link
                  href="/auth/register"
                  className={`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all duration-300 mb-8 ${
                    plan.popular
                      ? 'velora-btn-primary'
                      : 'velora-btn-secondary'
                  }`}
                >
                  {plan.cta}
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3 text-sm">
                      <Check className="w-4 h-4 text-[#10b981] flex-shrink-0" />
                      <span className="text-[#e2e8f0]">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#1a1a2e] bg-[#0c0c0f] py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <span className="text-lg font-bold text-white">
                  Velora <span className="text-[#6366f1]">Billing</span>
                </span>
              </div>
              <p className="text-sm text-[#64748b] leading-relaxed">
                Premium game hosting and VPS solutions with an intuitive billing experience.
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Product</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/client/products" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    Game Servers
                  </Link>
                </li>
                <li>
                  <a href="#pricing" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    VPS Hosting
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    Dedicated Servers
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Company</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    Careers
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Support</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                    Status Page
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-[#1a1a2e] pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-[#64748b]">
              &copy; {new Date().getFullYear()} Velora Billing. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
