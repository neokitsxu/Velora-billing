'use client';

import { useEffect } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error('Application error:', error);
  }, [error]);

  return (
    <div className="min-h-screen bg-[#09090b] grid-bg flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center animate-fade-in">
        {/* Animated Error Icon */}
        <div className="relative mb-8">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#ef4444]/10 to-[#ef4444]/5 border-2 border-[#ef4444]/20 flex items-center justify-center mx-auto animate-pulse-glow" style={{ boxShadow: '0 0 30px rgba(239,68,68,0.15)' }}>
            <AlertTriangle size={40} className="text-[#ef4444]" />
          </div>
          <div className="absolute -bottom-2 -right-2 left-1/2 ml-6">
            <div className="px-3 py-1 rounded-full bg-[#ef4444]/10 border border-[#ef4444]/20">
              <span className="text-[10px] font-bold text-[#ef4444] uppercase tracking-wider">Error</span>
            </div>
          </div>
        </div>

        <h1 className="text-2xl font-bold text-[#e2e8f0] mb-3">Something Went Wrong</h1>
        <p className="text-[#64748b] text-sm mb-2 leading-relaxed">
          An unexpected error occurred while loading this page. This might be a temporary issue.
        </p>
        {error.message && (
          <p className="text-[#475569] text-xs font-mono bg-[#0c0c0f] border border-[#1a1a2e] rounded-lg p-3 mb-6 break-all">
            {error.message}
          </p>
        )}

        <div className="flex gap-3 justify-center">
          <button
            onClick={reset}
            className="velora-btn-primary flex items-center gap-2 px-6 py-3 text-sm"
          >
            <RefreshCw size={14} />
            Try Again
          </button>
          <a
            href="/"
            className="velora-btn-secondary flex items-center gap-2 px-6 py-3 text-sm"
          >
            <Home size={14} />
            Go Home
          </a>
        </div>

        <p className="text-[10px] text-[#475569] mt-8">
          If this persists, please contact support.
          {error.digest && <span className="ml-1">Error ID: {error.digest}</span>}
        </p>
      </div>
    </div>
  );
}
