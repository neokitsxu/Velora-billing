import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from 'react-hot-toast';

export const metadata: Metadata = {
  title: 'Velora Billing - Modern Hosting Billing Platform',
  description: 'Velora Billing - Premium hosting billing & server provisioning platform. Minecraft hosting, VPS, dedicated servers, and more.',
  icons: { icon: '/favicon.ico' },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased min-h-screen bg-[#09090b] text-[#e2e8f0] font-sans grid-bg">
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#0c0c0f',
              color: '#e2e8f0',
              border: '1px solid #1a1a2e',
              borderRadius: '12px',
              fontSize: '14px',
            },
            success: { iconTheme: { primary: '#10b981', secondary: '#0c0c0f' } },
            error: { iconTheme: { primary: '#ef4444', secondary: '#0c0c0f' } },
          }}
        />
      </body>
    </html>
  );
}
