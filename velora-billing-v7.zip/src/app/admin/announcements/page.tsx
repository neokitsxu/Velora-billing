'use client';

import { useState, useEffect } from 'react';
import {
  Megaphone,
  Plus,
  X,
  Pencil,
  Trash2,
  Power,
  Info,
  AlertTriangle,
  CheckCircle2,
  Wrench,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Announcement {
  id: number;
  title: string;
  content: string;
  type: 'info' | 'warning' | 'success' | 'maintenance';
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

const typeConfig: Record<string, { label: string; badge: string; icon: React.ReactNode }> = {
  info: { label: 'Info', badge: 'velora-badge velora-badge-info', icon: <Info size={14} /> },
  warning: { label: 'Warning', badge: 'velora-badge velora-badge-warning', icon: <AlertTriangle size={14} /> },
  success: { label: 'Success', badge: 'velora-badge velora-badge-success', icon: <CheckCircle2 size={14} /> },
  maintenance: { label: 'Maintenance', badge: 'velora-badge velora-badge-danger', icon: <Wrench size={14} /> },
};

const emptyForm = {
  title: '',
  content: '',
  type: 'info' as Announcement['type'],
  active: true,
};

export default function AdminAnnouncements() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Announcement | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const token = typeof window !== 'undefined' ? localStorage.getItem('velora_token') : null;

  const fetchAnnouncements = async () => {
    try {
      const res = await fetch('/api/announcements');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.data) setAnnouncements(data.data);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setShowModal(true);
  };

  const openEdit = (a: Announcement) => {
    setEditing(a);
    setForm({
      title: a.title,
      content: a.content,
      type: a.type,
      active: a.active,
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.title.trim() || !form.content.trim()) {
      toast.error('Title and content are required');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/announcements', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ ...form, id: editing?.id }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(editing ? 'Announcement updated' : 'Announcement created');
        setShowModal(false);
        fetchAnnouncements();
      } else {
        toast.error(data.error || 'Failed to save');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (a: Announcement) => {
    try {
      const res = await fetch('/api/announcements', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ id: a.id, title: a.title, content: a.content, type: a.type, active: !a.active }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`Announcement ${!a.active ? 'activated' : 'deactivated'}`);
        fetchAnnouncements();
      } else {
        toast.error(data.error || 'Failed to toggle');
      }
    } catch {
      toast.error('Network error');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this announcement?')) return;
    try {
      const res = await fetch('/api/announcements', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('Announcement deleted');
        fetchAnnouncements();
      } else {
        toast.error(data.error || 'Failed to delete');
      }
    } catch {
      toast.error('Network error');
    }
  };

  const truncate = (str: string, len: number) => (str.length > len ? str.slice(0, len) + '...' : str);

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <Megaphone size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Announcements</h1>
            <p className="text-sm text-[#64748b]">Manage client-facing announcements</p>
          </div>
        </div>
        <button onClick={openCreate} className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Create Announcement
        </button>
      </div>

      {/* Announcements List */}
      {loading ? (
        <div className="velora-card p-12 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full mx-auto" />
        </div>
      ) : announcements.length === 0 ? (
        <div className="velora-card p-12 text-center">
          <Megaphone size={48} className="text-[#64748b] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Announcements</h3>
          <p className="text-[#64748b] text-sm">Create your first announcement to keep clients informed.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {announcements.map((a) => {
            const cfg = typeConfig[a.type] || typeConfig.info;
            return (
              <div key={a.id} className="velora-card p-5 animate-slide-up">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-[#e2e8f0] font-semibold truncate">{a.title}</h3>
                      <span className={cfg.badge}>{cfg.icon} {cfg.label}</span>
                      <span className={`flex items-center gap-1.5 text-xs ${a.active ? 'text-[#10b981]' : 'text-[#64748b]'}`}>
                        <span className={`w-2 h-2 rounded-full ${a.active ? 'bg-[#10b981]' : 'bg-[#64748b]'}`} />
                        {a.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <p className="text-[#64748b] text-sm leading-relaxed">{truncate(a.content, 200)}</p>
                    <p className="text-[#64748b] text-xs mt-2">Created {formatDate(a.createdAt)}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => openEdit(a)}
                      className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors"
                      title="Edit"
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      onClick={() => toggleActive(a)}
                      className={`p-2 rounded-lg transition-colors ${a.active ? 'text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10' : 'text-[#64748b] hover:text-[#10b981] hover:bg-[#10b981]/10'}`}
                      title={a.active ? 'Deactivate' : 'Activate'}
                    >
                      <Power size={16} />
                    </button>
                    <button
                      onClick={() => handleDelete(a.id)}
                      className="p-2 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="velora-card w-full max-w-lg mx-4 p-6 animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-[#e2e8f0]">
                {editing ? 'Edit Announcement' : 'Create Announcement'}
              </h2>
              <button onClick={() => setShowModal(false)} className="text-[#64748b] hover:text-[#e2e8f0]">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Title</label>
                <input
                  type="text"
                  className="velora-input w-full"
                  placeholder="Announcement title..."
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Content</label>
                <textarea
                  className="velora-input w-full min-h-[120px] resize-y"
                  placeholder="Announcement content..."
                  value={form.content}
                  onChange={(e) => setForm({ ...form, content: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Type</label>
                <select
                  className="velora-input w-full"
                  value={form.type}
                  onChange={(e) => setForm({ ...form, type: e.target.value as Announcement['type'] })}
                >
                  <option value="info">Info</option>
                  <option value="warning">Warning</option>
                  <option value="success">Success</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-[#e2e8f0]">Active</label>
                <button
                  type="button"
                  onClick={() => setForm({ ...form, active: !form.active })}
                  className={`relative w-11 h-6 rounded-full transition-colors ${form.active ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'}`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${form.active ? 'translate-x-5' : 'translate-x-0'}`}
                  />
                </button>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="velora-btn-secondary">
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving} className="velora-btn-primary">
                {saving ? 'Saving...' : editing ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
