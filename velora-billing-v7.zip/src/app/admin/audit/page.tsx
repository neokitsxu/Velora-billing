'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  ScrollText, Search, ChevronLeft, ChevronRight, User, Shield,
  Edit, Trash2, Plus, LogIn, CreditCard, Download, Loader2,
  RefreshCw, Eye, EyeOff, XCircle, Package, Server, Settings,
  AlertTriangle, Clock, Filter,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { Modal, ConfirmModal } from '@/components/ui/modal';

type AuditLog = {
  id: number;
  timestamp: string;
  user: string;
  userId: number;
  action: string;
  details: string;
  ipAddress: string;
  userAgent: string;
  detailsJson?: string;
};

const demoLogs: AuditLog[] = [
  { id: 1, timestamp: '2025-01-15 14:32:10', user: 'Admin', userId: 1, action: 'product.create', details: 'Created product "Minecraft Premium"', ipAddress: '103.45.67.89', userAgent: 'Chrome/121', detailsJson: '{"productId":12,"name":"Minecraft Premium","price":599}' },
  { id: 2, timestamp: '2025-01-15 14:28:05', user: 'Admin', userId: 1, action: 'client.edit', details: 'Updated client "Rahul Sharma"', ipAddress: '103.45.67.89', userAgent: 'Chrome/121', detailsJson: '{"clientId":5,"changes":["role"]}' },
  { id: 3, timestamp: '2025-01-15 14:20:33', user: 'Rahul Sharma', userId: 2, action: 'order.create', details: 'Placed order #ORD-1041', ipAddress: '49.207.123.45', userAgent: 'Chrome/121' },
  { id: 4, timestamp: '2025-01-15 13:55:12', user: 'Priya Patel', userId: 3, action: 'ticket.create', details: 'Opened ticket #TKT-501', ipAddress: '157.49.210.33', userAgent: 'Safari/604' },
  { id: 5, timestamp: '2025-01-15 13:40:00', user: 'Admin', userId: 1, action: 'settings.update', details: 'Updated payment settings', ipAddress: '103.45.67.89', userAgent: 'Chrome/121', detailsJson: '{"section":"payment","changes":["upi_id"]}' },
  { id: 6, timestamp: '2025-01-15 12:15:44', user: 'Admin', userId: 1, action: 'node.sync', details: 'Synced node "India-Mumbai-1"', ipAddress: '103.45.67.89', userAgent: 'Chrome/121' },
  { id: 7, timestamp: '2025-01-15 11:30:22', user: 'Amit Kumar', userId: 4, action: 'auth.login', details: 'User logged in from new device', ipAddress: '182.75.43.21', userAgent: 'Chrome/121' },
  { id: 8, timestamp: '2025-01-15 10:45:18', user: 'Admin', userId: 1, action: 'invoice.mark_paid', details: 'Marked invoice #INV-2034 as paid', ipAddress: '103.45.67.89', userAgent: 'Chrome/121' },
  { id: 9, timestamp: '2025-01-15 10:10:55', user: 'Admin', userId: 1, action: 'client.suspend', details: 'Suspended client "Amit Kumar"', ipAddress: '103.45.67.89', userAgent: 'Chrome/121' },
  { id: 10, timestamp: '2025-01-15 09:30:00', user: 'Sneha Reddy', userId: 5, action: 'payment.complete', details: 'UPI payment ₹299 for order #ORD-1038', ipAddress: '157.49.88.12', userAgent: 'Firefox/122' },
];

const actionIcons: Record<string, any> = {
  'product.create': Plus, 'product.edit': Edit, 'client.edit': Edit,
  'client.suspend': Shield, 'client.delete': Trash2, 'order.create': Plus,
  'order.refund': CreditCard, 'ticket.create': Plus, 'ticket.reply': Edit,
  'auth.login': LogIn, 'settings.update': Settings, 'node.sync': Server,
  'node.create': Plus, 'invoice.mark_paid': CreditCard,
  'payment.complete': CreditCard, 'invoice.create': Plus,
};

const actionCategories = ['all', 'Auth', 'Orders', 'Products', 'Clients', 'Settings', 'System'];

const PER_PAGE = 10;

export default function AuditLogs() {
  const [logs, setLogs] = useState<AuditLog[]>(demoLogs);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [userFilter, setUserFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [page, setPage] = useState(1);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [expandedLog, setExpandedLog] = useState<AuditLog | null>(null);
  const [showClear, setShowClear] = useState(false);

  const fetchLogs = useCallback(async () => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/audit', { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        if (data.logs) setLogs(data.logs);
      }
    } catch { /* use demo */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(fetchLogs, 15000);
    return () => clearInterval(interval);
  }, [autoRefresh, fetchLogs]);

  const uniqueUsers = [...new Set(logs.map(l => l.user))];

  const filtered = logs.filter(log => {
    const matchSearch = log.user.toLowerCase().includes(search.toLowerCase()) ||
      log.action.toLowerCase().includes(search.toLowerCase()) ||
      log.details.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === 'all' || log.action.split('.')[0].toLowerCase() === categoryFilter.toLowerCase();
    const matchUser = userFilter === 'all' || log.user === userFilter;
    const matchDateFrom = !dateFrom || log.timestamp >= dateFrom;
    const matchDateTo = !dateTo || log.timestamp <= dateTo + ' 23:59:59';
    return matchSearch && matchCat && matchUser && matchDateFrom && matchDateTo;
  });

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const getActionColor = (action: string) => {
    if (action.includes('create')) return 'text-[#10b981] bg-[#10b981]/10';
    if (action.includes('delete') || action.includes('suspend')) return 'text-[#ef4444] bg-[#ef4444]/10';
    if (action.includes('edit') || action.includes('update') || action.includes('reply') || action.includes('sync') || action.includes('mark_paid')) return 'text-[#f59e0b] bg-[#f59e0b]/10';
    if (action.includes('refund')) return 'text-[#8b5cf6] bg-[#8b5cf6]/10';
    if (action.includes('login')) return 'text-[#6366f1] bg-[#6366f1]/10';
    if (action.includes('payment') || action.includes('complete')) return 'text-[#10b981] bg-[#10b981]/10';
    return 'text-[#64748b] bg-[#64748b]/10';
  };

  const handleClearLogs = () => {
    setLogs([]);
    toast.success('Old logs cleared');
    setShowClear(false);
  };

  const handleExport = () => {
    const csv = 'Timestamp,User,Action,Details,IP Address\n' +
      logs.map(l => `"${l.timestamp}","${l.user}","${l.action}","${l.details}","${l.ipAddress}"`).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'audit-log.csv'; a.click();
    URL.revokeObjectURL(url);
    toast.success('Audit log exported');
  };

  const todayCount = logs.filter(l => l.timestamp.startsWith(new Date().toISOString().split('T')[0])).length;
  const mostActiveAdmin = 'Admin';
  const statsBar = [
    { label: 'Total Actions', value: logs.length, icon: ScrollText },
    { label: 'Actions Today', value: todayCount, icon: Clock },
    { label: 'Most Active', value: mostActiveAdmin, icon: User },
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse"><div className="h-64 bg-[#1a1a2e] rounded" /></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <ScrollText size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Audit Logs</h1>
            <p className="text-sm text-[#64748b]">Track all administrative and user actions</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExport} className="velora-btn-secondary flex items-center gap-2 text-sm">
            <Download size={14} /> Export
          </button>
          <button onClick={() => setShowClear(true)} className="velora-btn-danger flex items-center gap-2 text-sm">
            <Trash2 size={14} /> Clear Old
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 stagger-children">
        {statsBar.map((s, i) => (
          <div key={i} className="velora-card p-4 flex items-center gap-3 hover-lift">
            <div className="p-2.5 rounded-lg bg-[#6366f1]/10"><s.icon size={16} className="text-[#6366f1]" /></div>
            <div>
              <p className="text-xs text-[#64748b]">{s.label}</p>
              <p className="text-lg font-bold text-[#e2e8f0]">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="velora-card p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="relative sm:col-span-2">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
            <input type="text" placeholder="Search logs..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} className="velora-input pl-9 w-full text-sm" />
          </div>
          <select value={userFilter} onChange={(e) => { setUserFilter(e.target.value); setPage(1); }} className="velora-input text-sm">
            <option value="all">All Users</option>
            {uniqueUsers.map(u => <option key={u} value={u}>{u}</option>)}
          </select>
          <select value={categoryFilter} onChange={(e) => { setCategoryFilter(e.target.value); setPage(1); }} className="velora-input text-sm">
            {actionCategories.map(a => <option key={a} value={a}>{a === 'all' ? 'All Categories' : a}</option>)}
          </select>
          <input type="date" value={dateFrom} onChange={(e) => { setDateFrom(e.target.value); setPage(1); }} className="velora-input text-sm" />
          <input type="date" value={dateTo} onChange={(e) => { setDateTo(e.target.value); setPage(1); }} className="velora-input text-sm" />
        </div>
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-2">
            <Filter size={12} className="text-[#64748b]" />
            <span className="text-xs text-[#64748b]">{filtered.length} logs found</span>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-xs text-[#64748b]">Auto-refresh</span>
            <div
              className={`w-9 h-5 rounded-full relative transition-colors cursor-pointer ${autoRefresh ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'}`}
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${autoRefresh ? 'translate-x-4' : 'translate-x-0.5'}`} />
            </div>
            {autoRefresh && <RefreshCw size={12} className="text-[#6366f1] animate-spin" />}
          </label>
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>User</th>
                <th>Action</th>
                <th>Details</th>
                <th>IP Address</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {paginated.map(log => {
                const Icon = actionIcons[log.action] || Edit;
                const isExpanded = expandedLog?.id === log.id;
                return (
                  <tr key={log.id} className="cursor-pointer" onClick={() => setExpandedLog(isExpanded ? null : log)}>
                    <td className="text-sm text-[#64748b] whitespace-nowrap font-mono">{log.timestamp}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center"><User size={10} className="text-white" /></div>
                        <span className="text-sm text-[#e2e8f0]">{log.user}</span>
                      </div>
                    </td>
                    <td>
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium ${getActionColor(log.action)}`}>
                        <Icon size={11} /> {log.action}
                      </span>
                    </td>
                    <td className="text-sm text-[#64748b] max-w-[250px] truncate">{log.details}</td>
                    <td className="text-sm text-[#64748b] font-mono">{log.ipAddress}</td>
                    <td>
                      <button onClick={(e) => { e.stopPropagation(); setExpandedLog(isExpanded ? null : log); }} className="p-1.5 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                        {isExpanded ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-[#64748b]">
            <ScrollText size={40} className="mx-auto mb-3 opacity-50" />
            <p>No audit logs found</p>
          </div>
        )}
        {expandedLog && (
          <div className="border-t border-[#1a1a2e] p-4 bg-[#09090b] animate-slide-down">
            <h4 className="text-sm font-semibold text-[#e2e8f0] mb-2">Full Details</h4>
            <p className="text-sm text-[#64748b] mb-2">{expandedLog.details}</p>
            {expandedLog.detailsJson && (
              <div className="bg-[#0c0c0f] rounded-lg p-3 border border-[#1a1a2e]">
                <code className="text-xs text-[#6366f1] font-mono whitespace-pre-wrap">{JSON.stringify(JSON.parse(expandedLog.detailsJson), null, 2)}</code>
              </div>
            )}
            <div className="flex gap-4 mt-3 text-xs text-[#475569]">
              <span>User Agent: {expandedLog.userAgent}</span>
              <span>IP: {expandedLog.ipAddress}</span>
            </div>
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-[#64748b]">
            Showing {(page - 1) * PER_PAGE + 1}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length} logs
          </p>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1} className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors disabled:opacity-30"><ChevronLeft size={16} /></button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum: number;
              if (totalPages <= 5) pageNum = i + 1;
              else if (page <= 3) pageNum = i + 1;
              else if (page >= totalPages - 2) pageNum = totalPages - 4 + i;
              else pageNum = page - 2 + i;
              return (
                <button key={pageNum} onClick={() => setPage(pageNum)} className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors ${page === pageNum ? 'bg-[#6366f1] text-white velora-glow' : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'}`}>{pageNum}</button>
              );
            })}
            <button onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page === totalPages} className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors disabled:opacity-30"><ChevronRight size={16} /></button>
          </div>
        </div>
      )}

      {/* Clear Confirm */}
      <ConfirmModal open={showClear} onClose={() => setShowClear(false)} onConfirm={handleClearLogs} title="Clear Old Logs" message="This will remove all audit logs. This action cannot be undone." confirmText="Clear All Logs" type="danger" />
    </div>
  );
}
