'use client';

import { useState, useEffect } from 'react';
import {
  ShoppingCart, Search, Eye, CheckCircle, RotateCcw, XCircle, Filter,
  Loader2, Download, Package, User, CreditCard, Clock, Calendar,
  ChevronDown, ChevronUp, DollarSign,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { ConfirmModal } from '@/components/ui/modal';



interface Order {
  id: string;
  client: string;
  clientId: number;
  product: string;
  productId: number;
  amount: number;
  tax: number;
  status: string;
  payment: string | null;
  paymentId: string | null;
  date: string;
  paidAt: string | null;
  notes: string;
}

const statusWorkflow: Record<string, string[]> = {
  pending: ['paid', 'cancelled'],
  paid: ['provisioning', 'refunded', 'cancelled'],
  provisioning: ['active', 'refunded', 'cancelled'],
  active: ['expired', 'cancelled'],
};

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<{ order: Order; action: string } | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/orders', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const data = await res.json();
          if (data.orders) setOrders(data.orders);
        }
      } catch { /* no data */ } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  const filtered = orders.filter(o => {
    const matchSearch = o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.client.toLowerCase().includes(search.toLowerCase()) ||
      o.product.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    const matchDateFrom = !dateFrom || o.date >= dateFrom;
    const matchDateTo = !dateTo || o.date <= dateTo + ' 23:59:59';
    return matchSearch && matchStatus && matchDateFrom && matchDateTo;
  });

  const statusColor = (status: string) => {
    switch (status) {
      case 'paid': case 'active': return 'velora-badge-success';
      case 'pending': case 'provisioning': return 'velora-badge-warning';
      case 'refunded': return 'velora-badge-info';
      case 'cancelled': case 'expired': return 'velora-badge-danger';
      default: return 'velora-badge';
    }
  };

  const markPaid = (order: Order) => {
    setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status: 'paid', payment: 'manual', paidAt: new Date().toISOString().replace('T', ' ').slice(0, 16) } : o));
    toast.success(`Order ${order.id} marked as paid`);
  };

  const refundOrder = (order: Order) => {
    setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status: 'refunded' } : o));
    toast.success(`Order ${order.id} refunded`);
  };

  const cancelOrder = (order: Order) => {
    setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status: 'cancelled' } : o));
    toast.success(`Order ${order.id} cancelled`);
  };

  const bulkAction = (action: string) => {
    setOrders(prev => prev.map(o => selected.has(o.id) ? { ...o, status: action as Order['status'] } : o));
    toast.success(`${selected.size} orders updated`);
    setSelected(new Set());
  };

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selected.size === filtered.length) { setSelected(new Set()); }
    else { setSelected(new Set(filtered.map(o => o.id))); }
  };

  const handleExport = () => {
    const csv = 'Order,Client,Product,Amount,Status,Date\n' +
      orders.map(o => `"${o.id}","${o.client}","${o.product}",${o.amount},"${o.status}","${o.date}"`).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'orders.csv'; a.click();
    URL.revokeObjectURL(url);
    toast.success('Orders exported');
  };

  const executeConfirmAction = () => {
    if (!confirmAction) return;
    const { order, action } = confirmAction;
    if (action === 'paid') markPaid(order);
    else if (action === 'refund') refundOrder(order);
    else if (action === 'cancel') cancelOrder(order);
    setConfirmAction(null);
  };

  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  const paidToday = orders.filter(o => o.status === 'paid' && o.date.startsWith(new Date().toISOString().split('T')[0])).length;
  const refundedToday = orders.filter(o => o.status === 'refunded' && o.date.startsWith(new Date().toISOString().split('T')[0])).length;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse"><div className="h-64 bg-[#1a1a2e] rounded" /></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <ShoppingCart size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Orders</h1>
            <p className="text-sm text-[#64748b]">Manage all orders</p>
          </div>
        </div>
        <button onClick={handleExport} className="velora-btn-secondary flex items-center gap-2 text-sm">
          <Download size={14} /> Export
        </button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 stagger-children">
        {[
          { label: 'Total Orders', value: totalOrders, icon: ShoppingCart, color: '#6366f1' },
          { label: 'Pending', value: pendingOrders, icon: Clock, color: '#f59e0b' },
          { label: 'Paid Today', value: paidToday, icon: CheckCircle, color: '#10b981' },
          { label: 'Refunded Today', value: refundedToday, icon: RotateCcw, color: '#8b5cf6' },
        ].map((s, i) => (
          <div key={i} className="velora-card p-4 hover-lift">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg" style={{ backgroundColor: `${s.color}15` }}>
                <s.icon size={16} style={{ color: s.color }} />
              </div>
              <div>
                <p className="text-xs text-[#64748b]">{s.label}</p>
                <p className="text-xl font-bold text-[#e2e8f0]">{s.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bulk Actions */}
      {selected.size > 0 && (
        <div className="velora-card p-4 flex items-center justify-between animate-fade-in">
          <span className="text-sm text-[#6366f1] font-medium">{selected.size} orders selected</span>
          <div className="flex gap-2">
            <button onClick={() => bulkAction('paid')} className="velora-btn-success text-xs px-3 py-1.5">Mark Paid</button>
            <button onClick={() => bulkAction('cancelled')} className="velora-btn-danger text-xs px-3 py-1.5">Cancel</button>
            <button onClick={() => setSelected(new Set())} className="velora-btn-secondary text-xs px-3 py-1.5">Clear</button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="velora-card p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative sm:col-span-2">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
            <input type="text" placeholder="Search by order ID, client, or product..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input pl-10 w-full" />
          </div>
          <div className="flex items-center gap-2">
            <Filter size={16} className="text-[#64748b] flex-shrink-0" />
            {['all', 'pending', 'paid', 'provisioning', 'active', 'refunded', 'cancelled', 'expired'].map(s => (
              <button key={s} onClick={() => setStatusFilter(s)} className={`px-2.5 py-1.5 text-xs rounded-lg font-medium transition-colors capitalize ${statusFilter === s ? 'bg-[#6366f1]/10 text-[#6366f1]' : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'}`}>
                {s}
              </button>
            ))}
          </div>
          <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="velora-input text-sm" />
          <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="velora-input text-sm" />
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th className="w-10">
                  <input type="checkbox" checked={filtered.length > 0 && selected.size === filtered.length} onChange={toggleSelectAll} className="rounded bg-[#1a1a2e] border-[#1a1a2e] text-[#6366f1] focus:ring-[#6366f1]" />
                </th>
                <th></th>
                <th>Order #</th>
                <th>Client</th>
                <th>Product</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(order => {
                const isExpanded = expandedOrder === order.id;
                return (
                  <>
                    <tr key={order.id} className={`${selected.has(order.id) ? 'bg-[#6366f1]/5' : ''}`}>
                      <td>
                        <input type="checkbox" checked={selected.has(order.id)} onChange={() => toggleSelect(order.id)} className="rounded bg-[#1a1a2e] border-[#1a1a2e] text-[#6366f1] focus:ring-[#6366f1]" />
                      </td>
                      <td>
                        <button onClick={() => setExpandedOrder(isExpanded ? null : order.id)} className="p-1 rounded text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                          {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                        </button>
                      </td>
                      <td className="font-mono text-sm text-[#6366f1]">{order.id}</td>
                      <td className="text-[#e2e8f0]">{order.client}</td>
                      <td className="text-[#64748b]">{order.product}</td>
                      <td className="text-[#e2e8f0] font-medium">₹{order.amount.toLocaleString()}</td>
                      <td><span className={statusColor(order.status)}>{order.status}</span></td>
                      <td className="text-[#64748b] capitalize">{order.payment || '—'}</td>
                      <td className="text-[#64748b] text-sm">{order.date}</td>
                      <td>
                        <div className="flex items-center gap-1">
                          {order.status !== 'paid' && order.status !== 'active' && order.status !== 'provisioning' && (
                            <button onClick={() => setConfirmAction({ order, action: 'paid' })} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#10b981] hover:bg-[#10b981]/10 transition-colors" title="Mark Paid"><CheckCircle size={14} /></button>
                          )}
                          {(order.status === 'paid' || order.status === 'active') && (
                            <button onClick={() => setConfirmAction({ order, action: 'refund' })} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 transition-colors" title="Refund"><RotateCcw size={14} /></button>
                          )}
                          {order.status !== 'cancelled' && order.status !== 'refunded' && order.status !== 'expired' && (
                            <button onClick={() => setConfirmAction({ order, action: 'cancel' })} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors" title="Cancel"><XCircle size={14} /></button>
                          )}
                        </div>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr key={`${order.id}-detail`}>
                        <td colSpan={10} className="p-0">
                          <div className="p-5 bg-[#09090b] border-t border-b border-[#1a1a2e] animate-slide-down">
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                              <div>
                                <p className="text-xs font-semibold text-[#64748b] uppercase mb-2 flex items-center gap-1"><Package size={12} /> Product Info</p>
                                <div className="space-y-1 text-sm">
                                  <p className="text-[#e2e8f0]">{order.product}</p>
                                  <p className="text-[#64748b]">Product ID: #{order.productId}</p>
                                </div>
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-[#64748b] uppercase mb-2 flex items-center gap-1"><User size={12} /> Client Info</p>
                                <div className="space-y-1 text-sm">
                                  <p className="text-[#e2e8f0]">{order.client}</p>
                                  <p className="text-[#64748b]">Client ID: #{order.clientId}</p>
                                </div>
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-[#64748b] uppercase mb-2 flex items-center gap-1"><CreditCard size={12} /> Payment Info</p>
                                <div className="space-y-1 text-sm">
                                  <p className="text-[#e2e8f0]">₹{order.amount} + ₹{order.tax} tax</p>
                                  <p className="text-[#64748b]">Method: {order.payment || 'N/A'}</p>
                                  {order.paymentId && <p className="text-[#64748b]">ID: <code className="text-[#6366f1]">{order.paymentId}</code></p>}
                                </div>
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-[#64748b] uppercase mb-2 flex items-center gap-1"><Clock size={12} /> Timestamps</p>
                                <div className="space-y-1 text-sm">
                                  <p className="text-[#64748b]">Created: {order.date}</p>
                                  {order.paidAt && <p className="text-[#10b981]">Paid: {order.paidAt}</p>}
                                  {order.notes && <p className="text-[#f59e0b]">{order.notes}</p>}
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="velora-card p-12 text-center">
            <ShoppingCart className="h-12 w-12 text-[#6366f1]/30 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2">No orders found</h3>
            <p className="text-sm text-[#64748b]">
              {search || statusFilter !== 'all' || dateFrom || dateTo
                ? 'No orders match your current filters.'
                : 'Orders will appear here when clients make purchases.'}
            </p>
          </div>
        )}
      </div>

      {/* Confirm Modal */}
      <ConfirmModal
        open={!!confirmAction}
        onClose={() => setConfirmAction(null)}
        onConfirm={executeConfirmAction}
        title={confirmAction?.action === 'paid' ? 'Mark as Paid' : confirmAction?.action === 'refund' ? 'Refund Order' : 'Cancel Order'}
        message={`Are you sure you want to ${confirmAction?.action} order ${confirmAction?.order.id}?`}
        confirmText={confirmAction?.action === 'paid' ? 'Mark Paid' : confirmAction?.action === 'refund' ? 'Refund' : 'Cancel Order'}
        type={confirmAction?.action === 'paid' ? 'info' : confirmAction?.action === 'refund' ? 'warning' : 'danger'}
      />
    </div>
  );
}
