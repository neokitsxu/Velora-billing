'use client';

import { useState, useEffect } from 'react';
import {
  Palette,
  Save,
  Eye,
  SwatchBook,
  Type,
  RectangleHorizontal,
  RotateCcw,
  Trash2,
  Download,
  Check,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface ThemeColors {
  primary: string;
  accent: string;
  background: string;
  sidebarBg: string;
  cardBg: string;
  text: string;
}

interface ThemeSettings {
  name: string;
  colors: ThemeColors;
  font: string;
  borderRadius: number;
}

interface SavedTheme {
  id?: number;
  name: string;
  settings: ThemeSettings;
  createdAt: string;
}

const defaultTheme: ThemeSettings = {
  name: 'Default Dark',
  colors: {
    primary: '#6366f1',
    accent: '#8b5cf6',
    background: '#09090b',
    sidebarBg: '#0c0c14',
    cardBg: '#0c0c0f',
    text: '#e2e8f0',
  },
  font: 'Inter',
  borderRadius: 8,
};

const presets: ThemeSettings[] = [
  {
    name: 'Default Dark',
    colors: { primary: '#6366f1', accent: '#8b5cf6', background: '#09090b', sidebarBg: '#0c0c14', cardBg: '#0c0c0f', text: '#e2e8f0' },
    font: 'Inter',
    borderRadius: 8,
  },
  {
    name: 'Purple Haze',
    colors: { primary: '#a855f7', accent: '#c084fc', background: '#0a0515', sidebarBg: '#0d0720', cardBg: '#0f0a1e', text: '#e8e0f0' },
    font: 'Inter',
    borderRadius: 12,
  },
  {
    name: 'Ocean Blue',
    colors: { primary: '#0ea5e9', accent: '#38bdf8', background: '#020617', sidebarBg: '#050d18', cardBg: '#071022', text: '#e0f0ff' },
    font: 'Inter',
    borderRadius: 8,
  },
  {
    name: 'Forest Green',
    colors: { primary: '#10b981', accent: '#34d399', background: '#022c22', sidebarBg: '#061210', cardBg: '#081815', text: '#d0f0e0' },
    font: 'Inter',
    borderRadius: 10,
  },
];

const colorLabels: { key: keyof ThemeColors; label: string }[] = [
  { key: 'primary', label: 'Primary Color' },
  { key: 'accent', label: 'Accent Color' },
  { key: 'background', label: 'Background' },
  { key: 'sidebarBg', label: 'Sidebar Background' },
  { key: 'cardBg', label: 'Card Background' },
  { key: 'text', label: 'Text Color' },
];

const fonts = ['Inter', 'Roboto', 'Poppins', 'JetBrains Mono', 'System UI'];

export default function AdminThemes() {
  const [theme, setTheme] = useState<ThemeSettings>(defaultTheme);
  const [customCss, setCustomCss] = useState('/* Custom CSS here */\n.card-hover:hover {\n  transform: translateY(-2px);\n}');
  const [savedThemes, setSavedThemes] = useState<SavedTheme[]>([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const token = typeof window !== 'undefined' ? localStorage.getItem('velora_token') : null;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/admin/settings', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.theme) setTheme((prev) => ({ ...prev, ...data.theme, colors: { ...prev.colors, ...data.theme.colors } }));
          if (data.customCss) setCustomCss(data.customCss);
          if (data.savedThemes) setSavedThemes(data.savedThemes);
        }
      } catch {
        // use defaults
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const updateColor = (key: keyof ThemeColors, value: string) => {
    setTheme((prev) => ({
      ...prev,
      colors: { ...prev.colors, [key]: value },
    }));
  };

  const applyPreset = (preset: ThemeSettings) => {
    setTheme({ ...preset });
    toast.success(`Applied "${preset.name}" preset`);
  };

  const resetToDefault = () => {
    setTheme({ ...defaultTheme });
    setCustomCss('/* Custom CSS here */\n.card-hover:hover {\n  transform: translateY(-2px);\n}');
    toast.success('Reset to default theme');
  };

  const saveTheme = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ theme, customCss }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('Theme saved successfully');
      } else {
        toast.error(data.error || 'Failed to save');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const saveAsTheme = async (name: string) => {
    try {
      const newSaved = { name, settings: { ...theme }, createdAt: new Date().toISOString() };
      const updated = [...savedThemes, newSaved];
      setSavedThemes(updated);
      toast.success(`Theme "${name}" saved`);
    } catch {
      toast.error('Failed to save theme');
    }
  };

  const loadSavedTheme = (st: SavedTheme) => {
    setTheme({ ...st.settings });
    toast.success(`Loaded "${st.name}"`);
  };

  const deleteSavedTheme = (index: number) => {
    const updated = savedThemes.filter((_, i) => i !== index);
    setSavedThemes(updated);
    toast.success('Theme deleted');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <Palette size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Theme Editor</h1>
            <p className="text-sm text-[#64748b]">Customize the look and feel of your platform</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={resetToDefault} className="velora-btn-secondary flex items-center gap-2">
            <RotateCcw size={16} /> Reset to Default
          </button>
          <button onClick={saveTheme} disabled={saving} className="velora-btn-primary flex items-center gap-2">
            <Save size={16} /> {saving ? 'Saving...' : 'Save Theme'}
          </button>
        </div>
      </div>

      {/* Main Editor Layout: Form + Live Preview */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        {/* Left: Theme Settings Form (3 cols) */}
        <div className="xl:col-span-3 space-y-6">
          {/* Color Pickers */}
          <div className="velora-card p-6 animate-slide-up">
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
              <Palette size={18} className="text-[#6366f1]" /> Colors
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {colorLabels.map(({ key, label }) => (
                <div key={key}>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">{label}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={theme.colors[key]}
                      onChange={(e) => updateColor(key, e.target.value)}
                      className="w-10 h-10 rounded-lg border border-[#1a1a2e] bg-transparent cursor-pointer"
                    />
                    <input
                      type="text"
                      value={theme.colors[key]}
                      onChange={(e) => updateColor(key, e.target.value)}
                      className="velora-input flex-1 font-mono text-sm"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Font & Border Radius */}
          <div className="velora-card p-6 animate-slide-up">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5 flex items-center gap-1.5">
                  <Type size={14} className="text-[#6366f1]" /> Font Family
                </label>
                <select
                  value={theme.font}
                  onChange={(e) => setTheme({ ...theme, font: e.target.value })}
                  className="velora-input w-full"
                >
                  {fonts.map((f) => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5 flex items-center gap-1.5">
                  <RectangleHorizontal size={14} className="text-[#6366f1]" /> Border Radius
                  <span className="ml-auto text-xs font-mono text-[#64748b]">{theme.borderRadius}px</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={theme.borderRadius}
                  onChange={(e) => setTheme({ ...theme, borderRadius: parseInt(e.target.value) })}
                  className="w-full accent-[#6366f1] mt-2"
                />
                <div className="flex justify-between text-xs text-[#64748b] mt-1">
                  <span>0px</span>
                  <span>20px</span>
                </div>
              </div>
            </div>
          </div>

          {/* Custom CSS */}
          <div className="velora-card p-6 animate-slide-up">
            <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Custom CSS</label>
            <textarea
              value={customCss}
              onChange={(e) => setCustomCss(e.target.value)}
              className="velora-input w-full min-h-[160px] resize-y font-mono text-sm"
              spellCheck={false}
            />
          </div>
        </div>

        {/* Right: Live Preview Panel (2 cols) */}
        <div className="xl:col-span-2">
          <div className="velora-card p-6 xl:sticky xl:top-6 animate-slide-up">
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
              <Eye size={18} className="text-[#6366f1]" /> Live Preview
            </h3>
            <div
              className="rounded-xl border overflow-hidden transition-all duration-300"
              style={{ borderColor: theme.colors.primary + '33' }}
            >
              {/* Mini Layout */}
              <div className="flex" style={{ minHeight: '260px' }}>
                {/* Sidebar */}
                <div
                  className="w-32 p-2.5 space-y-1.5 shrink-0"
                  style={{ backgroundColor: theme.colors.sidebarBg, borderRight: `1px solid ${theme.colors.primary}15` }}
                >
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-5 h-5 rounded" style={{ backgroundColor: theme.colors.primary, borderRadius: theme.borderRadius }} />
                    <div className="h-2.5 w-14 rounded" style={{ backgroundColor: theme.colors.primary + '33' }} />
                  </div>
                  {['Dashboard', 'Clients', 'Products', 'Orders', 'Settings'].map((item, i) => (
                    <div
                      key={item}
                      className="h-6 rounded-md flex items-center px-2 text-[10px]"
                      style={{
                        backgroundColor: i === 0 ? theme.colors.primary + '15' : 'transparent',
                        color: i === 0 ? theme.colors.primary : theme.colors.text + '80',
                        borderLeft: i === 0 ? `2px solid ${theme.colors.primary}` : '2px solid transparent',
                        borderRadius: theme.borderRadius,
                      }}
                    >
                      {item}
                    </div>
                  ))}
                </div>
                {/* Content */}
                <div className="flex-1 p-3 space-y-2.5" style={{ backgroundColor: theme.colors.background }}>
                  {/* Stats row */}
                  <div className="grid grid-cols-3 gap-1.5">
                    {[theme.colors.primary, theme.colors.accent, theme.colors.primary + '88'].map((color, i) => (
                      <div
                        key={i}
                        className="rounded-lg p-2"
                        style={{
                          backgroundColor: theme.colors.cardBg,
                          border: `1px solid ${color}22`,
                          borderRadius: theme.borderRadius,
                        }}
                      >
                        <div className="w-4 h-4 rounded mb-1.5" style={{ backgroundColor: color + '33', borderRadius: theme.borderRadius }} />
                        <div className="h-1.5 w-10 rounded" style={{ backgroundColor: color + '44' }} />
                      </div>
                    ))}
                  </div>
                  {/* Table area */}
                  <div
                    className="rounded-lg p-2.5"
                    style={{
                      backgroundColor: theme.colors.cardBg,
                      border: `1px solid ${theme.colors.primary}15`,
                      borderRadius: theme.borderRadius,
                    }}
                  >
                    <div className="h-2 w-16 rounded mb-2" style={{ backgroundColor: theme.colors.text + '30' }} />
                    {[50, 70, 40, 85, 60].map((w, i) => (
                      <div key={i} className="flex items-center gap-2 mb-1">
                        <div className="h-1.5 rounded" style={{ width: `${w}%`, backgroundColor: theme.colors.primary + '25', borderRadius: theme.borderRadius }} />
                      </div>
                    ))}
                  </div>
                  {/* Button preview */}
                  <div className="flex gap-2 pt-1">
                    <div
                      className="px-3 py-1.5 text-[10px] font-medium rounded-md"
                      style={{
                        backgroundColor: theme.colors.primary,
                        color: '#fff',
                        borderRadius: theme.borderRadius,
                      }}
                    >
                      Primary Button
                    </div>
                    <div
                      className="px-3 py-1.5 text-[10px] font-medium rounded-md"
                      style={{
                        backgroundColor: 'transparent',
                        color: theme.colors.primary,
                        border: `1px solid ${theme.colors.primary}50`,
                        borderRadius: theme.borderRadius,
                      }}
                    >
                      Secondary
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Color swatches under preview */}
            <div className="flex items-center gap-2 mt-4">
              <span className="text-xs text-[#64748b] shrink-0">Active palette:</span>
              <div className="flex gap-1.5 flex-1">
                {Object.values(theme.colors).map((color, i) => (
                  <div
                    key={i}
                    className="flex-1 h-6 rounded-md border border-white/10"
                    style={{ backgroundColor: color, borderRadius: theme.borderRadius }}
                    title={color}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Theme Presets */}
      <div className="velora-card p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
          <SwatchBook size={18} className="text-[#6366f1]" /> Theme Presets
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {presets.map((preset) => {
            const isActive =
              theme.colors.primary === preset.colors.primary &&
              theme.colors.accent === preset.colors.accent &&
              theme.colors.background === preset.colors.background;
            return (
              <button
                key={preset.name}
                onClick={() => applyPreset(preset)}
                className={`relative p-4 rounded-xl border transition-all text-left hover:scale-[1.02] ${
                  isActive
                    ? 'border-[#6366f1] bg-[#6366f1]/5 ring-1 ring-[#6366f1]/30'
                    : 'border-[#1a1a2e] hover:border-[#6366f1]/40'
                }`}
                style={{ borderRadius: theme.borderRadius }}
              >
                {isActive && (
                  <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#6366f1] flex items-center justify-center">
                    <Check size={12} className="text-white" />
                  </div>
                )}
                {/* Mini preview of preset */}
                <div
                  className="rounded-lg p-2 mb-3 border border-white/5"
                  style={{ backgroundColor: preset.colors.background }}
                >
                  <div className="flex gap-1 mb-2">
                    <div className="w-3 h-3 rounded" style={{ backgroundColor: preset.colors.primary }} />
                    <div className="w-3 h-3 rounded" style={{ backgroundColor: preset.colors.accent }} />
                    <div className="w-3 h-3 rounded" style={{ backgroundColor: preset.colors.text + '40' }} />
                  </div>
                  <div className="flex gap-1">
                    <div
                      className="w-2/3 h-1.5 rounded"
                      style={{ backgroundColor: preset.colors.primary + '30' }}
                    />
                    <div
                      className="w-1/3 h-1.5 rounded"
                      style={{ backgroundColor: preset.colors.accent + '30' }}
                    />
                  </div>
                </div>
                <p className="text-sm font-medium text-[#e2e8f0]">{preset.name}</p>
                <div className="flex items-center gap-2 mt-1.5">
                  {Object.values(preset.colors).slice(0, 4).map((color, i) => (
                    <div
                      key={i}
                      className="w-3.5 h-3.5 rounded-full border border-white/10"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Saved Themes */}
      <div className="velora-card p-6 animate-slide-up">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
            <Download size={18} className="text-[#6366f1]" /> Saved Themes
          </h3>
          <button
            onClick={() => {
              const name = prompt('Theme name:');
              if (name?.trim()) saveAsTheme(name.trim());
            }}
            className="velora-btn-secondary text-sm"
          >
            Save Current as Theme
          </button>
        </div>
        {savedThemes.length === 0 ? (
          <p className="text-[#64748b] text-sm text-center py-6">No saved themes yet. Save your current configuration to reuse it later.</p>
        ) : (
          <div className="space-y-3">
            {savedThemes.map((st, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-lg border border-[#1a1a2e] hover:border-[#6366f1]/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="flex gap-1">
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: st.settings.colors.primary }} />
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: st.settings.colors.accent }} />
                    <div className="w-4 h-4 rounded-full border border-white/10" style={{ backgroundColor: st.settings.colors.background }} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-[#e2e8f0]">{st.name}</p>
                    <p className="text-xs text-[#64748b]">{st.settings.font} · {st.settings.borderRadius}px radius</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => loadSavedTheme(st)}
                    className="velora-btn-secondary text-xs px-3 py-1.5"
                  >
                    Load
                  </button>
                  <button
                    onClick={() => deleteSavedTheme(index)}
                    className="velora-btn-danger text-xs px-3 py-1.5"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
