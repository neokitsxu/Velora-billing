'use client';

import { useState, useEffect } from 'react';
import {
  Database, Download, Trash2, Play, Loader2, HardDrive,
  RefreshCw, Clock, CheckCircle, XCircle, AlertTriangle, Plus,
  Search, CloudUpload, Shield, Archive,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { Modal, ConfirmModal } from '@/components/ui/modal';

interface Backup {
  id: string;
  name: string;
  date: string;
  size: string;
  type: 'full' | 'database' | 'files';
  status: 'completed' | 'in_progress' | 'failed';
  sizeBytes: number;
}

export default function AdminBackups() {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [search, setSearch] = useState('');
  const [autoBackup, setAutoBackup] = useState<'daily' | 'weekly' | 'monthly' | 'off'>('weekly');
  const [deleteTarget, setDeleteTarget] = useState<Backup | null>(null);
  const [restoreTarget, setRestoreTarget] = useState<Backup | null>(null);

  useEffect(() => {
    const fetchBackups = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/backups', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const data = await res.json();
          setBackups(data.backups || []);
        }
      } catch { /* */ } finally {
        setLoading(false);
      }
    };
    fetchBackups();
  }, []);

  const filtered = backups.filter(b => b.name.toLowerCase().includes(search.toLowerCase()));

  const createBackup = async () => {
    setCreating(true);
    toast.loading('Creating backup...', { id: 'backup' });
    setTimeout(() => {
      const newBackup: Backup = {
        id: Date.now().toString(),
        name: `backup_${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}`,
        date: new Date().toISOString(),
        size: '0 MB',
        type: 'full',
        status: 'completed',
        sizeBytes: Math.floor(Math.random() * 500 + 100) * 1024 * 1024,
      };
      newBackup.size = `${(newBackup.sizeBytes / (1024 * 1024)).toFixed(1)} MB`;
      setBackups(prev => [newBackup, ...prev]);
      setCreating(false);
      toast.success('Backup created successfully', { id: 'backup' });
    }, 3000);
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    setBackups(prev => prev.filter(b => b.id !== deleteTarget.id));
    toast.success('Backup deleted');
    setDeleteTarget(null);
  };

  const handleRestore = () => {
    if (!restoreTarget) return;
    toast.loading(`Restoring from ${restoreTarget.name}...`, { id: 'restore' });
    setTimeout(() => {
      toast.success('Backup restored successfully', { id: 'restore' });
      setRestoreTarget(null);
    }, 2000);
  };

  const downloadBackup = (b: Backup) => {
    toast.success(`Downloading ${b.name}...`);
  };

  const totalStorage = backups.reduce((s, b) => s + b.sizeBytes, 0);
  const maxStorage = 10 * 1024 * 1024 * 1024; // 10 GB
  const usagePercent = Math.min((totalStorage / maxStorage) * 100, 100);

  const statusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle size={14} className="text-[#10b981]" />;
      case 'in_progress': return <Loader2 size={14} className="text-[#f59e0b] animate-spin" />;
      case 'failed': return <XCircle size={14} className="text-[#ef4444]" />;
      default: return null;
    }
  };

  const statusBadge = (status: string) => {
    switch (status) {
      case 'completed': return 'velora-badge-success';
      case 'in_progress': return 'velora-badge-warning';
      case 'failed': return 'velora-badge-danger';
      default: return 'velora-badge';
    }
  };

  const typeBadge = (type: string) => {
    switch (type) {
      case 'full': return 'velora-badge-info';
      case 'database': return 'velora-badge-warning';
      case 'files': return 'velora-badge-success';
      default: return 'velora-badge';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <Database size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Backup Management</h1>
            <p className="text-sm text-[#64748b]">Create, restore & manage system backups</p>
          </div>
        </div>
        <button onClick={createBackup} disabled={creating} className="velora-btn-primary flex items-center gap-2">
          {creating ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
          {creating ? 'Creating...' : 'Create Backup'}
        </button>
      </div>

      {/* Storage & Auto-Backup */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="velora-card p-6 hover-lift">
          <div className="flex items-center gap-2 mb-4">
            <HardDrive size={16} className="text-[#6366f1]" />
            <h3 className="text-base font-semibold text-[#e2e8f0]">Storage Usage</h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#64748b]">Used</span>
              <span className="text-[#e2e8f0] font-medium">{(totalStorage / (1024 * 1024)).toFixed(1)} MB / 10 GB</span>
            </div>
            <div className="h-2.5 rounded-full bg-[#1a1a2e] overflow-hidden">
              <div className="h-full rounded-full bg-gradient-to-r from-[#6366f1] to-[#8b5cf6] animate-progress-fill transition-all" style={{ width: `${usagePercent}%` }} />
            </div>
            <div className="flex items-center gap-4 text-xs text-[#64748b]">
              <span>{backups.length} backups</span>
              <span>{backups.filter(b => b.status === 'completed').length} completed</span>
              {backups.length > 0 && <span>Last: {new Date(backups[0].date).toLocaleDateString()}</span>}
            </div>
          </div>
        </div>

        <div className="velora-card p-6 hover-lift">
          <div className="flex items-center gap-2 mb-4">
            <RefreshCw size={16} className="text-[#8b5cf6]" />
            <h3 className="text-base font-semibold text-[#e2e8f0]">Auto-Backup</h3>
          </div>
          <p className="text-sm text-[#64748b] mb-4">Configure automatic backup schedule</p>
          <div className="flex gap-2">
            {([
              { id: 'off' as const, label: 'Off' },
              { id: 'daily' as const, label: 'Daily' },
              { id: 'weekly' as const, label: 'Weekly' },
              { id: 'monthly' as const, label: 'Monthly' },
            ]).map(opt => (
              <button key={opt.id} onClick={() => setAutoBackup(opt.id)} className={`px-3 py-1.5 text-xs rounded-lg font-medium transition-all ${autoBackup === opt.id ? 'bg-[#6366f1] text-white' : 'bg-[#09090b] border border-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0]'}`}>
                {opt.label}
              </button>
            ))}
          </div>
          {autoBackup !== 'off' && (
            <div className="mt-3 flex items-center gap-2 text-xs text-[#10b981] animate-fade-in">
              <CheckCircle size={12} /> Next backup: {autoBackup === 'daily' ? 'tomorrow' : autoBackup === 'weekly' ? 'next week' : 'next month'}
            </div>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
        <input type="text" placeholder="Search backups..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input w-full pl-10" />
      </div>

      {/* Backup List */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : filtered.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <Archive size={48} className="mx-auto text-[#64748b] mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Backups</h3>
          <p className="text-[#64748b] text-sm mb-6">Create your first backup to secure your data.</p>
          <button onClick={createBackup} className="velora-btn-primary">
            <Database size={16} className="inline mr-2" />Create Backup
          </button>
        </div>
      ) : (
        <div className="velora-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="velora-table">
              <thead>
                <tr>
                  <th>Backup Name</th>
                  <th>Date</th>
                  <th>Size</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        {statusIcon(b.status)}
                        <div>
                          <p className="text-sm text-[#e2e8f0] font-mono">{b.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="text-sm text-[#64748b]">{new Date(b.date).toLocaleString()}</td>
                    <td className="text-sm text-[#e2e8f0] font-medium">{b.size}</td>
                    <td><span className={typeBadge(b.type)}>{b.type}</span></td>
                    <td><span className={statusBadge(b.status)}>{b.status.replace('_', ' ')}</span></td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => downloadBackup(b)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#10b981] transition-colors" title="Download"><Download size={14} /></button>
                        <button onClick={() => setRestoreTarget(b)} disabled={b.status !== 'completed'} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#6366f1] transition-colors disabled:opacity-30" title="Restore"><Play size={14} /></button>
                        <button onClick={() => setDeleteTarget(b)} className="p-2 rounded-lg hover:bg-[#ef4444]/10 text-[#64748b] hover:text-[#ef4444] transition-colors" title="Delete"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      <ConfirmModal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete Backup" message={`Delete "${deleteTarget?.name}"? This cannot be undone.`} confirmText="Delete" type="danger" />

      {/* Restore Confirm */}
      <ConfirmModal open={!!restoreTarget} onClose={() => setRestoreTarget(null)} onConfirm={handleRestore} title="Restore Backup" message={`Restore from "${restoreTarget?.name}"? The current data will be replaced.`} confirmText="Restore" type="warning" />
    </div>
  );
}
