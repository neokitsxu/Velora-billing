'use client';

import { useState, useEffect } from 'react';
import {
  Key, Plus, Copy, Trash2, Eye, EyeOff, Loader2, Shield, X,
  Clock, CheckCircle, AlertTriangle, Zap, RefreshCw,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { Modal, ConfirmModal } from '@/components/ui/modal';

interface ApiKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  lastUsed: string;
  createdAt: string;
  expiresAt?: string;
  active: boolean;
  usageCount: number;
}

const permissionCategories = [
  { key: 'read_orders', label: 'Read Orders', category: 'Orders' },
  { key: 'write_orders', label: 'Write Orders', category: 'Orders' },
  { key: 'read_clients', label: 'Read Clients', category: 'Clients' },
  { key: 'read_products', label: 'Read Products', category: 'Products' },
  { key: 'read_invoices', label: 'Read Invoices', category: 'Invoices' },
];

function generateKey(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = 'vl_live_';
  for (let i = 0; i < 24; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
  return result;
}

export default function AdminApiKeys() {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [deleteTarget, setDeleteTarget] = useState<ApiKey | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', permissions: ['read_orders'], expiry: '30' });

  useEffect(() => { fetchKeys(); }, []);

  const fetchKeys = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/settings', { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        const apiKeys = data.settings?.api?.keys || [];
        if (apiKeys.length > 0) {
          setKeys(apiKeys);
        }
      }
    } catch { /* */ } finally { setLoading(false); }
  };

  const createKey = () => {
    if (!form.name.trim()) { toast.error('Enter a name'); return; }
    if (form.permissions.length === 0) { toast.error('Select at least one permission'); return; }
    const generatedKey = generateKey();
    const key: ApiKey = {
      id: Date.now().toString(),
      name: form.name,
      key: generatedKey,
      permissions: form.permissions,
      lastUsed: '-',
      createdAt: new Date().toISOString(),
      expiresAt: form.expiry === 'never' ? undefined : new Date(Date.now() + parseInt(form.expiry) * 86400000).toISOString(),
      active: true,
      usageCount: 0,
    };
    setKeys(prev => [...prev, key]);
    setShowCreate(false);
    setForm({ name: '', permissions: ['read_orders'], expiry: '30' });
    toast.success('API key created! Copy it now — it won\'t be shown again.');
  };

  const deleteKey = () => {
    if (!deleteTarget) return;
    setKeys(prev => prev.filter(k => k.id !== deleteTarget.id));
    toast.success('API key revoked');
    setDeleteTarget(null);
  };

  const toggleVisibility = (id: string) => {
    setVisibleKeys(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const copyKey = (key: string, id: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKey(id);
    toast.success('Key copied to clipboard');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const maskKey = (key: string) => key.slice(0, 13) + '•••••••••••••';

  const togglePermission = (perm: string) => {
    setForm(prev => ({
      ...prev,
      permissions: prev.permissions.includes(perm) ? prev.permissions.filter(p => p !== perm) : [...prev.permissions, perm],
    }));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <Key size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">API Keys</h1>
            <p className="text-sm text-[#64748b]">Manage API keys for external integrations</p>
          </div>
        </div>
        <button onClick={() => setShowCreate(true)} className="velora-btn-primary flex items-center gap-2 text-sm">
          <Plus size={14} /> Create Key
        </button>
      </div>

      {/* Info Banner */}
      <div className="flex items-center gap-3 p-4 rounded-xl bg-[#6366f1]/5 border border-[#6366f1]/20 animate-fade-in">
        <Shield size={16} className="text-[#6366f1] flex-shrink-0" />
        <p className="text-xs text-[#6366f1]">API keys allow external applications to access your Velora Billing API. Keys are formatted as <code className="bg-[#6366f1]/10 px-1 rounded">vl_live_xxxxxxxxxxxx</code>. Keep them secure and rotate regularly.</p>
      </div>

      {/* Create Modal */}
      <Modal open={showCreate} onClose={() => setShowCreate(false)} title="Create New API Key" size="lg">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Key Name</label>
            <input type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g., Pterodactyl Integration" className="velora-input w-full" />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Expires In</label>
            <select value={form.expiry} onChange={(e) => setForm({ ...form, expiry: e.target.value })} className="velora-input w-full">
              <option value="7">7 Days</option>
              <option value="30">30 Days</option>
              <option value="90">90 Days</option>
              <option value="365">1 Year</option>
              <option value="never">Never</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-2">Permissions</label>
            <div className="space-y-2">
              {['Orders', 'Clients', 'Products', 'Invoices'].map(cat => (
                <div key={cat} className="p-3 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                  <p className="text-xs font-semibold text-[#64748b] uppercase mb-2">{cat}</p>
                  <div className="flex flex-wrap gap-2">
                    {permissionCategories.filter(p => p.category === cat).map(perm => (
                      <button key={perm.key} onClick={() => togglePermission(perm.key)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${form.permissions.includes(perm.key) ? 'bg-[#6366f1] text-white' : 'bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0]'}`}>
                        {perm.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button onClick={() => setShowCreate(false)} className="velora-btn-secondary text-sm">Cancel</button>
            <button onClick={createKey} className="velora-btn-primary text-sm">Generate Key</button>
          </div>
        </div>
      </Modal>

      {/* Key List */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : keys.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <Key size={48} className="mx-auto text-[#64748b] mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No API Keys</h3>
          <p className="text-[#64748b] text-sm mb-6">Create an API key to integrate with external services</p>
          <button onClick={() => setShowCreate(true)} className="velora-btn-primary">Create API Key</button>
        </div>
      ) : (
        <div className="space-y-3">
          {keys.map((key, i) => (
            <div key={key.id} className="velora-card p-5 hover:border-[#6366f1]/20 transition-all" style={{ animation: `fadeInUp 0.3s ease-out ${i * 0.05}s both` }}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center flex-shrink-0">
                    <Key size={16} className="text-[#6366f1]" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-semibold text-[#e2e8f0] truncate">{key.name}</p>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${key.active ? 'velora-badge-success' : 'velora-badge-danger'}`}>
                        {key.active ? 'Active' : 'Revoked'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <code className="text-[11px] font-mono text-[#475569] bg-[#09090b] px-2 py-0.5 rounded truncate max-w-[250px]">
                        {visibleKeys.has(key.id) ? key.key : maskKey(key.key)}
                      </code>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-[10px] text-[#475569]">
                      <span className="flex items-center gap-1"><Clock size={10} />Created {new Date(key.createdAt).toLocaleDateString()}</span>
                      <span className="flex items-center gap-1"><Zap size={10} />{key.usageCount} requests</span>
                      {key.lastUsed !== '-' && <span>Last used: {key.lastUsed}</span>}
                    </div>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {key.permissions.map(p => (
                        <span key={p} className="px-2 py-0.5 rounded bg-[#0c0c0f] text-[9px] text-[#475569] border border-[#1a1a2e]">{p}</span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => toggleVisibility(key.id)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#e2e8f0] transition-colors" title={visibleKeys.has(key.id) ? 'Hide' : 'Show'}>
                    {visibleKeys.has(key.id) ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                  <button onClick={() => copyKey(key.key, key.id)} className={`p-2 rounded-lg transition-colors ${copiedKey === key.id ? 'bg-[#10b981]/10 text-[#10b981]' : 'hover:bg-[#1a1a2e] text-[#475569] hover:text-[#10b981]'}`} title="Copy">
                    <Copy size={14} />
                  </button>
                  <button onClick={() => setDeleteTarget(key)} className="p-2 rounded-lg hover:bg-[#ef4444]/10 text-[#475569] hover:text-[#ef4444] transition-colors" title="Revoke">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Revoke Confirm */}
      <ConfirmModal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={deleteKey} title="Revoke API Key" message={`Revoke "${deleteTarget?.name}"? This action cannot be undone. All applications using this key will lose access.`} confirmText="Revoke Key" type="danger" />
    </div>
  );
}
