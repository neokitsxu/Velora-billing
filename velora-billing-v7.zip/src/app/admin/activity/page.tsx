'use client';

import { useState, useEffect } from 'react';
import { Activity, RefreshCw, Clock, Filter, Search, Loader2, User, ShoppingCart, Shield, CreditCard, Server, FileText, Settings, Tag } from 'lucide-react';
import { Sparkline } from '@/components/ui/common';

interface ActivityEntry {
  id: string;
  action: string;
  target: string;
  userId: string;
  userName: string;
  details: string;
  ip: string;
  createdAt: string;
}

export default function AdminActivity() {
  const [activities, setActivities] = useState<ActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => { fetchActivity(); }, [page]);

  const fetchActivity = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/admin/activity?page=${page}&limit=25`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setActivities(data.activities || []);
        setTotalPages(data.pagination?.pages || 1);
      }
    } catch { /* empty */ } finally { setLoading(false); }
  };

  const filtered = activities.filter(a => {
    const matchSearch = a.action.toLowerCase().includes(search.toLowerCase()) || a.userName.toLowerCase().includes(search.toLowerCase()) || a.details.toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === 'all' || a.action.toLowerCase().includes(filterType.toLowerCase());
    return matchSearch && matchType;
  });

  const getActionIcon = (action: string) => {
    const a = action.toLowerCase();
    if (a.includes('login') || a.includes('auth')) return <Shield size={14} className="text-[#6366f1]" />;
    if (a.includes('order') || a.includes('purchase')) return <ShoppingCart size={14} className="text-[#10b981]" />;
    if (a.includes('payment') || a.includes('invoice')) return <CreditCard size={14} className="text-[#f59e0b]" />;
    if (a.includes('server') || a.includes('provision')) return <Server size={14} className="text-[#8b5cf6]" />;
    if (a.includes('ticket')) return <FileText size={14} className="text-[#06b6d4]" />;
    if (a.includes('product') || a.includes('coupon')) return <Tag size={14} className="text-[#a855f7]" />;
    if (a.includes('setting') || a.includes('config')) return <Settings size={14} className="text-[#64748b]" />;
    return <Activity size={14} className="text-[#475569]" />;
  };

  const timeAgo = (date: string) => {
    const diff = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  // Mock timeline sparkline data
  const timelineData = [3, 5, 2, 8, 4, 6, 9, 3, 7, 5, 8, 6];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Activity Feed</h1>
          <p className="text-[#64748b] mt-1">Real-time system activity & audit trail</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden sm:block">
            <Sparkline data={timelineData} width={80} height={24} />
          </div>
          <button onClick={fetchActivity} className="velora-btn-primary flex items-center gap-2 text-sm">
            <RefreshCw size={14} /> Refresh
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#475569]" />
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search activities..." className="velora-input w-full pl-9 text-sm" />
        </div>
        <div className="flex gap-1 flex-wrap">
          {['all', 'login', 'order', 'payment', 'server', 'ticket', 'setting'].map(f => (
            <button key={f} onClick={() => setFilterType(f)} className={`px-3 py-1.5 text-[11px] rounded-lg font-medium capitalize transition-all ${filterType === f ? 'bg-[#6366f1] text-white' : 'bg-[#0c0c0f] border border-[#1a1a2e] text-[#475569] hover:text-[#e2e8f0]'}`}>
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Activity Timeline */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : filtered.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <Activity size={48} className="mx-auto text-[#1a1a2e] mb-4" />
          <p className="text-[#64748b]">No activity recorded yet</p>
          <p className="text-xs text-[#475569] mt-1">Activity will appear here as actions are performed</p>
        </div>
      ) : (
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-[19px] top-0 bottom-0 w-px bg-[#1a1a2e]" />

          <div className="space-y-3">
            {filtered.map((entry, i) => (
              <div key={entry.id} className="flex gap-4 animate-fade-in" style={{ animationDelay: `${i * 0.03}s` }}>
                {/* Icon */}
                <div className="relative z-10 w-10 h-10 rounded-xl bg-[#0c0c0f] border border-[#1a1a2e] flex items-center justify-center flex-shrink-0">
                  {getActionIcon(entry.action)}
                </div>

                {/* Content */}
                <div className="flex-1 velora-card p-4 hover:border-[#6366f1]/20 transition-all min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium text-[#e2e8f0]">{entry.action}</span>
                        <span className="text-[10px] text-[#475569]">on</span>
                        <span className="text-xs text-[#6366f1]">{entry.target}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-1.5 text-[11px] text-[#475569]">
                        <span className="flex items-center gap-1"><User size={10} />{entry.userName}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1"><Clock size={10} />{timeAgo(entry.createdAt)}</span>
                        <span>•</span>
                        <span className="font-mono">{entry.ip}</span>
                      </div>
                      {entry.details && (
                        <p className="text-xs text-[#475569] mt-2 bg-[#09090b] rounded-lg p-2.5 font-mono">{entry.details}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="velora-btn-secondary px-3 py-1.5 text-xs disabled:opacity-30">Previous</button>
          <span className="text-xs text-[#64748b]">Page {page} of {totalPages}</span>
          <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="velora-btn-secondary px-3 py-1.5 text-xs disabled:opacity-30">Next</button>
        </div>
      )}
    </div>
  );
}
