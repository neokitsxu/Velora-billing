'use client';

import { useState, useEffect } from 'react';
import {
  Settings as SettingsIcon,
  Globe,
  CreditCard,
  Mail,
  Server,
  Save,
  Eye,
  EyeOff,
  Shield,
  Bell,
  Key,
  Loader2,
} from 'lucide-react';
import toast from 'react-hot-toast';

type Tab = 'general' | 'payment' | 'email' | 'pterodactyl' | 'notifications' | 'security' | 'api';

interface SectionSettings {
  [key: string]: any;
}

const defaultSettings: Record<Tab, SectionSettings> = {
  general: {
    site_name: 'Velora Billing',
    site_description: 'Premium game server & VPS hosting billing platform',
    site_logo: '',
    site_favicon: '',
    currency: 'INR',
    currency_symbol: '₹',
    tax_enabled: false,
    tax_rate: 18,
    registration_enabled: true,
    maintenance_mode: false,
    footer_text: '© 2026 Velora Billing. All rights reserved.',
    support_email: 'support@velora.host',
    company_name: 'Velora Technologies',
    company_address: '',
  },
  payment: {
    upi_enabled: true,
    upi_id: '',
    upi_merchant_name: 'Velora Hosting',
    upi_merchant_code: 'VELORA',
    upi_min_amount: 10,
    auto_verify_upi: false,
    payment_timeout: 900,
    invoice_due_days: 7,
  },
  email: {
    smtp_host: 'smtp.gmail.com',
    smtp_port: 587,
    smtp_user: '',
    smtp_password: '',
    smtp_encryption: 'tls',
    from_email: 'noreply@velora.host',
    from_name: 'Velora Billing',
    email_enabled: false,
  },
  pterodactyl: {
    pterodactyl_url: '',
    pterodactyl_api_key: '',
    auto_provision: true,
    default_node_id: 1,
    default_egg_id: 1,
    default_nest_id: 1,
  },
  notifications: {
    new_order_notify: true,
    payment_notify: true,
    ticket_notify: true,
    registration_notify: true,
    server_notify: true,
    email_notify_enabled: true,
  },
  security: {
    force_https: false,
    session_timeout: 3600,
    max_login_attempts: 5,
    password_min_length: 8,
    two_factor_enabled: false,
    ip_whitelist: '',
    admin_ip_restrict: false,
  },
  api: {
    api_enabled: false,
    api_key: '',
    api_rate_limit: 100,
    webhook_url: '',
    webhook_secret: '',
  },
};

const tabs: { id: Tab; label: string; icon: any }[] = [
  { id: 'general', label: 'General', icon: Globe },
  { id: 'payment', label: 'Payment', icon: CreditCard },
  { id: 'email', label: 'Email', icon: Mail },
  { id: 'pterodactyl', label: 'Pterodactyl', icon: Server },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'api', label: 'API & Webhooks', icon: Key },
];

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState<Tab>('general');
  const [saving, setSaving] = useState(false);
  const [showSmtpPass, setShowSmtpPass] = useState(false);
  const [showPteroKey, setShowPteroKey] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [showWebhookSecret, setShowWebhookSecret] = useState(false);
  const [settings, setSettings] = useState<Record<Tab, SectionSettings>>({ ...defaultSettings });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/settings', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.settings) {
            setSettings((prev) => {
              const updated = { ...prev };
              for (const tab of Object.keys(prev) as Tab[]) {
                if (data.settings[tab] && Object.keys(data.settings[tab]).length > 0) {
                  updated[tab] = { ...prev[tab], ...data.settings[tab] };
                }
              }
              return updated;
            });
          }
        }
      } catch (err) {
        console.error('Failed to load settings:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const updateSetting = (section: Tab, key: string, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [section]: { ...prev[section], [key]: value },
    }));
  };

  const saveSection = async (section: Tab) => {
    setSaving(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ section, data: settings[section] }),
      });
      if (res.ok) {
        toast.success(`${tabs.find((t) => t.id === section)?.label} settings saved!`);
      } else {
        const err = await res.json();
        toast.error(err.error || 'Failed to save');
      }
    } catch {
      toast.error('Network error. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const toggleSwitch = (section: Tab, key: string) => {
    updateSetting(section, key, !settings[section][key]);
  };

  const Toggle = ({ checked, onChange, color = '#6366f1' }: { checked: boolean; onChange: () => void; color?: string }) => (
    <div
      className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer flex-shrink-0 ${checked ? '' : 'bg-[#1a1a2e]'}`}
      style={checked ? { backgroundColor: color } : {}}
      onClick={onChange}
    >
      <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${checked ? 'translate-x-5' : 'translate-x-0.5'}`} />
    </div>
  );

  const InputField = ({ label, value, onChange, type = 'text', placeholder = '' }: any) => (
    <div>
      <label className="block text-sm font-medium text-[#64748b] mb-1.5">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="velora-input w-full"
        placeholder={placeholder}
      />
    </div>
  );

  const PasswordField = ({ label, value, onChange, show, onToggleShow, placeholder = '' }: any) => (
    <div>
      <label className="block text-sm font-medium text-[#64748b] mb-1.5">{label}</label>
      <div className="relative">
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="velora-input w-full pr-10"
          placeholder={placeholder}
        />
        <button type="button" onClick={onToggleShow} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#e2e8f0]">
          {show ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>
    </div>
  );

  const SelectField = ({ label, value, onChange, options }: any) => (
    <div>
      <label className="block text-sm font-medium text-[#64748b] mb-1.5">{label}</label>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="velora-input w-full">
        {options.map((opt: any) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  );

  const NumberField = ({ label, value, onChange, min = 0, max = 999999 }: any) => (
    <div>
      <label className="block text-sm font-medium text-[#64748b] mb-1.5">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="velora-input w-full"
        min={min}
        max={max}
      />
    </div>
  );

  const SaveButton = ({ section }: { section: Tab }) => (
    <div className="pt-4 border-t border-[#1a1a2e] mt-6">
      <button onClick={() => saveSection(section)} disabled={saving} className="velora-btn-primary flex items-center gap-2">
        {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
        {saving ? 'Saving...' : `Save ${tabs.find((t) => t.id === section)?.label} Settings`}
      </button>
    </div>
  );

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Settings</h1>
        <p className="text-[#64748b] mt-1">Configure your billing platform</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-[#1a1a2e] overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors -mb-px whitespace-nowrap ${
                activeTab === tab.id
                  ? 'text-[#6366f1] border-[#6366f1]'
                  : 'text-[#64748b] border-transparent hover:text-[#e2e8f0]'
              }`}
            >
              <Icon size={16} /> {tab.label}
            </button>
          );
        })}
      </div>

      {/* General Tab */}
      {activeTab === 'general' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Globe size={18} className="text-[#6366f1]" /> General Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <div className="grid grid-cols-2 gap-4">
              <InputField label="Site Name" value={settings.general.site_name} onChange={(v: string) => updateSetting('general', 'site_name', v)} />
              <InputField label="Company Name" value={settings.general.company_name} onChange={(v: string) => updateSetting('general', 'company_name', v)} />
            </div>
            <InputField label="Description" value={settings.general.site_description} onChange={(v: string) => updateSetting('general', 'site_description', v)} />
            <div className="grid grid-cols-2 gap-4">
              <InputField label="Logo URL" value={settings.general.site_logo} onChange={(v: string) => updateSetting('general', 'site_logo', v)} placeholder="https://..." />
              <InputField label="Favicon URL" value={settings.general.site_favicon} onChange={(v: string) => updateSetting('general', 'site_favicon', v)} placeholder="https://..." />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <SelectField
                label="Currency"
                value={settings.general.currency}
                onChange={(v: string) => updateSetting('general', 'currency', v)}
                options={[
                  { value: 'INR', label: 'INR (₹)' },
                  { value: 'USD', label: 'USD ($)' },
                  { value: 'EUR', label: 'EUR (€)' },
                  { value: 'GBP', label: 'GBP (£)' },
                ]}
              />
              <InputField label="Support Email" value={settings.general.support_email} onChange={(v: string) => updateSetting('general', 'support_email', v)} />
            </div>
            <InputField label="Company Address" value={settings.general.company_address} onChange={(v: string) => updateSetting('general', 'company_address', v)} placeholder="Full address..." />
            <div className="grid grid-cols-2 gap-4">
              <NumberField label="Tax Rate (%)" value={settings.general.tax_rate} onChange={(v: number) => updateSetting('general', 'tax_rate', v)} min={0} max={50} />
              <div className="space-y-4 pt-6">
                <label className="flex items-center gap-3 cursor-pointer">
                  <Toggle checked={!!settings.general.tax_enabled} onChange={() => toggleSwitch('general', 'tax_enabled')} />
                  <span className="text-sm text-[#e2e8f0]">Enable Tax</span>
                </label>
              </div>
            </div>
            <div className="flex flex-wrap gap-6 pt-2">
              <label className="flex items-center gap-3 cursor-pointer">
                <Toggle checked={!!settings.general.registration_enabled} onChange={() => toggleSwitch('general', 'registration_enabled')} />
                <span className="text-sm text-[#e2e8f0]">Allow Registration</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <Toggle checked={!!settings.general.maintenance_mode} onChange={() => toggleSwitch('general', 'maintenance_mode')} color="#ef4444" />
                <span className="text-sm text-[#e2e8f0]">Maintenance Mode</span>
              </label>
            </div>
            <InputField label="Footer Text" value={settings.general.footer_text} onChange={(v: string) => updateSetting('general', 'footer_text', v)} />
            <SaveButton section="general" />
          </div>
        </div>
      )}

      {/* Payment Tab */}
      {activeTab === 'payment' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <CreditCard size={18} className="text-[#6366f1]" /> Payment Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.payment.upi_enabled} onChange={() => toggleSwitch('payment', 'upi_enabled')} />
              <span className="text-sm text-[#e2e8f0]">Enable UPI Payments</span>
            </label>
            <InputField label="UPI ID" value={settings.payment.upi_id} onChange={(v: string) => updateSetting('payment', 'upi_id', v)} placeholder="yourname@paytm" />
            <div className="grid grid-cols-2 gap-4">
              <InputField label="Merchant Name" value={settings.payment.upi_merchant_name} onChange={(v: string) => updateSetting('payment', 'upi_merchant_name', v)} />
              <InputField label="Merchant Code" value={settings.payment.upi_merchant_code} onChange={(v: string) => updateSetting('payment', 'upi_merchant_code', v)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <NumberField label="Min Amount (₹)" value={settings.payment.upi_min_amount} onChange={(v: number) => updateSetting('payment', 'upi_min_amount', v)} min={1} />
              <NumberField label="Payment Timeout (sec)" value={settings.payment.payment_timeout} onChange={(v: number) => updateSetting('payment', 'payment_timeout', v)} min={60} max={3600} />
            </div>
            <NumberField label="Invoice Due Days" value={settings.payment.invoice_due_days} onChange={(v: number) => updateSetting('payment', 'invoice_due_days', v)} min={1} max={90} />
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.payment.auto_verify_upi} onChange={() => toggleSwitch('payment', 'auto_verify_upi')} />
              <span className="text-sm text-[#e2e8f0]">Auto-verify UPI Payments</span>
            </label>
            <SaveButton section="payment" />
          </div>
        </div>
      )}

      {/* Email Tab */}
      {activeTab === 'email' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Mail size={18} className="text-[#6366f1]" /> Email Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.email.email_enabled} onChange={() => toggleSwitch('email', 'email_enabled')} />
              <span className="text-sm text-[#e2e8f0]">Enable Email Sending</span>
            </label>
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2">
                <InputField label="SMTP Host" value={settings.email.smtp_host} onChange={(v: string) => updateSetting('email', 'smtp_host', v)} />
              </div>
              <NumberField label="SMTP Port" value={settings.email.smtp_port} onChange={(v: number) => updateSetting('email', 'smtp_port', v)} min={1} max={65535} />
            </div>
            <SelectField
              label="SMTP Encryption"
              value={settings.email.smtp_encryption}
              onChange={(v: string) => updateSetting('email', 'smtp_encryption', v)}
              options={[
                { value: 'tls', label: 'TLS' },
                { value: 'ssl', label: 'SSL' },
                { value: 'none', label: 'None' },
              ]}
            />
            <InputField label="SMTP User" value={settings.email.smtp_user} onChange={(v: string) => updateSetting('email', 'smtp_user', v)} />
            <PasswordField
              label="SMTP Password"
              value={settings.email.smtp_password}
              onChange={(v: string) => updateSetting('email', 'smtp_password', v)}
              show={showSmtpPass}
              onToggleShow={() => setShowSmtpPass(!showSmtpPass)}
            />
            <div className="grid grid-cols-2 gap-4">
              <InputField label="From Email" value={settings.email.from_email} onChange={(v: string) => updateSetting('email', 'from_email', v)} />
              <InputField label="From Name" value={settings.email.from_name} onChange={(v: string) => updateSetting('email', 'from_name', v)} />
            </div>
            <SaveButton section="email" />
          </div>
        </div>
      )}

      {/* Pterodactyl Tab */}
      {activeTab === 'pterodactyl' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Server size={18} className="text-[#6366f1]" /> Pterodactyl Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <InputField label="Panel URL" value={settings.pterodactyl.pterodactyl_url} onChange={(v: string) => updateSetting('pterodactyl', 'pterodactyl_url', v)} placeholder="https://panel.example.com" />
            <PasswordField
              label="API Key"
              value={settings.pterodactyl.pterodactyl_api_key}
              onChange={(v: string) => updateSetting('pterodactyl', 'pterodactyl_api_key', v)}
              show={showPteroKey}
              onToggleShow={() => setShowPteroKey(!showPteroKey)}
              placeholder="ptlc_..."
            />
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.pterodactyl.auto_provision} onChange={() => toggleSwitch('pterodactyl', 'auto_provision')} />
              <span className="text-sm text-[#e2e8f0]">Auto-provision Servers</span>
            </label>
            <div className="grid grid-cols-3 gap-4">
              <NumberField label="Default Node ID" value={settings.pterodactyl.default_node_id} onChange={(v: number) => updateSetting('pterodactyl', 'default_node_id', v)} min={1} />
              <NumberField label="Default Egg ID" value={settings.pterodactyl.default_egg_id} onChange={(v: number) => updateSetting('pterodactyl', 'default_egg_id', v)} min={1} />
              <NumberField label="Default Nest ID" value={settings.pterodactyl.default_nest_id} onChange={(v: number) => updateSetting('pterodactyl', 'default_nest_id', v)} min={1} />
            </div>
            <SaveButton section="pterodactyl" />
          </div>
        </div>
      )}

      {/* Notifications Tab */}
      {activeTab === 'notifications' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Bell size={18} className="text-[#6366f1]" /> Notification Settings
          </h3>
          <div className="space-y-5 max-w-2xl">
            <p className="text-sm text-[#64748b]">Choose which events trigger admin notifications.</p>
            {[
              { key: 'new_order_notify', label: 'New Order Received', desc: 'Get notified when a client places a new order' },
              { key: 'payment_notify', label: 'Payment Confirmation', desc: 'Get notified when a payment is received or fails' },
              { key: 'ticket_notify', label: 'New Support Ticket', desc: 'Get notified when a client opens a support ticket' },
              { key: 'registration_notify', label: 'New Registration', desc: 'Get notified when a new user registers' },
              { key: 'server_notify', label: 'Server Status Change', desc: 'Get notified when a server status changes' },
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between p-3 bg-[#0c0c14] rounded-lg border border-[#1a1a2e]">
                <div>
                  <p className="text-sm font-medium text-[#e2e8f0]">{item.label}</p>
                  <p className="text-xs text-[#64748b] mt-0.5">{item.desc}</p>
                </div>
                <Toggle checked={!!settings.notifications[item.key]} onChange={() => toggleSwitch('notifications', item.key)} />
              </div>
            ))}
            <label className="flex items-center gap-3 cursor-pointer pt-2">
              <Toggle checked={!!settings.notifications.email_notify_enabled} onChange={() => toggleSwitch('notifications', 'email_notify_enabled')} />
              <span className="text-sm text-[#e2e8f0]">Send email notifications (requires SMTP configured)</span>
            </label>
            <SaveButton section="notifications" />
          </div>
        </div>
      )}

      {/* Security Tab */}
      {activeTab === 'security' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Shield size={18} className="text-[#6366f1]" /> Security Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.security.force_https} onChange={() => toggleSwitch('security', 'force_https')} />
              <span className="text-sm text-[#e2e8f0]">Force HTTPS</span>
            </label>
            <NumberField label="Session Timeout (seconds)" value={settings.security.session_timeout} onChange={(v: number) => updateSetting('security', 'session_timeout', v)} min={300} max={86400} />
            <NumberField label="Max Login Attempts" value={settings.security.max_login_attempts} onChange={(v: number) => updateSetting('security', 'max_login_attempts', v)} min={1} max={20} />
            <NumberField label="Min Password Length" value={settings.security.password_min_length} onChange={(v: number) => updateSetting('security', 'password_min_length', v)} min={6} max={32} />
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.security.two_factor_enabled} onChange={() => toggleSwitch('security', 'two_factor_enabled')} />
              <span className="text-sm text-[#e2e8f0]">Require Two-Factor Authentication</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.security.admin_ip_restrict} onChange={() => toggleSwitch('security', 'admin_ip_restrict')} />
              <span className="text-sm text-[#e2e8f0]">Restrict Admin Panel by IP</span>
            </label>
            <InputField label="IP Whitelist (comma-separated)" value={settings.security.ip_whitelist} onChange={(v: string) => updateSetting('security', 'ip_whitelist', v)} placeholder="192.168.1.1, 10.0.0.1" />
            <SaveButton section="security" />
          </div>
        </div>
      )}

      {/* API Tab */}
      {activeTab === 'api' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Key size={18} className="text-[#6366f1]" /> API & Webhooks
          </h3>
          <div className="space-y-4 max-w-2xl">
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!settings.api.api_enabled} onChange={() => toggleSwitch('api', 'api_enabled')} />
              <span className="text-sm text-[#e2e8f0]">Enable External API</span>
            </label>
            <PasswordField
              label="API Key"
              value={settings.api.api_key}
              onChange={(v: string) => updateSetting('api', 'api_key', v)}
              show={showApiKey}
              onToggleShow={() => setShowApiKey(!showApiKey)}
              placeholder="Auto-generated or custom"
            />
            <NumberField label="Rate Limit (req/min)" value={settings.api.api_rate_limit} onChange={(v: number) => updateSetting('api', 'api_rate_limit', v)} min={1} max={10000} />
            <InputField label="Webhook URL" value={settings.api.webhook_url} onChange={(v: string) => updateSetting('api', 'webhook_url', v)} placeholder="https://your-app.com/webhook" />
            <PasswordField
              label="Webhook Secret"
              value={settings.api.webhook_secret}
              onChange={(v: string) => updateSetting('api', 'webhook_secret', v)}
              show={showWebhookSecret}
              onToggleShow={() => setShowWebhookSecret(!showWebhookSecret)}
              placeholder="Secret for webhook signature"
            />
            <SaveButton section="api" />
          </div>
        </div>
      )}
    </div>
  );
}
