'use client';

import { useState, useEffect, useMemo } from 'react';
import {
  Tag, Plus, Edit3, Trash2, Search, X, Zap, Server, HardDrive, Globe,
  Cloud, Shield, Gamepad2, Database, Cpu, Star, Package, ArrowUpDown,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { ConfirmModal } from '@/components/ui/modal';

const ICON_OPTIONS = [
  { name: 'Zap', label: 'Minecraft', icon: Zap },
  { name: 'Server', label: 'VPS', icon: Server },
  { name: 'HardDrive', label: 'Dedicated', icon: HardDrive },
  ];

const EXTRA_ICONS = [
  { name: 'Globe', label: 'Domain', icon: Globe },
  { name: 'Cloud', label: 'Other', icon: Cloud },
  { name: 'Shield', label: 'Security', icon: Shield },
  { name: 'Gamepad2', label: 'Gaming', icon: Gamepad2 },
  { name: 'Database', label: 'Database', icon: Database },
  { name: 'Cpu', label: 'CPU Services', icon: Cpu },
  { name: 'Star', label: 'Featured', icon: Star },
];

const ALL_ICONS = [...ICON_OPTIONS, ...EXTRA_ICONS];

interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  sortOrder: number;
  productCount: number;
}

const iconMap: Record<string, any> = {};
ALL_ICONS.forEach(i => { iconMap[i.name] = i; });

export default function AdminCategories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Category | null>(null);
  const [sortField, setSortField] = useState<'name' | 'sortOrder' | 'productCount'>('sortOrder');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  // Add form
  const [addName, setAddName] = useState('');
  const [addIcon, setAddIcon] = useState('Zap');
  const [addSortOrder, setAddSortOrder] = useState(0);
  const [showIconPicker, setShowIconPicker] = useState(false);

  // Edit form
  const [editId, setEditId] = useState('');
  const [editName, setEditName] = useState('');
  [editIcon, setEditIcon] = useState('Zap');
  const [editSortOrder, setEditSortOrder] = useState(0);
  const [editShowIconPicker, setEditShowIconPicker] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        // Fetch categories from settings
        const settingsRes = await fetch('/api/admin/settings', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const settingsData = settingsRes.ok ? await settingsRes.json() : {};
        const cats = (settingsData.settings || []).filter(
          (s: any) => s.group === 'categories'
        );
        setCategories(cats.map((s: any) => ({
          id: s.id,
          name: s.key,
          slug: s.key.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
          icon: s.value?.icon || 'Tag',
          sortOrder: parseInt(s.value?.sortOrder || '0'),
          productCount: 0,
        }));

        // Fetch products for count
        const prodRes = await fetch('/api/admin/products', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (prodRes.ok) {
          const prodData = await prodRes.json();
          const prods = prodData.products || [];
          setProducts(prods);

          // Update product counts
          setCategories(prev => prev.map(cat => ({
            ...cat,
            productCount: prods.filter((p: any) => p.category === cat.name).length,
          }));
        }
      } catch {
        // no data
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const generateSlug = (name: string) =>
    name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');

  const handleSaveCategory = async () => {
    if (!addName.trim()) { toast.error('Category name is required'); return; }
    if (categories.some(c => c.name.toLowerCase() === addName.toLowerCase())) {
      toast.error('A category with this name already exists');
 return;
    }
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ key: addName.trim(), value: JSON.stringify({ icon: addIcon, sortOrder: addSortOrder }), group: 'categories' }),
      });
      if (res.ok) {
        const data = await res.json();
        setCategories(prev => [...prev, {
          id: data.setting?.id || `cat-${Date.now()}`,
          name: addName.trim(),
          slug: generateSlug(addName),
          icon: addIcon,
          sortOrder: addSortOrder,
          productCount: 0,
        }]);
        toast.success('Category created');
        resetAddForm();
 }
    } catch { toast.error('Failed to create category'); }
  };

  const handleUpdateCategory = async () => {
    if (!editName.trim()) { toast.error('Category name is required'); return; }
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/admin/settings/${editId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ key: editName.trim(), value: JSON.stringify({ icon: editIcon, sortOrder: editSortOrder }), group: 'categories' }),
      });
      if (res.ok) {
        setCategories(prev => prev.map(c => c.id === editId ? { ...c, name: editName.trim(), icon: editIcon, sortOrder: editSortOrder } : c));
        toast.success('Category updated');
        setShowEditModal(false);
 }
    } catch { toast.error('Failed to update category'); }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    if (deleteTarget.productCount > 0) {
      toast.error(`Cannot delete "${deleteTarget.name}" — ${deleteTarget.productCount} product(s) are using this category. Reassign or delete them first.`);
      setDeleteTarget(null);
      return;
    }
    try {
      const token = localStorage.getItem('velora_token');
      await fetch(`/api/admin/settings/${deleteTarget.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
 });
      setCategories(prev => prev.filter(c => c.id !== deleteTarget.id));
      toast.success('Category deleted');
      setDeleteTarget(null);
    } catch { toast.error('Failed to delete category'); }
  };

  const resetAddForm = () => {
    setAddName('');
    setAddIcon('Zap');
    setAddSortOrder(0);
    setShowAddModal(false);
  };

  const openEdit = (cat: Category) => {
    setEditId(cat.id);
    setEditName(cat.name);
    setEditIcon(cat.icon);
    setEditSortOrder(cat.sortOrder);
    setShowEditModal(true);
  };

  const sorted = useMemo(() => {
    return [...categories].sort((a, b) => {
    if (sortField === 'name') return sortDir === 'asc' ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name);
    if (sortField === 'sortOrder') return sortDir === 'asc' ? a.sortOrder - b.sortOrder : b.sortOrder - a.sortOrder;
    return sortDir === 'asc' ? a.productCount - b.productCount : b.productCount - a.productCount;
  });
  }, [categories, sortField, sortDir]);

  const filtered = sorted.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.slug.includes(search.toLowerCase())
  );

  const IconPicker = ({ value, onChange, onClose }: { value: string; onChange: (icon: string) => void; onClose: () => void }) => (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4" onClick={onClose}>
      <div className="velora-card p-6 w-full max-w-sm animate-slide-up" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#e2e8f0]">Choose Icon</h3>
          <button onClick={onClose} className="p-1 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors">
            <X size={18} />
          </button>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {ALL_ICONS.map(ic => {
            const Icon = ic.icon;
            const isSelected = value === ic.name;
            return (
              <button
                key={ic.name}
                onClick={() => { onChange(ic.name); onClose(); }}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl text-xs font-medium transition-all border ${
                  isSelected
                    ? 'bg-[#6366f1]/10 border-[#6366f1]/40 text-[#6366f1]'
                    : 'bg-[#0c0c0f] border-[#1a1a2e] text-[#64748b] hover:border-[#6366f1]/20 hover:text-[#e2e8f0]'
                }`}
              >
                <Icon size={18} />
                <span className="truncate w-full text-center">{ic.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );

  const renderIcon = (iconName: string, size = 16) => {
    const Ic = iconMap[iconName];
    if (!Ic) return <Tag size={size} className="text-[#64748b]" />;
    return <Ic size={size} className="text-[#6366f1]" />;
  };

  const SortHeader = ({ field, label }: { field: 'name' | 'sortOrder' | 'productCount'; label: string }) => {
    const isActive = sortField === field;
    return (
      <th
        className="cursor-pointer select-none"
        onClick={() => {
          if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
          else { setSortField(field); setSortDir('asc'); }
        }
      >
        <div className="flex items-center gap-1">
          <span>{label}</span>
          {isActive && <ArrowUpDown size={12} className="text-[#6366f1]" />}
        </div>
      </th>
    );
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse">
          <div className="h-64 bg-[#1a1a2e] rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Categories</h1>
          <p className="text-[#64748b] mt-1">Organize your products into categories</p>
        </div>
        <button onClick={() => setShowAddModal(true)} className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Add Category
        </button>
      </div>

      {/* Search */
      <div className="relative max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
        <input
          type="text"
          placeholder="Search categories..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="velora-input pl-10 w-full"
        />
      </div>

      {/* Table */
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <SortHeader field="name" label="Category" />
                <th>Slug</th>
                <th>Icon</th>
                <SortHeader field="productCount" label="Products" />
                <SortHeader field="sortOrder" label="Sort Order" />
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7}>
                    <div className="velora-card p-12 text-center">
                      <Tag className="h-12 w-12 text-[#6366f1]/30 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2">No categories yet</h3>
                      <p className="text-sm text-[#64748b] mb-4">
                        {search
                          ? 'No categories match your search.'
                          : 'No categories have been created yet. Add your first category to organize products.'}
                      </p>
                      <button onClick={() => setShowAddModal(true)} className="velora-btn-primary">Add Category</button>
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map((cat) => (
                  <tr key={cat.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-[#6366f1]/10 flex items-center justify-center shrink-0">
                          {renderIcon(cat.icon)}
                        </div>
                        <span className="text-sm font-medium text-[#e2e8f0]">{cat.name}</span>
                      </div>
                    </td>
                    <td className="text-sm text-[#64748b] font-mono">{cat.slug}</td>
                    <td>
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20">
                        {renderIcon(cat.icon, 12)}
                        <span>{ALL_ICONS.find(i => i.name === cat.icon)?.label || cat.icon}</span>
                      </span>
                    </td>
                    <td>
                      <span className={`inline-flex items-center justify-center w-8 h-8 rounded-lg text-xs font-bold ${
                        cat.productCount > 0 ? 'bg-[#6366f1]/10 text-[#6366f1]' : 'text-[#475569]'
                      }>
                        {cat.productCount}
                      </span>
                    </td>
                    <td className="text-sm text-[#64748b]">{cat.sortOrder}</td>
                    <td>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => openEdit(cat)}
                          className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#6366f1]/10 transition-colors"
                          title="Edit"
                        >
                          <Edit3 size={14} />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(cat)}
                          className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors"
                          title="Delete"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Summary */
      <div className="flex items-center justify-between text-sm text-[#64748b]">
        <span>{categories.length} categor{categories.length !== 1 ? 'ies' : 'y'}</span>
        {categories.length > 0 && (
          <span>•</span>
        )}
        {categories.length > 0 && (
          <span>{products.length} total product{products.length !== 1 ? 's' : ''}</span>
        )}
      </div>

      {/* Add Category Modal */
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="velora-card p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-[#e2e8f0]">Add Category</h3>
              <button onClick={resetAddForm} className="p-1 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors">
                <X size={18} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Name *</label>
                <input
                  type="text"
                  value={addName}
                  onChange={(e) => setAddName(e.target.value)}
                  placeholder="e.g., Minecraft"
                  className="velora-input w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Icon</label>
                <button
                  type="button"
                  onClick={() => setShowIconPicker(true)}
                  className="velora-input w-full flex items-center justify-center gap-2 cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-lg bg-[#6366f1]/10 flex items-center justify-center">
                    {renderIcon(addIcon, 14)}
                  </div>
                  <span className="text-[#e2e8f0] text-sm">{ALL_ICONS.find(i => i.name === addIcon)?.label || 'Choose icon'}</span>
                </button>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Sort Order</label>
                <input
                  type="number"
                  value={addSortOrder}
                  onChange={(e) => setAddSortOrder(parseInt(e.target.value) || 0)}
                  className="velora-input w-full"
                  placeholder="0"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={resetAddForm} className="velora-btn-secondary flex-1">Cancel</button>
                <button onClick={handleSaveCategory} className="velora-btn-primary flex-1">Create</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Category Modal */
      {showEditModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="velora-card p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-[#e2e8f0]">Edit Category</h3>
              <button onClick={() => setShowEditModal(false)} className="p-1 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors">
                <X size={18} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Name *</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="velora-input w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Icon</label>
                <button
                  type="button"
                  onClick={() => setEditShowIconPicker(true)}
                  className="velora-input w-full flex items-center justify-center gap-2 cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-lg bg-[#6366f1]/10 flex items-center justify-center">
                    {renderIcon(editIcon, 14)}
                  </div>
                  <span className="text-[#e2e8f0] text-sm">{ALL_ICONS.find(i => i.name === editIcon)?.label || 'Choose icon'}</span>
                </button>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Sort Order</label>
                <input
                  type="number"
                  value={editSortOrder}
                  onChange={(e) => setEditSortOrder(parseInt(e.target.value) || 0)}
                  className="velora-input w-full"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowEditModal(false)} className="velora-btn-secondary flex-1">Cancel</button>
                <button onClick={handleUpdateCategory} className="velora-btn-primary flex-1">Save Changes</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Icon Picker */
      {(showIconPicker || editShowIconPicker) && (
        <IconPicker
          value={showIconPicker ? addIcon : editIcon}
          onChange={showIconPicker ? (ic) => { setAddIcon(ic); setShowIconPicker(false); } : (ic) => { setEditIcon(ic); setEditShowIconPicker(false); }}
          onClose={() => { setShowIconPicker(false); setEditShowIconPicker(false); }}
        />
      )}

      {/* Delete Confirm */
      <ConfirmModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Category"
        message={
        deleteTarget?.productCount > 0
          ? `"${deleteTarget.name}" has ${deleteTarget.productCount} product(s) assigned. Please reassign or delete them first.`
          : `Are you sure you want to delete "${deleteTarget?.name}"? This cannot be undone.`
      }
        confirmText="Delete"
        type="danger"
      />
    </div>
  );
}
