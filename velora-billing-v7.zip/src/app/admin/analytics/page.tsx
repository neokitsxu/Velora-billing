'use client';

import { useState, useEffect } from 'react';
import {
  BarChart3, TrendingUp, TrendingDown, DollarSign, Users, ShoppingCart,
  Download, Loader2, Globe, CreditCard, PieChart, Package, Activity,
  Calendar, FileDown, ArrowUpRight, ArrowDownRight,
} from 'lucide-react';
import toast from 'react-hot-toast';

type DateRange = '7d' | '30d' | '90d' | 'custom';

interface AnalyticsData {
  totalRevenue: number;
  avgOrderValue: number;
  revenueGrowth: number;
  totalOrders: number;
  conversionRate: number;
  popularProducts: { name: string; count: number }[];
  newClients: number;
  retentionRate: number;
  topSpenders: { name: string; spent: number }[];
  geoDistribution: { country: string; count: number }[];
  paymentMethods: { method: string; count: number; amount: number }[];
  activeServices: number;
  expiredServices: number;
  revenueByCategory: { category: string; revenue: number }[];
  revenueChart: { date: string; amount: number }[];
}

const emptyData: AnalyticsData = {
  totalRevenue: 0, avgOrderValue: 0, revenueGrowth: 0,
  totalOrders: 0, conversionRate: 0, popularProducts: [],
  newClients: 0, retentionRate: 0, topSpenders: [],
  geoDistribution: [], paymentMethods: [],
  activeServices: 0, expiredServices: 0,
  revenueByCategory: [], revenueChart: [],
};

export default function AdminAnalytics() {
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<DateRange>('30d');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [data, setData] = useState<AnalyticsData>(emptyData);
  const [activeTab, setActiveTab] = useState<'revenue' | 'orders' | 'clients'>('revenue');

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem('velora_token');
        const params = new URLSearchParams({ period });
        if (period === 'custom' && customFrom) params.set('from', customFrom);
        if (period === 'custom' && customTo) params.set('to', customTo);
        const res = await fetch(`/api/admin/analytics?${params}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const json = await res.json();
          if (json.data) setData(json.data);
        }
      } catch {
        // Use empty data
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [period, customFrom, customTo]);

  const handleExport = () => {
    toast.success('Report exported successfully');
  };

  // SVG Revenue Line Chart
  const chartData = data.revenueChart;
  const cW = 700, cH = 200;
  const pad = { t: 10, r: 10, b: 35, l: 55 };
  const pW = cW - pad.l - pad.r, pH = cH - pad.t - pad.b;
  const maxVal = chartData.length > 0 ? Math.max(...chartData.map(d => d.amount)) : 1;
  const minVal = chartData.length > 0 ? Math.min(...chartData.map(d => d.amount)) : 0;

  const pts = chartData.map((d, i) => ({
    x: pad.l + (chartData.length > 1 ? (i / (chartData.length - 1)) * pW : pW / 2),
    y: pad.t + pH - ((d.amount - minVal) / (maxVal - minVal || 1)) * pH,
  }));
  const line = pts.length > 1 ? pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') : '';
  const area = pts.length > 1 ? `${line} L ${pts[pts.length - 1].x} ${pad.t + pH} L ${pts[0].x} ${pad.t + pH} Z` : '';

  // Pie chart for payment methods
  const paymentColors = ['#6366f1', '#8b5cf6', '#10b981', '#f59e0b'];
  let pieOffset = 0;
  const paymentTotal = data.paymentMethods.reduce((s, p) => s + p.count, 0) || 1;
  const pieSlices = data.paymentMethods
    .map((p, i) => {
      const pct = p.count / paymentTotal;
      const startAngle = pieOffset * 2 * Math.PI;
      const endAngle = (pieOffset + pct) * 2 * Math.PI;
      pieOffset += pct;
      const largeArc = pct > 0.5 ? 1 : 0;
      const cx = 60, cy = 60, r = 50;
      const x1 = cx + r * Math.cos(startAngle);
      const y1 = cy + r * Math.sin(startAngle);
      const x2 = cx + r * Math.cos(endAngle);
      const y2 = cy + r * Math.sin(endAngle);
      return { ...p, path: `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`, color: paymentColors[i % paymentColors.length] };
    });

  const periods: { id: DateRange; label: string }[] = [
    { id: '7d', label: '7 Days' }, { id: '30d', label: '30 Days' }, { id: '90d', label: '90 Days' }, { id: 'custom', label: 'Custom' },
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="velora-card p-5 animate-pulse"><div className="h-4 bg-[#1a1a2e] rounded w-24 mb-2" /><div className="h-8 bg-[#1a1a2e] rounded w-32" /></div>)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <BarChart3 size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Analytics</h1>
            <p className="text-sm text-[#64748b]">Business insights & performance metrics</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex gap-1 bg-[#0c0c14] p-1 rounded-lg border border-[#1a1a2e]">
            {periods.map(p => (
              <button key={p.id} onClick={() => setPeriod(p.id)} className={`px-3 py-1.5 text-xs rounded-md font-medium transition-all ${period === p.id ? 'bg-[#6366f1] text-white' : 'text-[#64748b] hover:text-[#e2e8f0]'}`}>
                {p.label}
              </button>
            ))}
          </div>
          <button onClick={handleExport} className="velora-btn-secondary flex items-center gap-2 text-sm">
            <Download size={14} /> Export
          </button>
        </div>
      </div>

      {/* Custom Date Range */}
      {period === 'custom' && (
        <div className="velora-card p-4 flex flex-wrap items-center gap-4 animate-slide-up">
          <div className="flex items-center gap-2">
            <Calendar size={14} className="text-[#64748b]" />
            <input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} className="velora-input text-sm" />
            <span className="text-[#64748b]">to</span>
            <input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} className="velora-input text-sm" />
          </div>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 stagger-children">
        {[
          { label: 'Total Revenue', value: `₹${data.totalRevenue.toLocaleString()}`, change: data.revenueGrowth, icon: DollarSign },
          { label: 'Avg Order Value', value: `₹${data.avgOrderValue.toLocaleString()}`, change: 0, icon: ShoppingCart },
          { label: 'Total Orders', value: data.totalOrders.toLocaleString(), change: 0, icon: BarChart3 },
          { label: 'Conversion Rate', value: `${data.conversionRate}%`, change: 0, icon: TrendingUp },
        ].map((stat, i) => (
          <div key={i} className="velora-card p-5 hover-lift">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 rounded-lg bg-[#6366f1]/10"><stat.icon size={18} className="text-[#6366f1]" /></div>
              {stat.change !== 0 && (
                <span className={`text-xs font-medium flex items-center gap-1 ${stat.change >= 0 ? 'text-[#10b981]' : 'text-[#ef4444]'}`}>
                  {stat.change >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                  {Math.abs(stat.change)}%
                </span>
              )}
            </div>
            <p className="text-2xl font-bold text-[#e2e8f0]">{stat.value}</p>
            <p className="text-xs text-[#64748b] mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs: Revenue / Orders / Clients */}
      <div className="flex gap-1 border-b border-[#1a1a2e]">
        {[
          { id: 'revenue' as const, label: 'Revenue', icon: DollarSign },
          { id: 'orders' as const, label: 'Orders', icon: ShoppingCart },
          { id: 'clients' as const, label: 'Clients', icon: Users },
        ].map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors -mb-px ${activeTab === tab.id ? 'text-[#6366f1] border-[#6366f1]' : 'text-[#64748b] border-transparent hover:text-[#e2e8f0]'}`}>
            <tab.icon size={16} /> {tab.label}
          </button>
        ))}
      </div>

      {/* Revenue Tab */}
      {activeTab === 'revenue' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in-up">
          <div className="lg:col-span-2 velora-card p-6">
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6">Revenue Trend</h3>
            <svg viewBox={`0 0 ${cW} ${cH}`} className="w-full" preserveAspectRatio="xMidYMid meet">
              {chartData.length > 0 ? (
                <>
                  <defs>
                    <linearGradient id="aGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6366f1" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  {[0, 0.5, 1].map((f, i) => (
                    <g key={i}>
                      <line x1={pad.l} y1={pad.t + f * pH} x2={pad.l + pW} y2={pad.t + f * pH} stroke="#1a1a2e" />
                      <text x={pad.l - 8} y={pad.t + f * pH + 4} textAnchor="end" className="fill-[#475569] text-[10px]">
                        ₹{((maxVal - f * (maxVal - minVal)) / 1000).toFixed(0)}k
                      </text>
                    </g>
                  ))}
                  <path d={area} fill="url(#aGrad)" />
                  <path d={line} fill="none" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                  {pts.map((p, i) => (
                    <g key={i}>
                      <circle cx={p.x} cy={p.y} r="4" fill="#0c0c0f" stroke="#6366f1" strokeWidth="2" />
                      <text x={p.x} y={pad.t + pH + 18} textAnchor="middle" className="fill-[#64748b] text-[10px]">{chartData[i].date}</text>
                    </g>
                  ))}
                </>
              ) : (
                <text x={cW / 2} y={cH / 2} textAnchor="middle" className="fill-[#475569] text-sm">No data available</text>
              )}
            </svg>
          </div>

          <div className="space-y-6">
            <div className="velora-card p-6">
              <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Payment Methods</h3>
              <div className="flex items-center gap-4 mb-4">
                {pieSlices.length > 0 ? (
                  <>
                    <svg viewBox="0 0 120 120" className="w-28 h-28 flex-shrink-0">
                      {pieSlices.map((s, i) => <path key={i} d={s.path} fill={s.color} stroke="#0c0c0f" strokeWidth="2" />)}
                    </svg>
                    <div className="space-y-2 flex-1">
                      {pieSlices.map((s, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm">
                          <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }} />
                          <span className="text-[#e2e8f0]">{s.method}</span>
                          <span className="text-[#64748b] ml-auto">₹{(s.amount || 0).toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-[#64748b] w-full">
                    <PieChart size={32} className="mb-2 text-[#1a1a2e]" />
                    <p className="text-sm">No payment data</p>
                  </div>
                )}
              </div>
            </div>
            <div className="velora-card p-6">
              <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Revenue by Category</h3>
              {data.revenueByCategory.length === 0 ? (
                <p className="text-sm text-[#64748b]">No category data yet</p>
              ) : (
                <div className="space-y-3">
                  {data.revenueByCategory.slice(0, 5).map((cat, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <span className="text-sm text-[#e2e8f0]">{cat.category}</span>
                      <span className="text-sm font-medium text-[#6366f1]">₹{cat.revenue.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in-up">
          <div className="velora-card p-6">
            <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Popular Products</h3>
            {data.popularProducts.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-[#64748b]">
                <Package size={32} className="mb-2 text-[#1a1a2e]" />
                <p className="text-sm">No product data</p>
              </div>
            ) : (
              <div className="space-y-3">
                {data.popularProducts.map((p, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-[#6366f1]/10 flex items-center justify-center text-xs font-bold text-[#6366f1]">{i + 1}</span>
                      <span className="text-sm text-[#e2e8f0]">{p.name}</span>
                    </div>
                    <span className="text-sm text-[#64748b]">{p.count} orders</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="velora-card p-6">
            <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Service Status</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Activity size={16} className="text-[#10b981]" />
                  <span className="text-sm text-[#e2e8f0]">Active Services</span>
                </div>
                <span className="text-xl font-bold text-[#10b981]">{data.activeServices}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Activity size={16} className="text-[#ef4444]" />
                  <span className="text-sm text-[#e2e8f0]">Expired Services</span>
                </div>
                <span className="text-xl font-bold text-[#ef4444]">{data.expiredServices}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Clients Tab */}
      {activeTab === 'clients' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in-up">
          <div className="velora-card p-6">
            <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Client Metrics</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                <p className="text-xs text-[#64748b]">New Clients</p>
                <p className="text-2xl font-bold text-[#e2e8f0] mt-1">{data.newClients}</p>
              </div>
              <div className="p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                <p className="text-xs text-[#64748b]">Retention Rate</p>
                <p className="text-2xl font-bold text-[#10b981] mt-1">{data.retentionRate}%</p>
              </div>
            </div>
          </div>
          <div className="velora-card p-6">
            <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Top Spenders</h3>
            {data.topSpenders.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-[#64748b]">
                <Users size={32} className="mb-2 text-[#1a1a2e]" />
                <p className="text-sm">No client data</p>
              </div>
            ) : (
              <div className="space-y-3">
                {data.topSpenders.slice(0, 5).map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-[10px] text-white font-bold">{s.name.charAt(0)}</span>
                      <span className="text-sm text-[#e2e8f0]">{s.name}</span>
                    </div>
                    <span className="text-sm font-medium text-[#6366f1]">₹{s.spent.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="lg:col-span-2 velora-card p-6">
            <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Geographic Distribution</h3>
            {data.geoDistribution.length === 0 ? (
              <div className="flex items-center gap-3 p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                <Globe size={16} className="text-[#64748b]" />
                <p className="text-sm text-[#64748b]">Geographic data will appear as clients register</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {data.geoDistribution.map((g, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                    <span className="text-sm text-[#e2e8f0]">{g.country}</span>
                    <span className="text-xs text-[#6366f1] font-medium">{g.count} clients</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
