'use client';

import { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Plus,
  Edit3,
  Ban,
  Trash2,
  X,
  MoreVertical,
  Filter,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Client {
  id: number;
  name: string;
  email: string;
  role: string;
  balance: number;
  totalSpent: number;
  status: string;
  joined: string;
  avatar: string | null;
}

export default function AdminClients() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [editClient, setEditClient] = useState<Client | null>(null);
  const [editForm, setEditForm] = useState({ name: '', email: '', role: 'client', balance: 0, status: 'active' });

  useEffect(() => {
    const fetchClients = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/clients', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.clients) setClients(data.clients);
        }
      } catch {
        // no data
      } finally {
        setLoading(false);
      }
    };
    fetchClients();
  }, []);

  const filteredClients = clients.filter((c) => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusColor = (status: string) => {
    switch (status) {
      case 'active': return 'velora-badge-success';
      case 'suspended': return 'velora-badge-warning';
      case 'banned': return 'velora-badge-danger';
      default: return 'velora-badge';
    }
  };

  const openEdit = (client: Client) => {
    setEditClient(client);
    setEditForm({ name: client.name, email: client.email, role: client.role, balance: client.balance, status: client.status });
  };

  const saveEdit = async () => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/admin/clients/${editClient?.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(editForm),
      });
      if (res.ok) {
        toast.success('Client updated');
      } else {
        toast.error('Failed to update client');
      }
    } catch {
      toast.error('Network error');
    }
    setClients((prev) =>
      prev.map((c) => (c.id === editClient?.id ? { ...c, ...editForm } : c))
    );
    setEditClient(null);
  };

  const suspendClient = (client: Client) => {
    const newStatus = client.status === 'suspended' ? 'active' : 'suspended';
    setClients((prev) => prev.map((c) => (c.id === client.id ? { ...c, status: newStatus } : c)));
    toast.success(`Client ${newStatus === 'suspended' ? 'suspended' : 'reactivated'}`);
  };

  const deleteClient = (client: Client) => {
    if (!confirm(`Delete ${client.name}? This action cannot be undone.`)) return;
    setClients((prev) => prev.filter((c) => c.id !== client.id));
    toast.success('Client deleted');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse">
          <div className="h-64 bg-[#1a1a2e] rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Clients</h1>
          <p className="text-[#64748b] mt-1">Manage all registered clients</p>
        </div>
        <button className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Add Client
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input
            type="text"
            placeholder="Search by name or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="velora-input pl-10 w-full"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-[#64748b]" />
          {['all', 'active', 'suspended', 'banned'].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-2 text-xs rounded-lg font-medium transition-colors capitalize ${
                statusFilter === s
                  ? 'bg-[#6366f1]/10 text-[#6366f1]'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="velora-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="velora-table">
            <thead>
              <tr>
                <th>Client</th>
                <th>Role</th>
                <th>Balance</th>
                <th>Total Spent</th>
                <th>Status</th>
                <th>Joined</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredClients.map((client) => (
                <tr key={client.id}>
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-sm font-medium shrink-0">
                        {client.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-[#e2e8f0]">{client.name}</p>
                        <p className="text-xs text-[#64748b]">{client.email}</p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`velora-badge ${client.role === 'admin' ? 'velora-badge-info' : ''}`}>{client.role}</span>
                  </td>
                  <td className="text-[#e2e8f0]">₹{client.balance.toLocaleString()}</td>
                  <td className="text-[#e2e8f0]">₹{client.totalSpent.toLocaleString()}</td>
                  <td><span className={statusColor(client.status)}>{client.status}</span></td>
                  <td className="text-[#64748b]">{client.joined}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      <button onClick={() => openEdit(client)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#6366f1]/10 transition-colors" title="Edit">
                        <Edit3 size={14} />
                      </button>
                      <button onClick={() => suspendClient(client)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 transition-colors" title="Suspend">
                        <Ban size={14} />
                      </button>
                      <button onClick={() => deleteClient(client)} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors" title="Delete">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredClients.length === 0 && (
          <div className="velora-card p-12 text-center">
            <Users className="h-12 w-12 text-[#6366f1]/30 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2">No clients found</h3>
            <p className="text-sm text-[#64748b]">
              {search || statusFilter !== 'all'
                ? 'No clients match your search or filter criteria.'
                : 'No clients have registered yet.'}
            </p>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editClient && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="velora-card p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-[#e2e8f0]">Edit Client</h3>
              <button onClick={() => setEditClient(null)} className="p-1 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors">
                <X size={18} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Name</label>
                <input type="text" value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="velora-input w-full" />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Email</label>
                <input type="email" value={editForm.email} onChange={(e) => setEditForm({ ...editForm, email: e.target.value })} className="velora-input w-full" />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Role</label>
                <select value={editForm.role} onChange={(e) => setEditForm({ ...editForm, role: e.target.value })} className="velora-input w-full">
                  <option value="client">Client</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Balance (₹)</label>
                <input type="number" value={editForm.balance} onChange={(e) => setEditForm({ ...editForm, balance: Number(e.target.value) })} className="velora-input w-full" />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Status</label>
                <select value={editForm.status} onChange={(e) => setEditForm({ ...editForm, status: e.target.value })} className="velora-input w-full">
                  <option value="active">Active</option>
                  <option value="suspended">Suspended</option>
                  <option value="banned">Banned</option>
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setEditClient(null)} className="velora-btn-secondary flex-1">Cancel</button>
                <button onClick={saveEdit} className="velora-btn-primary flex-1">Save Changes</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
