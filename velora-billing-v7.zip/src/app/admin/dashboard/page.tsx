'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  Users,
  DollarSign,
  Activity,
  Clock,
  HelpCircle,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Package,
  ShoppingCart,
  Plus,
  BarChart3,
  Loader2,
  HeartPulse,
  Server,
  Megaphone,
  FileText,
  Zap,
  AlertTriangle,
  CheckCircle,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { AnimatedCounter } from '@/components/ui/common';

interface Stats {
  totalClients?: number;
  totalRevenue?: number;
  activeServices?: number;
  pendingOrders?: number;
  openTickets?: number;
  monthlyRevenue?: number;
  revenueTrend?: number;
  userTrend?: number;
  systemHealth?: number;
  apiLatency?: number;
  uptime?: number;
  dbStatus?: string;
}

interface Order {
  id: string;
  client: string;
  product: string;
  amount: number;
  status: string;
  date: string;
}

interface TopProduct {
  name: string;
  revenue: number;
  orders: number;
}

interface ActivityItem {
  id: string;
  action: string;
  user: string;
  timestamp: string;
  type: string;
}

const statCards = [
  { label: 'Total Revenue', key: 'totalRevenue', icon: DollarSign, prefix: '₹', suffix: '', trendKey: 'revenueTrend' },
  { label: 'Active Users', key: 'totalClients', icon: Users, prefix: '', suffix: '', trendKey: 'userTrend' },
  { label: 'Pending Orders', key: 'pendingOrders', icon: Clock, prefix: '', suffix: '', trendKey: undefined },
  { label: 'Open Tickets', key: 'openTickets', icon: HelpCircle, prefix: '', suffix: '', trendKey: undefined },
  { label: 'Active Services', key: 'activeServices', icon: Activity, prefix: '', suffix: '', trendKey: undefined },
  { label: 'System Health', key: 'systemHealth', icon: HeartPulse, prefix: '', suffix: '%', trendKey: undefined, isHealth: true },
];

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({});
  const [orders, setOrders] = useState<Order[]>([]);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [activityFeed, setActivityFeed] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchData = useCallback(async () => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/stats', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.stats) setStats(data.stats);
        if (data.recentOrders) setOrders(data.recentOrders);
        if (data.topProducts) setTopProducts(data.topProducts);
      }
    } catch { /* No data */ }

    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/activity', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.activity) setActivityFeed(data.activity.slice(0, 5));
      }
    } catch { /* No data */ }
  }, []);

  useEffect(() => {
    (async () => {
      await fetchData();
      setLoading(false);
    })();
  }, [fetchData]);

  const statusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'velora-badge-success';
      case 'pending': return 'velora-badge-warning';
      case 'provisioning': return 'velora-badge-info';
      case 'active': return 'velora-badge-success';
      case 'refunded': return 'velora-badge-info';
      case 'cancelled': return 'velora-badge-danger';
      default: return 'velora-badge';
    }
  };

  // Revenue chart SVG (7-day line chart with gradient)
  const chartData = [3200, 4100, 3800, 5200, 4800, 6100, 5700];
  const chartLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const maxVal = Math.max(...chartData);
  const minVal = Math.min(...chartData);
  const chartW = 600;
  const chartH = 180;
  const padding = { top: 10, right: 10, bottom: 30, left: 50 };
  const plotW = chartW - padding.left - padding.right;
  const plotH = chartH - padding.top - padding.bottom;

  const points = chartData.map((v, i) => ({
    x: padding.left + (i / (chartData.length - 1)) * plotW,
    y: padding.top + plotH - ((v - minVal) / (maxVal - minVal || 1)) * plotH,
  }));
  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1].x} ${padding.top + plotH} L ${points[0].x} ${padding.top + plotH} Z`;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="velora-card p-6 animate-pulse">
              <div className="h-4 bg-[#1a1a2e] rounded w-24 mb-4" />
              <div className="h-8 bg-[#1a1a2e] rounded w-32" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const hasData = Object.keys(stats).length > 0;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header with Clock */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Dashboard</h1>
          <p className="text-[#64748b] mt-1">Welcome back, Admin. Here is your overview.</p>
        </div>
        <div className="velora-card px-4 py-2 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse" />
          <span className="text-sm font-mono text-[#e2e8f0]">
            {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </span>
          <span className="text-xs text-[#64748b] ml-1">
            {currentTime.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 stagger-children">
        {statCards.map((card) => {
          const Icon = card.icon;
          const value = (stats as any)[card.key] ?? 0;
          const trend = card.trendKey ? (stats as any)[card.trendKey] : undefined;
          return (
            <div key={card.key} className="velora-card p-6 hover-lift hover-glow card-shine">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2.5 rounded-lg bg-[#6366f1]/10">
                  <Icon size={20} className="text-[#6366f1]" />
                </div>
                {trend !== undefined && (
                  <span className={`flex items-center gap-1 text-xs font-medium ${trend >= 0 ? 'text-[#10b981]' : 'text-[#ef4444]'}`}>
                    {trend >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                    {Math.abs(trend)}%
                  </span>
                )}
                {card.isHealth && (
                  <span className={`flex items-center gap-1 text-xs font-medium ${value >= 90 ? 'text-[#10b981]' : value >= 70 ? 'text-[#f59e0b]' : 'text-[#ef4444]'}`}>
                    {value >= 90 ? <CheckCircle size={12} /> : <AlertTriangle size={12} />}
                  </span>
                )}
              </div>
              <p className="text-2xl font-bold text-[#e2e8f0]">
                {card.isHealth ? (
                  <AnimatedCounter value={value} suffix="%" />
                ) : (
                  <>{card.prefix}{value !== undefined ? value.toLocaleString() : '0'}{card.suffix}</>
                )}
              </p>
              <p className="text-sm text-[#64748b] mt-1">{card.label}</p>
              {card.isHealth && (
                <div className="mt-3 h-1.5 rounded-full bg-[#1a1a2e] overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000 animate-progress-fill"
                    style={{
                      width: `${value}%`,
                      background: value >= 90 ? '#10b981' : value >= 70 ? '#f59e0b' : '#ef4444',
                    }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Revenue Chart + System Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 velora-card p-6 animate-fade-in-up">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-[#e2e8f0]">Revenue Overview</h3>
              <p className="text-sm text-[#64748b]">Last 7 days performance</p>
            </div>
            <Link href="/admin/analytics" className="velora-link text-sm">View Analytics</Link>
          </div>
          <div className="w-full overflow-x-auto">
            <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full min-w-[400px]" preserveAspectRatio="xMidYMid meet">
              <defs>
                <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
                </linearGradient>
              </defs>
              {/* Grid lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((frac, idx) => (
                <line
                  key={idx}
                  x1={padding.left}
                  y1={padding.top + frac * plotH}
                  x2={padding.left + plotW}
                  y2={padding.top + frac * plotH}
                  stroke="#1a1a2e"
                  strokeWidth="1"
                />
              ))}
              {/* Y-axis labels */}
              {[0, 0.5, 1].map((frac, idx) => {
                const val = maxVal - frac * (maxVal - minVal);
                return (
                  <text key={idx} x={padding.left - 8} y={padding.top + frac * plotH + 4} textAnchor="end" className="fill-[#475569] text-[10px]">
                    ₹{(val / 1000).toFixed(1)}k
                  </text>
                );
              })}
              {/* Area fill */}
              <path d={areaPath} fill="url(#chartGradient)" />
              {/* Line */}
              <path d={linePath} fill="none" stroke="#6366f1" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              {/* Dots */}
              {points.map((p, i) => (
                <g key={i}>
                  <circle cx={p.x} cy={p.y} r="4" fill="#0c0c0f" stroke="#6366f1" strokeWidth="2" />
                  <text x={p.x} y={padding.top + plotH + 18} textAnchor="middle" className="fill-[#64748b] text-[10px]">
                    {chartLabels[i]}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>

        {/* System Health */}
        <div className="velora-card p-6 animate-fade-in-up">
          <div className="flex items-center gap-2 mb-6">
            <Server size={18} className="text-[#6366f1]" />
            <h3 className="text-lg font-semibold text-[#e2e8f0]">System Health</h3>
          </div>
          <div className="space-y-4">
            {[
              { label: 'Database', status: stats.dbStatus || 'connected', icon: Wifi, ok: true },
              { label: 'API Latency', status: `${stats.apiLatency || 45}ms`, icon: Zap, ok: (stats.apiLatency || 45) < 200 },
              { label: 'Uptime', status: `${stats.uptime || 99.9}%`, icon: Activity, ok: (stats.uptime || 99.9) > 95 },
              { label: 'Storage', status: '2.4 GB / 50 GB', icon: Server, ok: true },
              { label: 'Memory', status: '384 MB / 2 GB', icon: Activity, ok: true },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 rounded-lg bg-[#09090b] border border-[#1a1a2e]">
                <div className="flex items-center gap-3">
                  <item.icon size={16} className={item.ok ? 'text-[#10b981]' : 'text-[#f59e0b]'} />
                  <span className="text-sm text-[#e2e8f0]">{item.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono text-[#64748b]">{item.status}</span>
                  {item.ok ? (
                    <CheckCircle size={14} className="text-[#10b981]" />
                  ) : (
                    <AlertTriangle size={14} className="text-[#f59e0b]" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Orders + Top Products */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders Table */}
        <div className="lg:col-span-2 velora-card p-6 animate-fade-in-up">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-[#e2e8f0]">Recent Orders</h3>
            <Link href="/admin/orders" className="velora-link text-sm">View All</Link>
          </div>
          {orders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-[#64748b]">
              <ShoppingCart size={48} className="mb-3 text-[#1a1a2e]" />
              <p className="text-sm">No orders yet</p>
              <p className="text-xs text-[#475569] mt-1">Orders will appear here when clients make purchases</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="velora-table">
                <thead>
                  <tr>
                    <th>Order #</th>
                    <th>Client</th>
                    <th>Product</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.slice(0, 8).map((order) => (
                    <tr key={order.id}>
                      <td className="font-mono text-sm text-[#6366f1]">{order.id}</td>
                      <td className="text-[#e2e8f0]">{order.client}</td>
                      <td className="text-[#64748b]">{order.product}</td>
                      <td className="text-[#e2e8f0]">₹{order.amount.toLocaleString()}</td>
                      <td><span className={statusColor(order.status)}>{order.status}</span></td>
                      <td className="text-[#64748b]">{order.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Top Products + Activity Feed */}
        <div className="space-y-6">
          {/* Top Products */}
          <div className="velora-card p-6 animate-fade-in-up">
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Top Products</h3>
            {topProducts.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-[#64748b]">
                <Package size={32} className="mb-2 text-[#1a1a2e]" />
                <p className="text-sm">No product data</p>
              </div>
            ) : (
              <div className="space-y-3">
                {topProducts.slice(0, 5).map((prod, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2.5 rounded-lg hover:bg-[#1a1a2e]/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-[#6366f1]/10 flex items-center justify-center text-xs font-bold text-[#6366f1]">{idx + 1}</span>
                      <div>
                        <p className="text-sm text-[#e2e8f0]">{prod.name}</p>
                        <p className="text-xs text-[#64748b]">{prod.orders} orders</p>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-[#e2e8f0]">₹{prod.revenue.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Activity Feed */}
          <div className="velora-card p-6 animate-fade-in-up">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-[#e2e8f0]">Activity Feed</h3>
              <Link href="/admin/activity" className="velora-link text-sm">View All</Link>
            </div>
            {activityFeed.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-[#64748b]">
                <BarChart3 size={32} className="mb-2 text-[#1a1a2e]" />
                <p className="text-sm">No recent activity</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {activityFeed.map((item) => (
                  <div key={item.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-[#1a1a2e]/30 transition-colors">
                    <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                      item.type === 'payment' ? 'bg-[#10b981]' :
                      item.type === 'order' ? 'bg-[#6366f1]' :
                      item.type === 'ticket' ? 'bg-[#f59e0b]' :
                      'bg-[#8b5cf6]'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-[#e2e8f0] truncate">{item.action}</p>
                      <p className="text-xs text-[#64748b]">{item.user} · {item.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="animate-fade-in-up">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 stagger-children">
          <Link
            href="/admin/products/create"
            className="velora-card p-5 flex items-center gap-4 hover:border-[#6366f1]/50 transition-all group hover-lift hover-glow"
          >
            <div className="p-3 rounded-lg bg-[#6366f1]/10 group-hover:bg-[#6366f1]/20 group-hover:scale-110 transition-all">
              <Plus size={20} className="text-[#6366f1]" />
            </div>
            <div>
              <p className="font-medium text-[#e2e8f0]">Add Product</p>
              <p className="text-sm text-[#64748b]">New product or service</p>
            </div>
          </Link>
          <Link
            href="/admin/coupons"
            className="velora-card p-5 flex items-center gap-4 hover:border-[#10b981]/50 transition-all group hover-lift"
          >
            <div className="p-3 rounded-lg bg-[#10b981]/10 group-hover:bg-[#10b981]/20 group-hover:scale-110 transition-all">
              <Megaphone size={20} className="text-[#10b981]" />
            </div>
            <div>
              <p className="font-medium text-[#e2e8f0]">Create Coupon</p>
              <p className="text-sm text-[#64748b]">Discount codes</p>
            </div>
          </Link>
          <Link
            href="/admin/announcements"
            className="velora-card p-5 flex items-center gap-4 hover:border-[#8b5cf6]/50 transition-all group hover-lift"
          >
            <div className="p-3 rounded-lg bg-[#8b5cf6]/10 group-hover:bg-[#8b5cf6]/20 group-hover:scale-110 transition-all">
              <Megaphone size={20} className="text-[#8b5cf6]" />
            </div>
            <div>
              <p className="font-medium text-[#e2e8f0]">Announcement</p>
              <p className="text-sm text-[#64748b]">Broadcast message</p>
            </div>
          </Link>
          <Link
            href="/admin/audit"
            className="velora-card p-5 flex items-center gap-4 hover:border-[#f59e0b]/50 transition-all group hover-lift"
          >
            <div className="p-3 rounded-lg bg-[#f59e0b]/10 group-hover:bg-[#f59e0b]/20 group-hover:scale-110 transition-all">
              <FileText size={20} className="text-[#f59e0b]" />
            </div>
            <div>
              <p className="font-medium text-[#e2e8f0]">View Logs</p>
              <p className="text-sm text-[#64748b]">Audit trail</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
