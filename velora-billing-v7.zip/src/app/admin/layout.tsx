'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  FileText,
  HelpCircle,
  Server,
  CreditCard,
  Settings,
  Palette,
  ScrollText,
  LogOut,
  Menu,
  X,
  ArrowLeft,
  Bell,
  User,
  Megaphone,
  FileCode,
  Tag,
  BarChart3,
  Wallet,
  Shield,
  Globe,
  Activity,
  Key,
  Webhook,
  Search,
  Terminal,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { CommandPalette } from '@/components/ui/command-palette';
import { NotificationCenter } from '@/components/ui/notification-center';
import { ScrollToTop } from '@/hooks/scroll-to-top';

const navItems = [
  { label: 'Dashboard', href: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Clients', href: '/admin/clients', icon: Users },
  { label: 'Products', href: '/admin/products', icon: Package },
  { label: 'Categories', href: '/admin/categories', icon: Tag },
  { label: 'Orders', href: '/admin/orders', icon: ShoppingCart },,
  { label: 'Invoices', href: '/admin/invoices', icon: FileText },
  { label: 'Finance', href: '/admin/finance', icon: Wallet },
  { label: 'Tickets', href: '/admin/tickets', icon: HelpCircle },
  { label: 'Coupons', href: '/admin/coupons', icon: Tag },
  { label: 'Servers', href: '/admin/servers', icon: Server },
  { label: 'Server Nodes', href: '/admin/nodes', icon: Activity },
  { label: 'Locations', href: '/admin/locations', icon: Globe },
  { label: 'Staff', href: '/admin/staff', icon: Shield },
  { label: 'Analytics', href: '/admin/analytics', icon: BarChart3 },
  { label: 'Announcements', href: '/admin/announcements', icon: Megaphone },
  { label: 'Pages', href: '/admin/pages', icon: FileCode },
  { label: 'Payment Settings', href: '/admin/settings#payment', icon: CreditCard },
  { label: 'Settings', href: '/admin/settings', icon: Settings },
  { label: 'Themes', href: '/admin/themes', icon: Palette },
  { label: 'System Logs', href: '/admin/logs', icon: Activity },
  { label: 'Audit Logs', href: '/admin/audit', icon: ScrollText },
  { label: 'Activity Feed', href: '/admin/activity', icon: Activity },
  { label: 'API Keys', href: '/admin/api-keys', icon: Key },
  { label: 'Webhooks', href: '/admin/webhooks', icon: Webhook },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const token = localStorage.getItem('velora_token');
    const userData = localStorage.getItem('velora_user');
    if (!token || !userData) {
      router.push('/auth/login');
      return;
    }
    try {
      const parsed = JSON.parse(userData);
      if (parsed.role !== 'admin') {
        toast.error('Access denied. Admin only.');
        router.push('/auth/login');
        return;
      }
      setUser(parsed);
    } catch {
      router.push('/auth/login');
    }
  }, [router]);

  useEffect(() => {
    setSidebarOpen(false);
  }, [pathname]);

  const handleLogout = () => {
    localStorage.removeItem('velora_token');
    localStorage.removeItem('velora_user');
    toast.success('Logged out');
    router.push('/auth/login');
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#6366f1]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#09090b] grid-bg">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-[#0c0c14] border-r border-[#1a1a2e] z-50 flex flex-col transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0`}
      >
        <div className="p-6 border-b border-[#1a1a2e]">
          <Link href="/admin/dashboard" className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
              <span className="text-white font-bold text-sm">V</span>
            </div>
            <div>
              <h1 className="text-lg font-bold velora-gradient">Velora Admin</h1>
              <p className="text-xs text-[#64748b]">Admin Panel</p>
            </div>
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3">
          <div className="space-y-1">
            {navItems.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
              const Icon = item.icon;
              return (
                <Link
                  key={item.href + item.label}
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-300 hover:translate-x-1 ${
                    isActive
                      ? 'bg-[#6366f1]/10 text-[#6366f1] border-l-2 border-[#6366f1]'
                      : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5'
                  }`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </div>
        </nav>

        <div className="p-3 border-t border-[#1a1a2e] space-y-1">
          <Link
            href="/client/dashboard"
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 hover:translate-x-1 transition-all duration-300"
          >
            <ArrowLeft size={18} />
            <span>Back to Client</span>
          </Link>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-[#ef4444] hover:bg-[#ef4444]/10 hover:translate-x-1 transition-all duration-300"
          >
            <LogOut size={18} />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      <header className="fixed top-0 left-0 md:left-64 right-0 h-16 bg-[#0c0c14]/80 backdrop-blur-xl border-b border-[#1a1a2e] z-30 flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setSidebarOpen(true)}
            className="md:hidden p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors"
          >
            <Menu size={20} />
          </button>
          <h2 className="text-sm font-medium text-[#64748b]">
            {navItems.find((i) => pathname === i.href || pathname.startsWith(i.href + '/'))?.label || 'Admin'}
          </h2>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => {/* CommandPalette is global */}}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1a1a2e] text-[#475569] hover:text-[#64748b] text-xs transition-colors"
          >
            <Search size={12} /> Search... <kbd className="ml-4 px-1.5 py-0.5 rounded bg-[#0c0c14] text-[9px] font-mono">Ctrl+K</kbd>
          </button>
          <NotificationCenter />
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
              <User size={14} className="text-white" />
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-[#e2e8f0]">{user?.name || 'Admin'}</p>
              <p className="text-xs text-[#64748b]">{user?.email || ''}</p>
            </div>
          </div>
        </div>
      </header>

      <main className="md:ml-64 mt-16 p-6 min-h-[calc(100vh-4rem)]">
        <ScrollToTop />
        <div className="animate-fade-in">{children}</div>
      </main>
      <CommandPalette />
    </div>
  );
}
