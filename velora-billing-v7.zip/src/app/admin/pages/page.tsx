'use client';

import { useState, useEffect } from 'react';
import {
  FileText,
  Plus,
  X,
  Pencil,
  Trash2,
  ExternalLink,
  Eye,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Page {
  id: number;
  title: string;
  slug: string;
  content: string;
  status: 'published' | 'draft';
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

const emptyForm = {
  title: '',
  slug: '',
  content: '',
  status: 'published' as Page['status'],
  sortOrder: 0,
};

function slugify(str: string): string {
  return str
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

export default function AdminPages() {
  const [pages, setPages] = useState<Page[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Page | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [slugLocked, setSlugLocked] = useState(false);

  const token = typeof window !== 'undefined' ? localStorage.getItem('velora_token') : null;

  const fetchPages = async () => {
    try {
      const res = await fetch('/api/admin/pages', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.data) setPages(data.data);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPages();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setSlugLocked(false);
    setShowModal(true);
  };

  const openEdit = (p: Page) => {
    setEditing(p);
    setForm({
      title: p.title,
      slug: p.slug,
      content: p.content,
      status: p.status,
      sortOrder: p.sortOrder,
    });
    setSlugLocked(true);
    setShowModal(true);
  };

  const handleTitleChange = (title: string) => {
    setForm({ ...form, title, slug: slugLocked ? form.slug : slugify(title) });
  };

  const handleSave = async () => {
    if (!form.title.trim()) {
      toast.error('Title is required');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/pages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ ...form, id: editing?.id }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(editing ? 'Page updated' : 'Page created');
        setShowModal(false);
        fetchPages();
      } else {
        toast.error(data.error || 'Failed to save');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this page?')) return;
    try {
      const res = await fetch('/api/pages', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('Page deleted');
        fetchPages();
      } else {
        toast.error(data.error || 'Failed to delete');
      }
    } catch {
      toast.error('Network error');
    }
  };

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <FileText size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Custom Pages</h1>
            <p className="text-sm text-[#64748b]">Manage CMS pages and content</p>
          </div>
        </div>
        <button onClick={openCreate} className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Create Page
        </button>
      </div>

      {/* Pages Table */}
      {loading ? (
        <div className="velora-card p-12 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full mx-auto" />
        </div>
      ) : pages.length === 0 ? (
        <div className="velora-card p-12 text-center">
          <FileText size={48} className="text-[#64748b] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Pages</h3>
          <p className="text-[#64748b] text-sm">Create your first custom page for your clients.</p>
        </div>
      ) : (
        <div className="velora-card overflow-hidden">
          <table className="velora-table w-full">
            <thead>
              <tr>
                <th className="text-left">Title</th>
                <th className="text-left">Slug</th>
                <th className="text-left">Status</th>
                <th className="text-left">Sort Order</th>
                <th className="text-left">Updated</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pages.map((p) => (
                <tr key={p.id} className="border-t border-[#1a1a2e]">
                  <td className="text-[#e2e8f0] font-medium">{p.title}</td>
                  <td>
                    <code className="text-xs bg-white/5 px-2 py-1 rounded text-[#64748b]">{p.slug}</code>
                  </td>
                  <td>
                    <span
                      className={
                        p.status === 'published'
                          ? 'velora-badge velora-badge-success'
                          : 'velora-badge velora-badge-warning'
                      }
                    >
                      {p.status === 'published' ? 'Published' : 'Draft'}
                    </span>
                  </td>
                  <td className="text-[#64748b]">{p.sortOrder}</td>
                  <td className="text-[#64748b] text-sm">{formatDate(p.updatedAt)}</td>
                  <td>
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => openEdit(p)}
                        className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors"
                        title="Edit"
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        onClick={() => window.open(`/p/${p.slug}`, '_blank')}
                        className="p-2 rounded-lg text-[#64748b] hover:text-[#818cf8] hover:bg-[#6366f1]/10 transition-colors"
                        title="View"
                      >
                        <ExternalLink size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(p.id)}
                        className="p-2 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors"
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="velora-card w-full max-w-2xl mx-4 p-6 animate-slide-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-[#e2e8f0]">
                {editing ? 'Edit Page' : 'Create Page'}
              </h2>
              <button onClick={() => setShowModal(false)} className="text-[#64748b] hover:text-[#e2e8f0]">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Title</label>
                <input
                  type="text"
                  className="velora-input w-full"
                  placeholder="Page title..."
                  value={form.title}
                  onChange={(e) => handleTitleChange(e.target.value)}
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-sm font-medium text-[#e2e8f0]">Slug</label>
                  {!editing && (
                    <button
                      type="button"
                      onClick={() => setSlugLocked(!slugLocked)}
                      className="text-xs text-[#6366f1] hover:text-[#818cf8] transition-colors"
                    >
                      {slugLocked ? 'Unlock' : 'Lock slug'}
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  className="velora-input w-full font-mono"
                  placeholder="page-slug"
                  value={form.slug}
                  onChange={(e) => setForm({ ...form, slug: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Content</label>
                <textarea
                  className="velora-input w-full min-h-[200px] resize-y"
                  placeholder="Page content (supports plain text)..."
                  value={form.content}
                  onChange={(e) => setForm({ ...form, content: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Status</label>
                  <select
                    className="velora-input w-full"
                    value={form.status}
                    onChange={(e) => setForm({ ...form, status: e.target.value as Page['status'] })}
                  >
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Sort Order</label>
                  <input
                    type="number"
                    className="velora-input w-full"
                    value={form.sortOrder}
                    onChange={(e) => setForm({ ...form, sortOrder: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="velora-btn-secondary">
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving} className="velora-btn-primary">
                {saving ? 'Saving...' : editing ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
