'use client';

import { useState } from 'react';
import {
  FileText, Download, Calendar, DollarSign, Users, ShoppingCart,
  Package, Receipt, Loader2, Clock, CheckCircle, FileDown, BarChart3,
  AlertCircle, TrendingUp,
} from 'lucide-react';
import toast from 'react-hot-toast';

type ReportType = 'revenue' | 'clients' | 'orders' | 'products' | 'tax';

interface ReportConfig {
  type: ReportType;
  from: string;
  to: string;
}

const reportTypes: { id: ReportType; label: string; icon: any; description: string }[] = [
  { id: 'revenue', label: 'Revenue Report', icon: DollarSign, description: 'Total revenue, growth, trends' },
  { id: 'clients', label: 'Client Report', icon: Users, description: 'New clients, retention, spending' },
  { id: 'orders', label: 'Order Report', icon: ShoppingCart, description: 'Orders, status, products sold' },
  { id: 'products', label: 'Product Report', icon: Package, description: 'Product performance, stock' },
  { id: 'tax', label: 'Tax Report', icon: Receipt, description: 'Tax collected, breakdown' },
];

const quickStats = [
  { label: 'Reports Generated', value: 24, icon: FileText },
  { label: 'Last Generated', value: '2h ago', icon: Clock },
  { label: 'Scheduled Reports', value: 0, icon: Calendar },
];

export default function AdminReports() {
  const [config, setConfig] = useState<ReportConfig>({ type: 'revenue', from: new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0], to: new Date().toISOString().split('T')[0] });
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [reportData, setReportData] = useState<any>(null);

  const generateReport = async () => {
    setGenerating(true);
    setGenerated(false);
    setTimeout(() => {
      setReportData({
        totalRevenue: Math.floor(Math.random() * 500000 + 100000),
        totalOrders: Math.floor(Math.random() * 500 + 50),
        totalClients: Math.floor(Math.random() * 200 + 20),
        avgOrderValue: Math.floor(Math.random() * 2000 + 500),
        growthRate: (Math.random() * 30 - 5).toFixed(1),
      });
      setGenerating(false);
      setGenerated(true);
      toast.success('Report generated successfully');
    }, 2000);
  };

  const handleExport = (format: string) => {
    toast.success(`Report exported as ${format.toUpperCase()}`);
  };

  const selectedReport = reportTypes.find(r => r.id === config.type);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
          <BarChart3 size={20} className="text-[#6366f1]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Reports Center</h1>
          <p className="text-sm text-[#64748b]">Generate and export business reports</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 stagger-children">
        {quickStats.map((s, i) => (
          <div key={i} className="velora-card p-5 hover-lift">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-[#6366f1]/10"><s.icon size={18} className="text-[#6366f1]" /></div>
              <div>
                <p className="text-sm text-[#64748b]">{s.label}</p>
                <p className="text-xl font-bold text-[#e2e8f0]">{s.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Report Configuration */}
      <div className="velora-card p-6 animate-fade-in-up">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6">Generate Report</h3>

        {/* Report Type Selector */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
          {reportTypes.map(r => {
            const Icon = r.icon;
            const isSelected = config.type === r.id;
            return (
              <button
                key={r.id}
                onClick={() => setConfig({ ...config, type: r.id })}
                className={`p-4 rounded-xl text-left transition-all border ${
                  isSelected
                    ? 'bg-[#6366f1]/10 border-[#6366f1]/40 velora-glow'
                    : 'bg-[#09090b] border-[#1a1a2e] hover:border-[#6366f1]/20'
                }`}
              >
                <Icon size={20} className={isSelected ? 'text-[#6366f1]' : 'text-[#64748b]'} />
                <p className={`text-sm font-medium mt-2 ${isSelected ? 'text-[#e2e8f0]' : 'text-[#64748b]'}`}>{r.label}</p>
                <p className="text-[10px] text-[#475569] mt-1">{r.description}</p>
              </button>
            );
          })}
        </div>

        {/* Date Range */}
        <div className="flex flex-wrap items-end gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">From</label>
            <input type="date" className="velora-input" value={config.from} onChange={(e) => setConfig({ ...config, from: e.target.value })} />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">To</label>
            <input type="date" className="velora-input" value={config.to} onChange={(e) => setConfig({ ...config, to: e.target.value })} />
          </div>
          <button onClick={generateReport} disabled={generating} className="velora-btn-primary flex items-center gap-2">
            {generating ? <Loader2 size={16} className="animate-spin" /> : <FileText size={16} />}
            {generating ? 'Generating...' : 'Generate Report'}
          </button>
        </div>

        {/* Export Buttons */}
        {generated && (
          <div className="flex gap-2 animate-fade-in">
            <button onClick={() => handleExport('csv')} className="velora-btn-secondary flex items-center gap-2 text-sm">
              <FileDown size={14} /> Export CSV
            </button>
            <button onClick={() => handleExport('json')} className="velora-btn-secondary flex items-center gap-2 text-sm">
              <FileDown size={14} /> Export JSON
            </button>
            <button onClick={() => handleExport('pdf')} className="velora-btn-secondary flex items-center gap-2 text-sm">
              <FileDown size={14} /> Export PDF
            </button>
          </div>
        )}
      </div>

      {/* Report Preview */}
      {generating && (
        <div className="velora-card p-12 text-center animate-fade-in">
          <Loader2 size={32} className="animate-spin text-[#6366f1] mx-auto mb-4" />
          <p className="text-[#e2e8f0] font-medium">Generating {selectedReport?.label}...</p>
          <p className="text-sm text-[#64748b] mt-1">Analyzing data for {config.from} to {config.to}</p>
        </div>
      )}

      {generated && reportData && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-in-up stagger-children">
          <div className="velora-card p-5 hover-lift">
            <div className="flex items-center justify-between mb-2">
              <DollarSign size={16} className="text-[#6366f1]" />
              <TrendingUp size={14} className={parseFloat(reportData.growthRate) >= 0 ? 'text-[#10b981]' : 'text-[#ef4444]'} />
            </div>
            <p className="text-2xl font-bold text-[#e2e8f0]">₹{reportData.totalRevenue.toLocaleString()}</p>
            <p className="text-xs text-[#64748b]">Total Revenue</p>
          </div>
          <div className="velora-card p-5 hover-lift">
            <ShoppingCart size={16} className="text-[#8b5cf6] mb-2" />
            <p className="text-2xl font-bold text-[#e2e8f0]">{reportData.totalOrders}</p>
            <p className="text-xs text-[#64748b]">Total Orders</p>
          </div>
          <div className="velora-card p-5 hover-lift">
            <Users size={16} className="text-[#10b981] mb-2" />
            <p className="text-2xl font-bold text-[#e2e8f0]">{reportData.totalClients}</p>
            <p className="text-xs text-[#64748b]">Total Clients</p>
          </div>
          <div className="velora-card p-5 hover-lift">
            <Package size={16} className="text-[#f59e0b] mb-2" />
            <p className="text-2xl font-bold text-[#e2e8f0]">₹{reportData.avgOrderValue.toLocaleString()}</p>
            <p className="text-xs text-[#64748b]">Avg Order Value</p>
          </div>
        </div>
      )}

      {/* Scheduled Reports */}
      <div className="velora-card p-6 animate-fade-in-up">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-[#e2e8f0] flex items-center gap-2">
            <Calendar size={16} className="text-[#8b5cf6]" /> Scheduled Reports
          </h3>
          <span className="velora-badge velora-badge-warning">Coming Soon</span>
        </div>
        <div className="flex items-center gap-3 p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
          <AlertCircle size={16} className="text-[#64748b]" />
          <p className="text-sm text-[#64748b]">Scheduled reports will be available in a future update. Set up automated daily, weekly, or monthly reports.</p>
        </div>
      </div>
    </div>
  );
}
