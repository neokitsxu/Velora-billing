'use client';

import { useState, useEffect } from 'react';
import {
  Ticket,
  Plus,
  X,
  Pencil,
  Trash2,
  Power,
  RefreshCw,
  Hash,
  Tag,
  TrendingUp,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Coupon {
  id: number;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minOrderAmount: number;
  maxUses: number;
  usedCount: number;
  validFrom: string;
  validUntil: string;
  status: 'active' | 'inactive';
  createdAt: string;
  updatedAt: string;
}

const emptyForm = {
  code: '',
  type: 'percentage' as Coupon['type'],
  value: 0,
  minOrderAmount: 0,
  maxUses: -1,
  validFrom: new Date().toISOString().split('T')[0],
  validUntil: '',
  status: 'active' as Coupon['status'],
};

function generateCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export default function AdminCoupons() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Coupon | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const token = typeof window !== 'undefined' ? localStorage.getItem('velora_token') : null;

  const fetchCoupons = async () => {
    try {
      const res = await fetch('/api/coupons', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.data) setCoupons(data.data);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCoupons();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setForm({ ...emptyForm, validFrom: new Date().toISOString().split('T')[0] });
    setShowModal(true);
  };

  const openEdit = (c: Coupon) => {
    setEditing(c);
    setForm({
      code: c.code,
      type: c.type,
      value: c.value,
      minOrderAmount: c.minOrderAmount,
      maxUses: c.maxUses,
      validFrom: c.validFrom ? c.validFrom.split('T')[0] : '',
      validUntil: c.validUntil ? c.validUntil.split('T')[0] : '',
      status: c.status,
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.code.trim()) {
      toast.error('Coupon code is required');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...form,
          code: form.code.toUpperCase(),
          id: editing?.id,
        }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(editing ? 'Coupon updated' : 'Coupon created');
        setShowModal(false);
        fetchCoupons();
      } else {
        toast.error(data.error || 'Failed to save');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const toggleStatus = async (c: Coupon) => {
    try {
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...c,
          validFrom: c.validFrom ? c.validFrom.split('T')[0] : '',
          validUntil: c.validUntil ? c.validUntil.split('T')[0] : '',
          status: c.status === 'active' ? 'inactive' : 'active',
        }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`Coupon ${c.status === 'active' ? 'deactivated' : 'activated'}`);
        fetchCoupons();
      } else {
        toast.error(data.error || 'Failed to toggle');
      }
    } catch {
      toast.error('Network error');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this coupon?')) return;
    try {
      const res = await fetch('/api/coupons', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('Coupon deleted');
        fetchCoupons();
      } else {
        toast.error(data.error || 'Failed to delete');
      }
    } catch {
      toast.error('Network error');
    }
  };

  const totalCoupons = coupons.length;
  const activeCoupons = coupons.filter((c) => c.status === 'active').length;
  const totalUses = coupons.reduce((sum, c) => sum + c.usedCount, 0);

  const formatDate = (d: string) =>
    d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <Ticket size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Coupons</h1>
            <p className="text-sm text-[#64748b]">Manage discount coupons and promotional codes</p>
          </div>
        </div>
        <button onClick={openCreate} className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Create Coupon
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="velora-card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#6366f1]/10 flex items-center justify-center">
              <Tag size={18} className="text-[#6366f1]" />
            </div>
            <div>
              <p className="text-sm text-[#64748b]">Total Coupons</p>
              <p className="text-2xl font-bold text-[#e2e8f0]">{totalCoupons}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#10b981]/10 flex items-center justify-center">
              <TrendingUp size={18} className="text-[#10b981]" />
            </div>
            <div>
              <p className="text-sm text-[#64748b]">Active Coupons</p>
              <p className="text-2xl font-bold text-[#e2e8f0]">{activeCoupons}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#f59e0b]/10 flex items-center justify-center">
              <Hash size={18} className="text-[#f59e0b]" />
            </div>
            <div>
              <p className="text-sm text-[#64748b]">Total Uses</p>
              <p className="text-2xl font-bold text-[#e2e8f0]">{totalUses}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Coupons Table */}
      {loading ? (
        <div className="velora-card p-12 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full mx-auto" />
        </div>
      ) : coupons.length === 0 ? (
        <div className="velora-card p-12 text-center">
          <Ticket size={48} className="text-[#64748b] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Coupons</h3>
          <p className="text-[#64748b] text-sm">Create your first discount coupon to attract customers.</p>
        </div>
      ) : (
        <div className="velora-card overflow-hidden">
          <table className="velora-table w-full">
            <thead>
              <tr>
                <th className="text-left">Code</th>
                <th className="text-left">Type</th>
                <th className="text-left">Value</th>
                <th className="text-left">Min Amount</th>
                <th className="text-left">Uses</th>
                <th className="text-left">Status</th>
                <th className="text-left">Valid Until</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {coupons.map((c) => (
                <tr key={c.id} className="border-t border-[#1a1a2e]">
                  <td>
                    <code className="text-sm font-mono bg-white/5 px-2 py-1 rounded text-[#e2e8f0]">
                      {c.code.toUpperCase()}
                    </code>
                  </td>
                  <td>
                    <span
                      className={
                        c.type === 'percentage'
                          ? 'velora-badge velora-badge-info'
                          : 'velora-badge velora-badge-warning'
                      }
                    >
                      {c.type === 'percentage' ? '%' : '$'} {c.type}
                    </span>
                  </td>
                  <td className="text-[#e2e8f0]">
                    {c.type === 'percentage' ? `${c.value}%` : `$${c.value.toFixed(2)}`}
                  </td>
                  <td className="text-[#64748b]">
                    {c.minOrderAmount > 0 ? `$${c.minOrderAmount.toFixed(2)}` : '—'}
                  </td>
                  <td className="text-[#64748b]">
                    {c.usedCount} / {c.maxUses === -1 ? '∞' : c.maxUses}
                  </td>
                  <td>
                    <span
                      className={
                        c.status === 'active'
                          ? 'velora-badge velora-badge-success'
                          : 'velora-badge velora-badge-danger'
                      }
                    >
                      {c.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="text-[#64748b] text-sm">{formatDate(c.validUntil)}</td>
                  <td>
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => openEdit(c)}
                        className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors"
                        title="Edit"
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        onClick={() => toggleStatus(c)}
                        className={`p-2 rounded-lg transition-colors ${c.status === 'active' ? 'text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10' : 'text-[#64748b] hover:text-[#10b981] hover:bg-[#10b981]/10'}`}
                        title={c.status === 'active' ? 'Deactivate' : 'Activate'}
                      >
                        <Power size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(c.id)}
                        className="p-2 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors"
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="velora-card w-full max-w-lg mx-4 p-6 animate-slide-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-[#e2e8f0]">
                {editing ? 'Edit Coupon' : 'Create Coupon'}
              </h2>
              <button onClick={() => setShowModal(false)} className="text-[#64748b] hover:text-[#e2e8f0]">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-sm font-medium text-[#e2e8f0]">Code</label>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, code: generateCode() })}
                    className="text-xs text-[#6366f1] hover:text-[#818cf8] transition-colors flex items-center gap-1"
                  >
                    <RefreshCw size={12} /> Auto-generate
                  </button>
                </div>
                <input
                  type="text"
                  className="velora-input w-full font-mono uppercase"
                  placeholder="COUPONCODE"
                  value={form.code}
                  onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Type</label>
                  <select
                    className="velora-input w-full"
                    value={form.type}
                    onChange={(e) => setForm({ ...form, type: e.target.value as Coupon['type'] })}
                  >
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed Amount</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">
                    Value {form.type === 'percentage' ? '(%)' : '($)'}
                  </label>
                  <input
                    type="number"
                    className="velora-input w-full"
                    min="0"
                    step={form.type === 'percentage' ? '1' : '0.01'}
                    value={form.value}
                    onChange={(e) => setForm({ ...form, value: parseFloat(e.target.value) || 0 })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Min Order Amount</label>
                  <input
                    type="number"
                    className="velora-input w-full"
                    min="0"
                    step="0.01"
                    value={form.minOrderAmount}
                    onChange={(e) =>
                      setForm({ ...form, minOrderAmount: parseFloat(e.target.value) || 0 })
                    }
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Max Uses</label>
                  <input
                    type="number"
                    className="velora-input w-full"
                    min="-1"
                    value={form.maxUses}
                    onChange={(e) => setForm({ ...form, maxUses: parseInt(e.target.value) })}
                  />
                  <p className="text-xs text-[#64748b] mt-1">-1 for unlimited</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Valid From</label>
                  <input
                    type="date"
                    className="velora-input w-full"
                    value={form.validFrom}
                    onChange={(e) => setForm({ ...form, validFrom: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Valid Until</label>
                  <input
                    type="date"
                    className="velora-input w-full"
                    value={form.validUntil}
                    onChange={(e) => setForm({ ...form, validUntil: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#e2e8f0] mb-1.5">Status</label>
                <select
                  className="velora-input w-full"
                  value={form.status}
                  onChange={(e) => setForm({ ...form, status: e.target.value as Coupon['status'] })}
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="velora-btn-secondary">
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving} className="velora-btn-primary">
                {saving ? 'Saving...' : editing ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
