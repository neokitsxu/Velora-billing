'use client';

import { useState, useEffect } from 'react';
import {
  Webhook, Plus, Copy, Trash2, Send, Globe, Loader2, X,
  CheckCircle, XCircle, Clock, RefreshCw, Zap, Eye, EyeOff,
  AlertTriangle,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { Modal, ConfirmModal } from '@/components/ui/modal';

interface WebhookEndpoint {
  id: string;
  url: string;
  events: string[];
  secret: string;
  active: boolean;
  lastTriggered: string;
  successCount: number;
  failCount: number;
  createdAt: string;
  deliveryLog: { id: string; status: number; timestamp: string; response: string }[];
}

const availableEvents = [
  'order.created', 'order.paid', 'invoice.created', 'invoice.paid',
  'user.registered', 'ticket.created', 'ticket.replied',
  'service.created', 'service.suspended', 'service.terminated',
];

const eventCategories: { category: string; events: string[] }[] = [
  { category: 'Orders', events: ['order.created', 'order.paid'] },
  { category: 'Invoices', events: ['invoice.created', 'invoice.paid'] },
  { category: 'Users', events: ['user.registered'] },
  { category: 'Tickets', events: ['ticket.created', 'ticket.replied'] },
  { category: 'Services', events: ['service.created', 'service.suspended', 'service.terminated'] },
];

export default function AdminWebhooks() {
  const [webhooks, setWebhooks] = useState<WebhookEndpoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedEvents, setSelectedEvents] = useState<string[]>([]);
  const [url, setUrl] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<WebhookEndpoint | null>(null);
  const [visibleSecrets, setVisibleSecrets] = useState<Set<string>>(new Set());
  const [testing, setTesting] = useState<string | null>(null);
  const [showDelivery, setShowDelivery] = useState<WebhookEndpoint | null>(null);

  useEffect(() => { setLoading(false); }, []);

  const createWebhook = () => {
    if (!url.trim()) { toast.error('Enter a URL'); return; }
    if (selectedEvents.length === 0) { toast.error('Select at least one event'); return; }
    const wh: WebhookEndpoint = {
      id: Date.now().toString(),
      url,
      events: selectedEvents,
      secret: `whsec_${Math.random().toString(36).slice(2, 18)}`,
      active: true,
      lastTriggered: '-',
      successCount: 0,
      failCount: 0,
      createdAt: new Date().toISOString(),
      deliveryLog: [],
    };
    setWebhooks(prev => [...prev, wh]);
    setShowCreate(false);
    setUrl('');
    setSelectedEvents([]);
    toast.success('Webhook created!');
  };

  const deleteWebhook = () => {
    if (!deleteTarget) return;
    setWebhooks(prev => prev.filter(w => w.id !== deleteTarget.id));
    toast.success('Webhook deleted');
    setDeleteTarget(null);
  };

  const toggleEvent = (event: string) => {
    setSelectedEvents(prev => prev.includes(event) ? prev.filter(e => e !== event) : [...prev, event]);
  };

  const testWebhook = (id: string) => {
    setTesting(id);
    setTimeout(() => {
      setWebhooks(prev => prev.map(w => w.id === id ? {
        ...w,
        successCount: w.successCount + 1,
        deliveryLog: [
          { id: Date.now().toString(), status: 200, timestamp: new Date().toISOString(), response: 'OK - Test event delivered' },
          ...w.deliveryLog,
        ],
      } : w));
      setTesting(null);
      toast.success('Test event sent successfully!');
    }, 1500);
  };

  const toggleSecretVisibility = (id: string) => {
    setVisibleSecrets(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const copySecret = (secret: string) => {
    navigator.clipboard.writeText(secret);
    toast.success('Secret copied to clipboard');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#8b5cf6]/10 flex items-center justify-center">
            <Webhook size={20} className="text-[#8b5cf6]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Webhooks</h1>
            <p className="text-sm text-[#64748b]">Configure webhook endpoints for real-time events</p>
          </div>
        </div>
        <button onClick={() => setShowCreate(true)} className="velora-btn-primary flex items-center gap-2 text-sm">
          <Plus size={14} /> Add Webhook
        </button>
      </div>

      {/* Info */}
      <div className="flex items-center gap-3 p-4 rounded-xl bg-[#8b5cf6]/5 border border-[#8b5cf6]/20 animate-fade-in">
        <Globe size={16} className="text-[#8b5cf6] flex-shrink-0" />
        <p className="text-xs text-[#8b5cf6]">Webhooks send HTTP POST requests to your server when events occur. Use them to integrate with Discord, Slack, or custom systems.</p>
      </div>

      {/* Create Modal */}
      <Modal open={showCreate} onClose={() => setShowCreate(false)} title="Add Webhook Endpoint" size="lg">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Endpoint URL</label>
            <input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://your-server.com/webhook" className="velora-input w-full font-mono text-sm" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-[#64748b]">Events</label>
              <span className="text-xs text-[#6366f1]">{selectedEvents.length} selected</span>
            </div>
            <div className="space-y-3 max-h-64 overflow-y-auto p-3 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
              {eventCategories.map(cat => (
                <div key={cat.category}>
                  <p className="text-xs font-semibold text-[#64748b] uppercase mb-1.5">{cat.category}</p>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {cat.events.map(event => (
                      <button key={event} onClick={() => toggleEvent(event)} className={`px-2.5 py-1 rounded-lg text-[10px] font-mono transition-all ${selectedEvents.includes(event) ? 'bg-[#6366f1] text-white' : 'bg-[#1a1a2e] text-[#475569] hover:text-[#e2e8f0]'}`}>
                        {event}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button onClick={() => setShowCreate(false)} className="velora-btn-secondary text-sm">Cancel</button>
            <button onClick={createWebhook} className="velora-btn-primary text-sm flex items-center gap-2"><Send size={14} /> Create Webhook</button>
          </div>
        </div>
      </Modal>

      {/* Webhook List */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : webhooks.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <Webhook size={48} className="mx-auto text-[#64748b] mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Webhooks Configured</h3>
          <p className="text-[#64748b] text-sm mb-6">Add a webhook to receive real-time event notifications</p>
          <button onClick={() => setShowCreate(true)} className="velora-btn-primary">Add Webhook</button>
        </div>
      ) : (
        <div className="space-y-4">
          {webhooks.map((wh, i) => (
            <div key={wh.id} className="velora-card p-6 hover:border-[#6366f1]/20 transition-all" style={{ animation: `fadeInUp 0.3s ease-out ${i * 0.05}s both` }}>
              <div className="flex flex-col gap-4">
                {/* URL + Status */}
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold text-[#e2e8f0] font-mono truncate">{wh.url}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium flex-shrink-0 ${wh.active ? 'velora-badge-success' : 'velora-badge-danger'}`}>
                        {wh.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button onClick={() => testWebhook(wh.id)} disabled={testing === wh.id} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#6366f1] transition-colors" title="Test">
                      {testing === wh.id ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                    </button>
                    <button onClick={() => setShowDelivery(wh)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#e2e8f0] transition-colors" title="Delivery Log">
                      <Eye size={14} />
                    </button>
                    <button onClick={() => copySecret(wh.secret)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#475569] hover:text-[#10b981] transition-colors" title="Copy Secret">
                      <Copy size={14} />
                    </button>
                    <button onClick={() => setDeleteTarget(wh)} className="p-2 rounded-lg hover:bg-[#ef4444]/10 text-[#475569] hover:text-[#ef4444] transition-colors" title="Delete">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Secret */}
                <div className="flex items-center gap-2 text-[11px]">
                  <span className="text-[#475569]">Secret:</span>
                  <code className="font-mono text-[#475569] bg-[#09090b] px-2 py-0.5 rounded flex items-center gap-2">
                    {visibleSecrets.has(wh.id) ? wh.secret : wh.secret.slice(0, 16) + '••••••••'}
                    <button onClick={() => toggleSecretVisibility(wh.id)} className="text-[#475569] hover:text-[#e2e8f0]">
                      {visibleSecrets.has(wh.id) ? <EyeOff size={10} /> : <Eye size={10} />}
                    </button>
                  </code>
                </div>

                {/* Events */}
                <div className="flex flex-wrap gap-1.5">
                  {wh.events.slice(0, 6).map(e => (
                    <span key={e} className="px-2 py-0.5 rounded bg-[#0c0c0f] text-[9px] font-mono text-[#475569] border border-[#1a1a2e]">{e}</span>
                  ))}
                  {wh.events.length > 6 && <span className="text-[10px] text-[#475569]">+{wh.events.length - 6} more</span>}
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 text-[10px] text-[#475569]">
                  <span className="flex items-center gap-1"><CheckCircle size={10} className="text-[#10b981]" />{wh.successCount} success</span>
                  <span className="flex items-center gap-1"><XCircle size={10} className="text-[#ef4444]" />{wh.failCount} failed</span>
                  <span className="flex items-center gap-1"><Clock size={10} />Last: {wh.lastTriggered}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delivery Log Modal */}
      <Modal open={!!showDelivery} onClose={() => setShowDelivery(null)} title={`Delivery Log — ${showDelivery?.url}`} size="lg">
        {showDelivery && showDelivery.deliveryLog.length === 0 ? (
          <div className="flex items-center gap-3 p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
            <Clock size={16} className="text-[#64748b]" />
            <p className="text-sm text-[#64748b]">No delivery attempts recorded yet. Send a test event to generate logs.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {showDelivery?.deliveryLog.map(log => (
              <div key={log.id} className="flex items-center justify-between p-3 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                <div className="flex items-center gap-3">
                  {log.status >= 200 && log.status < 300 ? (
                    <CheckCircle size={14} className="text-[#10b981]" />
                  ) : (
                    <XCircle size={14} className="text-[#ef4444]" />
                  )}
                  <div>
                    <p className="text-sm text-[#e2e8f0]">HTTP {log.status}</p>
                    <p className="text-xs text-[#64748b]">{new Date(log.timestamp).toLocaleString()}</p>
                  </div>
                </div>
                <p className="text-xs text-[#64748b]">{log.response}</p>
              </div>
            ))}
          </div>
        )}
      </Modal>

      {/* Delete Confirm */}
      <ConfirmModal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={deleteWebhook} title="Delete Webhook" message={`Delete webhook for "${deleteTarget?.url}"? Events will no longer be sent to this endpoint.`} confirmText="Delete" type="danger" />
    </div>
  );
}
