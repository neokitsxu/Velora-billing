'use client';

import { useState, useEffect } from 'react';
import {
  Server,
  Plus,
  Edit3,
  Trash2,
  RefreshCw,
  X,
  MapPin,
  Cpu,
  HardDrive,
  MemoryStick,
} from 'lucide-react';
import toast from 'react-hot-toast';

type NodeResource = {
  cpu: number;
  ram: number;
  disk: number;
};

type NodeItem = {
  id: number;
  name: string;
  type: 'pterodactyl' | 'proxmox';
  hostname: string;
  port: number;
  location: string;
  status: 'online' | 'offline' | 'syncing';
  resources: {
    used: NodeResource;
    max: NodeResource;
  };
};



export default function AdminNodes() {
  const [nodes, setNodes] = useState<NodeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [addForm, setAddForm] = useState({
    name: '',
    type: 'pterodactyl' as 'pterodactyl' | 'proxmox',
    hostname: '',
    port: '8080',
    apiKey: '',
    location: '',
    maxCpu: '',
    maxRam: '',
    maxDisk: '',
  });

  useEffect(() => {
    const fetchNodes = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/nodes', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.nodes) setNodes(data.nodes);
        }
      } catch {
        // no data
      } finally {
        setLoading(false);
      }
    };
    fetchNodes();
  }, []);

  const statusDot = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-[#10b981]';
      case 'offline':
        return 'bg-[#ef4444]';
      case 'syncing':
        return 'bg-[#f59e0b] animate-pulse';
      default:
        return 'bg-[#64748b]';
    }
  };

  const typeColor = (type: string) => {
    switch (type) {
      case 'pterodactyl':
        return 'velora-badge-info';
      case 'proxmox':
        return 'velora-badge-warning';
      default:
        return 'velora-badge';
    }
  };

  const ResourceBar = ({ label, used, max, unit, icon: Icon }: { label: string; used: number; max: number; unit: string; icon: any }) => {
    const pct = max > 0 ? Math.min((used / max) * 100, 100) : 0;
    const barColor = pct > 85 ? '#ef4444' : pct > 60 ? '#f59e0b' : '#6366f1';
    return (
      <div>
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="flex items-center gap-1 text-[#64748b]">
            <Icon size={12} /> {label}
          </span>
          <span className="text-[#e2e8f0]">
            {used.toLocaleString()}/{max.toLocaleString()} {unit}
          </span>
        </div>
        <div className="h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: barColor }} />
        </div>
      </div>
    );
  };

  const syncNode = (node: NodeItem) => {
    setNodes((prev) => prev.map((n) => (n.id === node.id ? { ...n, status: 'syncing' as const } : n)));
    toast.success(`Syncing ${node.name}...`);
    setTimeout(() => {
      setNodes((prev) => prev.map((n) => (n.id === node.id ? { ...n, status: 'online' as const } : n)));
      toast.success(`${node.name} synced successfully`);
    }, 2000);
  };

  const deleteNode = (node: NodeItem) => {
    if (!confirm(`Delete node ${node.name}?`)) return;
    setNodes((prev) => prev.filter((n) => n.id !== node.id));
    toast.success('Node deleted');
  };

  const handleAddNode = async () => {
    if (!addForm.name || !addForm.hostname) {
      toast.error('Name and hostname are required');
      return;
    }
    try {
      const token = localStorage.getItem('velora_token');
      await fetch('/api/admin/nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(addForm),
      });
    } catch {
      // demo
    }
    const newNode: NodeItem = {
      id: Date.now(),
      name: addForm.name,
      type: addForm.type,
      hostname: addForm.hostname,
      port: parseInt(addForm.port) || 8080,
      location: addForm.location || 'Unknown',
      status: 'online',
      resources: {
        used: { cpu: 0, ram: 0, disk: 0 },
        max: {
          cpu: parseInt(addForm.maxCpu) || 16,
          ram: parseInt(addForm.maxRam) || 32768,
          disk: parseInt(addForm.maxDisk) || 500,
        },
      },
    };
    setNodes((prev) => [...prev, newNode]);
    toast.success('Node added');
    setShowAddModal(false);
    setAddForm({ name: '', type: 'pterodactyl', hostname: '', port: '8080', apiKey: '', location: '', maxCpu: '', maxRam: '', maxDisk: '' });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="velora-card p-6 animate-pulse h-64" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Server Nodes</h1>
          <p className="text-[#64748b] mt-1">Manage your server infrastructure</p>
        </div>
        <button onClick={() => setShowAddModal(true)} className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Add Node
        </button>
      </div>

      {/* Node Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {nodes.map((node) => (
          <div key={node.id} className="velora-card p-6 animate-slide-up hover:border-[#6366f1]/30 transition-all">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#6366f1]/10 flex items-center justify-center">
                  <Server size={20} className="text-[#6366f1]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-[#e2e8f0]">{node.name}</h3>
                    <span className={typeColor(node.type)}>{node.type}</span>
                  </div>
                  <p className="text-sm text-[#64748b] font-mono">{node.hostname}:{node.port}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${statusDot(node.status)}`} />
                <span className="text-xs text-[#64748b] capitalize">{node.status}</span>
              </div>
            </div>

            <div className="flex items-center gap-1 text-xs text-[#64748b] mb-4">
              <MapPin size={12} /> {node.location}
            </div>

            <div className="space-y-3 mb-5">
              <ResourceBar label="CPU" used={node.resources.used.cpu} max={node.resources.max.cpu} unit="cores" icon={Cpu} />
              <ResourceBar label="RAM" used={node.resources.used.ram} max={node.resources.max.ram} unit="MB" icon={MemoryStick} />
              <ResourceBar label="Disk" used={node.resources.used.disk} max={node.resources.max.disk} unit="GB" icon={HardDrive} />
            </div>

            <div className="flex items-center gap-2 pt-4 border-t border-[#1a1a2e]">
              <button className="p-2 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#6366f1]/10 transition-colors" title="Edit">
                <Edit3 size={14} />
              </button>
              <button onClick={() => syncNode(node)} className="p-2 rounded-lg text-[#64748b] hover:text-[#8b5cf6] hover:bg-[#8b5cf6]/10 transition-colors" title="Sync">
                <RefreshCw size={14} />
              </button>
              <button onClick={() => deleteNode(node)} className="p-2 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors" title="Delete">
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {nodes.length === 0 && (
        <div className="velora-card p-12 text-center">
          <Server className="h-12 w-12 text-[#6366f1]/30 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2">No nodes configured</h3>
          <p className="text-sm text-[#64748b] mb-4">Add your first server node to get started.</p>
          <button onClick={() => setShowAddModal(true)} className="velora-btn-primary">Add Node</button>
        </div>
      )}

      {/* Add Node Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="velora-card p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-[#e2e8f0]">Add Node</h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors">
                <X size={18} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Name *</label>
                <input type="text" value={addForm.name} onChange={(e) => setAddForm({ ...addForm, name: e.target.value })} className="velora-input w-full" placeholder="India-Mumbai-1" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">Type</label>
                  <select value={addForm.type} onChange={(e) => setAddForm({ ...addForm, type: e.target.value as any })} className="velora-input w-full">
                    <option value="pterodactyl">Pterodactyl</option>
                    <option value="proxmox">Proxmox</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">Location</label>
                  <input type="text" value={addForm.location} onChange={(e) => setAddForm({ ...addForm, location: e.target.value })} className="velora-input w-full" placeholder="Mumbai, India" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">Hostname *</label>
                  <input type="text" value={addForm.hostname} onChange={(e) => setAddForm({ ...addForm, hostname: e.target.value })} className="velora-input w-full" placeholder="node1.velora.host" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">Port</label>
                  <input type="number" value={addForm.port} onChange={(e) => setAddForm({ ...addForm, port: e.target.value })} className="velora-input w-full" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">API Key</label>
                <input type="password" value={addForm.apiKey} onChange={(e) => setAddForm({ ...addForm, apiKey: e.target.value })} className="velora-input w-full" placeholder="ptlc_..." />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">Max CPU</label>
                  <input type="number" value={addForm.maxCpu} onChange={(e) => setAddForm({ ...addForm, maxCpu: e.target.value })} className="velora-input w-full" placeholder="16" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">Max RAM (MB)</label>
                  <input type="number" value={addForm.maxRam} onChange={(e) => setAddForm({ ...addForm, maxRam: e.target.value })} className="velora-input w-full" placeholder="32768" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#64748b] mb-1.5">Max Disk (GB)</label>
                  <input type="number" value={addForm.maxDisk} onChange={(e) => setAddForm({ ...addForm, maxDisk: e.target.value })} className="velora-input w-full" placeholder="500" />
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowAddModal(false)} className="velora-btn-secondary flex-1">Cancel</button>
                <button onClick={handleAddNode} className="velora-btn-primary flex-1">Add Node</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
