'use client';

import { useState, useEffect } from 'react';
import {
  Users,
  Shield,
  UserPlus,
  Pencil,
  Trash2,
  Search,
  ShieldCheck,
  Loader2,
  X,
  Power,
  Eye,
  ShieldAlert,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { Modal, ConfirmModal } from '@/components/ui/modal';

interface Staff {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'staff' | 'support';
  permissions: string[];
  status: 'active' | 'inactive';
  lastLogin: string;
}

const allPermissions = [
  'view_orders', 'manage_orders', 'view_clients', 'manage_clients',
  'view_products', 'manage_products', 'view_tickets', 'manage_tickets',
  'view_invoices', 'manage_invoices', 'view_servers', 'manage_servers',
  'view_finance', 'manage_finance', 'view_settings', 'manage_settings',
  'view_logs', 'manage_announcements',
];

const emptyForm = { name: '', email: '', password: '', role: 'staff' as Staff['role'], permissions: ['view_orders', 'view_clients', 'view_tickets'] };

export default function AdminStaff() {
  const [staff, setStaff] = useState<Staff[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showPermissions, setShowPermissions] = useState<Staff | null>(null);
  const [editing, setEditing] = useState<Staff | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<Staff | null>(null);
  const [currentUserEmail, setCurrentUserEmail] = useState('');

  useEffect(() => {
    const userData = localStorage.getItem('velora_user');
    if (userData) {
      try {
        const parsed = JSON.parse(userData);
        setCurrentUserEmail(parsed.email || '');
      } catch { /* */ }
    }
    fetchStaff();
  }, []);

  const fetchStaff = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/staff', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStaff(data.staff || []);
      }
    } catch { /* */ } finally {
      setLoading(false);
    }
  };

  const filtered = staff.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) || s.email.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditing(null);
    setForm({ ...emptyForm });
    setShowModal(true);
  };

  const openEdit = (s: Staff) => {
    setEditing(s);
    setForm({ name: s.name, email: s.email, password: '', role: s.role, permissions: [...s.permissions] });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.email.trim()) { toast.error('Name and email are required'); return; }
    if (!editing && !form.password.trim()) { toast.error('Password is required'); return; }
    setSaving(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/staff', {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ ...form, id: editing?.id }),
      });
      if (res.ok) {
        toast.success(editing ? 'Staff updated' : 'Staff created');
        setShowModal(false);
        fetchStaff();
      } else {
        const err = await res.json();
        toast.error(err.error || 'Failed to save');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    if (deleteTarget.email === currentUserEmail) {
      toast.error('Cannot delete yourself');
      return;
    }
    setStaff(prev => prev.filter(s => s.id !== deleteTarget.id));
    toast.success('Staff member deleted');
    setDeleteTarget(null);
  };

  const toggleStatus = (s: Staff) => {
    if (s.email === currentUserEmail) { toast.error('Cannot deactivate yourself'); return; }
    setStaff(prev => prev.map(m => m.id === s.id ? { ...m, status: m.status === 'active' ? 'inactive' : 'active' } : m));
    toast.success(`Staff ${s.status === 'active' ? 'deactivated' : 'activated'}`);
  };

  const togglePermission = (perm: string) => {
    setForm(prev => ({
      ...prev,
      permissions: prev.permissions.includes(perm) ? prev.permissions.filter(p => p !== perm) : [...prev.permissions, perm],
    }));
  };

  const roleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-[#ef4444]/10 text-[#ef4444] border border-[#ef4444]/20';
      case 'staff': return 'bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20';
      case 'support': return 'bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/20';
      default: return 'bg-[#64748b]/10 text-[#64748b] border border-[#64748b]/20';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <ShieldCheck size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Staff Management</h1>
            <p className="text-sm text-[#64748b]">Manage admin team members & permissions</p>
          </div>
        </div>
        <button onClick={openCreate} className="velora-btn-primary flex items-center gap-2">
          <UserPlus size={16} /> Add Staff
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 stagger-children">
        <div className="velora-card p-5 hover-lift">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-[#6366f1]/10"><ShieldCheck size={18} className="text-[#6366f1]" /></div>
            <div>
              <p className="text-sm text-[#64748b]">Active Staff</p>
              <p className="text-2xl font-bold text-[#e2e8f0]">{staff.filter(s => s.status === 'active').length}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-5 hover-lift">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-[#8b5cf6]/10"><Shield size={18} className="text-[#8b5cf6]" /></div>
            <div>
              <p className="text-sm text-[#64748b]">Total Staff</p>
              <p className="text-2xl font-bold text-[#e2e8f0]">{staff.length}</p>
            </div>
          </div>
        </div>
        <div className="velora-card p-5 hover-lift">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-[#ef4444]/10"><ShieldAlert size={18} className="text-[#ef4444]" /></div>
            <div>
              <p className="text-sm text-[#64748b]">Admins</p>
              <p className="text-2xl font-bold text-[#e2e8f0]">{staff.filter(s => s.role === 'admin').length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
        <input type="text" placeholder="Search staff..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input w-full pl-10" />
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : filtered.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <ShieldCheck size={48} className="mx-auto text-[#64748b] mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Staff Members</h3>
          <p className="text-[#64748b] text-sm mb-6">Add staff members to manage your team</p>
          <button onClick={openCreate} className="velora-btn-primary px-6">
            <UserPlus size={16} className="inline mr-2" />Add Staff Member
          </button>
        </div>
      ) : (
        <div className="velora-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="velora-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Last Login</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((member) => (
                  <tr key={member.id} className="border-t border-[#1a1a2e]/50">
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-xs font-bold">{member.name.charAt(0)}</div>
                        <span className="text-sm text-[#e2e8f0]">{member.name}</span>
                      </div>
                    </td>
                    <td className="text-sm text-[#64748b]">{member.email}</td>
                    <td>
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${roleBadgeColor(member.role)}`}>
                        {member.role.charAt(0).toUpperCase() + member.role.slice(1)}
                      </span>
                    </td>
                    <td>
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${member.status === 'active' ? 'velora-badge-success' : 'velora-badge-danger'}`}>
                        {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                      </span>
                    </td>
                    <td className="text-sm text-[#64748b]">{member.lastLogin || 'Never'}</td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => setShowPermissions(member)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#6366f1] transition-colors" title="View Permissions">
                          <Eye size={14} />
                        </button>
                        <button onClick={() => openEdit(member)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] transition-colors" title="Edit">
                          <Pencil size={14} />
                        </button>
                        <button onClick={() => toggleStatus(member)} className={`p-2 rounded-lg transition-colors ${member.status === 'active' ? 'text-[#64748b] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10' : 'text-[#64748b] hover:text-[#10b981] hover:bg-[#10b981]/10'}`} title={member.status === 'active' ? 'Deactivate' : 'Activate'}>
                          <Power size={14} />
                        </button>
                        <button onClick={() => setDeleteTarget(member)} className="p-2 rounded-lg hover:bg-[#ef4444]/10 text-[#64748b] hover:text-[#ef4444] transition-colors" title="Delete">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Create/Edit Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title={editing ? 'Edit Staff Member' : 'Add New Staff Member'} size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Name</label>
              <input type="text" className="velora-input w-full" placeholder="Staff name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Email</label>
              <input type="email" className="velora-input w-full" placeholder="email@example.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} disabled={!!editing} />
            </div>
          </div>
          {!editing && (
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Password</label>
              <input type="password" className="velora-input w-full" placeholder="Strong password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Role</label>
            <select className="velora-input w-full" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Staff['role'] })}>
              <option value="admin">Admin — Full access</option>
              <option value="staff">Staff — Manage orders, clients, products</option>
              <option value="support">Support — View tickets, clients only</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-2">Permissions</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-3 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
              {allPermissions.map(perm => (
                <label key={perm} className="flex items-center gap-2 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={form.permissions.includes(perm)}
                    onChange={() => togglePermission(perm)}
                    className="rounded bg-[#1a1a2e] border-[#1a1a2e] text-[#6366f1] focus:ring-[#6366f1]"
                  />
                  <span className="text-[#c8ccd0]">{perm.replace(/_/g, ' ').replace(/view_|manage_/g, '')}</span>
                </label>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setShowModal(false)} className="velora-btn-secondary text-sm">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="velora-btn-primary text-sm">
              {saving ? <><Loader2 size={14} className="inline mr-2 animate-spin" />Saving...</> : editing ? 'Update' : 'Create'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Permissions Modal */}
      <Modal open={!!showPermissions} onClose={() => setShowPermissions(null)} title={`Permissions — ${showPermissions?.name}`} size="lg">
        {showPermissions && (
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${roleBadgeColor(showPermissions.role)}`}>
                {showPermissions.role.charAt(0).toUpperCase() + showPermissions.role.slice(1)}
              </span>
              <span className="text-xs text-[#64748b]">{showPermissions.email}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-64 overflow-y-auto">
              {allPermissions.map(perm => (
                <div key={perm} className={`flex items-center gap-2 p-2 rounded-lg text-xs border ${
                  showPermissions.permissions.includes(perm)
                    ? 'bg-[#10b981]/5 border-[#10b981]/20 text-[#10b981]'
                    : 'bg-[#09090b] border-[#1a1a2e] text-[#475569]'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${showPermissions.permissions.includes(perm) ? 'bg-[#10b981]' : 'bg-[#475569]'}`} />
                  {perm.replace(/_/g, ' ')}
                </div>
              ))}
            </div>
            <div className="mt-4 text-xs text-[#64748b]">
              {showPermissions.permissions.length} of {allPermissions.length} permissions granted
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirm */}
      <ConfirmModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Staff Member"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone.`}
        confirmText="Delete"
        type="danger"
      />
    </div>
  );
}
