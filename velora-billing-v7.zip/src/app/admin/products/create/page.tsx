'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  ArrowLeft,
  Save,
  Cpu,
  HardDrive,
  Wifi,
  Server,
} from 'lucide-react';
import Link from 'next/link';
import toast from 'react-hot-toast';

export default function CreateProduct() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const editId = searchParams.get('edit');
  const isEditing = !!editId;

  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '',
    slug: '',
    description: '',
    type: 'minecraft',
    category: '',
    price: '',
    cycle: 'monthly',
    stock: '-1',
    status: 'active',
    cpu: '',
    ram: '',
    disk: '',
    bandwidth: '',
    slots: '',
    nestId: '',
    eggId: '',
    nodeId: '',
    features: '[]',
    imageUrl: '',
  });

  useEffect(() => {
    if (editId) {
      // In real app, fetch product by ID
      setForm({
        name: 'Minecraft Pro',
        slug: 'minecraft-pro',
        description: 'A premium Minecraft server with 8GB RAM and unlimited slots.',
        type: 'minecraft',
        category: 'gaming',
        price: '599',
        cycle: 'monthly',
        stock: '-1',
        status: 'active',
        cpu: '2',
        ram: '8192',
        disk: '50',
        bandwidth: '2000',
        slots: '100',
        nestId: '1',
        eggId: '5',
        nodeId: '1',
        features: '["DDoS Protection","Auto Backup","SSD Storage"]',
        imageUrl: '',
      });
    }
  }, [editId]);

  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleNameChange = (name: string) => {
    setForm((prev) => ({ ...prev, name, slug: generateSlug(name) }));
  };

  const handleSave = async () => {
    if (!form.name || !form.price) {
      toast.error('Name and price are required');
      return;
    }
    setSaving(true);
    try {
      const token = localStorage.getItem('velora_token');
      const url = isEditing ? `/api/admin/products/${editId}` : '/api/admin/products';
      const method = isEditing ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        toast.success(isEditing ? 'Product updated' : 'Product created');
        router.push('/admin/products');
      } else {
        toast.error('Failed to save product');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const showResources = form.type === 'minecraft' || form.type === 'vps' || form.type === 'dedicated';

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link href="/admin/products" className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-white/5 transition-colors">
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">{isEditing ? 'Edit Product' : 'Create Product'}</h1>
          <p className="text-[#64748b] mt-1">{isEditing ? 'Update product details' : 'Add a new product or service'}</p>
        </div>
      </div>

      {/* Basic Info */}
      <div className="velora-card p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6">Basic Information</h3>
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Name *</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => handleNameChange(e.target.value)}
                className="velora-input w-full"
                placeholder="Product name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Slug</label>
              <input
                type="text"
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: e.target.value })}
                className="velora-input w-full"
                placeholder="auto-generated"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Description</label>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="velora-input w-full h-24 resize-none"
              placeholder="Product description"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Type</label>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="velora-input w-full">
                <option value="minecraft">Minecraft</option>
                <option value="vps">VPS</option>
                <option value="dedicated">Dedicated</option>
                <option value="domain">Domain</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Category</label>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="velora-input w-full">
                <option value="">Select category</option>
                <option value="gaming">Gaming</option>
                <option value="hosting">Hosting</option>
                <option value="domains">Domains</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Status</label>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="velora-input w-full">
                <option value="active">Active</option>
                <option value="draft">Draft</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Price (₹) *</label>
              <input
                type="number"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                className="velora-input w-full"
                placeholder="0"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Billing Cycle</label>
              <select value={form.cycle} onChange={(e) => setForm({ ...form, cycle: e.target.value })} className="velora-input w-full">
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="semi-annually">Semi-Annually</option>
                <option value="annually">Annually</option>
                <option value="lifetime">Lifetime</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Stock (-1 = unlimited)</label>
              <input
                type="number"
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: e.target.value })}
                className="velora-input w-full"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Resource Specs */}
      {showResources && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Cpu size={18} className="text-[#6366f1]" /> Resource Specifications
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">CPU Cores</label>
              <input
                type="number"
                value={form.cpu}
                onChange={(e) => setForm({ ...form, cpu: e.target.value })}
                className="velora-input w-full"
                placeholder="2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">RAM (MB)</label>
              <input
                type="number"
                value={form.ram}
                onChange={(e) => setForm({ ...form, ram: e.target.value })}
                className="velora-input w-full"
                placeholder="4096"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Disk (GB)</label>
              <input
                type="number"
                value={form.disk}
                onChange={(e) => setForm({ ...form, disk: e.target.value })}
                className="velora-input w-full"
                placeholder="50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Bandwidth (GB)</label>
              <input
                type="number"
                value={form.bandwidth}
                onChange={(e) => setForm({ ...form, bandwidth: e.target.value })}
                className="velora-input w-full"
                placeholder="2000"
              />
            </div>
            {form.type === 'minecraft' && (
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Player Slots</label>
                <input
                  type="number"
                  value={form.slots}
                  onChange={(e) => setForm({ ...form, slots: e.target.value })}
                  className="velora-input w-full"
                  placeholder="20"
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Pterodactyl Integration */}
      <div className="velora-card p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
          <Server size={18} className="text-[#6366f1]" /> Pterodactyl Integration
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Nest ID</label>
            <input type="text" value={form.nestId} onChange={(e) => setForm({ ...form, nestId: e.target.value })} className="velora-input w-full" placeholder="1" />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Egg ID</label>
            <input type="text" value={form.eggId} onChange={(e) => setForm({ ...form, eggId: e.target.value })} className="velora-input w-full" placeholder="5" />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Node ID</label>
            <input type="text" value={form.nodeId} onChange={(e) => setForm({ ...form, nodeId: e.target.value })} className="velora-input w-full" placeholder="1" />
          </div>
        </div>
      </div>

      {/* Features & Image */}
      <div className="velora-card p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6">Features & Media</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Features (JSON Array)</label>
            <textarea
              value={form.features}
              onChange={(e) => setForm({ ...form, features: e.target.value })}
              className="velora-input w-full h-24 resize-none font-mono text-sm"
              placeholder='["DDoS Protection","Auto Backup"]'
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#64748b] mb-1.5">Image URL</label>
            <input
              type="url"
              value={form.imageUrl}
              onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
              className="velora-input w-full"
              placeholder="https://example.com/image.png"
            />
          </div>
        </div>
      </div>

      {/* Save */}
      <div className="flex justify-end gap-3 animate-slide-up">
        <Link href="/admin/products" className="velora-btn-secondary">Cancel</Link>
        <button onClick={handleSave} disabled={saving} className="velora-btn-primary flex items-center gap-2">
          <Save size={16} />
          {saving ? 'Saving...' : isEditing ? 'Update Product' : 'Create Product'}
        </button>
      </div>
    </div>
  );
}
