'use client';

import { useState, useEffect } from 'react';
import {
  Mail, Plus, Pencil, Trash2, Eye, RotateCcw, Search, Loader2,
  FileText, X, Save, Code, Sparkles, AlertCircle,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { Modal, ConfirmModal } from '@/components/ui/modal';

interface EmailTemplate {
  id: string;
  name: string;
  type: string;
  subject: string;
  body: string;
  lastModified: string;
  isDefault: boolean;
}

const defaultTemplates: Omit<EmailTemplate, 'id' | 'lastModified'>[] = [
  { name: 'Welcome Email', type: 'welcome', subject: 'Welcome to {{site_name}}!', body: '<h1>Welcome, {{name}}!</h1>\n<p>Thank you for registering at {{site_name}}.</p>\n<p>Your account has been created successfully.</p>', isDefault: true },
  { name: 'Order Confirmation', type: 'order_confirmation', subject: 'Order #{{order_id}} Confirmed', body: '<h1>Order Confirmed</h1>\n<p>Dear {{name}},</p>\n<p>Your order #{{order_id}} for {{product_name}} has been confirmed.</p>\n<p>Amount: ₹{{amount}}</p>', isDefault: true },
  { name: 'Payment Received', type: 'payment_received', subject: 'Payment Received - Order #{{order_id}}', body: '<h1>Payment Received</h1>\n<p>Dear {{name}},</p>\n<p>We have received ₹{{amount}} for order #{{order_id}}.</p>', isDefault: true },
  { name: 'Invoice Reminder', type: 'invoice_reminder', subject: 'Invoice #{{invoice_id}} Due Soon', body: '<h1>Invoice Reminder</h1>\n<p>Dear {{name}},</p>\n<p>Your invoice #{{invoice_id}} for ₹{{amount}} is due on {{due_date}}.</p>', isDefault: true },
  { name: 'Password Reset', type: 'password_reset', subject: 'Password Reset - {{site_name}}', body: '<h1>Password Reset</h1>\n<p>Dear {{name}},</p>\n<p>You requested a password reset. Click the link below:</p>\n<p><a href="{{reset_url}}">Reset Password</a></p>', isDefault: true },
  { name: 'Ticket Reply', type: 'ticket_reply', subject: 'Re: #{{ticket_id}} - {{subject}}', body: '<h1>Ticket Update</h1>\n<p>Dear {{name}},</p>\n<p>Your ticket #{{ticket_id}} has been updated.</p>\n<p>{{reply_message}}</p>', isDefault: true },
];

const variables = [
  { key: '{{name}}', desc: 'Client full name' },
  { key: '{{email}}', desc: 'Client email' },
  { key: '{{site_name}}', desc: 'Your site name' },
  { key: '{{order_id}}', desc: 'Order ID' },
  { key: '{{product_name}}', desc: 'Product/service name' },
  { key: '{{amount}}', desc: 'Payment amount' },
  { key: '{{invoice_id}}', desc: 'Invoice ID' },
  { key: '{{due_date}}', desc: 'Invoice due date' },
  { key: '{{ticket_id}}', desc: 'Ticket ID' },
  { key: '{{subject}}', desc: 'Ticket subject' },
  { key: '{{reply_message}}', desc: 'Ticket reply content' },
  { key: '{{reset_url}}', desc: 'Password reset URL' },
];

export default function AdminEmailTemplates() {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [form, setForm] = useState({ name: '', subject: '', body: '' });
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<EmailTemplate | null>(null);
  const [copyVar, setCopyVar] = useState('');

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/email-templates', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const data = await res.json();
          if (data.templates && data.templates.length > 0) {
            setTemplates(data.templates);
          } else {
            setTemplates(defaultTemplates.map((t, i) => ({ ...t, id: String(i + 1), lastModified: new Date().toISOString(), isDefault: true })));
          }
        } else {
          setTemplates(defaultTemplates.map((t, i) => ({ ...t, id: String(i + 1), lastModified: new Date().toISOString(), isDefault: true })));
        }
      } catch {
        setTemplates(defaultTemplates.map((t, i) => ({ ...t, id: String(i + 1), lastModified: new Date().toISOString(), isDefault: true })));
      } finally {
        setLoading(false);
      }
    };
    fetchTemplates();
  }, []);

  const filtered = templates.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase()) || t.type.toLowerCase().includes(search.toLowerCase())
  );

  const openEdit = (t: EmailTemplate) => {
    setEditingTemplate(t);
    setForm({ name: t.name, subject: t.subject, body: t.body });
    setPreviewMode(false);
    setShowEditor(true);
  };

  const openCreate = () => {
    setEditingTemplate(null);
    setForm({ name: '', subject: '', body: '<p>Write your email content here...</p>' });
    setPreviewMode(false);
    setShowEditor(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.subject.trim()) { toast.error('Name and subject are required'); return; }
    setSaving(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/email-templates', {
        method: editingTemplate ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ ...form, id: editingTemplate?.id }),
      });
      if (res.ok) {
        toast.success(editingTemplate ? 'Template updated' : 'Template created');
        setShowEditor(false);
      } else {
        toast.error('Failed to save');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const resetToDefault = (t: EmailTemplate) => {
    const def = defaultTemplates.find(d => d.type === t.type);
    if (def) {
      setTemplates(prev => prev.map(tmp => tmp.id === t.id ? { ...tmp, subject: def.subject, body: def.body } : tmp));
      toast.success('Template reset to default');
    }
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    setTemplates(prev => prev.filter(t => t.id !== deleteTarget.id));
    toast.success('Template deleted');
    setDeleteTarget(null);
  };

  const handleCopyVar = (v: string) => {
    navigator.clipboard.writeText(v);
    setCopyVar(v);
    setTimeout(() => setCopyVar(''), 2000);
  };

  const formatPreview = (html: string) => {
    return html.replace(/\{\{(\w+)\}\}/g, '<span style="color: #6366f1; font-weight: bold; background: rgba(99,102,241,0.1); padding: 2px 6px; border-radius: 4px;">{{$1}}</span>');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
            <Mail size={20} className="text-[#6366f1]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#e2e8f0]">Email Templates</h1>
            <p className="text-sm text-[#64748b]">Manage email notification templates</p>
          </div>
        </div>
        <button onClick={openCreate} className="velora-btn-primary flex items-center gap-2">
          <Plus size={16} /> Create Template
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
        <input type="text" placeholder="Search templates..." value={search} onChange={(e) => setSearch(e.target.value)} className="velora-input w-full pl-10" />
      </div>

      {/* Templates List */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[#6366f1]" size={32} /></div>
      ) : filtered.length === 0 ? (
        <div className="velora-card p-16 text-center">
          <Mail size={48} className="mx-auto text-[#64748b] mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Templates Found</h3>
          <p className="text-[#64748b] text-sm mb-6">Create email templates or load defaults to get started.</p>
          <button onClick={openCreate} className="velora-btn-primary">Create Template</button>
        </div>
      ) : (
        <div className="velora-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="velora-table">
              <thead>
                <tr>
                  <th>Template Name</th>
                  <th>Type</th>
                  <th>Subject</th>
                  <th>Last Modified</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((t) => (
                  <tr key={t.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-[#6366f1]/10 flex items-center justify-center"><Mail size={14} className="text-[#6366f1]" /></div>
                        <div>
                          <p className="text-sm text-[#e2e8f0] font-medium">{t.name}</p>
                          {t.isDefault && <span className="text-[10px] text-[#64748b]">Default</span>}
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="velora-badge velora-badge-info">{t.type}</span>
                    </td>
                    <td className="text-sm text-[#64748b] max-w-[200px] truncate">{t.subject}</td>
                    <td className="text-sm text-[#64748b]">{new Date(t.lastModified).toLocaleDateString()}</td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => openEdit(t)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] transition-colors" title="Edit"><Pencil size={14} /></button>
                        {t.isDefault && <button onClick={() => resetToDefault(t)} className="p-2 rounded-lg hover:bg-[#1a1a2e] text-[#64748b] hover:text-[#f59e0b] transition-colors" title="Reset to Default"><RotateCcw size={14} /></button>}
                        <button onClick={() => setDeleteTarget(t)} className="p-2 rounded-lg hover:bg-[#ef4444]/10 text-[#64748b] hover:text-[#ef4444] transition-colors" title="Delete"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Editor Modal */}
      <Modal open={showEditor} onClose={() => setShowEditor(false)} title={editingTemplate ? `Edit: ${editingTemplate.name}` : 'Create Template'} size="xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Editor */}
          <div className="lg:col-span-2 space-y-4">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Template Name</label>
              <input type="text" className="velora-input w-full" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g., Welcome Email" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Subject</label>
              <input type="text" className="velora-input w-full" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="Email subject line..." />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-sm font-medium text-[#64748b]">Body (HTML)</label>
                <button onClick={() => setPreviewMode(!previewMode)} className="text-xs text-[#6366f1] hover:text-[#818cf8] flex items-center gap-1">
                  {previewMode ? <Code size={12} /> : <Eye size={12} />}
                  {previewMode ? 'Edit' : 'Preview'}
                </button>
              </div>
              {previewMode ? (
                <div className="min-h-[250px] bg-[#09090b] border border-[#1a1a2e] rounded-lg p-4 text-sm text-[#e2e8f0]" dangerouslySetInnerHTML={{ __html: formatPreview(form.body) }} />
              ) : (
                <textarea
                  className="velora-input w-full font-mono text-sm min-h-[250px] resize-y"
                  value={form.body}
                  onChange={(e) => setForm({ ...form, body: e.target.value })}
                  placeholder="<p>Write your HTML content...</p>"
                />
              )}
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setShowEditor(false)} className="velora-btn-secondary text-sm">Cancel</button>
              <button onClick={handleSave} disabled={saving} className="velora-btn-primary text-sm flex items-center gap-2">
                {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                {saving ? 'Saving...' : 'Save Template'}
              </button>
            </div>
          </div>

          {/* Variables Sidebar */}
          <div>
            <div className="velora-card p-4 sticky top-0">
              <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3 flex items-center gap-2">
                <Sparkles size={14} className="text-[#8b5cf6]" /> Variables
              </h4>
              <p className="text-xs text-[#64748b] mb-3">Click to copy a variable</p>
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {variables.map(v => (
                  <button
                    key={v.key}
                    onClick={() => handleCopyVar(v.key)}
                    className="w-full text-left p-2 rounded-lg bg-[#09090b] border border-[#1a1a2e] hover:border-[#6366f1]/30 transition-colors"
                  >
                    <code className="text-xs text-[#6366f1]">{v.key}</code>
                    <p className="text-[10px] text-[#64748b] mt-0.5">{v.desc}</p>
                  </button>
                ))}
              </div>
              {copyVar && (
                <div className="mt-3 p-2 rounded-lg bg-[#10b981]/10 border border-[#10b981]/20 text-xs text-[#10b981] animate-fade-in flex items-center gap-2">
                  <Sparkles size={12} /> Copied {copyVar}
                </div>
              )}
            </div>
          </div>
        </div>
      </Modal>

      {/* Delete Confirm */}
      <ConfirmModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Template"
        message={`Delete "${deleteTarget?.name}"? This cannot be undone.`}
        confirmText="Delete"
        type="danger"
      />
    </div>
  );
}
