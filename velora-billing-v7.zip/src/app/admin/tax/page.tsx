'use client';

import { useState, useEffect } from 'react';
import {
  Receipt, Save, Loader2, Calculator, Info, History, ToggleLeft, ToggleRight,
  DollarSign, AlertTriangle, CheckCircle, RotateCcw,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface TaxConfig {
  enabled: boolean;
  name: string;
  rate: number;
  inclusive: boolean;
}

interface TaxLogEntry {
  id: string;
  action: string;
  previousValue: string;
  newValue: string;
  timestamp: string;
  admin: string;
}

export default function AdminTax() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [config, setConfig] = useState<TaxConfig>({ enabled: false, name: 'GST', rate: 18, inclusive: false });
  const [logs, setLogs] = useState<TaxLogEntry[]>([]);

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/tax', { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) {
          const data = await res.json();
          if (data.config) setConfig(data.config);
          if (data.logs) setLogs(data.logs);
        }
      } catch { /* */ } finally {
        setLoading(false);
      }
    };
    fetchConfig();
  }, []);

  const handleSave = async () => {
    if (config.enabled && config.rate <= 0) { toast.error('Tax rate must be greater than 0'); return; }
    if (config.enabled && !config.name.trim()) { toast.error('Tax name is required'); return; }
    setSaving(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/admin/tax', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(config),
      });
      if (res.ok) {
        toast.success('Tax configuration saved');
      } else {
        toast.error('Failed to save');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setSaving(false);
    }
  };

  const exampleAmount = 1000;
  const taxAmount = config.enabled ? (exampleAmount * config.rate) / 100 : 0;
  const totalAmount = config.inclusive ? exampleAmount : exampleAmount + taxAmount;
  const baseAmount = config.inclusive ? exampleAmount - taxAmount : exampleAmount;

  const Toggle = ({ checked, onChange, color = '#6366f1' }: { checked: boolean; onChange: () => void; color?: string }) => (
    <div
      className={`w-11 h-6 rounded-full relative transition-colors cursor-pointer flex-shrink-0 ${checked ? '' : 'bg-[#1a1a2e]'}`}
      style={checked ? { backgroundColor: color } : {}}
      onClick={onChange}
    >
      <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${checked ? 'translate-x-5.5' : 'translate-x-0.5'}`} />
    </div>
  );

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
          <Receipt size={20} className="text-[#6366f1]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-[#e2e8f0]">Tax Management</h1>
          <p className="text-sm text-[#64748b]">Configure tax settings for invoices</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tax Configuration */}
        <div className="lg:col-span-2 velora-card p-6 animate-fade-in-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Receipt size={18} className="text-[#6366f1]" /> Tax Configuration
          </h3>

          <div className="space-y-6 max-w-xl">
            {/* Enable Toggle */}
            <div className="flex items-center justify-between p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
              <div className="flex items-center gap-3">
                {config.enabled ? <ToggleRight size={20} className="text-[#10b981]" /> : <ToggleLeft size={20} className="text-[#64748b]" />}
                <div>
                  <p className="text-sm font-medium text-[#e2e8f0]">Enable Tax</p>
                  <p className="text-xs text-[#64748b]">Apply tax to all invoices</p>
                </div>
              </div>
              <Toggle checked={config.enabled} onChange={() => setConfig({ ...config, enabled: !config.enabled })} />
            </div>

            {/* Tax Fields */}
            <div className={`space-y-4 transition-opacity ${config.enabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Tax Name</label>
                <input
                  type="text"
                  className="velora-input w-full"
                  value={config.name}
                  onChange={(e) => setConfig({ ...config, name: e.target.value })}
                  placeholder="e.g., GST, VAT, Sales Tax"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Tax Rate (%)</label>
                <div className="relative">
                  <input
                    type="number"
                    className="velora-input w-full pr-12"
                    value={config.rate}
                    onChange={(e) => setConfig({ ...config, rate: parseFloat(e.target.value) || 0 })}
                    min="0"
                    max="100"
                    step="0.5"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[#64748b] text-sm">%</span>
                </div>
              </div>

              {/* Inclusive Toggle */}
              <div className="flex items-center justify-between p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
                <div>
                  <p className="text-sm font-medium text-[#e2e8f0]">Tax Inclusive Pricing</p>
                  <p className="text-xs text-[#64748b]">Tax is included in the displayed price</p>
                </div>
                <Toggle
                  checked={config.inclusive}
                  onChange={() => setConfig({ ...config, inclusive: !config.inclusive })}
                  color="#8b5cf6"
                />
              </div>
            </div>

            {/* Save */}
            <div className="pt-4 border-t border-[#1a1a2e]">
              <button onClick={handleSave} disabled={saving} className="velora-btn-primary flex items-center gap-2">
                {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                {saving ? 'Saving...' : 'Save Configuration'}
              </button>
            </div>
          </div>
        </div>

        {/* Preview */}
        <div className="velora-card p-6 animate-fade-in-up">
          <h3 className="text-base font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
            <Calculator size={16} className="text-[#8b5cf6]" /> Tax Preview
          </h3>

          {config.enabled ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-[#64748b]">
                <Info size={14} /> Example calculation for ₹{exampleAmount.toLocaleString()}
              </div>
              <div className="bg-[#09090b] rounded-lg border border-[#1a1a2e] p-4 space-y-3">
                {config.inclusive ? (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#64748b]">Total (incl. {config.name})</span>
                      <span className="text-[#e2e8f0] font-medium">₹{exampleAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#64748b]">Base Price</span>
                      <span className="text-[#e2e8f0]">₹{baseAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#64748b]">{config.name} ({config.rate}%)</span>
                      <span className="text-[#f59e0b] font-medium">₹{taxAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#64748b]">Subtotal</span>
                      <span className="text-[#e2e8f0]">₹{exampleAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#64748b]">{config.name} ({config.rate}%)</span>
                      <span className="text-[#f59e0b] font-medium">₹{taxAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                    </div>
                    <div className="border-t border-[#1a1a2e] pt-2 flex justify-between text-sm font-medium">
                      <span className="text-[#e2e8f0]">Total</span>
                      <span className="text-[#10b981]">₹{totalAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                    </div>
                  </>
                )}
              </div>
              <div className="p-3 rounded-lg bg-[#6366f1]/5 border border-[#6366f1]/20 text-xs text-[#6366f1]">
                <AlertTriangle size={12} className="inline mr-1" />
                {config.inclusive ? 'Tax is included in displayed prices' : 'Tax is added on top of the base price'}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-[#64748b]">
              <Receipt size={40} className="mb-3 text-[#1a1a2e]" />
              <p className="text-sm">Tax is disabled</p>
              <p className="text-xs text-[#475569] mt-1">Enable tax to see preview</p>
            </div>
          )}
        </div>
      </div>

      {/* Tax History */}
      <div className="velora-card p-6 animate-fade-in-up">
        <h3 className="text-base font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
          <History size={16} className="text-[#6366f1]" /> Tax History
        </h3>
        {logs.length === 0 ? (
          <div className="flex items-center gap-3 p-4 bg-[#09090b] rounded-lg border border-[#1a1a2e]">
            <CheckCircle size={16} className="text-[#64748b]" />
            <p className="text-sm text-[#64748b]">No changes recorded yet. Tax history will appear here.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="velora-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Action</th>
                  <th>Previous</th>
                  <th>New</th>
                  <th>Admin</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log) => (
                  <tr key={log.id}>
                    <td className="text-sm text-[#64748b] font-mono">{log.timestamp}</td>
                    <td className="text-sm text-[#e2e8f0]">{log.action}</td>
                    <td className="text-sm text-[#64748b]">{log.previousValue}</td>
                    <td className="text-sm text-[#10b981] font-medium">{log.newValue}</td>
                    <td className="text-sm text-[#64748b]">{log.admin}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
