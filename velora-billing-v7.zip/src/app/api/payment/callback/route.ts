import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { paymentId, txnId, adminUserId } = await request.json();

    if (!paymentId || !txnId) {
      return NextResponse.json({ success: false, error: 'Payment ID and Transaction ID are required' }, { status: 400 });
    }

    // Fetch the payment
    const payment = await db.upiPayment.findUnique({ where: { id: paymentId } });
    if (!payment) {
      return NextResponse.json({ success: false, error: 'Payment not found' }, { status: 404 });
    }

    if (payment.status === 'successful') {
      return NextResponse.json({ success: false, error: 'Payment already verified' }, { status: 400 });
    }

    // Update payment status
    await db.upiPayment.update({
      where: { id: paymentId },
      data: {
        status: 'successful',
        txnId,
        verifiedBy: adminUserId || (payload.id as string),
        verifiedAt: new Date(),
      },
    });

    // Find and update the associated order
    const order = await db.order.findFirst({
      where: { paymentId },
    });

    if (order) {
      await db.order.update({
        where: { id: order.id },
        data: { status: 'paid', paidAt: new Date() },
      });

      // Update the invoice
      const invoice = await db.invoice.findFirst({
        where: { orderId: order.id },
      });

      if (invoice) {
        await db.invoice.update({
          where: { id: invoice.id },
          data: { status: 'paid', paidAt: new Date() },
        });
      }

      // Update user total spent
      await db.user.update({
        where: { id: payment.userId },
        data: { totalSpent: { increment: payment.amount } },
      });

      // Create notification for user
      await db.notification.create({
        data: {
          userId: payment.userId,
          title: 'Payment Received',
          message: `Your payment of ₹${payment.amount} for order ${order.orderNumber} has been verified. Transaction ID: ${txnId}`,
          type: 'success',
        },
      });
    }

    // Create audit log
    await db.auditLog.create({
      data: {
        userId: adminUserId || (payload.id as string),
        action: 'payment_verified',
        details: JSON.stringify({ paymentId, txnId, amount: payment.amount }),
      },
    });

    return NextResponse.json({ success: true, message: 'Payment verified successfully' });
  } catch (error) {
    console.error('Payment callback error:', error);
    return NextResponse.json({ success: false, error: 'Failed to verify payment' }, { status: 500 });
  }
}
