import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { buildUpiUrl, generateQRCode } from '@/lib/upi';

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Invalid token' }, { status: 401 });
    }

    const { orderId } = await request.json();
    if (!orderId) {
      return NextResponse.json({ success: false, error: 'Order ID is required' }, { status: 400 });
    }

    // Fetch order
    const order = await db.order.findFirst({
      where: { id: orderId, userId: payload.id as string },
      include: { product: true },
    });

    if (!order) {
      return NextResponse.json({ success: false, error: 'Order not found' }, { status: 404 });
    }

    if (order.status === 'paid') {
      return NextResponse.json({ success: false, error: 'Order is already paid' }, { status: 400 });
    }

    // Check for existing pending payment for this order
    const existingPayment = await db.upiPayment.findFirst({
      where: {
        userId: payload.id as string,
        status: 'pending',
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });

    if (existingPayment) {
      return NextResponse.json({ success: true, data: existingPayment });
    }

    // Get UPI settings
    const upiIdSetting = await db.setting.findUnique({ where: { key: 'payment_upi_id' } });
    const upiId = upiIdSetting?.value || 'yourname@paytm';

    // Build UPI deep link
    const paymentUrl = buildUpiUrl({
      upiId,
      amount: order.amount,
      merchantName: 'Velora Billing',
      transactionId: order.orderNumber,
      note: `Payment for ${order.orderNumber}`,
    });

    // Generate QR code
    const qrCode = await generateQRCode(paymentUrl);

    // Create UPI payment record
    const upiPayment = await db.upiPayment.create({
      data: {
        userId: payload.id as string,
        invoiceId: order.id,
        amount: order.amount,
        upiId,
        paymentUrl,
        qrCode,
        status: 'pending',
        expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
      },
    });

    // Link payment to order
    await db.order.update({
      where: { id: order.id },
      data: { paymentId: upiPayment.id, paymentMethod: 'upi' },
    });

    return NextResponse.json({ success: true, data: upiPayment }, { status: 201 });
  } catch (error) {
    console.error('Payment create error:', error);
    return NextResponse.json({ success: false, error: 'Failed to create payment' }, { status: 500 });
  }
}
