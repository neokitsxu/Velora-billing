import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

// GET - Public: return published pages
export async function GET() {
  try {
    const pages = await db.page.findMany({
    where: { status: 'published' },
    orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({ success: true, data: pages });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: 'Failed to fetch pages' }, { status: 500 });
  }
}

// POST - Admin: create or update page
export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const body = await request.json();
    const { id, title, slug, content, status, sortOrder } = body;

    if (!title?.trim() || !slug?.trim()) {
      return NextResponse.json({ success: false, error: 'Title and slug are required' }, { status: 400 });
    }

    if (id) {
      // Update existing
      const page = await db.page.update({
        where: { id },
        data: {
          title: title.trim(),
          slug: slug.trim(),
          content: content || '',
          status: status || 'draft',
          sortOrder: sortOrder ?? 0,
        },
      });
      return NextResponse.json({ success: true, data: page });
    }

    // Create new
    const page = await db.page.create({
      data: {
        title: title.trim(),
        slug: slug.trim(),
        content: content || '',
        status: status || 'draft',
        sortOrder: sortOrder ?? 0,
      },
    });

    return NextResponse.json({ success: true, data: page });
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json({ success: false, error: 'A page with this slug already exists' }, { status: 409 });
    }
    return NextResponse.json({ success: false, error: 'Failed to save page' }, { status: 500 });
  }
}

// DELETE - Admin: delete page
export async function DELETE(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const body = await request.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: 'ID is required' }, { status: 400 });
    }

    await db.page.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: 'Failed to delete page' }, { status: 500 });
  }
}
