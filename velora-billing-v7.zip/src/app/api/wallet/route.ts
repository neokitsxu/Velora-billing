import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Invalid token' }, { status: 401 });
    }

    const transactions = await db.walletTransaction.findMany({
      where: { userId: payload.id as string },
      orderBy: { createdAt: 'desc' },
    });

    const user = await db.user.findUnique({
      where: { id: payload.id as string },
      select: { balance: true },
    });

    return NextResponse.json({
      success: true,
      data: {
        balance: user?.balance || 0,
        transactions,
      },
    });
  } catch (error) {
    console.error('Wallet fetch error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch wallet' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Invalid token' }, { status: 401 });
    }

    const { amount, method } = await request.json();

    if (!amount || amount <= 0) {
      return NextResponse.json({ success: false, error: 'Valid amount is required' }, { status: 400 });
    }

    const user = await db.user.findUnique({ where: { id: payload.id as string } });
    if (!user) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }

    const newBalance = user.balance + amount;

    await db.user.update({
      where: { id: user.id },
      data: { balance: newBalance },
    });

    const transaction = await db.walletTransaction.create({
      data: {
        userId: user.id,
        type: 'credit',
        amount,
        balance: newBalance,
        description: `Funds added via ${method || 'wallet'}`,
        method: method || 'wallet',
        status: 'completed',
      },
    });

    return NextResponse.json({ success: true, data: transaction }, { status: 201 });
  } catch (error) {
    console.error('Wallet add funds error:', error);
    return NextResponse.json({ success: false, error: 'Failed to add funds' }, { status: 500 });
  }
}
