import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

// GET - Public: return active announcements for client display
export async function GET() {
  try {
    const announcements = await db.announcement.findMany({
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: announcements });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: 'Failed to fetch announcements' }, { status: 500 });
  }
}

// POST - Admin: create or update announcement
export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const body = await request.json();
    const { id, title, content, type, active } = body;

    if (!title?.trim() || !content?.trim()) {
      return NextResponse.json({ success: false, error: 'Title and content are required' }, { status: 400 });
    }

    if (id) {
      // Update existing
      const announcement = await db.announcement.update({
        where: { id },
        data: {
          title: title.trim(),
          content: content.trim(),
          type: type || 'info',
          active: active !== undefined ? active : true,
        },
      });
      return NextResponse.json({ success: true, data: announcement });
    }

    // Create new
    const announcement = await db.announcement.create({
      data: {
        title: title.trim(),
        content: content.trim(),
        type: type || 'info',
        active: active !== undefined ? active : true,
      },
    });

    return NextResponse.json({ success: true, data: announcement });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: 'Failed to save announcement' }, { status: 500 });
  }
}

// DELETE - Admin: delete announcement
export async function DELETE(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const body = await request.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: 'ID is required' }, { status: 400 });
    }

    await db.announcement.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: 'Failed to delete announcement' }, { status: 500 });
  }
}
