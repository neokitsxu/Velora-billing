import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken, generateOrderNumber, generateInvoiceNumber } from '@/lib/auth';

async function getUserFromRequest(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  return payload;
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const orderId = searchParams.get('id');

    if (orderId) {
      // Fetch single order
      const order = await db.order.findFirst({
        where: { id: orderId, userId: user.id },
        include: { product: true, invoice: true, service: true },
      });
      if (!order) {
        return NextResponse.json({ success: false, error: 'Order not found' }, { status: 404 });
      }
      return NextResponse.json({ success: true, data: order });
    }

    // Fetch all user orders
    const orders = await db.order.findMany({
      where: { userId: user.id },
      include: { product: true, invoice: true, service: true },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: orders });
  } catch (error) {
    console.error('Orders fetch error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch orders' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { productId, quantity, paymentMethod } = await request.json();

    if (!productId) {
      return NextResponse.json({ success: false, error: 'Product ID is required' }, { status: 400 });
    }

    const product = await db.product.findUnique({ where: { id: productId } });
    if (!product || product.status !== 'active') {
      return NextResponse.json({ success: false, error: 'Product not available' }, { status: 404 });
    }

    if (product.stock !== -1 && product.stock < (quantity || 1)) {
      return NextResponse.json({ success: false, error: 'Product is out of stock' }, { status: 400 });
    }

    const qty = quantity || 1;
    const amount = product.price * qty;

    // Create order
    const order = await db.order.create({
      data: {
        orderNumber: generateOrderNumber(),
        userId: user.id,
        productId: product.id,
        quantity: qty,
        amount,
        paymentMethod: paymentMethod || null,
        status: 'pending',
      },
      include: { product: true },
    });

    // Create invoice
    const tax = Math.round(amount * 0.18 * 100) / 100;
    await db.invoice.create({
      data: {
        invoiceNumber: generateInvoiceNumber(),
        userId: user.id,
        orderId: order.id,
        amount,
        tax,
        discount: 0,
        total: amount + tax,
        status: 'unpaid',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    // Update stock if limited
    if (product.stock !== -1) {
      await db.product.update({
        where: { id: product.id },
        data: { stock: product.stock - qty },
      });
    }

    return NextResponse.json({ success: true, data: order }, { status: 201 });
  } catch (error) {
    console.error('Order creation error:', error);
    return NextResponse.json({ success: false, error: 'Failed to create order' }, { status: 500 });
  }
}
