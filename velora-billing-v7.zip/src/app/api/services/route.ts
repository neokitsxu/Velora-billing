import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Invalid token' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const serviceId = searchParams.get('id');

    if (serviceId) {
      const service = await db.service.findFirst({
        where: { id: serviceId, userId: payload.id as string },
        include: { product: true, order: true },
      });
      if (!service) {
        return NextResponse.json({ success: false, error: 'Service not found' }, { status: 404 });
      }
      return NextResponse.json({ success: true, data: service });
    }

    const services = await db.service.findMany({
      where: { userId: payload.id as string },
      include: { product: true, order: true },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: services });
  } catch (error) {
    console.error('Services fetch error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch services' }, { status: 500 });
  }
}