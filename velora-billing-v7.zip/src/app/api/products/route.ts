import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const type = searchParams.get('type');

    const where: any = { status: 'active' };

    if (category) {
      where.categories = { some: { slug: category } };
    }

    if (type) {
      where.type = type;
    }

    const products = await db.product.findMany({
      where,
      include: {
        categories: true,
      },
      orderBy: { sortOrder: 'asc' },
    });

    return NextResponse.json({ success: true, data: products });
  } catch (error) {
    console.error('Products fetch error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch products' }, { status: 500 });
  }
}
