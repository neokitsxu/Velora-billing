import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import crypto from 'crypto';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

// POST — handle incoming webhook event (public endpoint, verifies signature)
export async function POST(request: NextRequest) {
  try {
    const signature = request.headers.get('X-Webhook-Signature') || '';
    const eventId = request.headers.get('X-Webhook-Event-Id') || '';

    if (!signature) {
      return NextResponse.json(
        { success: false, error: 'Missing webhook signature' },
        { status: 400 }
      );
    }

    // Get the raw body for signature verification
    const rawBody = await request.text();
    let body: Record<string, unknown>;
    try {
      body = JSON.parse(rawBody);
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON payload' },
        { status: 400 }
      );
    }

    const { event, data } = body;

    if (!event) {
      return NextResponse.json(
        { success: false, error: 'Missing event type' },
        { status: 400 }
      );
    }

    // Find matching webhook endpoint by looking up secret
    const webhookConfigs = await db.setting.findMany({
      where: { group: 'webhooks_config' },
    });

    let matchedWebhook = false;
    let webhookSecret = '';

    for (const config of webhookConfigs) {
      try {
        const configData = JSON.parse(config.value);
        if (configData.secret) {
          const expectedSig = crypto
            .createHmac('sha256', configData.secret)
            .update(rawBody)
            .digest('hex');
          if (expectedSig === signature) {
            matchedWebhook = true;
            webhookSecret = configData.secret;
            break;
          }
        }
      } catch {
        continue;
      }
    }

    if (!matchedWebhook) {
      return NextResponse.json(
        { success: false, error: 'Invalid webhook signature' },
        { status: 401 }
      );
    }

    // Log the webhook event
    await db.auditLog.create({
      data: {
        action: 'webhook_received',
        details: JSON.stringify({ event, eventId, signature: signature.substring(0, 8) + '...' }),
      },
    });

    // Process the event based on type
    switch (event) {
      case 'payment.completed':
        // Handle payment completion — could update order/invoice status
        break;
      case 'payment.failed':
        // Handle payment failure
        break;
      case 'user.created':
        // Handle new user event
        break;
      case 'service.provisioned':
        // Handle service provisioning callback
        break;
      default:
        console.log(`Unhandled webhook event: ${event}`);
    }

    return NextResponse.json({ success: true, message: 'Webhook processed' });
  } catch (error) {
    console.error('Webhook processing error:', error);
    return NextResponse.json(
      { success: false, error: 'Webhook processing failed' },
      { status: 500 }
    );
  }
}

// GET — list registered webhook endpoints (admin only)
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const webhookConfigs = await db.setting.findMany({
      where: { group: 'webhooks_config' },
    });

    const webhooks = webhookConfigs.map((s) => {
      let parsed: Record<string, unknown> = {};
      try {
        parsed = JSON.parse(s.value);
      } catch {
        parsed = {};
      }
      return {
        id: s.key,
        ...parsed,
        secret: parsed.secret ? '****' + (parsed.secret as string).slice(-4) : undefined,
        createdAt: s.createdAt,
        updatedAt: s.updatedAt,
      };
    });

    return NextResponse.json({ success: true, data: webhooks });
  } catch (error) {
    console.error('Admin webhook list error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch webhooks' },
      { status: 500 }
    );
  }
}

// PUT — register/update a webhook endpoint (admin only)
export async function PUT(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { url, events, description, id } = await request.json();

    if (!url) {
      return NextResponse.json(
        { success: false, error: 'Webhook URL is required' },
        { status: 400 }
      );
    }

    // Validate URL format
    try {
      new URL(url);
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid webhook URL' },
        { status: 400 }
      );
    }

    const secret = crypto.randomBytes(32).toString('hex');
    const webhookKey = id || `webhook_${Date.now()}`;

    const webhookData = {
      url,
      events: events || ['*'],
      description: description || '',
      secret,
    };

    const isUpdate = !!id;

    const setting = await db.setting.upsert({
      where: { key: webhookKey },
      update: {
        value: JSON.stringify({
          ...webhookData,
          secret: isUpdate ? undefined : secret, // Don't overwrite secret on update unless explicitly provided
        }),
        group: 'webhooks_config',
        type: 'json',
      },
      create: {
        key: webhookKey,
        value: JSON.stringify(webhookData),
        group: 'webhooks_config',
        type: 'json',
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: isUpdate ? 'webhook_updated' : 'webhook_registered',
        details: JSON.stringify({ key: webhookKey, url, events: webhookData.events }),
      },
    });

    return NextResponse.json({
      success: true,
      message: isUpdate ? 'Webhook updated successfully' : 'Webhook registered successfully',
      data: {
        id: setting.key,
        url: webhookData.url,
        events: webhookData.events,
        description: webhookData.description,
        secret: isUpdate ? undefined : secret, // Only return secret on creation
      },
    });
  } catch (error) {
    console.error('Admin webhook register error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to register webhook' },
      { status: 500 }
    );
  }
}

// DELETE — remove a webhook endpoint (admin only)
export async function DELETE(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Webhook ID is required' },
        { status: 400 }
      );
    }

    const existing = await db.setting.findUnique({
      where: { key: id },
    });
    if (!existing || existing.group !== 'webhooks_config') {
      return NextResponse.json(
        { success: false, error: 'Webhook not found' },
        { status: 404 }
      );
    }

    await db.setting.delete({ where: { key: id } });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'webhook_deleted',
        details: JSON.stringify({ key: id }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Webhook deleted successfully',
    });
  } catch (error) {
    console.error('Admin webhook delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete webhook' },
      { status: 500 }
    );
  }
}
