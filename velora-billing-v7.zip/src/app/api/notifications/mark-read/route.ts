import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function getUserFromRequest(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload) return null;
  return payload;
}

// POST — mark a single notification as read
export async function POST(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;
    const { notificationId, markAll } = await request.json();

    if (markAll) {
      // Mark all notifications as read
      const result = await db.notification.updateMany({
        where: { userId, read: false },
        data: { read: true },
      });

      return NextResponse.json({
        success: true,
        message: `${result.count} notifications marked as read`,
        data: { marked: result.count },
      });
    }

    if (!notificationId) {
      return NextResponse.json(
        { success: false, error: 'Notification ID is required' },
        { status: 400 }
      );
    }

    // Verify the notification belongs to the user
    const notification = await db.notification.findFirst({
      where: { id: notificationId, userId },
    });

    if (!notification) {
      return NextResponse.json(
        { success: false, error: 'Notification not found' },
        { status: 404 }
      );
    }

    if (notification.read) {
      return NextResponse.json({
        success: true,
        message: 'Notification is already read',
        data: { id: notificationId, read: true },
      });
    }

    await db.notification.update({
      where: { id: notificationId },
      data: { read: true },
    });

    return NextResponse.json({
      success: true,
      message: 'Notification marked as read',
      data: { id: notificationId, read: true },
    });
  } catch (error) {
    console.error('Notification mark-read error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to mark notification as read' },
      { status: 500 }
    );
  }
}

// DELETE — mark all as read (alternative to POST with markAll=true)
export async function DELETE(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;

    const result = await db.notification.updateMany({
      where: { userId, read: false },
      data: { read: true },
    });

    return NextResponse.json({
      success: true,
      message: `${result.count} notifications marked as read`,
      data: { marked: result.count },
    });
  } catch (error) {
    console.error('Notification mark-all-read error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to mark notifications as read' },
      { status: 500 }
    );
  }
}
