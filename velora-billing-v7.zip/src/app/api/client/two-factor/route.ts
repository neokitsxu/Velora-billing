import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken, verifyPassword } from '@/lib/auth';
import crypto from 'crypto';

function getUserFromRequest(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload) return null;
  return payload;
}

// POST /enable — generate a 2FA code and store it
export async function POST(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;
    const { action, password, code: verifyCode } = await request.json();

    if (!action) {
      return NextResponse.json(
        { success: false, error: 'Action is required (enable, verify, disable)' },
        { status: 400 }
      );
    }

    switch (action) {
      case 'enable': {
        // Generate a 6-digit code with 5-minute expiry
        const code = String(crypto.randomInt(100000, 999999));
        const expiresAt = Date.now() + 5 * 60 * 1000; // 5 minutes

        await db.setting.upsert({
          where: { key: `2fa_${userId}` },
          update: {
            value: JSON.stringify({
              code,
              expiresAt,
              enabled: false,
              pending: true,
            }),
            group: 'security',
            type: 'json',
          },
          create: {
            key: `2fa_${userId}`,
            value: JSON.stringify({
              code,
              expiresAt,
              enabled: false,
              pending: true,
            }),
            group: 'security',
            type: 'json',
          },
        });

        // Audit log
        await db.auditLog.create({
          data: {
            userId,
            action: '2fa_initiated',
            details: JSON.stringify({ method: 'numeric_code' }),
          },
        });

        return NextResponse.json({
          success: true,
          message: '2FA code generated. Please verify the code to enable 2FA.',
          data: {
            code, // Dev only — in production, send via email/SMS
            expiresAt: new Date(expiresAt).toISOString(),
            expiresIn: 300,
          },
        });
      }

      case 'verify': {
        if (!verifyCode) {
          return NextResponse.json(
            { success: false, error: 'Verification code is required' },
            { status: 400 }
          );
        }

        const setting = await db.setting.findUnique({
          where: { key: `2fa_${userId}` },
        });

        if (!setting) {
          return NextResponse.json(
            { success: false, error: 'No 2FA setup in progress. Please initiate 2FA first.' },
            { status: 400 }
          );
        }

        let twoFaData: Record<string, unknown> = {};
        try {
          twoFaData = JSON.parse(setting.value);
        } catch {
          return NextResponse.json(
            { success: false, error: 'Invalid 2FA data. Please restart setup.' },
            { status: 400 }
          );
        }

        if (!twoFaData.pending) {
          return NextResponse.json(
            { success: false, error: 'No 2FA setup in progress.' },
            { status: 400 }
          );
        }

        if (Date.now() > (twoFaData.expiresAt as number)) {
          // Clean up expired code
          await db.setting.delete({ where: { key: `2fa_${userId}` } });
          return NextResponse.json(
            { success: false, error: 'Verification code has expired. Please request a new one.' },
            { status: 400 }
          );
        }

        if (verifyCode !== (twoFaData.code as string)) {
          return NextResponse.json(
            { success: false, error: 'Invalid verification code.' },
            { status: 400 }
          );
        }

        // Mark 2FA as enabled
        await db.setting.update({
          where: { key: `2fa_${userId}` },
          data: {
            value: JSON.stringify({
              enabled: true,
              pending: false,
              enabledAt: new Date().toISOString(),
            }),
          },
        });

        // Audit log
        await db.auditLog.create({
          data: {
            userId,
            action: '2fa_enabled',
          },
        });

        return NextResponse.json({
          success: true,
          message: 'Two-factor authentication enabled successfully.',
          data: { enabled: true },
        });
      }

      case 'disable': {
        if (!password) {
          return NextResponse.json(
            { success: false, error: 'Password confirmation is required to disable 2FA' },
            { status: 400 }
          );
        }

        const user = await db.user.findUnique({ where: { id: userId } });
        if (!user) {
          return NextResponse.json(
            { success: false, error: 'User not found' },
            { status: 404 }
          );
        }

        const valid = await verifyPassword(password, user.password);
        if (!valid) {
          return NextResponse.json(
            { success: false, error: 'Password is incorrect' },
            { status: 400 }
          );
        }

        const setting = await db.setting.findUnique({
          where: { key: `2fa_${userId}` },
        });

        if (!setting) {
          return NextResponse.json(
            { success: false, error: '2FA is not enabled on your account' },
            { status: 400 }
          );
        }

        await db.setting.delete({ where: { key: `2fa_${userId}` } });

        // Audit log
        await db.auditLog.create({
          data: {
            userId,
            action: '2fa_disabled',
          },
        });

        return NextResponse.json({
          success: true,
          message: 'Two-factor authentication disabled successfully.',
          data: { enabled: false },
        });
      }

      default: {
        return NextResponse.json(
          { success: false, error: 'Invalid action. Use: enable, verify, or disable.' },
          { status: 400 }
        );
      }
    }
  } catch (error) {
    console.error('Client 2FA error:', error);
    return NextResponse.json(
      { success: false, error: 'Two-factor authentication operation failed' },
      { status: 500 }
    );
  }
}

// GET — check 2FA status
export async function GET(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;

    const setting = await db.setting.findUnique({
      where: { key: `2fa_${userId}` },
    });

    let enabled = false;
    if (setting) {
      try {
        const data = JSON.parse(setting.value);
        enabled = data.enabled === true;
      } catch {
        enabled = false;
      }
    }

    return NextResponse.json({
      success: true,
      data: { enabled },
    });
  } catch (error) {
    console.error('Client 2FA status error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch 2FA status' },
      { status: 500 }
    );
  }
}
