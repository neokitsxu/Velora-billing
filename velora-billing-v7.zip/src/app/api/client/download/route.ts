import { NextRequest, NextResponse } from 'next/server';
import { verifyToken } from '@/lib/auth';

function getUserFromRequest(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload) return null;
  return payload;
}

// GET — list downloadable files/resources for a service (mock data)
export async function GET(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;
    const { searchParams } = new URL(request.url);
    const serviceId = searchParams.get('serviceId');

    if (!serviceId) {
      return NextResponse.json(
        { success: false, error: 'Service ID is required' },
        { status: 400 }
      );
    }

    // Mock downloadable files — in production, this would integrate with Pterodactyl
    // to list server backups, logs, and other downloadable resources.
    const mockDownloads = [
      {
        id: 'dl_001',
        name: 'server-backup-latest.tar.gz',
        type: 'backup',
        size: '2.4 GB',
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        downloadUrl: `/api/client/download?serviceId=${serviceId}&file=server-backup-latest.tar.gz`,
      },
      {
        id: 'dl_002',
        name: 'server.log',
        type: 'log',
        size: '156 KB',
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        downloadUrl: `/api/client/download?serviceId=${serviceId}&file=server.log`,
      },
      {
        id: 'dl_003',
        name: 'world-backup.tar.gz',
        type: 'backup',
        size: '890 MB',
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        downloadUrl: `/api/client/download?serviceId=${serviceId}&file=world-backup.tar.gz`,
      },
      {
        id: 'dl_004',
        name: 'plugins-list.txt',
        type: 'config',
        size: '12 KB',
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        downloadUrl: `/api/client/download?serviceId=${serviceId}&file=plugins-list.txt`,
      },
      {
        id: 'dl_005',
        name: 'server.properties',
        type: 'config',
        size: '2 KB',
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        downloadUrl: `/api/client/download?serviceId=${serviceId}&file=server.properties`,
      },
    ];

    return NextResponse.json({
      success: true,
      data: {
        serviceId,
        userId,
        files: mockDownloads,
        totalFiles: mockDownloads.length,
        note: 'In production, this endpoint integrates with Pterodactyl to list real server files, backups, and logs.',
      },
    });
  } catch (error) {
    console.error('Client download list error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch downloadable files' },
      { status: 500 }
    );
  }
}
