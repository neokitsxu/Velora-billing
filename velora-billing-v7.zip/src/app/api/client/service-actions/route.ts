import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { suspendServer, unsuspendServer, reinstallServer } from '@/lib/pterodactyl';

function getUserFromRequest(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload) return null;
  return payload;
}

const VALID_ACTIONS = ['start', 'stop', 'restart', 'reinstall', 'kill'] as const;
type ServiceAction = (typeof VALID_ACTIONS)[number];

function mapActionToPterodactyl(action: ServiceAction): string {
  const mapping: Record<ServiceAction, string> = {
    start: 'start',
    stop: 'suspend',
    restart: 'restart',
    reinstall: 'reinstall',
    kill: 'kill',
  };
  return mapping[action];
}

// POST — perform a service action (start, stop, restart, reinstall, kill)
export async function POST(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;
    const { serviceId, action } = await request.json();

    if (!serviceId || !action) {
      return NextResponse.json(
        { success: false, error: 'Service ID and action are required' },
        { status: 400 }
      );
    }

    if (!VALID_ACTIONS.includes(action as ServiceAction)) {
      return NextResponse.json(
        { success: false, error: `Invalid action. Valid actions: ${VALID_ACTIONS.join(', ')}` },
        { status: 400 }
      );
    }

    // Find the service and verify ownership
    const service = await db.service.findFirst({
      where: { id: serviceId, userId },
      include: { product: true },
    });

    if (!service) {
      return NextResponse.json(
        { success: false, error: 'Service not found or you do not have permission' },
        { status: 404 }
      );
    }

    if (service.status === 'terminated') {
      return NextResponse.json(
        { success: false, error: 'Cannot perform actions on a terminated service' },
        { status: 400 }
      );
    }

    const serviceAction = action as ServiceAction;

    // Call Pterodactyl API if server ID exists
    if (service.serverId) {
      try {
        switch (serviceAction) {
          case 'start':
            await unsuspendServer(service.serverId);
            break;
          case 'stop':
            await suspendServer(service.serverId);
            break;
          case 'restart':
            await suspendServer(service.serverId);
            await unsuspendServer(service.serverId);
            break;
          case 'reinstall':
            await reinstallServer(service.serverId);
            break;
          case 'kill':
            await suspendServer(service.serverId);
            break;
        }
      } catch (pterodactylError) {
        console.error('Pterodactyl action error:', pterodactylError);
        const errorMessage =
          pterodactylError instanceof Error
            ? pterodactylError.message
            : 'Pterodactyl API call failed';

        // Audit log for failed action
        await db.auditLog.create({
          data: {
            userId,
            action: `service_${serviceAction}_failed`,
            details: JSON.stringify({ serviceId, serverId: service.serverId, error: errorMessage }),
            ipAddress: request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || undefined,
          },
        });

        return NextResponse.json(
          { success: false, error: `Failed to ${action} service: ${errorMessage}` },
          { status: 502 }
        );
      }
    }

    // Update service status based on action
    const statusMap: Record<ServiceAction, string> = {
      start: 'active',
      stop: 'suspended',
      restart: 'active',
      reinstall: 'active',
      kill: 'suspended',
    };

    await db.service.update({
      where: { id: serviceId },
      data: { status: statusMap[serviceAction] },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId,
        action: `service_${serviceAction}`,
        details: JSON.stringify({
          serviceId,
          serverId: service.serverId,
          productName: service.product.name,
        }),
        ipAddress: request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || undefined,
        userAgent: request.headers.get('user-agent') || undefined,
      },
    });

    // Create notification
    await db.notification.create({
      data: {
        userId,
        title: `Service ${action}`,
        message: `Your service "${service.name}" (${service.product.name}) has been ${action}ed successfully.`,
        type: serviceAction === 'reinstall' ? 'warning' : 'info',
      },
    });

    return NextResponse.json({
      success: true,
      message: `Service ${action} action completed successfully`,
      data: {
        serviceId,
        action: serviceAction,
        newStatus: statusMap[serviceAction],
      },
    });
  } catch (error) {
    console.error('Service actions error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to perform service action' },
      { status: 500 }
    );
  }
}

// GET — list available actions for a service
export async function GET(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;
    const { searchParams } = new URL(request.url);
    const serviceId = searchParams.get('serviceId');

    if (!serviceId) {
      return NextResponse.json(
        { success: false, error: 'Service ID is required' },
        { status: 400 }
      );
    }

    const service = await db.service.findFirst({
      where: { id: serviceId, userId },
    });

    if (!service) {
      return NextResponse.json(
        { success: false, error: 'Service not found' },
        { status: 404 }
      );
    }

    // Determine available actions based on service status
    const availableActions: Array<{
      action: ServiceAction;
      label: string;
      description: string;
      available: boolean;
    }> = VALID_ACTIONS.map((a) => ({
      action: a,
      label: a.charAt(0).toUpperCase() + a.slice(1),
      description: `${a} the service`,
      available:
        service.status !== 'terminated' &&
        !(a === 'start' && service.status === 'active') &&
        !(a === 'stop' && service.status === 'suspended'),
    }));

    return NextResponse.json({
      success: true,
      data: {
        serviceId,
        currentStatus: service.status,
        actions: availableActions,
      },
    });
  } catch (error) {
    console.error('Service actions list error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch service actions' },
      { status: 500 }
    );
  }
}
