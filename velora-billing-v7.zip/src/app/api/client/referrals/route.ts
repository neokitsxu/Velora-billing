import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import crypto from 'crypto';

function getUserFromRequest(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload) return null;
  return payload;
}

// GET — get user's referral code and stats
export async function GET(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;

    // Look up referral code from settings
    const referralSetting = await db.setting.findUnique({
      where: { key: `referral_${userId}` },
    });

    let referralCode: string | null = null;
    let referralData: Record<string, unknown> = {};

    if (referralSetting) {
      try {
        referralData = JSON.parse(referralSetting.value);
        referralCode = referralData.code as string;
      } catch {
        referralCode = null;
      }
    }

    // Calculate referral stats from audit logs and users
    const referredUsers = await db.user.findMany({
      where: {
        AND: [
          { createdAt: { gt: new Date(0) } }, // all users
        ],
      },
      select: { id: true, createdAt: true },
    });

    // Count referrals from audit logs where action is 'referral_signup' and details contain userId
    const referralLogs = await db.auditLog.findMany({
      where: {
        action: 'referral_signup',
      },
    });

    const referralCount = referralLogs.filter((log) => {
      try {
        const details = JSON.parse(log.details || '{}');
        return details.referrerId === userId;
      } catch {
        return false;
      }
    }).length;

    return NextResponse.json({
      success: true,
      data: {
        referralCode,
        referralCount,
        totalEarnings: referralData.totalEarnings || 0,
        availableBalance: referralData.availableBalance || 0,
        hasReferralCode: !!referralCode,
      },
    });
  } catch (error) {
    console.error('Client referral error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch referral data' },
      { status: 500 }
    );
  }
}

// GET /stats — detailed referral statistics
export async function PUT(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;

    // Get all referral-related audit logs
    const clickLogs = await db.auditLog.findMany({
      where: {
        action: 'referral_click',
      },
    });

    const signupLogs = await db.auditLog.findMany({
      where: {
        action: 'referral_signup',
      },
    });

    const referralClicks = clickLogs.filter((log) => {
      try {
        const details = JSON.parse(log.details || '{}');
        return details.referrerId === userId;
      } catch {
        return false;
      }
    }).length;

    const referralSignups = signupLogs.filter((log) => {
      try {
        const details = JSON.parse(log.details || '{}');
        return details.referrerId === userId;
      } catch {
        return false;
      }
    });

    const referralSetting = await db.setting.findUnique({
      where: { key: `referral_${userId}` },
    });

    let totalEarnings = 0;
    if (referralSetting) {
      try {
        const data = JSON.parse(referralSetting.value);
        totalEarnings = (data.totalEarnings as number) || 0;
      } catch {
        totalEarnings = 0;
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        clicks: referralClicks,
        signups: referralSignups.length,
        conversions: referralSignups.length,
        conversionRate: referralClicks > 0
          ? Math.round((referralSignups.length / referralClicks) * 100 * 100) / 100
          : 0,
        totalEarnings,
        recentSignups: referralSignups.slice(-10).map((log) => ({
          id: log.id,
          date: log.createdAt,
          details: log.details,
        })),
      },
    });
  } catch (error) {
    console.error('Client referral stats error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch referral stats' },
      { status: 500 }
    );
  }
}

// POST — generate a referral code for the user
export async function POST(request: NextRequest) {
  try {
    const payload = getUserFromRequest(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const userId = payload.id as string;

    // Check if user already has a referral code
    const existing = await db.setting.findUnique({
      where: { key: `referral_${userId}` },
    });

    if (existing) {
      try {
        const data = JSON.parse(existing.value);
        return NextResponse.json({
          success: true,
          message: 'Referral code already exists',
          data: { code: data.code },
        });
      } catch {
        // Corrupted data — generate a new one
      }
    }

    // Generate referral code: VL-{first 8 chars of user id}-{random 4 chars}
    const randomPart = crypto.randomBytes(2).toString('hex').toUpperCase();
    const referralCode = `VL-${userId.substring(0, 8)}-${randomPart}`;

    // Check for uniqueness (shouldn't collide, but check anyway)
    const allReferrals = await db.setting.findMany({
      where: { group: 'referrals' },
    });
    const allCodes = new Set<string>();
    allReferrals.forEach((r) => {
      try {
        const data = JSON.parse(r.value);
        if (data.code) allCodes.add(data.code as string);
      } catch {
        // skip
      }
    });

    if (allCodes.has(referralCode)) {
      // Generate another code if collision occurs
      const fallbackRandom = crypto.randomBytes(4).toString('hex').toUpperCase();
      const newCode = `VL-${userId.substring(0, 8)}-${fallbackRandom}`;

      await db.setting.create({
        data: {
          key: `referral_${userId}`,
          value: JSON.stringify({
            code: newCode,
            totalEarnings: 0,
            availableBalance: 0,
            createdAt: new Date().toISOString(),
          }),
          group: 'referrals',
          type: 'json',
        },
      });

      return NextResponse.json({
        success: true,
        message: 'Referral code generated successfully',
        data: { code: newCode },
      });
    }

    await db.setting.create({
      data: {
        key: `referral_${userId}`,
        value: JSON.stringify({
          code: referralCode,
          totalEarnings: 0,
          availableBalance: 0,
          createdAt: new Date().toISOString(),
        }),
        group: 'referrals',
        type: 'json',
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId,
        action: 'referral_code_generated',
        details: JSON.stringify({ code: referralCode }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Referral code generated successfully',
      data: { code: referralCode },
    });
  } catch (error) {
    console.error('Client referral generate error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to generate referral code' },
      { status: 500 }
    );
  }
}
