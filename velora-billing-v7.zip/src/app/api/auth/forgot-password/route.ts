import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { hashPassword, verifyPassword, generateToken, verifyToken } from '@/lib/auth';
import crypto from 'crypto';

const RESET_TOKEN_SECRET = process.env.JWT_SECRET || 'velora-secret';

// POST /api/auth/forgot-password — initiate password reset
export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json(
        { success: false, error: 'Email is required' },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (!user) {
      // Always return success to prevent email enumeration
      return NextResponse.json({
        success: true,
        message: 'If an account with that email exists, a reset link has been sent.',
      });
    }

    if (user.status === 'banned') {
      return NextResponse.json({
        success: true,
        message: 'If an account with that email exists, a reset link has been sent.',
      });
    }

    // Generate a reset token stored as a Setting record
    const rawToken = crypto.randomBytes(32).toString('hex');
    const resetTokenKey = `password_reset_${user.id}`;

    // Store reset token hash and expiry (1 hour) in settings
    const tokenPayload = {
      userId: user.id,
      token: rawToken,
      exp: Date.now() + 60 * 60 * 1000, // 1 hour
    };

    const jwtToken = generateToken(tokenPayload);

    await db.setting.upsert({
      where: { key: resetTokenKey },
      update: {
        value: jwtToken,
        group: 'password_resets',
        type: 'text',
      },
      create: {
        key: resetTokenKey,
        value: jwtToken,
        group: 'password_resets',
        type: 'text',
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: user.id,
        action: 'password_reset_requested',
        details: JSON.stringify({ email: user.email }),
      },
    });

    // In production, you would send an email with the reset token here.
    // For now we include the token in the response (development only).
    return NextResponse.json({
      success: true,
      message: 'If an account with that email exists, a reset link has been sent.',
      // Dev only — remove in production:
      _devToken: rawToken,
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to process request' },
      { status: 500 }
    );
  }
}

// POST /api/auth/forgot-password?verify=1 — verify token and reset password
export async function PUT(request: NextRequest) {
  try {
    const { token, userId, newPassword } = await request.json();

    if (!token || !userId || !newPassword) {
      return NextResponse.json(
        { success: false, error: 'Token, user ID, and new password are required' },
        { status: 400 }
      );
    }

    if (newPassword.length < 8) {
      return NextResponse.json(
        { success: false, error: 'Password must be at least 8 characters long' },
        { status: 400 }
      );
    }

    // Look up the stored reset token
    const resetTokenKey = `password_reset_${userId}`;
    const stored = await db.setting.findUnique({
      where: { key: resetTokenKey },
    });

    if (!stored) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired reset token' },
        { status: 400 }
      );
    }

    // Verify the stored JWT contains the matching token
    const decoded = verifyToken(stored.value);
    if (!decoded) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired reset token' },
        { status: 400 }
      );
    }

    if ((decoded as any).token !== token) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired reset token' },
        { status: 400 }
      );
    }

    if ((decoded as any).exp && Date.now() > (decoded as any).exp) {
      // Clean up expired token
      await db.setting.delete({ where: { key: resetTokenKey } });
      return NextResponse.json(
        { success: false, error: 'Reset token has expired' },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Update password
    const hashedPassword = await hashPassword(newPassword);
    await db.user.update({
      where: { id: userId },
      data: { password: hashedPassword },
    });

    // Remove the used reset token
    await db.setting.delete({ where: { key: resetTokenKey } });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: user.id,
        action: 'password_reset_completed',
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Password has been reset successfully.',
    });
  } catch (error) {
    console.error('Password reset verification error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to reset password' },
      { status: 500 }
    );
  }
}
