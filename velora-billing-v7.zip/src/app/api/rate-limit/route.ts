import { NextResponse } from 'next/server';
import { clearRateLimits, getRateLimitStats } from '@/lib/rate-limit';

// GET — view rate limit stats (for admin/debug purposes)
export async function GET() {
  try {
    const stats = getRateLimitStats();
    return NextResponse.json({
      success: true,
      data: {
        totalEntries: stats.length,
        entries: stats,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch rate limit stats' },
      { status: 500 }
    );
  }
}

// DELETE — clear all rate limits (admin use)
export async function DELETE() {
  try {
    clearRateLimits();
    return NextResponse.json({
      success: true,
      message: 'All rate limits cleared',
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to clear rate limits' },
      { status: 500 }
    );
  }
}
