import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const group = searchParams.get('group');

    const where: any = {};
    if (group) where.group = group;

    const settings = await db.setting.findMany({ where });

    // Build nested object: { general: { siteName: '...', ... }, payment: { ... }, ... }
    const config: Record<string, Record<string, any>> = {
      general: {},
      payment: {},
      email: {},
      pterodactyl: {},
      notifications: {},
      security: {},
      api: {},
    };

    settings.forEach((s) => {
      let value: any = s.value;
      if (s.type === 'boolean') value = s.value === 'true';
      else if (s.type === 'number') value = parseFloat(s.value);
      else if (s.type === 'json') {
        try { value = JSON.parse(s.value); } catch { value = s.value; }
      }
      const grp = s.group || 'general';
      if (!config[grp]) config[grp] = {};
      config[grp][s.key] = value;
    });

    return NextResponse.json({ success: true, settings: config });
  } catch (error) {
    console.error('Admin settings error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { section, data } = body;

    if (!section || !data || typeof data !== 'object') {
      return NextResponse.json({ success: false, error: 'Section and data are required' }, { status: 400 });
    }

    // Map section to database group
    const groupMap: Record<string, string> = {
      general: 'general',
      payment: 'payment',
      email: 'email',
      pterodactyl: 'pterodactyl',
      notifications: 'notifications',
      security: 'security',
      api: 'api',
    };

    const group = groupMap[section] || section;

    // Upsert each key in the section
    for (const [key, value] of Object.entries(data)) {
      const strValue = String(value);
      const type = typeof value === 'boolean' ? 'boolean' : typeof value === 'number' ? 'number' : 'text';

      await db.setting.upsert({
        where: { key },
        update: { value: strValue, group, type },
        create: { key, value: strValue, group, type },
      });
    }

    // Audit log
    try {
      await db.auditLog.create({
        data: {
          userId: payload.id as string,
          action: 'settings_updated',
          details: JSON.stringify({ section, keys: Object.keys(data) }),
        },
      });
    } catch {}

    return NextResponse.json({ success: true, message: `${section} settings saved successfully` });
  } catch (error) {
    console.error('Admin settings update error:', error);
    return NextResponse.json({ success: false, error: 'Failed to update settings' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  return PUT(request);
}