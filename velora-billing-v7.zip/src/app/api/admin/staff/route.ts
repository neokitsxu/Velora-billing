import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken, hashPassword } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

// GET — list all staff users
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search');
    const status = searchParams.get('status');

    const where: Record<string, unknown> = {
      role: { in: ['admin', 'staff'] },
    };

    if (search) {
      (where as any).OR = [
        { name: { contains: search } },
        { email: { contains: search } },
      ];
    }

    if (status) {
      (where as any).status = status;
    }

    const [staff, total] = await Promise.all([
      db.user.findMany({
        where,
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          status: true,
          lastLogin: true,
          createdAt: true,
          _count: {
            select: {
              auditLogs: true,
              tickets: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.user.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        staff,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Admin staff list error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch staff' },
      { status: 500 }
    );
  }
}

// POST — create a new staff user
export async function POST(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { name, email, password, role } = await request.json();

    if (!name || !email || !password) {
      return NextResponse.json(
        { success: false, error: 'Name, email, and password are required' },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return NextResponse.json(
        { success: false, error: 'Password must be at least 8 characters long' },
        { status: 400 }
      );
    }

    const validRoles = ['admin', 'staff'];
    const assignedRole = validRoles.includes(role) ? role : 'staff';

    // Check if email already exists
    const existing = await db.user.findUnique({
      where: { email: email.toLowerCase() },
    });
    if (existing) {
      return NextResponse.json(
        { success: false, error: 'A user with this email already exists' },
        { status: 409 }
      );
    }

    const hashedPassword = await hashPassword(password);

    const staffUser = await db.user.create({
      data: {
        name,
        email: email.toLowerCase(),
        password: hashedPassword,
        role: assignedRole,
        status: 'active',
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        status: true,
        createdAt: true,
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'staff_created',
        details: JSON.stringify({ staffId: staffUser.id, email: staffUser.email, role: assignedRole }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Staff member created successfully',
      data: staffUser,
    });
  } catch (error) {
    console.error('Admin staff create error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create staff member' },
      { status: 500 }
    );
  }
}

// PUT — update staff member details
export async function PUT(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { userId, name, email, role, status } = await request.json();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'User ID is required' },
        { status: 400 }
      );
    }

    const staffUser = await db.user.findUnique({ where: { id: userId } });
    if (!staffUser) {
      return NextResponse.json(
        { success: false, error: 'Staff member not found' },
        { status: 404 }
      );
    }

    if (!['admin', 'staff'].includes(staffUser.role)) {
      return NextResponse.json(
        { success: false, error: 'User is not a staff member' },
        { status: 400 }
      );
    }

    const updateData: Record<string, unknown> = {};
    if (name) updateData.name = name;
    if (email) updateData.email = email.toLowerCase();
    if (role && ['admin', 'staff'].includes(role)) updateData.role = role;
    if (status && ['active', 'inactive', 'suspended'].includes(status)) updateData.status = status;

    const updated = await db.user.update({
      where: { id: userId },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        status: true,
        updatedAt: true,
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'staff_updated',
        details: JSON.stringify({ staffId: userId, updateData }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Staff member updated successfully',
      data: updated,
    });
  } catch (error) {
    console.error('Admin staff update error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update staff member' },
      { status: 500 }
    );
  }
}

// DELETE — soft-delete (deactivate) a staff member
export async function DELETE(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Prevent deleting yourself
    if (userId === payload.id) {
      return NextResponse.json(
        { success: false, error: 'You cannot deactivate your own account' },
        { status: 400 }
      );
    }

    const staffUser = await db.user.findUnique({ where: { id: userId } });
    if (!staffUser) {
      return NextResponse.json(
        { success: false, error: 'Staff member not found' },
        { status: 404 }
      );
    }

    if (!['admin', 'staff'].includes(staffUser.role)) {
      return NextResponse.json(
        { success: false, error: 'User is not a staff member' },
        { status: 400 }
      );
    }

    await db.user.update({
      where: { id: userId },
      data: { status: 'inactive' },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'staff_deactivated',
        details: JSON.stringify({ staffId: userId, email: staffUser.email }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Staff member deactivated successfully',
    });
  } catch (error) {
    console.error('Admin staff delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to deactivate staff member' },
      { status: 500 }
    );
  }
}
