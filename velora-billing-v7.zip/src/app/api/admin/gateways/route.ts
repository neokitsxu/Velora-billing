import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const settings = await db.setting.findMany({
      where: {
        OR: [
          { key: { startsWith: 'payment_upi' } },
          { key: { startsWith: 'payment_' } },
        ],
      },
    });

    const config: Record<string, string> = {};
    settings.forEach((s) => {
      config[s.key] = s.value;
    });

    return NextResponse.json({
      success: true,
      data: {
        upiId: config['payment_upi_id'] || '',
        upiEnabled: config['payment_upi_enabled'] || 'false',
        upiMerchantName: config['payment_upi_merchant_name'] || 'Velora Billing',
        upiMerchantCode: config['payment_upi_merchant_code'] || '',
        walletEnabled: config['payment_wallet_enabled'] || 'false',
      },
    });
  } catch (error) {
    console.error('Admin gateways error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch gateway settings' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const {
      upiId,
      upiEnabled,
      upiMerchantName,
      upiMerchantCode,
      walletEnabled,
    } = await request.json();

    // Upsert all UPI settings
    const settingsMap: Record<string, { key: string; value: string; group: string }> = {
      payment_upi_id: { key: 'payment_upi_id', value: upiId || '', group: 'payment' },
      payment_upi_enabled: { key: 'payment_upi_enabled', value: upiEnabled ? 'true' : 'false', group: 'payment' },
      payment_upi_merchant_name: { key: 'payment_upi_merchant_name', value: upiMerchantName || 'Velora Billing', group: 'payment' },
      payment_upi_merchant_code: { key: 'payment_upi_merchant_code', value: upiMerchantCode || '', group: 'payment' },
      payment_wallet_enabled: { key: 'payment_wallet_enabled', value: walletEnabled ? 'true' : 'false', group: 'payment' },
    };

    for (const setting of Object.values(settingsMap)) {
      await db.setting.upsert({
        where: { key: setting.key },
        update: { value: setting.value },
        create: { key: setting.key, value: setting.value, group: setting.group, type: 'text' },
      });
    }

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'gateway_settings_updated',
        details: JSON.stringify({ upiId, upiEnabled, upiMerchantName }),
      },
    });

    return NextResponse.json({ success: true, message: 'Gateway settings updated' });
  } catch (error) {
    console.error('Admin gateway update error:', error);
    return NextResponse.json({ success: false, error: 'Failed to update gateway settings' }, { status: 500 });
  }
}
