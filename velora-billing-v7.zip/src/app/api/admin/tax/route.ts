import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

const TAX_SETTINGS_KEYS = [
  'tax_enabled',
  'tax_percentage',
  'tax_name',
  'tax_inclusive',
];

// GET — get current tax configuration
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const settings = await db.setting.findMany({
      where: { key: { in: TAX_SETTINGS_KEYS } },
    });

    const taxConfig: Record<string, unknown> = {
      tax_enabled: false,
      tax_percentage: 0,
      tax_name: 'Tax',
      tax_inclusive: false,
    };

    settings.forEach((s) => {
      if (s.type === 'boolean') {
        taxConfig[s.key] = s.value === 'true';
      } else if (s.type === 'number') {
        taxConfig[s.key] = parseFloat(s.value);
      } else {
        taxConfig[s.key] = s.value;
      }
    });

    return NextResponse.json({ success: true, data: taxConfig });
  } catch (error) {
    console.error('Admin tax config error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch tax configuration' },
      { status: 500 }
    );
  }
}

// POST/PUT — update tax configuration
export async function PUT(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { tax_enabled, tax_percentage, tax_name, tax_inclusive } = body;

    // Validate inputs
    if (tax_percentage !== undefined && (tax_percentage < 0 || tax_percentage > 100)) {
      return NextResponse.json(
        { success: false, error: 'Tax percentage must be between 0 and 100' },
        { status: 400 }
      );
    }

    // Upsert each tax setting
    const updates: Array<{ key: string; value: string; type: string }> = [];

    if (tax_enabled !== undefined) {
      updates.push({ key: 'tax_enabled', value: String(tax_enabled), type: 'boolean' });
    }
    if (tax_percentage !== undefined) {
      updates.push({ key: 'tax_percentage', value: String(tax_percentage), type: 'number' });
    }
    if (tax_name !== undefined) {
      updates.push({ key: 'tax_name', value: String(tax_name), type: 'text' });
    }
    if (tax_inclusive !== undefined) {
      updates.push({ key: 'tax_inclusive', value: String(tax_inclusive), type: 'boolean' });
    }

    for (const update of updates) {
      await db.setting.upsert({
        where: { key: update.key },
        update: { value: update.value, group: 'tax', type: update.type },
        create: { key: update.key, value: update.value, group: 'tax', type: update.type },
      });
    }

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'tax_config_updated',
        details: JSON.stringify({ tax_enabled, tax_percentage, tax_name, tax_inclusive }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Tax configuration updated successfully',
    });
  } catch (error) {
    console.error('Admin tax config update error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update tax configuration' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  return PUT(request);
}
