import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status');
    const priority = searchParams.get('priority');
    const department = searchParams.get('department');

    const where: any = {};

    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (department) where.department = department;

    const [tickets, total] = await Promise.all([
      db.ticket.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true, avatar: true } },
          _count: { select: { replies: true } },
          replies: {
            take: 1,
            orderBy: { createdAt: 'desc' },
            select: { message: true, createdAt: true },
          },
        },
        orderBy: { updatedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.ticket.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        tickets,
        pagination: { page, limit, total, pages: Math.ceil(total / limit) },
      },
    });
  } catch (error) {
    console.error('Admin tickets error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch tickets' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { ticketId, action, message, priority } = await request.json();

    if (!ticketId) {
      return NextResponse.json({ success: false, error: 'Ticket ID is required' }, { status: 400 });
    }

    const ticket = await db.ticket.findUnique({ where: { id: ticketId } });
    if (!ticket) {
      return NextResponse.json({ success: false, error: 'Ticket not found' }, { status: 404 });
    }

    // Reply to ticket
    if (action === 'reply' && message) {
      const reply = await db.ticketReply.create({
        data: {
          ticketId,
          userId: payload.id as string,
          message,
          isStaff: true,
        },
      });

      await db.ticket.update({
        where: { id: ticketId },
        data: { status: 'in_progress' },
      });

      // Notify user
      await db.notification.create({
        data: {
          userId: ticket.userId,
          title: 'New Reply on Ticket',
          message: `Your ticket "${ticket.subject}" has received a new reply from staff.`,
          type: 'info',
        },
      });

      return NextResponse.json({ success: true, data: reply });
    }

    // Close ticket
    if (action === 'close') {
      const updated = await db.ticket.update({
        where: { id: ticketId },
        data: { status: 'closed' },
      });

      await db.notification.create({
        data: {
          userId: ticket.userId,
          title: 'Ticket Closed',
          message: `Your ticket "${ticket.subject}" has been closed.`,
          type: 'info',
        },
      });

      // Audit log
      await db.auditLog.create({
        data: {
          userId: payload.id as string,
          action: 'ticket_closed',
          details: JSON.stringify({ ticketId, subject: ticket.subject }),
        },
      });

      return NextResponse.json({ success: true, data: updated });
    }

    // Update priority
    if (action === 'update_priority' && priority) {
      const updated = await db.ticket.update({
        where: { id: ticketId },
        data: { priority },
      });
      return NextResponse.json({ success: true, data: updated });
    }

    return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('Admin ticket action error:', error);
    return NextResponse.json({ success: false, error: 'Failed to process ticket action' }, { status: 500 });
  }
}
