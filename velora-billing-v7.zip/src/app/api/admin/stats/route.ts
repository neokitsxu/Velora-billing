import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    // Parallel queries
    const [
      totalUsers,
      totalOrders,
      totalRevenue,
      totalServices,
      activeServices,
      pendingOrders,
      recentOrders,
      monthlyRevenue,
      recentUsers,
      openTickets,
      pendingPayments,
    ] = await Promise.all([
      db.user.count({ where: { role: 'client' } }),
      db.order.count(),
      db.order.aggregate({ where: { status: 'paid' }, _sum: { amount: true } }),
      db.service.count(),
      db.service.count({ where: { status: 'active' } }),
      db.order.count({ where: { status: 'pending' } }),
      db.order.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
      db.order.aggregate({
        where: { status: 'paid', paidAt: { gte: thirtyDaysAgo } },
        _sum: { amount: true },
      }),
      db.user.count({ where: { role: 'client', createdAt: { gte: sevenDaysAgo } } }),
      db.ticket.count({ where: { status: { in: ['open', 'in_progress'] } } }),
      db.upiPayment.count({ where: { status: 'pending' } }),
    ]);

    // Revenue chart data (last 7 days)
    const revenueByDay: Array<{ date: string; revenue: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const dayStart = new Date(now);
      dayStart.setDate(dayStart.getDate() - i);
      dayStart.setHours(0, 0, 0, 0);

      const dayEnd = new Date(dayStart);
      dayEnd.setHours(23, 59, 59, 999);

      const dayRevenue = await db.order.aggregate({
        where: { status: 'paid', paidAt: { gte: dayStart, lte: dayEnd } },
        _sum: { amount: true },
      });

      revenueByDay.push({
        date: dayStart.toISOString().split('T')[0],
        revenue: dayRevenue._sum.amount || 0,
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        totalUsers,
        totalOrders,
        totalRevenue: totalRevenue._sum.amount || 0,
        totalServices,
        activeServices,
        pendingOrders,
        recentOrders,
        monthlyRevenue: monthlyRevenue._sum.amount || 0,
        recentUsers,
        openTickets,
        pendingPayments,
        revenueByDay,
      },
    });
  } catch (error) {
    console.error('Admin stats error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch stats' }, { status: 500 });
  }
}
