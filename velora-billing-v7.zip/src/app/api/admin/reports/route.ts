import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

// GET — generate reports (revenue, clients, orders by date range)
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'revenue';
    const fromStr = searchParams.get('from');
    const toStr = searchParams.get('to');
    const format = searchParams.get('format') || 'json'; // json or csv-like structure

    // Parse date range
    const to = toStr ? new Date(toStr) : new Date();
    const from = fromStr
      ? new Date(fromStr)
      : new Date(to.getTime() - 30 * 24 * 60 * 60 * 1000); // Default: last 30 days

    if (isNaN(from.getTime()) || isNaN(to.getTime())) {
      return NextResponse.json(
        { success: false, error: 'Invalid date range. Use ISO format (YYYY-MM-DD)' },
        { status: 400 }
      );
    }

    if (from > to) {
      return NextResponse.json(
        { success: false, error: 'Start date must be before end date' },
        { status: 400 }
      );
    }

    switch (type) {
      case 'revenue': {
        const [paidOrders, totalRevenue, invoices] = await Promise.all([
          db.order.findMany({
            where: {
              status: 'paid',
              paidAt: { gte: from, lte: to },
            },
            orderBy: { paidAt: 'asc' },
          }),
          db.order.aggregate({
            where: { status: 'paid', paidAt: { gte: from, lte: to } },
            _sum: { amount: true },
          }),
          db.invoice.aggregate({
            where: { status: 'paid', paidAt: { gte: from, lte: to } },
            _sum: { total: true },
          }),
        ]);

        // Group revenue by day
        const revenueByDay: Record<string, number> = {};
        paidOrders.forEach((order) => {
          if (order.paidAt) {
            const day = order.paidAt.toISOString().split('T')[0];
            revenueByDay[day] = (revenueByDay[day] || 0) + order.amount;
          }
        });

        // Group revenue by month
        const revenueByMonth: Record<string, number> = {};
        paidOrders.forEach((order) => {
          if (order.paidAt) {
            const month = order.paidAt.toISOString().substring(0, 7);
            revenueByMonth[month] = (revenueByMonth[month] || 0) + order.amount;
          }
        });

        // Payment method breakdown
        const byPaymentMethod: Record<string, number> = {};
        paidOrders.forEach((order) => {
          const method = order.paymentMethod || 'unknown';
          byPaymentMethod[method] = (byPaymentMethod[method] || 0) + order.amount;
        });

        return NextResponse.json({
          success: true,
          data: {
            type: 'revenue',
            dateRange: { from: from.toISOString(), to: to.toISOString() },
            summary: {
              totalRevenue: totalRevenue._sum.amount || 0,
              totalOrders: paidOrders.length,
              averageOrderValue: paidOrders.length > 0
                ? Math.round(((totalRevenue._sum.amount || 0) / paidOrders.length) * 100) / 100
                : 0,
              invoiceTotal: invoices._sum.total || 0,
            },
            revenueByDay,
            revenueByMonth,
            byPaymentMethod,
            orders: paidOrders.map((o) => ({
              id: o.id,
              orderNumber: o.orderNumber,
              amount: o.amount,
              paymentMethod: o.paymentMethod,
              paidAt: o.paidAt,
            })),
          },
        });
      }

      case 'clients': {
        const [newClients, totalClients, clientStats] = await Promise.all([
          db.user.findMany({
            where: {
              role: 'client',
              createdAt: { gte: from, lte: to },
            },
            orderBy: { createdAt: 'asc' },
            select: {
              id: true,
              name: true,
              email: true,
              status: true,
              balance: true,
              totalSpent: true,
              createdAt: true,
              lastLogin: true,
            },
          }),
          db.user.count({ where: { role: 'client' } }),
          db.user.aggregate({
            where: { role: 'client', createdAt: { gte: from, lte: to } },
            _sum: { totalSpent: true },
            _avg: { totalSpent: true },
          }),
        ]);

        // Group new clients by day
        const clientsByDay: Record<string, number> = {};
        newClients.forEach((client) => {
          const day = client.createdAt.toISOString().split('T')[0];
          clientsByDay[day] = (clientsByDay[day] || 0) + 1;
        });

        // Client status breakdown
        const byStatus: Record<string, number> = {};
        newClients.forEach((client) => {
          byStatus[client.status] = (byStatus[client.status] || 0) + 1;
        });

        return NextResponse.json({
          success: true,
          data: {
            type: 'clients',
            dateRange: { from: from.toISOString(), to: to.toISOString() },
            summary: {
              newClients: newClients.length,
              totalClients,
              totalSpent: clientStats._sum.totalSpent || 0,
              averageSpent: clientStats._avg.totalSpent
                ? Math.round(clientStats._avg.totalSpent * 100) / 100
                : 0,
            },
            clientsByDay,
            byStatus,
            clients: newClients,
          },
        });
      }

      case 'orders': {
        const [orders, orderStats, byStatusAgg] = await Promise.all([
          db.order.findMany({
            where: { createdAt: { gte: from, lte: to } },
            orderBy: { createdAt: 'desc' },
            include: { user: { select: { name: true, email: true } } },
          }),
          db.order.aggregate({
            where: { createdAt: { gte: from, lte: to } },
            _sum: { amount: true },
            _count: true,
          }),
          db.$queryRaw<Array<{ status: string; _count: bigint }>>`
            SELECT status, COUNT(*) as _count
            FROM "Order"
            WHERE "createdAt" >= ${from} AND "createdAt" <= ${to}
            GROUP BY status
          `,
        ]);

        // Group orders by day
        const ordersByDay: Record<string, number> = {};
        orders.forEach((order) => {
          const day = order.createdAt.toISOString().split('T')[0];
          ordersByDay[day] = (ordersByDay[day] || 0) + 1;
        });

        const byStatus: Record<string, number> = {};
        byStatusAgg.forEach((row) => {
          byStatus[row.status] = Number(row._count);
        });

        return NextResponse.json({
          success: true,
          data: {
            type: 'orders',
            dateRange: { from: from.toISOString(), to: to.toISOString() },
            summary: {
              totalOrders: orders.length,
              totalAmount: orderStats._sum.amount || 0,
              averageAmount: orders.length > 0
                ? Math.round(((orderStats._sum.amount || 0) / orders.length) * 100) / 100
                : 0,
            },
            ordersByDay,
            byStatus,
            orders: orders.map((o) => ({
              id: o.id,
              orderNumber: o.orderNumber,
              amount: o.amount,
              status: o.status,
              paymentMethod: o.paymentMethod,
              createdAt: o.createdAt,
              customerName: o.user.name,
              customerEmail: o.user.email,
            })),
          },
        });
      }

      default: {
        return NextResponse.json(
          { success: false, error: `Invalid report type: ${type}. Use: revenue, clients, orders` },
          { status: 400 }
        );
      }
    }
  } catch (error) {
    console.error('Admin reports error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to generate report' },
      { status: 500 }
    );
  }
}
