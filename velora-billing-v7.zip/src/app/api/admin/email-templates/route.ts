import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

const DEFAULT_TEMPLATES = [
  {
    key: 'welcome_email',
    subject: 'Welcome to {{site_name}}!',
    body: '<h1>Welcome aboard!</h1><p>Thank you for joining {{site_name}}. Your account has been created successfully.</p><p>Best regards,<br/>The {{site_name}} Team</p>',
    type: 'transactional',
  },
  {
    key: 'order_confirmation',
    subject: 'Order Confirmed - #{{order_number}}',
    body: '<h1>Order Confirmed</h1><p>Your order <strong>#{{order_number}}</strong> has been confirmed.</p><p>Amount: {{order_amount}}</p><p>Thank you for your purchase!</p>',
    type: 'transactional',
  },
  {
    key: 'payment_received',
    subject: 'Payment Received - #{{invoice_number}}',
    body: '<h1>Payment Received</h1><p>We have received your payment of <strong>{{payment_amount}}</strong> for invoice <strong>#{{invoice_number}}</strong>.</p><p>Thank you!</p>',
    type: 'transactional',
  },
  {
    key: 'invoice_reminder',
    subject: 'Invoice Reminder - #{{invoice_number}}',
    body: '<h1>Invoice Reminder</h1><p>This is a reminder that invoice <strong>#{{invoice_number}}</strong> for <strong>{{invoice_amount}}</strong> is due on <strong>{{due_date}}</strong>.</p><p>Please make your payment to avoid any service interruptions.</p>',
    type: 'notification',
  },
  {
    key: 'password_reset',
    subject: 'Password Reset Request',
    body: '<h1>Password Reset</h1><p>You requested a password reset. Click the link below to reset your password:</p><p><a href="{{reset_url}}">Reset Password</a></p><p>If you did not request this, please ignore this email.</p>',
    type: 'transactional',
  },
  {
    key: 'ticket_reply',
    subject: 'New Reply to Ticket #{{ticket_id}}',
    body: '<h1>New Reply</h1><p>A new reply has been posted to your ticket <strong>#{{ticket_id}}</strong>: <em>{{ticket_subject}}</em></p><blockquote>{{reply_message}}</blockquote>',
    type: 'notification',
  },
];

// GET — list email templates
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const templateSettings = await db.setting.findMany({
      where: { group: 'email_templates' },
    });

    const templates: Array<{ id: string; key: string; subject?: string; body?: string; type?: string; [k: string]: unknown }> = templateSettings.map((s) => {
      let parsed: Record<string, unknown> = {};
      try {
        parsed = JSON.parse(s.value);
      } catch {
        parsed = { body: s.value };
      }
      return {
        id: s.key,
        key: s.key,
        ...parsed,
      };
    });

    // Seed default templates that don't exist yet
    const existingKeys = new Set(templates.map((t) => t.key));
    const missingDefaults = DEFAULT_TEMPLATES.filter((dt) => !existingKeys.has(dt.key));

    for (const dt of missingDefaults) {
      await db.setting.create({
        data: {
          key: dt.key,
          value: JSON.stringify({
            subject: dt.subject,
            body: dt.body,
            type: dt.type,
          }),
          group: 'email_templates',
          type: 'json',
        },
      });
      templates.push({
        id: dt.key,
        key: dt.key,
        subject: dt.subject,
        body: dt.body,
        type: dt.type,
      });
    }

    return NextResponse.json({ success: true, data: templates });
  } catch (error) {
    console.error('Admin email templates error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch email templates' },
      { status: 500 }
    );
  }
}

// POST — create a new email template
export async function POST(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { key, subject, body, type } = await request.json();

    if (!key || !subject || !body) {
      return NextResponse.json(
        { success: false, error: 'Template key, subject, and body are required' },
        { status: 400 }
      );
    }

    // Check if template already exists
    const existing = await db.setting.findUnique({ where: { key } });
    if (existing) {
      return NextResponse.json(
        { success: false, error: 'A template with this key already exists. Use PUT to update it.' },
        { status: 409 }
      );
    }

    const templateData = {
      subject,
      body,
      type: type || 'transactional',
    };

    const setting = await db.setting.create({
      data: {
        key,
        value: JSON.stringify(templateData),
        group: 'email_templates',
        type: 'json',
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'email_template_created',
        details: JSON.stringify({ key }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Email template created successfully',
      data: { id: setting.key, key, ...templateData },
    });
  } catch (error) {
    console.error('Admin email template create error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create email template' },
      { status: 500 }
    );
  }
}

// PUT — update an email template
export async function PUT(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { key, subject, body, type } = await request.json();

    if (!key) {
      return NextResponse.json(
        { success: false, error: 'Template key is required' },
        { status: 400 }
      );
    }

    const existing = await db.setting.findUnique({ where: { key } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Template not found' },
        { status: 404 }
      );
    }

    let currentData: Record<string, unknown> = {};
    try {
      currentData = JSON.parse(existing.value);
    } catch {
      currentData = { body: existing.value };
    }

    const updatedData = {
      subject: subject || currentData.subject,
      body: body || currentData.body,
      type: type || currentData.type,
    };

    await db.setting.update({
      where: { key },
      data: { value: JSON.stringify(updatedData) },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'email_template_updated',
        details: JSON.stringify({ key, updatedData }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Email template updated successfully',
      data: { id: key, key, ...updatedData },
    });
  } catch (error) {
    console.error('Admin email template update error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update email template' },
      { status: 500 }
    );
  }
}

// DELETE — delete an email template
export async function DELETE(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const key = searchParams.get('key');

    if (!key) {
      return NextResponse.json(
        { success: false, error: 'Template key is required' },
        { status: 400 }
      );
    }

    const existing = await db.setting.findUnique({ where: { key } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Template not found' },
        { status: 404 }
      );
    }

    await db.setting.delete({ where: { key } });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'email_template_deleted',
        details: JSON.stringify({ key }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Email template deleted successfully',
    });
  } catch (error) {
    console.error('Admin email template delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete email template' },
      { status: 500 }
    );
  }
}
