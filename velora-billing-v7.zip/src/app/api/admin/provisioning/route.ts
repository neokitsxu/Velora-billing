import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

// GET — list provisioning jobs
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status');
    const type = searchParams.get('type');

    const where: Record<string, unknown> = {};

    if (status && ['pending', 'processing', 'completed', 'failed'].includes(status)) {
      where.status = status;
    }

    if (type && ['create', 'suspend', 'terminate', 'reinstall'].includes(type)) {
      where.type = type;
    }

    const [jobs, total] = await Promise.all([
      db.provisioningJob.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.provisioningJob.count({ where }),
    ]);

    const parsedJobs = jobs.map((job) => ({
      ...job,
      payload: job.payload ? JSON.parse(job.payload) : null,
      result: job.result ? JSON.parse(job.result) : null,
    }));

    return NextResponse.json({
      success: true,
      data: {
        jobs: parsedJobs,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Admin provisioning jobs error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch provisioning jobs' },
      { status: 500 }
    );
  }
}

// POST — create / retry / cancel provisioning jobs
export async function POST(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { action, jobId, type, orderId, payload: jobPayload } = await request.json();

    switch (action) {
      case 'retry': {
        if (!jobId) {
          return NextResponse.json(
            { success: false, error: 'Job ID is required for retry' },
            { status: 400 }
          );
        }

        const job = await db.provisioningJob.findUnique({ where: { id: jobId } });
        if (!job) {
          return NextResponse.json(
            { success: false, error: 'Provisioning job not found' },
            { status: 404 }
          );
        }

        if (job.status !== 'failed') {
          return NextResponse.json(
            { success: false, error: 'Only failed jobs can be retried' },
            { status: 400 }
          );
        }

        const retried = await db.provisioningJob.update({
          where: { id: jobId },
          data: {
            status: 'pending',
            attempts: { increment: 1 },
            error: null,
          },
        });

        // Audit log
        await db.auditLog.create({
          data: {
            userId: payload.id as string,
            action: 'provisioning_job_retried',
            details: JSON.stringify({ jobId, orderId: job.orderId }),
          },
        });

        return NextResponse.json({
          success: true,
          message: 'Provisioning job queued for retry',
          data: retried,
        });
      }

      case 'cancel': {
        if (!jobId) {
          return NextResponse.json(
            { success: false, error: 'Job ID is required for cancel' },
            { status: 400 }
          );
        }

        const job = await db.provisioningJob.findUnique({ where: { id: jobId } });
        if (!job) {
          return NextResponse.json(
            { success: false, error: 'Provisioning job not found' },
            { status: 404 }
          );
        }

        if (!['pending', 'failed'].includes(job.status)) {
          return NextResponse.json(
            { success: false, error: 'Only pending or failed jobs can be cancelled' },
            { status: 400 }
          );
        }

        const cancelled = await db.provisioningJob.update({
          where: { id: jobId },
          data: { status: 'failed', error: 'Cancelled by admin' },
        });

        // Audit log
        await db.auditLog.create({
          data: {
            userId: payload.id as string,
            action: 'provisioning_job_cancelled',
            details: JSON.stringify({ jobId, orderId: job.orderId }),
          },
        });

        return NextResponse.json({
          success: true,
          message: 'Provisioning job cancelled',
          data: cancelled,
        });
      }

      case 'create': {
        if (!orderId || !type) {
          return NextResponse.json(
            { success: false, error: 'Order ID and type are required' },
            { status: 400 }
          );
        }

        const newJob = await db.provisioningJob.create({
          data: {
            orderId,
            type,
            payload: jobPayload ? JSON.stringify(jobPayload) : null,
            status: 'pending',
            attempts: 0,
          },
        });

        // Audit log
        await db.auditLog.create({
          data: {
            userId: payload.id as string,
            action: 'provisioning_job_created',
            details: JSON.stringify({ jobId: newJob.id, orderId, type }),
          },
        });

        return NextResponse.json({
          success: true,
          message: 'Provisioning job created',
          data: newJob,
        });
      }

      default: {
        return NextResponse.json(
          { success: false, error: 'Invalid action. Use: retry, cancel, or create.' },
          { status: 400 }
        );
      }
    }
  } catch (error) {
    console.error('Admin provisioning jobs error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to process provisioning job' },
      { status: 500 }
    );
  }
}
