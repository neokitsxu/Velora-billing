import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status');
    const search = searchParams.get('search');

    const where: any = {};

    if (status) where.status = status;

    if (search) {
      where.OR = [
        { orderNumber: { contains: search } },
        { user: { name: { contains: search } } },
        { user: { email: { contains: search } } },
      ];
    }

    const [orders, total] = await Promise.all([
      db.order.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true } },
          product: { select: { id: true, name: true, type: true } },
          invoice: true,
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.order.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        orders,
        pagination: { page, limit, total, pages: Math.ceil(total / limit) },
      },
    });
  } catch (error) {
    console.error('Admin orders error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch orders' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { orderId, action } = await request.json();

    if (!orderId || !action) {
      return NextResponse.json({ success: false, error: 'Order ID and action are required' }, { status: 400 });
    }

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: { user: true, invoice: true },
    });

    if (!order) {
      return NextResponse.json({ success: false, error: 'Order not found' }, { status: 404 });
    }

    const updateData: any = {};

    if (action === 'mark_paid') {
      updateData.status = 'paid';
      updateData.paidAt = new Date();

      // Update invoice
      if (order.invoice) {
        await db.invoice.update({
          where: { id: order.invoice.id },
          data: { status: 'paid', paidAt: new Date() },
        });
      }

      // Update user totalSpent
      await db.user.update({
        where: { id: order.userId },
        data: { totalSpent: { increment: order.amount } },
      });

      // Notify user
      await db.notification.create({
        data: {
          userId: order.userId,
          title: 'Order Paid',
          message: `Your order ${order.orderNumber} has been marked as paid.`,
          type: 'success',
        },
      });
    } else if (action === 'refund') {
      updateData.status = 'refunded';

      // Credit user balance
      await db.user.update({
        where: { id: order.userId },
        data: { balance: { increment: order.amount } },
      });

      await db.walletTransaction.create({
        data: {
          userId: order.userId,
          type: 'refund',
          amount: order.amount,
          balance: order.user.balance + order.amount,
          description: `Refund for order ${order.orderNumber}`,
          method: 'admin',
          status: 'completed',
        },
      });

      await db.notification.create({
        data: {
          userId: order.userId,
          title: 'Order Refunded',
          message: `Your order ${order.orderNumber} has been refunded. ₹${order.amount} has been added to your wallet.`,
          type: 'info',
        },
      });
    } else if (action === 'cancel') {
      updateData.status = 'cancelled';

      if (order.invoice) {
        await db.invoice.update({
          where: { id: order.invoice.id },
          data: { status: 'cancelled' },
        });
      }
    } else {
      return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
    }

    const updated = await db.order.update({
      where: { id: orderId },
      data: updateData,
      include: { user: true, product: true, invoice: true },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: `order_${action}`,
        details: JSON.stringify({ orderId, action, orderNumber: order.orderNumber }),
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error('Admin order update error:', error);
    return NextResponse.json({ success: false, error: 'Failed to update order' }, { status: 500 });
  }
}
