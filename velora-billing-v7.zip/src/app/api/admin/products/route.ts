import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const category = searchParams.get('category');

    const where: any = {};

    if (type) where.type = type;
    if (category) where.categories = { some: { slug: category } };

    const products = await db.product.findMany({
      where,
      include: {
        categories: true,
        _count: { select: { orders: true } },
      },
      orderBy: { sortOrder: 'asc' },
    });

    return NextResponse.json({ success: true, data: products });
  } catch (error) {
    console.error('Admin products error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch products' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const {
      name,
      description,
      slug,
      type,
      price,
      billingCycle,
      stock,
      features,
      image,
      cpu,
      ram,
      disk,
      bandwidth,
      slots,
      nestId,
      eggId,
      nodeId,
      sortOrder,
      categoryIds,
    } = await request.json();

    if (!name || !slug || !type || price === undefined) {
      return NextResponse.json({ success: false, error: 'Name, slug, type, and price are required' }, { status: 400 });
    }

    const existing = await db.product.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json({ success: false, error: 'Product slug already exists' }, { status: 409 });
    }

    const product = await db.product.create({
      data: {
        name,
        description,
        slug,
        type,
        price,
        billingCycle: billingCycle || 'monthly',
        stock: stock ?? -1,
        features: features ? JSON.stringify(features) : null,
        image,
        cpu,
        ram,
        disk,
        bandwidth,
        slots,
        nestId,
        eggId,
        nodeId,
        sortOrder: sortOrder || 0,
        categories: categoryIds
          ? {
              connect: categoryIds.map((id: string) => ({ id })),
            }
          : undefined,
      },
      include: { categories: true },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'product_created',
        details: JSON.stringify({ productId: product.id, name }),
      },
    });

    return NextResponse.json({ success: true, data: product }, { status: 201 });
  } catch (error) {
    console.error('Admin product create error:', error);
    return NextResponse.json({ success: false, error: 'Failed to create product' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { id, ...updateData } = await request.json();

    if (!id) {
      return NextResponse.json({ success: false, error: 'Product ID is required' }, { status: 400 });
    }

    if (updateData.features && Array.isArray(updateData.features)) {
      updateData.features = JSON.stringify(updateData.features);
    }

    if (updateData.categoryIds) {
      const { categoryIds, ...rest } = updateData;
      await db.product.update({
        where: { id },
        data: {
          ...rest,
          categories: {
            set: categoryIds.map((cid: string) => ({ id: cid })),
          },
        },
        include: { categories: true },
      });
    } else {
      await db.product.update({ where: { id }, data: updateData });
    }

    return NextResponse.json({ success: true, message: 'Product updated' });
  } catch (error) {
    console.error('Admin product update error:', error);
    return NextResponse.json({ success: false, error: 'Failed to update product' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ success: false, error: 'Product ID is required' }, { status: 400 });
    }

    // Check for active orders
    const activeOrders = await db.order.count({
      where: { productId: id, status: { in: ['pending', 'paid'] } },
    });

    if (activeOrders > 0) {
      return NextResponse.json({
        success: false,
        error: `Cannot delete product with ${activeOrders} active orders`,
      }, { status: 400 });
    }

    await db.product.delete({ where: { id } });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'product_deleted',
        details: JSON.stringify({ productId: id }),
      },
    });

    return NextResponse.json({ success: true, message: 'Product deleted' });
  } catch (error) {
    console.error('Admin product delete error:', error);
    return NextResponse.json({ success: false, error: 'Failed to delete product' }, { status: 500 });
  }
}
