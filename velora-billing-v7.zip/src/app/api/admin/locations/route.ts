import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

// GET — list locations (from Setting model, group='locations')
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const locationSettings = await db.setting.findMany({
      where: { group: 'locations' },
      orderBy: { key: 'asc' },
    });

    const locations = locationSettings.map((s) => {
      let parsed: Record<string, unknown> = {};
      try {
        parsed = JSON.parse(s.value);
      } catch {
        parsed = { name: s.value };
      }
      return {
        id: s.key,
        ...parsed,
      };
    });

    return NextResponse.json({ success: true, data: locations });
  } catch (error) {
    console.error('Admin locations error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch locations' },
      { status: 500 }
    );
  }
}

// POST — create a new location
export async function POST(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { name, code, description, flag } = await request.json();

    if (!name || !code) {
      return NextResponse.json(
        { success: false, error: 'Location name and code are required' },
        { status: 400 }
      );
    }

    const key = `location_${code.toLowerCase().replace(/\s+/g, '_')}`;

    // Check for existing location
    const existing = await db.setting.findUnique({ where: { key } });
    if (existing) {
      return NextResponse.json(
        { success: false, error: 'A location with this code already exists' },
        { status: 409 }
      );
    }

    const locationData = {
      name,
      code,
      description: description || '',
      flag: flag || '',
    };

    const setting = await db.setting.create({
      data: {
        key,
        value: JSON.stringify(locationData),
        group: 'locations',
        type: 'json',
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'location_created',
        details: JSON.stringify({ key, name, code }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Location created successfully',
      data: { id: setting.key, ...locationData },
    });
  } catch (error) {
    console.error('Admin location create error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create location' },
      { status: 500 }
    );
  }
}

// PUT — update a location
export async function PUT(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { id, name, code, description, flag } = await request.json();

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Location ID is required' },
        { status: 400 }
      );
    }

    const existing = await db.setting.findUnique({ where: { key: id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Location not found' },
        { status: 404 }
      );
    }

    let currentData: Record<string, unknown> = {};
    try {
      currentData = JSON.parse(existing.value);
    } catch {
      currentData = { name: existing.value };
    }

    const updatedData = {
      name: name || currentData.name,
      code: code || currentData.code,
      description: description !== undefined ? description : currentData.description,
      flag: flag !== undefined ? flag : currentData.flag,
    };

    await db.setting.update({
      where: { key: id },
      data: {
        value: JSON.stringify(updatedData),
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'location_updated',
        details: JSON.stringify({ key: id, updatedData }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Location updated successfully',
      data: { id, ...updatedData },
    });
  } catch (error) {
    console.error('Admin location update error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update location' },
      { status: 500 }
    );
  }
}

// DELETE — delete a location
export async function DELETE(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Location ID is required' },
        { status: 400 }
      );
    }

    const existing = await db.setting.findUnique({ where: { key: id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Location not found' },
        { status: 404 }
      );
    }

    await db.setting.delete({ where: { key: id } });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'location_deleted',
        details: JSON.stringify({ key: id }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Location deleted successfully',
    });
  } catch (error) {
    console.error('Admin location delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete location' },
      { status: 500 }
    );
  }
}
