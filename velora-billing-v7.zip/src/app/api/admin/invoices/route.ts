import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status');
    const search = searchParams.get('search');

    const where: any = {};

    if (status) where.status = status;

    if (search) {
      where.OR = [
        { invoiceNumber: { contains: search } },
        { user: { name: { contains: search } } },
        { user: { email: { contains: search } } },
      ];
    }

    const [invoices, total] = await Promise.all([
      db.invoice.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true } },
          order: { include: { product: { select: { name: true } } } },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.invoice.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        invoices,
        pagination: { page, limit, total, pages: Math.ceil(total / limit) },
      },
    });
  } catch (error) {
    console.error('Admin invoices error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch invoices' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { invoiceId, status: newStatus } = await request.json();

    if (!invoiceId || !newStatus) {
      return NextResponse.json({ success: false, error: 'Invoice ID and status are required' }, { status: 400 });
    }

    const validStatuses = ['unpaid', 'paid', 'overdue', 'cancelled'];
    if (!validStatuses.includes(newStatus)) {
      return NextResponse.json({ success: false, error: 'Invalid status' }, { status: 400 });
    }

    const updateData: any = { status: newStatus };

    if (newStatus === 'paid') {
      updateData.paidAt = new Date();
    }

    const invoice = await db.invoice.update({
      where: { id: invoiceId },
      data: updateData,
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'invoice_status_updated',
        details: JSON.stringify({ invoiceId, newStatus, invoiceNumber: invoice.invoiceNumber }),
      },
    });

    return NextResponse.json({ success: true, data: invoice });
  } catch (error) {
    console.error('Admin invoice update error:', error);
    return NextResponse.json({ success: false, error: 'Failed to update invoice' }, { status: 500 });
  }
}