import { PrismaClient } from '@prisma/client';
import { NextRequest, NextResponse } from 'next/server';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get('authorization')?.replace('Bearer ', '');
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const startTime = Date.now();
    await prisma.$queryRaw`SELECT 1`;
    const dbLatency = Date.now() - startTime;

    const totalClients = await prisma.user.count({ where: { role: 'client' } });
    const totalOrders = await prisma.order.count();
    const activeServices = await prisma.service.count({ where: { status: 'active' } });
    const openTickets = await prisma.ticket.count({ where: { status: 'open' } });
    const pendingPayments = await prisma.upiPayment.count({ where: { status: 'pending' } });
    const totalRevenue = await prisma.walletTransaction.aggregate({ _sum: { amount: true }, where: { type: 'credit', status: 'completed' } });
    const totalNodes = await prisma.serverNode.count();

    const healthStatus = dbLatency < 100 ? 'healthy' : dbLatency < 500 ? 'degraded' : 'unhealthy';

    return NextResponse.json({
      status: healthStatus,
      uptime: process.uptime(),
      database: { status: dbLatency < 100 ? 'connected' : 'slow', latency: `${dbLatency}ms`, type: 'SQLite' },
      stats: { totalClients, totalOrders, activeServices, openTickets, pendingPayments, totalRevenue: totalRevenue._sum.amount || 0, totalNodes },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json({ status: 'error', database: { status: 'disconnected' }, stats: {}, timestamp: new Date().toISOString() }, { status: 500 });
  }
}
