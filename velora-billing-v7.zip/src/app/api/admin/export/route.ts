import { PrismaClient } from '@prisma/client';
import { NextRequest, NextResponse } from 'next/server';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const token = req.headers.get('authorization')?.replace('Bearer ', '');
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const type = req.nextUrl.searchParams.get('type') || 'clients';
    const format = req.nextUrl.searchParams.get('format') || 'json';

    let data: any[] = [];

    switch (type) {
      case 'clients':
        data = await prisma.user.findMany({ select: { id: true, name: true, email: true, role: true, balance: true, createdAt: true } });
        break;
      case 'orders':
        data = await prisma.order.findMany({ include: { user: { select: { name: true, email: true } } } });
        break;
      case 'invoices':
        data = await prisma.invoice.findMany({ include: { user: { select: { name: true, email: true } } } });
        break;
      case 'products':
        data = await prisma.product.findMany();
        break;
      case 'transactions':
        data = await prisma.walletTransaction.findMany({ orderBy: { createdAt: 'desc' } });
        break;
      default:
        data = await prisma.user.findMany();
    }

    if (format === 'csv') {
      if (data.length === 0) return NextResponse.json({ error: 'No data to export' }, { status: 404 });
      const headers = Object.keys(data[0]);
      const csvRows = [headers.join(','), ...data.map(row => headers.map(h => { const val = row[h]; return typeof val === 'string' && val.includes(',') ? `"${val}"` : val ?? ''; }).join(','))];
      return new NextResponse(csvRows.join('\n'), {
        headers: { 'Content-Type': 'text/csv', 'Content-Disposition': `attachment; filename="${type}-export-${new Date().toISOString().split('T')[0]}.csv"` },
      });
    }

    return NextResponse.json({ success: true, data, type, count: data.length });
  } catch (error) {
    return NextResponse.json({ error: 'Export failed' }, { status: 500 });
  }
}
