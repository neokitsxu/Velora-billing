import { PrismaClient } from '@prisma/client';
import { NextRequest, NextResponse } from 'next/server';

const prisma = new PrismaClient();

// POST /api/admin/bulk - Bulk operations (delete, suspend, email)
export async function POST(req: NextRequest) {
  try {
    const token = req.headers.get('authorization')?.replace('Bearer ', '');
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { action, type, ids } = await req.json();

    if (!action || !type || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: 'Invalid request. Provide action, type, and ids.' }, { status: 400 });
    }

    let count = 0;

    switch (action) {
      case 'delete':
        if (type === 'clients') count = await prisma.user.deleteMany({ where: { id: { in: ids } } }).then(r => r.count);
        else if (type === 'products') count = await prisma.product.deleteMany({ where: { id: { in: ids } } }).then(r => r.count);
        else if (type === 'orders') count = await prisma.order.deleteMany({ where: { id: { in: ids } } }).then(r => r.count);
        else if (type === 'coupons') count = await prisma.coupon.deleteMany({ where: { id: { in: ids } } }).then(r => r.count);
        break;

      case 'suspend':
        if (type === 'clients') count = await prisma.user.updateMany({ where: { id: { in: ids } }, data: { status: 'suspended' } }).then(r => r.count);
        if (type === 'services') count = await prisma.service.updateMany({ where: { id: { in: ids } }, data: { status: 'suspended' } }).then(r => r.count);
        break;

      case 'activate':
        if (type === 'clients') count = await prisma.user.updateMany({ where: { id: { in: ids } }, data: { status: 'active' } }).then(r => r.count);
        if (type === 'services') count = await prisma.service.updateMany({ where: { id: { in: ids } }, data: { status: 'active' } }).then(r => r.count);
        break;

      case 'close':
        if (type === 'tickets') count = await prisma.ticket.updateMany({ where: { id: { in: ids } }, data: { status: 'closed' } }).then(r => r.count);
        break;

      default:
        return NextResponse.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }

    return NextResponse.json({ success: true, action, type, affected: count });
  } catch (error) {
    console.error('Bulk operation error:', error);
    return NextResponse.json({ error: 'Bulk operation failed' }, { status: 500 });
  }
}
