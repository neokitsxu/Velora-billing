import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

// GET — list backup records
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const backupSettings = await db.setting.findMany({
      where: { group: 'backups' },
      orderBy: { createdAt: 'desc' },
    });

    const backups = backupSettings.map((s) => {
      let parsed: Record<string, unknown> = {};
      try {
        parsed = JSON.parse(s.value);
      } catch {
        parsed = { status: s.value };
      }
      return {
        id: s.key,
        key: s.key,
        ...parsed,
        createdAt: s.createdAt,
        updatedAt: s.updatedAt,
      };
    });

    return NextResponse.json({ success: true, data: backups });
  } catch (error) {
    console.error('Admin backups list error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch backups' },
      { status: 500 }
    );
  }
}

// POST — trigger a backup (creates a record, does not actually backup SQLite)
export async function POST(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { type } = body || {};

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const key = `backup_${timestamp}`;

    const backupData = {
      type: type || 'manual',
      status: 'completed',
      size: '0 KB',
      filename: `velora-backup-${timestamp}.db`,
      triggeredBy: payload.id,
      completedAt: new Date().toISOString(),
    };

    const setting = await db.setting.create({
      data: {
        key,
        value: JSON.stringify(backupData),
        group: 'backups',
        type: 'json',
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'backup_triggered',
        details: JSON.stringify({ key, type: backupData.type }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Backup completed successfully',
      data: {
        id: setting.key,
        key,
        ...backupData,
        createdAt: setting.createdAt,
      },
    });
  } catch (error) {
    console.error('Admin backup trigger error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to trigger backup' },
      { status: 500 }
    );
  }
}

// DELETE — delete a backup record
export async function DELETE(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const key = searchParams.get('key');

    if (!key) {
      return NextResponse.json(
        { success: false, error: 'Backup key is required' },
        { status: 400 }
      );
    }

    const existing = await db.setting.findUnique({
      where: { key },
    });
    if (!existing || existing.group !== 'backups') {
      return NextResponse.json(
        { success: false, error: 'Backup record not found' },
        { status: 404 }
      );
    }

    await db.setting.delete({ where: { key } });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'backup_deleted',
        details: JSON.stringify({ key }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Backup record deleted successfully',
    });
  } catch (error) {
    console.error('Admin backup delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete backup record' },
      { status: 500 }
    );
  }
}
