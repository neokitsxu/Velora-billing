import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

function verifyAdmin(request: NextRequest) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const payload = verifyToken(authHeader.replace('Bearer ', ''));
  if (!payload || payload.role !== 'admin') return null;
  return payload;
}

// GET — get maintenance mode status
export async function GET(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const setting = await db.setting.findUnique({
      where: { key: 'maintenance_mode' },
    });

    const maintenanceEnabled = setting?.value === 'true';

    let maintenanceData: Record<string, unknown> = {};
    try {
      if (setting) {
        maintenanceData = JSON.parse(setting.value);
      }
    } catch {
      maintenanceData = {};
    }

    return NextResponse.json({
      success: true,
      data: {
        enabled: maintenanceEnabled,
        ...maintenanceData,
      },
    });
  } catch (error) {
    console.error('Admin maintenance status error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch maintenance status' },
      { status: 500 }
    );
  }
}

// POST — enable/disable maintenance mode
export async function POST(request: NextRequest) {
  try {
    const payload = verifyAdmin(request);
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { enabled, message, retryAfter } = body;

    if (typeof enabled !== 'boolean') {
      return NextResponse.json(
        { success: false, error: 'Enabled boolean is required' },
        { status: 400 }
      );
    }

    const maintenanceData = {
      enabled,
      message: message || 'We are currently performing scheduled maintenance. We will be back shortly.',
      retryAfter: retryAfter || 30, // minutes
      updatedAt: new Date().toISOString(),
      updatedBy: payload.id,
    };

    await db.setting.upsert({
      where: { key: 'maintenance_mode' },
      update: {
        value: JSON.stringify(maintenanceData),
        group: 'system',
        type: 'json',
      },
      create: {
        key: 'maintenance_mode',
        value: JSON.stringify(maintenanceData),
        group: 'system',
        type: 'json',
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: enabled ? 'maintenance_enabled' : 'maintenance_disabled',
        details: JSON.stringify(maintenanceData),
      },
    });

    return NextResponse.json({
      success: true,
      message: enabled ? 'Maintenance mode enabled' : 'Maintenance mode disabled',
      data: maintenanceData,
    });
  } catch (error) {
    console.error('Admin maintenance toggle error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update maintenance mode' },
      { status: 500 }
    );
  }
}
