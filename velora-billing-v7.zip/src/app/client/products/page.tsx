'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Package, Check, ArrowRight, Zap, Star, TrendingUp, Shield, Cpu, HardDrive } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  billingCycle: string;
  category: string;
  features: string[];
  stock: number;
}



const categories = ['All', 'Minecraft', 'VPS', 'Dedicated'];

const categoryIcons: Record<string, any> = {
  All: Zap,
  Minecraft: Star,
  VPS: Cpu,
  Dedicated: HardDrive,
};

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCategory, setActiveCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/products', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setProducts(data);
          else if (Array.isArray(data.products)) setProducts(data.products);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const filtered =
    activeCategory === 'All'
      ? products
      : products.filter((p) => p.category === activeCategory);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center mx-auto animate-pulse-glow">
            <Package size={20} className="text-white animate-pulse" />
          </div>
          <p className="text-[#64748b] text-sm">Loading products...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center">
            <Zap size={18} className="text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#e2e8f0]">Hosting Plans</h2>
            <p className="text-sm text-[#64748b]">Premium hosting solutions for every need</p>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => {
          const Icon = categoryIcons[cat] || Zap;
          return (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                activeCategory === cat
                  ? 'bg-[#6366f1] text-white shadow-lg shadow-[#6366f1]/20 velora-glow'
                  : 'bg-[#0c0c0f] border border-[#1a1a2e] text-[#64748b] hover:text-[#e2e8f0] hover:border-[#6366f1]/30'
              }`}
            >
              <Icon size={14} />
              {cat}
            </button>
          );
        })}
      </div>

      {/* Product Grid */}
      {filtered.length === 0 ? (
        <div className="velora-card text-center py-20">
          <Package className="h-12 w-12 text-[#6366f1]/30 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2">No products available</h3>
          <p className="text-sm text-[#64748b]">
            {activeCategory !== 'All'
              ? `No products in the ${activeCategory} category.`
              : "No products have been added yet. Check back soon!"}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 stagger-children">
          {filtered.map((product) => (
            <div key={product.id} className="velora-card flex flex-col hover-lift hover-glow group overflow-hidden">
              {/* Card top accent */}
              <div className="h-1 bg-gradient-to-r from-[#6366f1] via-[#8b5cf6] to-[#a855f7] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="flex-1 p-5">
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <h3 className="text-lg font-bold text-[#e2e8f0] group-hover:text-[#6366f1] transition-colors">{product.name}</h3>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-[#6366f1]/10 text-[#6366f1] text-[10px] font-medium border border-[#6366f1]/20">
                      {product.category}
                    </span>
                  </div>
                  {product.stock <= 5 && product.stock > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-[#f59e0b]/10 text-[#f59e0b] text-[10px] font-medium border border-[#f59e0b]/20 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#f59e0b] animate-pulse" />
                      {product.stock} left
                    </span>
                  )}
                </div>

                <p className="text-sm text-[#64748b] mb-4 leading-relaxed">{product.description}</p>

                {/* Price */}
                <div className="flex items-baseline gap-2 mb-5">
                  <span className="text-3xl font-extrabold bg-gradient-to-r from-[#6366f1] to-[#8b5cf6] bg-clip-text text-transparent">
                    ₹{product.price.toLocaleString()}
                  </span>
                  <span className="text-xs text-[#475569] font-medium">/{product.billingCycle.toLowerCase()}</span>
                </div>

                {/* Features */}
                <ul className="space-y-2 mb-5">
                  {product.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-[#c8ccd0]">
                      <div className="w-4 h-4 rounded bg-[#10b981]/10 flex items-center justify-center flex-shrink-0">
                        <Check size={8} className="text-[#10b981]" strokeWidth={3} />
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {/* CTA */}
              <div className="px-5 pb-5">
                <Link
                  href={`/client/checkout?id=${product.id}`}
                  className={`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all duration-300 active:scale-[0.97] ${
                    product.stock <= 0
                      ? 'bg-[#1a1a2e] text-[#475569] cursor-not-allowed'
                      : 'gradient-animate text-white velora-glow hover:shadow-[0_0_30px_rgba(99,102,241,0.3)]'
                  }`}
                  onClick={(e) => product.stock <= 0 && e.preventDefault()}
                >
                  {product.stock <= 0 ? (
                    'Out of Stock'
                  ) : (
                    <>
                      Order Now
                      <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Trust Bar */}
      <div className="flex items-center justify-center gap-8 py-4">
        {[
          { icon: Shield, text: 'DDoS Protection' },
          { icon: TrendingUp, text: '99.9% Uptime' },
          { icon: Cpu, text: 'Instant Setup' },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-2 text-[#475569]">
            <item.icon size={14} />
            <span className="text-xs">{item.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
