'use client';

import { useState, useEffect } from 'react';
import {
  Bell, BellOff, Check, CheckCheck, Trash2, ShoppingCart, CreditCard,
  HelpCircle, AlertCircle, Info, CheckCircle, Filter, ChevronLeft, ChevronRight,
  Mail, MessageSquare, Settings, Sparkles, Inbox,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'payment' | 'ticket' | 'system';
  category: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
  actionUrl?: string;
  actionLabel?: string;
}

type FilterType = 'all' | 'order' | 'payment' | 'ticket' | 'system';
type ReadFilter = 'all' | 'unread' | 'read';



const typeIcons: Record<string, React.ElementType> = {
  order: ShoppingCart,
  payment: CreditCard,
  ticket: HelpCircle,
  system: Settings,
};

const typeColors: Record<string, { bg: string; color: string }> = {
  order: { bg: 'bg-[#6366f1]/10', color: 'text-[#6366f1]' },
  payment: { bg: 'bg-[#10b981]/10', color: 'text-[#10b981]' },
  ticket: { bg: 'bg-[#f59e0b]/10', color: 'text-[#f59e0b]' },
  system: { bg: 'bg-[#8b5cf6]/10', color: 'text-[#8b5cf6]' },
};

const categoryIcons: Record<string, React.ElementType> = {
  info: Info,
  success: CheckCircle,
  warning: AlertCircle,
  error: AlertCircle,
};

const categoryColors: Record<string, string> = {
  info: 'text-[#6366f1]',
  success: 'text-[#10b981]',
  warning: 'text-[#f59e0b]',
  error: 'text-[#ef4444]',
};

const ITEMS_PER_PAGE = 8;

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState<FilterType>('all');
  const [readFilter, setReadFilter] = useState<ReadFilter>('all');
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/notifications', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setNotifications(data);
          else if (Array.isArray(data.notifications)) setNotifications(data.notifications);
        }
      } catch { /* fallback */ } finally {
        setLoading(false);
      }
    };
    fetchNotifications();
  }, []);

  const filtered = notifications.filter(n => {
    if (typeFilter !== 'all' && n.type !== typeFilter) return false;
    if (readFilter === 'unread' && n.read) return false;
    if (readFilter === 'read' && !n.read) return false;
    return true;
  });

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = async (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    try {
      const token = localStorage.getItem('velora_token');
      await fetch(`/api/client/notifications/${id}/read`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch { /* ignore */ }
  };

  const markAllAsRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    toast.success('All notifications marked as read');
    try {
      const token = localStorage.getItem('velora_token');
      await fetch('/api/client/notifications/read-all', {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch { /* ignore */ }
  };

  const deleteNotification = async (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    toast.success('Notification deleted');
    try {
      const token = localStorage.getItem('velora_token');
      await fetch(`/api/client/notifications/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch { /* ignore */ }
  };

  const formatTimeAgo = (dateStr: string) => {
    const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
    return new Date(dateStr).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-8 w-56 skeleton-shimmer rounded-lg" />
        <div className="skeleton-card h-12 p-4" />
        <div className="space-y-3">
          {[1,2,3,4,5].map(i => (
            <div key={i} className="skeleton-card p-5 flex items-start gap-4">
              <div className="w-10 h-10 skeleton rounded-xl" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-48 skeleton rounded" />
                <div className="h-3 w-72 skeleton rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const typeFilters: { id: FilterType; label: string }[] = [
    { id: 'all', label: 'All' },
    { id: 'order', label: 'Orders' },
    { id: 'payment', label: 'Payments' },
    { id: 'ticket', label: 'Tickets' },
    { id: 'system', label: 'System' },
  ];

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#e2e8f0] flex items-center gap-2">
            Notifications
            {unreadCount > 0 && (
              <span className="w-6 h-6 rounded-full bg-[#6366f1] text-white text-xs font-bold flex items-center justify-center animate-pulse-glow">{unreadCount}</span>
            )}
          </h2>
          <p className="text-[#64748b] mt-1">{unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}</p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllAsRead} className="velora-btn-secondary inline-flex items-center gap-2 text-sm">
            <CheckCheck size={16} />
            Mark All Read
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="velora-card">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="flex items-center gap-1.5 flex-wrap flex-1">
            <Filter size={14} className="text-[#64748b] mr-1" />
            {typeFilters.map(f => (
              <button
                key={f.id}
                onClick={() => { setTypeFilter(f.id); setCurrentPage(1); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                  typeFilter === f.id
                    ? 'bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20'
                    : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 border border-transparent'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-[#64748b]">Show:</span>
            {(['all', 'unread', 'read'] as ReadFilter[]).map(f => (
              <button
                key={f}
                onClick={() => { setReadFilter(f); setCurrentPage(1); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                  readFilter === f
                    ? 'bg-[#8b5cf6]/10 text-[#8b5cf6] border border-[#8b5cf6]/20'
                    : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 border border-transparent'
                }`}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Notification List */}
      {paginated.length === 0 ? (
        <div className="velora-card text-center py-16">
          <Inbox className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Notifications</h3>
          <p className="text-[#64748b]">
            {typeFilter !== 'all' || readFilter !== 'all'
              ? 'No notifications match your current filters.'
              : 'You&apos;re all caught up! No notifications to show.'}
          </p>
        </div>
      ) : (
        <div className="space-y-2 stagger-children">
          {paginated.map(notification => {
            const TypeIcon = typeIcons[notification.type] || Bell;
            const CatIcon = categoryIcons[notification.category] || Info;
            const typeStyle = typeColors[notification.type] || typeColors.system;
            const catColor = categoryColors[notification.category] || categoryColors.info;

            return (
              <div
                key={notification.id}
                className={`velora-card flex items-start gap-4 p-4 transition-all duration-200 ${
                  !notification.read ? 'border-[#6366f1]/20 bg-[#6366f1]/[0.03]' : ''
                }`}
              >
                {/* Type Icon */}
                <div className={`w-10 h-10 rounded-xl ${typeStyle.bg} flex items-center justify-center flex-shrink-0 relative`}>
                  <TypeIcon size={18} className={typeStyle.color} />
                  {!notification.read && (
                    <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-[#6366f1] animate-pulse" />
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <h4 className={`text-sm font-semibold ${!notification.read ? 'text-[#e2e8f0]' : 'text-[#94a3b8]'}`}>
                        {notification.title}
                      </h4>
                      <CatIcon size={14} className={catColor} />
                    </div>
                    <span className="text-xs text-[#64748b] whitespace-nowrap flex-shrink-0">{formatTimeAgo(notification.createdAt)}</span>
                  </div>
                  <p className={`text-sm mt-1 ${!notification.read ? 'text-[#94a3b8]' : 'text-[#64748b]'}`}>
                    {notification.message}
                  </p>

                  {/* Actions Row */}
                  <div className="flex items-center gap-2 mt-2">
                    {notification.actionUrl && notification.actionLabel && (
                      <a href={notification.actionUrl} className="text-xs text-[#6366f1] hover:text-[#818cf8] transition-colors inline-flex items-center gap-1">
                        {notification.actionLabel}
                      </a>
                    )}
                    {!notification.read && (
                      <button onClick={() => markAsRead(notification.id)} className="text-xs text-[#64748b] hover:text-[#e2e8f0] transition-colors inline-flex items-center gap-1">
                        <Check size={12} /> Mark read
                      </button>
                    )}
                  </div>
                </div>

                {/* Delete */}
                <button
                  onClick={() => deleteNotification(notification.id)}
                  className="p-1.5 rounded-lg text-[#475569] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors flex-shrink-0 self-start"
                  title="Delete notification"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ChevronLeft size={16} />
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={`w-8 h-8 rounded-lg text-sm font-medium transition-all duration-200 ${
                currentPage === page
                  ? 'bg-[#6366f1] text-white'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50'
              }`}
            >
              {page}
            </button>
          ))}
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
