'use client';

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  ArrowLeft,
  Check,
  Tag,
  QrCode,
  Wallet as WalletIcon,
  Loader2,
  AlertCircle,
  X,
  Shield,
  Zap,
  Clock,
  CreditCard,
  ChevronRight,
  Sparkles,
  Lock,
  BadgePercent,
  Gift,
  ArrowRight,
  Timer,
  Star,
  TrendingUp,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface ProductResource {
  label: string;
  value: string;
  icon?: string;
}

interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  billingCycle: string;
  features: string[];
  resources?: ProductResource[];
  taxEnabled: boolean;
  taxRate: number;
  category?: string;
  stock?: number;
}

interface CouponResponse {
  success: boolean;
  data?: {
    id: string;
    code: string;
    type: 'percentage' | 'fixed';
    value: number;
    maxDiscount?: number;
  };
  error?: string;
}

interface OrderResponse {
  success: boolean;
  data?: {
    orderId: string;
    orderNumber: string;
  };
  error?: string;
}

type PaymentMethod = 'upi' | 'wallet';

type FetchState = 'idle' | 'loading' | 'success' | 'error';

function CheckoutContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const productId = searchParams.get('product') || searchParams.get('id');

  // Product state
  const [product, setProduct] = useState<Product | null>(null);
  const [fetchState, setFetchState] = useState<FetchState>('idle');

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponDiscount, setCouponDiscount] = useState(0);
  const [couponType, setCouponType] = useState<'percentage' | 'fixed'>('percentage');

  // Tax state
  const [taxEnabled, setTaxEnabled] = useState(true);
  const [taxRate, setTaxRate] = useState(18);

  // Payment state
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [placing, setPlacing] = useState(false);

  // Step state for checkout flow
  const [step, setStep] = useState<1 | 2>(1);

  // Fetch product + wallet on mount
  useEffect(() => {
    const fetchData = async () => {
      setFetchState('loading');
      const token = localStorage.getItem('velora_token');

      try {
        let url = '/api/products';
        if (productId) {
          url = `/api/products?slug=${encodeURIComponent(productId)}`;
        }
        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const json = await res.json();
        if (json.success && json.data) {
          const productData: Product = Array.isArray(json.data)
            ? json.data.find((p: Product) => p.id === productId || p.slug === productId) || json.data[0]
            : json.data;
          if (productData) {
            setProduct(productData);
            setTaxEnabled(productData.taxEnabled ?? true);
            setTaxRate(productData.taxRate ?? 18);
          }
        }
      } catch {
        // Silently fail
      }

      try {
        const res = await fetch('/api/wallet', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const json = await res.json();
        if (json.success && json.data) {
          setWalletBalance(json.data.balance ?? 0);
        } else if (json.balance !== undefined) {
          setWalletBalance(json.balance);
        }
      } catch {
        // Silently fail
      }

      setFetchState('success');
    };

    fetchData();
  }, [productId]);

  // Apply coupon
  const applyCoupon = async () => {
    const code = couponCode.trim();
    if (!code) {
      toast.error('Please enter a coupon code');
      return;
    }

    setCouponLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ code, productId: product?.id }),
      });
      const json: CouponResponse = await res.json();
      if (json.success && json.data) {
        setCouponApplied(true);
        setCouponType(json.data.type);
        setCouponDiscount(json.data.value);
        toast.success(`Coupon applied! ${json.data.type === 'percentage' ? `${json.data.value}%` : `₹${json.data.value}`} discount`);
      } else {
        toast.error(json.error || 'Invalid coupon code');
      }
    } catch {
      toast.error('Failed to validate coupon');
    } finally {
      setCouponLoading(false);
    }
  };

  const removeCoupon = () => {
    setCouponApplied(false);
    setCouponDiscount(0);
    setCouponCode('');
    setCouponType('percentage');
  };

  // Calculate totals
  const subtotal = product?.price ?? 0;
  const discountAmount = couponApplied
    ? couponType === 'percentage'
      ? (subtotal * couponDiscount) / 100
      : Math.min(couponDiscount, subtotal)
    : 0;
  const savingsPercent = couponApplied ? Math.round((discountAmount / subtotal) * 100) : 0;
  const afterDiscount = subtotal - discountAmount;
  const taxAmount = taxEnabled ? (afterDiscount * taxRate) / 100 : 0;
  const total = afterDiscount + taxAmount;

  // Place order
  const handlePlaceOrder = async () => {
    if (!product) return;

    if (paymentMethod === 'wallet' && walletBalance < total) {
      toast.error('Insufficient wallet balance');
      return;
    }

    setPlacing(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          productId: product.id,
          paymentMethod,
          couponCode: couponApplied ? couponCode.trim() : null,
        }),
      });
      const json: OrderResponse = await res.json();

      if (json.success && json.data) {
        if (paymentMethod === 'upi') {
          router.push(`/client/payment?order=${json.data.orderId || json.data.orderNumber}`);
        } else {
          toast.success('Order placed successfully via wallet!');
          router.push('/client/orders');
        }
      } else {
        toast.error(json.error || 'Failed to place order');
      }
    } catch {
      toast.error('Network error. Please try again.');
    } finally {
      setPlacing(false);
    }
  };

  // Loading state
  if (fetchState === 'loading') {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center mx-auto animate-pulse-glow">
              <Loader2 className="w-8 h-8 text-white animate-spin" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[#8b5cf6] animate-ping" />
          </div>
          <p className="text-[#64748b] text-sm animate-pulse">Preparing your checkout...</p>
        </div>
      </div>
    );
  }

  // Error / not found state
  if (fetchState === 'success' && !product) {
    return (
      <div className="velora-card text-center py-20 animate-scale-in">
        <div className="w-20 h-20 rounded-full bg-[#ef4444]/10 border-2 border-[#ef4444]/30 flex items-center justify-center mx-auto mb-6">
          <AlertCircle className="text-[#ef4444]" size={40} />
        </div>
        <h3 className="text-2xl font-bold text-[#e2e8f0] mb-3">Product Not Found</h3>
        <p className="text-[#64748b] mb-8 max-w-md mx-auto">The product you are looking for does not exist or has been removed. Browse our available products below.</p>
        <Link href="/client/products" className="velora-btn-primary inline-flex items-center gap-2 px-8 py-3 text-sm">
          <Package size={16} />
          Browse Products
          <ArrowRight size={16} />
        </Link>
      </div>
    );
  }

  if (!product) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      {/* Back Link */}
      <Link
        href="/client/products"
        className="inline-flex items-center gap-2 text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors mb-6 group"
      >
        <div className="w-8 h-8 rounded-lg bg-[#0c0c0f] border border-[#1a1a2e] group-hover:border-[#6366f1]/40 flex items-center justify-center transition-all">
          <ArrowLeft size={14} className="group-hover:-translate-x-0.5 transition-transform" />
        </div>
        Back to Products
      </Link>

      {/* Progress Steps */}
      <div className="flex items-center gap-3 mb-8">
        {[
          { num: 1, label: 'Review Order' },
          { num: 2, label: 'Payment' },
        ].map((s, i) => (
          <div key={s.num} className="flex items-center gap-3">
            <button
              onClick={() => s.num < step ? setStep(s.num as 1 | 2) : null}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                step === s.num
                  ? 'bg-[#6366f1]/10 border border-[#6366f1]/30 text-[#6366f1]'
                  : step > s.num
                  ? 'bg-[#10b981]/10 border border-[#10b981]/30 text-[#10b981] cursor-pointer'
                  : 'bg-[#0c0c0f] border border-[#1a1a2e] text-[#475569]'
              }`}
            >
              {step > s.num ? (
                <Check size={14} />
              ) : (
                <span className="w-5 h-5 rounded-full bg-current/20 flex items-center justify-center text-xs">{s.num}</span>
              )}
              <span className="hidden sm:inline">{s.label}</span>
            </button>
            {i === 0 && (
              <div className={`w-8 h-0.5 rounded-full transition-all duration-500 ${step > 1 ? 'bg-[#10b981]' : 'bg-[#1a1a2e]'}`} />
            )}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* ====== LEFT COLUMN ====== */}
        <div className="lg:col-span-3 space-y-5">
          {/* Step 1: Product Details */}
          <div className={`velora-card overflow-hidden transition-all duration-500 ${step !== 1 ? 'opacity-50 scale-[0.98]' : ''}`}>
            {/* Product Hero Banner */}
            <div className="relative p-6 pb-0">
              <div className="absolute inset-0 bg-gradient-to-br from-[#6366f1]/8 via-transparent to-[#8b5cf6]/5 pointer-events-none" />
              <div className="relative">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {product.category && (
                        <span className="px-2.5 py-0.5 rounded-full bg-[#6366f1]/10 text-[#6366f1] text-xs font-medium border border-[#6366f1]/20">
                          {product.category}
                        </span>
                      )}
                      <span className="px-2.5 py-0.5 rounded-full bg-[#10b981]/10 text-[#10b981] text-xs font-medium border border-[#10b981]/20 flex items-center gap-1">
                        <Zap size={10} />
                        Popular
                      </span>
                    </div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-[#e2e8f0] mb-2">{product.name}</h1>
                    <p className="text-[#64748b] text-sm leading-relaxed max-w-xl">{product.description}</p>
                  </div>
                </div>

                {/* Price Display */}
                <div className="flex items-end gap-3 mb-6">
                  <div>
                    <span className="text-sm text-[#64748b]">Starting from</span>
                    <div className="flex items-baseline gap-1">
                      <span className="text-sm text-[#6366f1] font-medium">₹</span>
                      <span className="text-4xl font-extrabold bg-gradient-to-r from-[#6366f1] via-[#8b5cf6] to-[#a855f7] bg-clip-text text-transparent">
                        {product.price.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-[#1a1a2e] text-[#64748b] text-xs font-medium border border-[#1a1a2e] mb-1">
                    /{product.billingCycle?.toLowerCase()}
                  </span>
                </div>
              </div>
            </div>

            {/* Resource Specs - Premium Grid */}
            {product.resources && product.resources.length > 0 && (
              <div className="p-6 pt-0">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {product.resources.map((res, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-xl bg-[#09090b] border border-[#1a1a2e] hover:border-[#6366f1]/20 transition-all duration-300 group text-center"
                      style={{ animation: `fadeInUp 0.4s ease-out ${i * 0.08}s both` }}
                    >
                      <p className="text-[10px] uppercase tracking-wider text-[#475569] mb-1.5 font-medium">{res.label}</p>
                      <p className="text-base font-bold text-[#e2e8f0] group-hover:text-[#6366f1] transition-colors">{res.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Features List */}
            <div className="p-6 pt-2">
              <h3 className="text-xs font-semibold text-[#475569] uppercase tracking-wider mb-3 flex items-center gap-2">
                <Sparkles size={12} className="text-[#6366f1]" />
                Everything Included
              </h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {product.features.map((feature, i) => (
                  <li
                    key={i}
                    className="flex items-center gap-2.5 text-sm text-[#c8ccd0] hover:text-[#e2e8f0] transition-colors"
                    style={{ animation: `fadeInUp 0.3s ease-out ${i * 0.05}s both` }}
                  >
                    <div className="w-5 h-5 rounded-md bg-gradient-to-br from-[#10b981]/20 to-[#10b981]/5 flex items-center justify-center flex-shrink-0 border border-[#10b981]/20">
                      <Check size={10} className="text-[#10b981]" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Continue Button - Step 1 */}
            {step === 1 && (
              <div className="px-6 pb-6">
                <button
                  onClick={() => setStep(2)}
                  className="w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 gradient-animate text-white velora-glow hover:shadow-[0_0_30px_rgba(99,102,241,0.4)] transition-all duration-300 active:scale-[0.98]"
                >
                  Continue to Payment
                  <ArrowRight size={16} />
                </button>
              </div>
            )}
          </div>

          {/* Step 2: Payment Method */}
          {step === 2 && (
            <>
              {/* Payment Method Selector */}
              <div className="velora-card p-6 animate-fade-in-up">
                <h3 className="text-base font-semibold text-[#e2e8f0] mb-1">Select Payment Method</h3>
                <p className="text-xs text-[#475569] mb-5">Choose your preferred way to pay</p>

                <div className="space-y-3">
                  {/* UPI Payment */}
                  <button
                    onClick={() => setPaymentMethod('upi')}
                    className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-300 ${
                      paymentMethod === 'upi'
                        ? 'border-[#6366f1] bg-gradient-to-r from-[#6366f1]/5 to-[#8b5cf6]/5 shadow-lg shadow-[#6366f1]/10'
                        : 'border-[#1a1a2e] hover:border-[#6366f1]/30 bg-[#0c0c0f]'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                      paymentMethod === 'upi'
                        ? 'bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] shadow-lg shadow-[#6366f1]/30'
                        : 'bg-[#1a1a2e]'
                    }`}>
                      <QrCode size={22} className={paymentMethod === 'upi' ? 'text-white' : 'text-[#6366f1]'} />
                    </div>
                    <div className="text-left flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-[#e2e8f0]">UPI Payment</p>
                        {paymentMethod === 'upi' && (
                          <span className="px-1.5 py-0.5 rounded bg-[#10b981]/10 text-[#10b981] text-[10px] font-medium">RECOMMENDED</span>
                        )}
                      </div>
                      <p className="text-xs text-[#64748b] mt-0.5">Pay via any UPI app — GPay, PhonePe, Paytm</p>
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
                      paymentMethod === 'upi'
                        ? 'border-[#6366f1] bg-[#6366f1] scale-110'
                        : 'border-[#1a1a2e]'
                    }`}>
                      {paymentMethod === 'upi' && (
                        <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </button>

                  {/* Wallet Balance */}
                  <button
                    onClick={() => setPaymentMethod('wallet')}
                    className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-300 ${
                      paymentMethod === 'wallet'
                        ? 'border-[#8b5cf6] bg-gradient-to-r from-[#8b5cf6]/5 to-[#a855f7]/5 shadow-lg shadow-[#8b5cf6]/10'
                        : 'border-[#1a1a2e] hover:border-[#8b5cf6]/30 bg-[#0c0c0f]'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                      paymentMethod === 'wallet'
                        ? 'bg-gradient-to-br from-[#8b5cf6] to-[#a855f7] shadow-lg shadow-[#8b5cf6]/30'
                        : 'bg-[#1a1a2e]'
                    }`}>
                      <WalletIcon size={22} className={paymentMethod === 'wallet' ? 'text-white' : 'text-[#8b5cf6]'} />
                    </div>
                    <div className="text-left flex-1">
                      <p className="text-sm font-semibold text-[#e2e8f0]">Wallet Balance</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <p className="text-xs text-[#64748b]">Available:</p>
                        <span className="text-xs font-bold text-[#e2e8f0]">₹{walletBalance.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
                      paymentMethod === 'wallet'
                        ? 'border-[#8b5cf6] bg-[#8b5cf6] scale-110'
                        : 'border-[#1a1a2e]'
                    }`}>
                      {paymentMethod === 'wallet' && (
                        <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </button>
                </div>

                {/* Insufficient balance warning */}
                {paymentMethod === 'wallet' && walletBalance < total && (
                  <div className="mt-4 flex items-center gap-2.5 p-3.5 rounded-xl bg-[#ef4444]/5 border border-[#ef4444]/20 animate-shake">
                    <AlertCircle size={16} className="text-[#ef4444] flex-shrink-0" />
                    <div>
                      <p className="text-xs text-[#ef4444] font-medium">Insufficient Balance</p>
                      <p className="text-[11px] text-[#ef4444]/70">You need ₹{(total - walletBalance).toLocaleString('en-IN')} more. Top up your wallet or use UPI.</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Coupon Card - Premium */}
              <div className="velora-card p-6 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#8b5cf6]/20 to-[#a855f7]/10 flex items-center justify-center border border-[#8b5cf6]/20">
                      <Gift size={14} className="text-[#8b5cf6]" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-[#e2e8f0]">Have a Coupon?</h3>
                      <p className="text-[11px] text-[#475569]">Apply discount code for extra savings</p>
                    </div>
                  </div>
                  {couponApplied && (
                    <span className="px-2 py-0.5 rounded-full bg-[#10b981]/10 text-[#10b981] text-[10px] font-bold border border-[#10b981]/20 animate-scale-in">
                      SAVED ₹{Math.round(discountAmount).toLocaleString('en-IN')}
                    </span>
                  )}
                </div>

                {couponApplied ? (
                  <div className="flex items-center justify-between p-3.5 rounded-xl bg-gradient-to-r from-[#10b981]/5 to-[#10b981]/2 border border-[#10b981]/20">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#10b981]/10 flex items-center justify-center">
                        <BadgePercent size={16} className="text-[#10b981]" />
                      </div>
                      <div>
                        <span className="text-sm font-bold text-[#10b981]">{couponCode.toUpperCase()}</span>
                        <span className="text-xs text-[#10b981]/70 ml-2">
                          {couponType === 'percentage' ? `${couponDiscount}% off` : `Flat ₹${couponDiscount} off`}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={removeCoupon}
                      className="p-1.5 rounded-lg hover:bg-[#ef4444]/10 text-[#64748b] hover:text-[#ef4444] transition-all"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#475569]" />
                      <input
                        type="text"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                        onKeyDown={(e) => e.key === 'Enter' && applyCoupon()}
                        placeholder="COUPON CODE"
                        className="velora-input w-full pl-10 uppercase tracking-wider text-sm"
                      />
                    </div>
                    <button
                      onClick={applyCoupon}
                      disabled={couponLoading || !couponCode.trim()}
                      className="velora-btn-primary px-6 flex items-center gap-2 disabled:opacity-40 text-sm font-medium"
                    >
                      {couponLoading ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : (
                        <>
                          <Sparkles size={14} />
                          Apply
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {/* Trust Signals */}
              <div className="grid grid-cols-3 gap-3 animate-fade-in-up" style={{ animationDelay: '0.15s' }}>
                {[
                  { icon: Shield, label: 'SSL Secured', sub: '256-bit encryption' },
                  { icon: Lock, label: 'Safe Payments', sub: 'UPI verified' },
                  { icon: Star, label: 'Instant Setup', sub: 'Automated provision' },
                ].map((item, i) => (
                  <div key={i} className="velora-card p-3 text-center">
                    <item.icon size={16} className="text-[#6366f1] mx-auto mb-1.5" />
                    <p className="text-[11px] font-semibold text-[#e2e8f0]">{item.label}</p>
                    <p className="text-[9px] text-[#475569]">{item.sub}</p>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* ====== RIGHT COLUMN: Order Summary ====== */}
        <div className="lg:col-span-2">
          <div className="velora-card overflow-hidden lg:sticky lg:top-20 animate-fade-in-right">
            {/* Summary Header */}
            <div className="p-5 border-b border-[#1a1a2e] bg-gradient-to-r from-[#6366f1]/5 to-transparent">
              <h3 className="text-base font-semibold text-[#e2e8f0] flex items-center gap-2">
                <CreditCard size={16} className="text-[#6366f1]" />
                Order Summary
              </h3>
            </div>

            <div className="p-5 space-y-4">
              {/* Product Line */}
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6366f1]/20 to-[#8b5cf6]/10 flex items-center justify-center flex-shrink-0 border border-[#6366f1]/20">
                  <Zap size={16} className="text-[#6366f1]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[#e2e8f0] truncate">{product.name}</p>
                  <p className="text-xs text-[#475569] capitalize">{product.billingCycle?.toLowerCase()} billing</p>
                </div>
                <p className="text-sm font-semibold text-[#e2e8f0] flex-shrink-0">₹{subtotal.toLocaleString('en-IN')}</p>
              </div>

              {/* Divider */}
              <div className="border-t border-[#1a1a2e]" />

              {/* Subtotal */}
              <div className="flex justify-between text-sm">
                <span className="text-[#64748b]">Subtotal</span>
                <span className="text-[#e2e8f0]">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>

              {/* Tax toggle */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-[#64748b]">GST ({taxRate}%)</span>
                  <button
                    onClick={() => setTaxEnabled(!taxEnabled)}
                    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-all duration-300 ${
                      taxEnabled ? 'bg-[#6366f1] shadow-lg shadow-[#6366f1]/20' : 'bg-[#1a1a2e]'
                    }`}
                  >
                    <span
                      className={`inline-block h-3.5 w-3.5 rounded-full bg-white transition-all duration-300 shadow-sm ${
                        taxEnabled ? 'translate-x-4.5 ml-[18px]' : 'ml-[2px]'
                      }`}
                    />
                  </button>
                </div>
                <span className={`text-sm font-medium transition-all ${taxEnabled ? 'text-[#e2e8f0]' : 'text-[#475569] line-through'}`}>
                  ₹{taxAmount.toLocaleString('en-IN')}
                </span>
              </div>

              {/* Coupon discount */}
              {couponApplied && discountAmount > 0 && (
                <div className="flex justify-between items-center animate-scale-in">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-md bg-[#10b981]/10 flex items-center justify-center">
                      <BadgePercent size={10} className="text-[#10b981]" />
                    </div>
                    <span className="text-sm text-[#10b981]">
                      Discount {couponType === 'percentage' ? `(${couponDiscount}%)` : ''}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {savingsPercent > 0 && (
                      <span className="px-1.5 py-0.5 rounded bg-[#10b981]/10 text-[#10b981] text-[10px] font-bold">
                        {savingsPercent}% OFF
                      </span>
                    )}
                    <span className="text-sm font-medium text-[#10b981]">-₹{Math.round(discountAmount).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              )}

              {/* Divider */}
              <div className="border-t border-[#1a1a2e]" />

              {/* Total */}
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-xs text-[#475569] uppercase tracking-wider font-medium">Total Amount</p>
                  <p className="text-[10px] text-[#475569] mt-0.5">Inclusive of all taxes</p>
                </div>
                <div className="text-right">
                  <span className="text-3xl font-extrabold bg-gradient-to-r from-[#6366f1] via-[#8b5cf6] to-[#a855f7] bg-clip-text text-transparent">
                    ₹{Math.round(total).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Savings Banner */}
              {couponApplied && discountAmount > 0 && (
                <div className="p-3 rounded-xl bg-gradient-to-r from-[#10b981]/10 to-[#10b981]/5 border border-[#10b981]/20 animate-scale-in">
                  <div className="flex items-center gap-2">
                    <TrendingUp size={14} className="text-[#10b981]" />
                    <p className="text-xs text-[#10b981] font-medium">
                      You&apos;re saving ₹{Math.round(discountAmount).toLocaleString('en-IN')} on this order!
                    </p>
                  </div>
                </div>
              )}

              {/* CTA Button */}
              <button
                onClick={step === 1 ? () => setStep(2) : handlePlaceOrder}
                disabled={placing || (paymentMethod === 'wallet' && walletBalance < total)}
                className="w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2.5 gradient-animate text-white velora-glow hover:shadow-[0_0_40px_rgba(99,102,241,0.4)] transition-all duration-300 active:scale-[0.97] disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:shadow-none"
              >
                {placing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Processing Securely...
                  </>
                ) : step === 1 ? (
                  <>
                    Proceed to Pay
                    <ChevronRight size={16} />
                  </>
                ) : paymentMethod === 'upi' ? (
                  <>
                    <QrCode size={16} />
                    Pay ₹{Math.round(total).toLocaleString('en-IN')} via UPI
                  </>
                ) : (
                  <>
                    <WalletIcon size={16} />
                    Pay ₹{Math.round(total).toLocaleString('en-IN')} from Wallet
                  </>
                )}
              </button>

              {/* Security badges */}
              <div className="flex items-center justify-center gap-4 pt-2">
                <div className="flex items-center gap-1.5 text-[10px] text-[#475569]">
                  <Lock size={10} className="text-[#10b981]" />
                  <span>256-bit SSL</span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-[#475569]">
                  <Shield size={10} className="text-[#10b981]" />
                  <span>Secure Checkout</span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-[#475569]">
                  <Timer size={10} className="text-[#10b981]" />
                  <span>10 min expiry</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center mx-auto animate-pulse-glow">
              <Loader2 className="w-8 h-8 text-white animate-spin" />
            </div>
            <p className="text-[#64748b] text-sm">Loading checkout...</p>
          </div>
        </div>
      }
    >
      <CheckoutContent />
    </Suspense>
  );
}

// Need Package import for error state
function Package({ size, className }: { size: number; className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="m7.5 4.27 9 5.15" />
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </svg>
  );
}
