'use client';

import { useState, useEffect } from 'react';
import {
  Gift, Copy, Check, Users, TrendingUp, Wallet, Clock, ArrowRight,
  Share2, Zap, Trophy, Star, ChevronRight, Crown,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { useCopyToClipboard } from '@/hooks/use-hooks';

interface ReferralStats {
  totalReferrals: number;
  activeReferrals: number;
  totalEarnings: number;
  pendingEarnings: number;
  referralCode: string;
  referralLink: string;
}

interface ReferralHistory {
  id: string;
  referredUser: string;
  date: string;
  status: 'active' | 'pending' | 'inactive';
  commission: number;
  productName: string;
}

const defaultStats: ReferralStats = {
  totalReferrals: 0,
  activeReferrals: 0,
  totalEarnings: 0,
  pendingEarnings: 0,
  referralCode: '',
  referralLink: '',
};

const tiers = [
  { tier: 'Bronze', referrals: 0, commission: '5%', color: '#cd7f32', bg: 'bg-[#cd7f32]/10', border: 'border-[#cd7f32]/20', icon: Star },
  { tier: 'Silver', referrals: 10, commission: '8%', color: '#c0c0c0', bg: 'bg-[#c0c0c0]/10', border: 'border-[#c0c0c0]/20', icon: Star },
  { tier: 'Gold', referrals: 25, commission: '10%', color: '#ffd700', bg: 'bg-[#ffd700]/10', border: 'border-[#ffd700]/20', icon: Crown },
  { tier: 'Platinum', referrals: 50, commission: '12%', color: '#e5e4e2', bg: 'bg-[#e5e4e2]/10', border: 'border-[#e5e4e2]/20', icon: Trophy },
];

const statusBadge: Record<string, string> = {
  active: 'velora-badge-success',
  pending: 'velora-badge-warning',
  inactive: 'velora-badge',
};

export default function ReferralsPage() {
  const [stats, setStats] = useState<ReferralStats>(defaultStats);
  const [history, setHistory] = useState<ReferralHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const { copied, copy } = useCopyToClipboard();

  useEffect(() => {
    const fetchReferrals = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/referrals', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.referralCode) setStats(data);
          if (Array.isArray(data.history)) setHistory(data.history);
        }
      } catch { /* fallback */ } finally {
        setLoading(false);
      }
    };
    fetchReferrals();
  }, []);

  const shareWhatsApp = () => {
    const text = `Join Velora Billing and get amazing hosting services! Use my referral code: ${stats.referralCode}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const shareTwitter = () => {
    const text = `Check out Velora Billing for premium hosting! 🚀 Use my referral code: ${stats.referralCode}`;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`, '_blank');
  };

  const shareTelegram = () => {
    const text = `Join Velora Billing for premium hosting! Use my referral code: ${stats.referralCode}`;
    window.open(`https://t.me/share/url?url=${encodeURIComponent(stats.referralLink)}&text=${encodeURIComponent(text)}`, '_blank');
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-8 w-56 skeleton-shimmer rounded-lg" />
        <div className="skeleton-card h-32 p-6" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="skeleton-card h-28 p-5" />)}
        </div>
      </div>
    );
  }

  const displayHistory = history.length > 0 ? history : fallbackHistory;
  const currentTier = [...tiers].reverse().find(t => stats.totalReferrals >= t.referrals) || tiers[0];

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="relative overflow-hidden velora-card p-6">
        <div className="absolute inset-0 bg-gradient-to-br from-[#6366f1]/20 via-transparent to-[#8b5cf6]/20 pointer-events-none" />
        <div className="relative">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center animate-pulse-glow">
              <Gift size={24} className="text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-[#e2e8f0]">Referral Program</h2>
              <p className="text-[#64748b]">Earn commission by inviting friends to Velora.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Referral Code + Link */}
      <div className="velora-card">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="flex-1 w-full">
            <label className="block text-xs text-[#64748b] mb-1.5 uppercase tracking-wider">Your Referral Code</label>
            <div className="flex items-center gap-2">
              <div className="velora-input flex-1 font-mono text-lg tracking-wider text-[#6366f1] font-bold bg-[#09090b]">
                {stats.referralCode}
              </div>
              <button
                onClick={() => copy(stats.referralCode)}
                className={`px-4 py-2.5 rounded-lg font-medium text-sm transition-all duration-300 inline-flex items-center gap-2 ${
                  copied ? 'bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/20' : 'velora-btn-primary'
                }`}
              >
                {copied ? <><Check size={16} /> Copied!</> : <><Copy size={16} /> Copy</>}
              </button>
            </div>
          </div>
          <div className="flex-1 w-full">
            <label className="block text-xs text-[#64748b] mb-1.5 uppercase tracking-wider">Referral Link</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={stats.referralLink}
                readOnly
                className="velora-input flex-1 text-sm font-mono bg-[#09090b]"
              />
              <button
                onClick={() => copy(stats.referralLink)}
                className="velora-btn-secondary px-4 py-2.5 text-sm inline-flex items-center gap-2"
              >
                <Copy size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Share Buttons */}
        <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-[#1a1a2e]">
          <span className="text-sm text-[#64748b] self-center mr-2">Share:</span>
          <button onClick={shareWhatsApp} className="px-4 py-2 rounded-lg bg-[#25D366]/10 text-[#25D366] border border-[#25D366]/20 text-sm font-medium hover:bg-[#25D366]/20 transition-all inline-flex items-center gap-2">
            <Share2 size={14} /> WhatsApp
          </button>
          <button onClick={shareTwitter} className="px-4 py-2 rounded-lg bg-[#1DA1F2]/10 text-[#1DA1F2] border border-[#1DA1F2]/20 text-sm font-medium hover:bg-[#1DA1F2]/20 transition-all inline-flex items-center gap-2">
            <Share2 size={14} /> Twitter
          </button>
          <button onClick={shareTelegram} className="px-4 py-2 rounded-lg bg-[#0088cc]/10 text-[#0088cc] border border-[#0088cc]/20 text-sm font-medium hover:bg-[#0088cc]/20 transition-all inline-flex items-center gap-2">
            <Share2 size={14} /> Telegram
          </button>
          <button onClick={() => copy(stats.referralLink)} className="px-4 py-2 rounded-lg bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20 text-sm font-medium hover:bg-[#6366f1]/20 transition-all inline-flex items-center gap-2">
            <Copy size={14} /> Copy Link
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 stagger-children">
        {[
          { label: 'Total Referrals', value: stats.totalReferrals, icon: Users, color: '#6366f1', bg: 'bg-[#6366f1]/10' },
          { label: 'Active', value: stats.activeReferrals, icon: Zap, color: '#10b981', bg: 'bg-[#10b981]/10' },
          { label: 'Total Earnings', value: `₹${stats.totalEarnings.toLocaleString()}`, icon: Wallet, color: '#f59e0b', bg: 'bg-[#f59e0b]/10' },
          { label: 'Pending', value: `₹${stats.pendingEarnings.toLocaleString()}`, icon: Clock, color: '#8b5cf6', bg: 'bg-[#8b5cf6]/10' },
        ].map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="velora-card p-5 hover-lift">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#64748b]">{stat.label}</p>
                  <p className="text-2xl font-bold text-[#e2e8f0] mt-1">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl ${stat.bg} flex items-center justify-center`}>
                  <Icon size={22} style={{ color: stat.color }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Commission Tiers */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1 flex items-center gap-2">
          <Trophy size={18} className="text-[#f59e0b]" />
          Commission Tiers
        </h3>
        <p className="text-sm text-[#64748b] mb-4">Earn more as you refer more people. Current tier: <span className="font-bold" style={{ color: currentTier.color }}>{currentTier.tier}</span></p>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {tiers.map((tier, i) => {
            const isCurrentTier = tier.tier === currentTier.tier;
            const isLocked = stats.totalReferrals < tier.referrals;
            return (
              <div key={i} className={`relative p-4 rounded-xl border transition-all duration-300 ${tier.bg} ${tier.border} ${isCurrentTier ? 'ring-2 ring-offset-2 ring-offset-[#0c0c0f] animate-border-glow' : ''} ${isLocked ? 'opacity-50' : ''}`} style={isCurrentTier ? { borderColor: tier.color, boxShadow: `0 0 15px ${tier.color}30` } : {}}>
                {isCurrentTier && (
                  <div className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-bold text-white" style={{ backgroundColor: tier.color }}>
                    ✓
                  </div>
                )}
                <div className="flex items-center gap-2 mb-2">
                  <tier.icon size={18} style={{ color: tier.color }} />
                  <span className="text-sm font-bold" style={{ color: tier.color }}>{tier.tier}</span>
                </div>
                <p className="text-2xl font-bold text-[#e2e8f0]">{tier.commission}</p>
                <p className="text-xs text-[#64748b] mt-1">{tier.referrals}+ referrals</p>
                {isLocked && (
                  <div className="mt-2 flex items-center gap-1 text-xs text-[#64748b]">
                    <ArrowRight size={10} />
                    {tier.referrals - stats.totalReferrals} more to unlock
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* How It Works */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4">How It Works</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { step: '1', title: 'Share Your Code', desc: 'Share your unique referral code or link with friends and on social media.', color: '#6366f1' },
            { step: '2', title: 'Friend Signs Up', desc: 'When your friend creates an account and makes a purchase using your code.', color: '#8b5cf6' },
            { step: '3', title: 'Earn Commission', desc: 'Receive a percentage of their purchase amount as wallet credit.', color: '#a855f7' },
          ].map((item, i) => (
            <div key={i} className="relative p-5 rounded-xl bg-[#09090b] border border-[#1a1a2e]">
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-lg mb-3" style={{ backgroundColor: item.color }}>
                {item.step}
              </div>
              <h4 className="text-sm font-semibold text-[#e2e8f0] mb-1">{item.title}</h4>
              <p className="text-xs text-[#64748b]">{item.desc}</p>
              {i < 2 && (
                <div className="hidden md:block absolute top-1/2 -right-3 transform -translate-y-1/2 text-[#1a1a2e] z-10">
                  <ChevronRight size={16} />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Referral History */}
      <div className="velora-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
            <TrendingUp size={18} className="text-[#10b981]" />
            Referral History
          </h3>
          <span className="text-sm text-[#64748b]">{displayHistory.length} referral{displayHistory.length !== 1 ? 's' : ''}</span>
        </div>

        {displayHistory.length === 0 ? (
          <div className="text-center py-12">
            <Users className="mx-auto text-[#64748b] mb-3" size={40} />
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Referrals Yet</h3>
            <p className="text-sm text-[#64748b]">Start sharing your referral code to earn commissions!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="velora-table w-full">
              <thead>
                <tr>
                  <th>Referral #</th>
                  <th>User</th>
                  <th>Product</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Commission</th>
                </tr>
              </thead>
              <tbody>
                {displayHistory.map(ref => (
                  <tr key={ref.id}>
                    <td className="font-mono text-sm">{ref.id}</td>
                    <td className="text-[#e2e8f0] font-medium">{ref.referredUser}</td>
                    <td className="text-[#64748b]">{ref.productName}</td>
                    <td className="text-[#64748b]">{new Date(ref.date).toLocaleDateString()}</td>
                    <td><span className={statusBadge[ref.status] || 'velora-badge'}>{ref.status}</span></td>
                    <td className={`font-medium ${ref.commission > 0 ? 'text-[#10b981]' : 'text-[#64748b]'}`}>
                      {ref.commission > 0 ? `₹${ref.commission.toLocaleString()}` : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
