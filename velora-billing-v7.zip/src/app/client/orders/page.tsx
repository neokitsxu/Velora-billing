'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ShoppingCart, Eye, Package, Clock, CheckCircle, XCircle, RefreshCw,
  Search, Filter, ChevronDown, ChevronRight, Server, CreditCard, IndianRupee,
  AlertCircle, ArrowRight, RotateCcw,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Order {
  id: string;
  orderNumber: string;
  productName: string;
  amount: number;
  status: 'pending' | 'paid' | 'processing' | 'active' | 'completed' | 'cancelled' | 'refunded' | 'failed';
  paymentMethod: string;
  date: string;
  productId?: string;
  serviceId?: string;
  updatedAt: string;
}

type StatusFilter = 'all' | 'pending' | 'paid' | 'active' | 'completed' | 'cancelled' | 'refunded';

const fallbackOrders: Order[] = [
  { id: 'ORD-001', orderNumber: 'ORD-2025-001', productName: 'Minecraft Premium', amount: 352.82, status: 'active', paymentMethod: 'Wallet', date: '2025-01-10', productId: 'p1', serviceId: 'SVC-001', updatedAt: '2025-01-10' },
  { id: 'ORD-002', orderNumber: 'ORD-2025-002', productName: 'VPS Starter', amount: 538.82, status: 'pending', paymentMethod: '—', date: '2025-01-12', productId: 'p2', updatedAt: '2025-01-12' },
  { id: 'ORD-003', orderNumber: 'ORD-2025-003', productName: 'Dedicated 32GB', amount: 2948.82, status: 'active', paymentMethod: 'UPI', date: '2025-01-08', productId: 'p3', serviceId: 'SVC-003', updatedAt: '2025-01-08' },
  { id: 'ORD-004', orderNumber: 'ORD-2025-004', productName: 'Minecraft Basic', amount: 175.82, status: 'completed', paymentMethod: 'UPI', date: '2025-01-05', productId: 'p4', updatedAt: '2025-01-06' },
  { id: 'ORD-005', orderNumber: 'ORD-2025-005', productName: 'VPS Pro', amount: 960.82, status: 'cancelled', paymentMethod: 'Wallet', date: '2025-01-03', productId: 'p5', updatedAt: '2025-01-04' },
  { id: 'ORD-006', orderNumber: 'ORD-2025-006', productName: 'Minecraft Premium', amount: 352.82, status: 'refunded', paymentMethod: 'UPI', date: '2024-12-28', productId: 'p6', updatedAt: '2024-12-30' },
  { id: 'ORD-007', orderNumber: 'ORD-2025-007', productName: 'VPS Starter', amount: 538.82, status: 'failed', paymentMethod: 'UPI', date: '2025-01-14', productId: 'p2', updatedAt: '2025-01-14' },
];

const statusConfig: Record<string, { badge: string; color: string; icon: React.ElementType; label: string }> = {
  pending: { badge: 'velora-badge-warning', color: '#f59e0b', icon: Clock, label: 'Pending' },
  paid: { badge: 'velora-badge-info', color: '#6366f1', icon: CreditCard, label: 'Paid' },
  processing: { badge: 'velora-badge-info', color: '#6366f1', icon: RefreshCw, label: 'Processing' },
  active: { badge: 'velora-badge-success', color: '#10b981', icon: CheckCircle, label: 'Active' },
  completed: { badge: 'velora-badge-success', color: '#10b981', icon: CheckCircle, label: 'Completed' },
  cancelled: { badge: 'velora-badge-danger', color: '#ef4444', icon: XCircle, label: 'Cancelled' },
  refunded: { badge: 'velora-badge', color: '#64748b', icon: RotateCcw, label: 'Refunded' },
  failed: { badge: 'velora-badge-danger', color: '#ef4444', icon: AlertCircle, label: 'Failed' },
};

const timelineSteps = ['pending', 'paid', 'processing', 'active'];

function getTimelineIndex(status: string): number {
  if (status === 'pending') return 0;
  if (status === 'paid' || status === 'processing') return status === 'paid' ? 1 : 2;
  if (status === 'active' || status === 'completed') return 3;
  return -1;
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/orders', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setOrders(data);
          else if (Array.isArray(data.orders)) setOrders(data.orders);
        }
      } catch { /* fallback */ } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  const displayOrders = orders.length > 0 ? orders : fallbackOrders;

  const filtered = displayOrders.filter(o => {
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    if (searchQuery && !o.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) && !o.productName.toLowerCase().includes(searchQuery.toLowerCase()) && !o.id.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const handleCancelOrder = async (orderId: string) => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/orders/${orderId}/cancel`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'cancelled' as const, updatedAt: new Date().toISOString() } : o));
        toast.success('Order cancelled');
      } else {
        toast.error('Failed to cancel order');
      }
    } catch { toast.error('Network error'); }
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-8 w-48 skeleton-shimmer rounded-lg" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[1,2,3,4].map(i => <div key={i} className="skeleton-card h-24 p-4" />)}
        </div>
        <div className="space-y-3">
          {[1,2,3,4].map(i => <div key={i} className="skeleton-card h-20 p-5" />)}
        </div>
      </div>
    );
  }

  const totalSpent = displayOrders.filter(o => ['active', 'completed', 'paid'].includes(o.status)).reduce((s, o) => s + o.amount, 0);

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-[#e2e8f0]">My Orders</h2>
          <p className="text-[#64748b] mt-1">View and manage all your orders.</p>
        </div>
        <Link href="/client/products" className="velora-btn-primary inline-flex items-center gap-2 text-sm">
          <ShoppingCart size={16} />
          New Order
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total Spent', value: `₹${totalSpent.toLocaleString()}`, color: '#6366f1', bg: 'bg-[#6366f1]/10', icon: IndianRupee },
          { label: 'Active', value: displayOrders.filter(o => o.status === 'active').length, color: '#10b981', bg: 'bg-[#10b981]/10', icon: CheckCircle },
          { label: 'Pending', value: displayOrders.filter(o => o.status === 'pending').length, color: '#f59e0b', bg: 'bg-[#f59e0b]/10', icon: Clock },
          { label: 'Total Orders', value: displayOrders.length, color: '#8b5cf6', bg: 'bg-[#8b5cf6]/10', icon: Package },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="velora-card p-4 hover-lift">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#64748b]">{s.label}</p>
                  <p className="text-xl font-bold text-[#e2e8f0] mt-0.5">{s.value}</p>
                </div>
                <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center`}>
                  <Icon size={18} style={{ color: s.color }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Search + Filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search by order # or product..." className="velora-input w-full pl-9" />
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <Filter size={14} className="text-[#64748b]" />
          {(['all', 'pending', 'active', 'completed', 'cancelled', 'refunded'] as StatusFilter[]).map(f => (
            <button
              key={f}
              onClick={() => setStatusFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                statusFilter === f
                  ? 'bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 border border-transparent'
              }`}
            >
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Order List */}
      {filtered.length === 0 ? (
        <div className="velora-card text-center py-16">
          <ShoppingCart className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Orders Yet</h3>
          <p className="text-[#64748b] mb-6">
            {searchQuery ? 'No orders match your search.' : "You haven't placed any orders yet."}
          </p>
          {!searchQuery && (
            <Link href="/client/products" className="velora-btn-primary inline-flex items-center gap-2">
              <ShoppingCart size={16} />
              Browse Products
            </Link>
          )}
        </div>
      ) : (
        <div className="space-y-3 stagger-children">
          {filtered.map(order => {
            const sConfig = statusConfig[order.status] || statusConfig.pending;
            const StatusIcon = sConfig.icon;
            const isExpanded = expandedId === order.id;
            const timelineIdx = getTimelineIndex(order.status);
            const isCancelable = order.status === 'pending';

            return (
              <div key={order.id} className={`velora-card transition-all duration-200 ${isExpanded ? 'ring-1 ring-[#6366f1]/20' : ''}`}>
                <button
                  onClick={() => setExpandedId(isExpanded ? null : order.id)}
                  className="w-full flex items-center justify-between text-left p-4"
                >
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0`} style={{ backgroundColor: `${sConfig.color}15` }}>
                      <StatusIcon size={18} style={{ color: sConfig.color }} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-[#e2e8f0]">{order.productName}</p>
                      <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                        <span className="text-xs text-[#64748b] font-mono">{order.orderNumber}</span>
                        <span className={sConfig.badge}>{sConfig.label}</span>
                        <span className="text-xs text-[#64748b]">{order.paymentMethod}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0 ml-4">
                    <div className="text-right hidden sm:block">
                      <p className="text-lg font-bold text-[#e2e8f0]">₹{order.amount.toLocaleString()}</p>
                      <p className="text-xs text-[#64748b]">{new Date(order.date).toLocaleDateString()}</p>
                    </div>
                    {isExpanded ? <ChevronDown size={16} className="text-[#64748b]" /> : <ChevronRight size={16} className="text-[#64748b]" />}
                  </div>
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t border-[#1a1a2e] p-4 animate-fade-in">
                    {/* Status Timeline (for normal flow orders) */}
                    {!['cancelled', 'refunded', 'failed'].includes(order.status) && (
                      <div className="mb-5">
                        <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3">Order Timeline</h4>
                        <div className="flex items-center gap-1">
                          {timelineSteps.map((step, i) => {
                            const isComplete = i <= timelineIdx;
                            const isCurrent = i === timelineIdx;
                            const stepConfig = statusConfig[step] || statusConfig.pending;
                            return (
                              <div key={step} className="flex-1 flex flex-col items-center">
                                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all duration-300 ${
                                  isComplete
                                    ? 'border-[#6366f1] bg-[#6366f1]/20 text-[#6366f1]'
                                    : 'border-[#1a1a2e] bg-[#0c0c0f] text-[#475569]'
                                } ${isCurrent ? 'animate-pulse-glow ring-2 ring-[#6366f1]/30' : ''}`}>
                                  {isComplete ? '✓' : i + 1}
                                </div>
                                <span className={`text-[10px] mt-1 capitalize ${isComplete ? 'text-[#6366f1]' : 'text-[#475569]'}`}>
                                  {step}
                                </span>
                                {i < timelineSteps.length - 1 && (
                                  <div className={`h-0.5 w-full absolute mt-3.5 left-1/2 ${i < timelineIdx ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'}`} />
                                )}
                              </div>
                            );
                          })}
                        </div>
                        <div className="relative flex mt-[-44px] mb-6">
                          {timelineSteps.map((step, i) => (
                            <div key={step} className={`flex-1 h-0.5 ${i < timelineIdx ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'}`} />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Order Details */}
                    <div className="bg-[#09090b] rounded-xl p-4 mb-4">
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                        <div>
                          <span className="text-[#64748b]">Order #</span>
                          <p className="text-[#e2e8f0] font-mono">{order.orderNumber}</p>
                        </div>
                        <div>
                          <span className="text-[#64748b]">Amount</span>
                          <p className="text-[#e2e8f0] font-bold">₹{order.amount.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-[#64748b]">Payment</span>
                          <p className="text-[#e2e8f0]">{order.paymentMethod}</p>
                        </div>
                        <div>
                          <span className="text-[#64748b]">Date</span>
                          <p className="text-[#e2e8f0]">{new Date(order.date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 flex-wrap">
                      {order.serviceId && (
                        <Link
                          href="/client/services"
                          className="velora-btn-secondary inline-flex items-center gap-2 text-sm"
                        >
                          <Server size={14} />
                          View Service
                        </Link>
                      )}
                      {order.productId && (
                        <Link
                          href={`/client/products?product=${order.productId}`}
                          className="velora-btn-secondary inline-flex items-center gap-2 text-sm"
                        >
                          <RefreshCw size={14} />
                          Reorder
                        </Link>
                      )}
                      {isCancelable && (
                        <button
                          onClick={() => handleCancelOrder(order.id)}
                          className="velora-btn-danger inline-flex items-center gap-2 text-sm"
                        >
                          <XCircle size={14} />
                          Cancel Order
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
