'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Server, ExternalLink, Play, Square, RotateCcw, Terminal, XCircle,
  Globe, Box, Clock, Wifi, WifiOff, Loader2, X, ChevronRight,
  Cpu, HardDrive, MemoryStick, Activity, Eye, Copy, Check,
  ShoppingCart, RefreshCw,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface ResourceUsage {
  cpu: number;
  ram: number;
  disk: number;
  bandwidth: number;
}

interface Service {
  id: string;
  name: string;
  productType: string;
  status: 'active' | 'suspended' | 'terminated' | 'pending';
  serverStatus: 'online' | 'offline' | 'pending';
  ip: string;
  port: number;
  username?: string;
  password?: string;
  serverId?: string;
  panelUrl?: string;
  nextDueDate: string;
  billingAmount: number;
  resources?: ResourceUsage;
  createdAt: string;
}



const statusBadge: Record<string, string> = {
  active: 'velora-badge-success',
  suspended: 'velora-badge-warning',
  terminated: 'velora-badge-danger',
  pending: 'velora-badge-info',
};

const serverStatusDot: Record<string, { color: string; bg: string; pulse: boolean }> = {
  online: { color: 'bg-[#10b981]', bg: 'bg-[#10b981]/20', pulse: true },
  offline: { color: 'bg-[#ef4444]', bg: 'bg-[#ef4444]/20', pulse: false },
  pending: { color: 'bg-[#f59e0b]', bg: 'bg-[#f59e0b]/20', pulse: true },
};

const typeIcons: Record<string, React.ElementType> = { Minecraft: Box, VPS: Server, Dedicated: Server };

function ResourceBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-[#64748b]">{label}</span>
        <span className="text-[#e2e8f0]">{value}%</span>
      </div>
      <div className="h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full animate-progress-fill ${color}`}
          style={{ width: `${Math.min(value, 100)}%` }}
        />
      </div>
    </div>
  );
}

function SparklineMini({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const w = 80;
  const h = 24;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / range) * h}`).join(' ');
  return (
    <svg width={w} height={h} className="opacity-60">
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function ServicesPage() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmAction, setConfirmAction] = useState<{ serviceId: string; action: string } | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/services', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setServices(data);
          else if (Array.isArray(data.services)) setServices(data.services);
        }
      } catch { /* fallback */ } finally {
        setLoading(false);
      }
    };
    fetchServices();
  }, []);

  const handleAction = async (serviceId: string, action: string) => {
    if (!confirmAction || confirmAction.serviceId !== serviceId || confirmAction.action !== action) {
      setConfirmAction({ serviceId, action });
      return;
    }
    setConfirmAction(null);
    setActionLoading(serviceId);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/services/${serviceId}/${action}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        toast.success(`${action.charAt(0).toUpperCase() + action.slice(1)} request submitted`);
      } else {
        toast.error('Failed to submit request');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setActionLoading(null);
    }
  };

  const copyField = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopiedField(null), 2000);
  };

  const getDaysUntil = (dateStr: string) => {
    const diff = new Date(dateStr).getTime() - Date.now();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-8 w-64 skeleton-shimmer rounded-lg" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="skeleton-card p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 skeleton rounded-xl" />
                <div className="space-y-2 flex-1">
                  <div className="h-4 w-40 skeleton rounded" />
                  <div className="h-3 w-20 skeleton rounded" />
                </div>
              </div>
              <div className="h-24 skeleton rounded-lg" />
            </div>
          ))}
        </div>
      </div>
    );
  }



  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#e2e8f0]">My Services</h2>
          <p className="text-[#64748b] mt-1">Manage your active services and servers.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-[#64748b]">{services.length} service{services.length !== 1 ? 's' : ''}</span>
          <button
            onClick={() => window.location.reload()}
            className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors"
          >
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Online', count: services.filter(s => s.serverStatus === 'online').length, color: '#10b981', bg: 'bg-[#10b981]/10' },
          { label: 'Offline', count: services.filter(s => s.serverStatus === 'offline').length, color: '#ef4444', bg: 'bg-[#ef4444]/10' },
          { label: 'Pending', count: services.filter(s => s.serverStatus === 'pending').length, color: '#f59e0b', bg: 'bg-[#f59e0b]/10' },
          { label: 'Suspended', count: services.filter(s => s.status === 'suspended').length, color: '#f59e0b', bg: 'bg-[#f59e0b]/10' },
        ].map((stat, i) => (
          <div key={i} className="velora-card p-4">
            <div className={`text-2xl font-bold`} style={{ color: stat.color }}>{stat.count}</div>
            <div className="text-xs text-[#64748b] mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      {services.length === 0 ? (
        <div className="velora-card p-12 text-center">
          <Server className="h-12 w-12 text-[#6366f1]/30 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2">No Services</h3>
          <p className="text-sm text-[#64748b] mb-6">You don&apos;t have any active services yet.</p>
          <Link href="/client/products" className="velora-btn-primary inline-flex items-center gap-2">
            <ShoppingCart size={16} />
            Browse Products
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 stagger-children">
          {services.map((service) => {
            const TypeIcon = typeIcons[service.productType] || Server;
            const serverDot = serverStatusDot[service.serverStatus] || serverStatusDot.pending;
            const daysUntil = getDaysUntil(service.nextDueDate);
            const isSuspendedOrTerminated = service.status === 'suspended' || service.status === 'terminated';

            return (
              <div key={service.id} className={`velora-card ${isSuspendedOrTerminated ? 'opacity-60' : ''}`}>
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-[#6366f1]/10 flex items-center justify-center relative">
                      <TypeIcon size={20} className="text-[#6366f1]" />
                      <div className={`absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full ${serverDot.color} ${serverDot.pulse ? 'animate-pulse' : ''}`} />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-[#e2e8f0]">{service.name}</h3>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="velora-badge text-xs">{service.productType}</span>
                        <div className="flex items-center gap-1">
                          <div className={`w-1.5 h-1.5 rounded-full ${serverDot.color}`} />
                          <span className="text-xs text-[#64748b] capitalize">{service.serverStatus}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <span className={statusBadge[service.status] || 'velora-badge'}>{service.status}</span>
                </div>

                {/* Suspended/Terminated Banner */}
                {isSuspendedOrTerminated && (
                  <div className={`mb-4 p-3 rounded-lg ${service.status === 'suspended' ? 'bg-[#f59e0b]/10 border border-[#f59e0b]/20' : 'bg-[#ef4444]/10 border border-[#ef4444]/20'}`}>
                    <div className="flex items-center gap-2">
                      {service.status === 'suspended' ? (
                        <WifiOff size={16} className="text-[#f59e0b]" />
                      ) : (
                        <XCircle size={16} className="text-[#ef4444]" />
                      )}
                      <span className={`text-sm ${service.status === 'suspended' ? 'text-[#f59e0b]' : 'text-[#ef4444]'}`}>
                        {service.status === 'suspended'
                          ? 'This service has been suspended. Please pay the outstanding balance to reactivate.'
                          : 'This service has been terminated. Contact support for assistance.'}
                      </span>
                    </div>
                  </div>
                )}

                {/* Resource Usage */}
                {service.resources && service.serverStatus === 'online' && (
                  <div className="bg-[#09090b] rounded-lg p-3 mb-4 space-y-2.5">
                    <div className="text-xs text-[#64748b] font-medium uppercase tracking-wider mb-1">Resource Usage</div>
                    <ResourceBar label="CPU" value={service.resources.cpu} color="bg-gradient-to-r from-[#6366f1] to-[#818cf8]" />
                    <ResourceBar label="RAM" value={service.resources.ram} color="bg-gradient-to-r from-[#8b5cf6] to-[#a78bfa]" />
                    <ResourceBar label="Disk" value={service.resources.disk} color="bg-gradient-to-r from-[#10b981] to-[#34d399]" />
                    <ResourceBar label="Bandwidth" value={service.resources.bandwidth} color="bg-gradient-to-r from-[#f59e0b] to-[#fbbf24]" />
                  </div>
                )}

                {/* Mini Sparkline area for active services */}
                {service.serverStatus === 'online' && (
                  <div className="flex items-center justify-between mb-4 px-1">
                    <span className="text-xs text-[#64748b]">CPU (24h)</span>
                    <SparklineMini
                      data={Array.from({ length: 12 }, () => Math.random() * 60 + 20)}
                      color="#6366f1"
                    />
                  </div>
                )}

                {/* Server Info */}
                <div className="bg-[#09090b] rounded-lg p-3 mb-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Server IP</span>
                    <button onClick={() => copyField(`${service.ip}:${service.port}`, `ip-${service.id}`)} className="flex items-center gap-1.5 text-[#e2e8f0] font-mono hover:text-[#6366f1] transition-colors">
                      {service.ip}:{service.port}
                      {copiedField === `ip-${service.id}` ? <Check size={12} className="text-[#10b981]" /> : <Copy size={12} className="text-[#64748b]" />}
                    </button>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Service ID</span>
                    <span className="text-[#e2e8f0] font-mono text-xs">{service.id}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Next Renewal</span>
                    <div className="flex items-center gap-1.5">
                      <Clock size={12} className={daysUntil <= 7 ? 'text-[#f59e0b]' : 'text-[#64748b]'} />
                      <span className={`text-[#e2e8f0] ${daysUntil <= 7 ? 'text-[#f59e0b]' : ''}`}>
                        {daysUntil} day{daysUntil !== 1 ? 's' : ''}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Billing</span>
                    <span className="text-[#e2e8f0]">₹{service.billingAmount.toLocaleString()}/mo</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedService(service)}
                    className="velora-btn-secondary inline-flex items-center gap-2 text-xs px-3 py-1.5"
                  >
                    <Eye size={13} />
                    Details
                  </button>

                  {service.serverStatus === 'online' && service.panelUrl && service.serverId && (
                    <>
                      <a
                        href={service.panelUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="velora-btn-primary inline-flex items-center gap-2 text-xs px-3 py-1.5"
                      >
                        <Terminal size={13} />
                        Console
                      </a>
                      <button
                        onClick={() => handleAction(service.id, 'restart')}
                        className={`velora-btn-secondary inline-flex items-center gap-2 text-xs px-3 py-1.5 ${
                          confirmAction?.serviceId === service.id && confirmAction.action === 'restart'
                            ? '!border-[#6366f1] !text-[#6366f1]'
                            : ''
                        }`}
                        disabled={actionLoading === service.id}
                      >
                        {actionLoading === service.id ? <Loader2 size={13} className="animate-spin" /> : <RotateCcw size={13} />}
                        {confirmAction?.serviceId === service.id && confirmAction.action === 'restart' ? 'Confirm?' : 'Restart'}
                      </button>
                      <button
                        onClick={() => handleAction(service.id, 'stop')}
                        className={`velora-btn-secondary inline-flex items-center gap-2 text-xs px-3 py-1.5 ${
                          confirmAction?.serviceId === service.id && confirmAction.action === 'stop'
                            ? '!border-[#f59e0b] !text-[#f59e0b]'
                            : ''
                        }`}
                        disabled={actionLoading === service.id}
                      >
                        {actionLoading === service.id ? <Loader2 size={13} className="animate-spin" /> : <Square size={13} />}
                        {confirmAction?.serviceId === service.id && confirmAction.action === 'stop' ? 'Confirm?' : 'Stop'}
                      </button>
                    </>
                  )}

                  {service.serverStatus === 'offline' && service.status === 'active' && (
                    <button
                      onClick={() => handleAction(service.id, 'start')}
                      className={`velora-btn-success inline-flex items-center gap-2 text-xs px-3 py-1.5 ${
                        confirmAction?.serviceId === service.id && confirmAction.action === 'start'
                            ? '!bg-[#10b981]/30'
                            : ''
                      }`}
                      disabled={actionLoading === service.id}
                    >
                      {actionLoading === service.id ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} />}
                      {confirmAction?.serviceId === service.id && confirmAction.action === 'start' ? 'Confirm?' : 'Start'}
                    </button>
                  )}

                  {service.serverStatus === 'online' && (
                    <>
                      <button
                        onClick={() => handleAction(service.id, 'reinstall')}
                        className={`velora-btn-secondary inline-flex items-center gap-2 text-xs px-3 py-1.5 ${
                          confirmAction?.serviceId === service.id && confirmAction.action === 'reinstall'
                            ? '!border-[#f59e0b] !text-[#f59e0b]'
                            : ''
                        }`}
                        disabled={actionLoading === service.id}
                      >
                        {actionLoading === service.id ? <Loader2 size={13} className="animate-spin" /> : <RotateCcw size={13} />}
                        {confirmAction?.serviceId === service.id && confirmAction.action === 'reinstall' ? 'Confirm?' : 'Reinstall'}
                      </button>
                      <button
                        onClick={() => handleAction(service.id, 'kill')}
                        className={`velora-btn-danger inline-flex items-center gap-2 text-xs px-3 py-1.5 ${
                          confirmAction?.serviceId === service.id && confirmAction.action === 'kill'
                            ? '!border-[#ef4444] !bg-[#ef4444]/20'
                            : ''
                        }`}
                        disabled={actionLoading === service.id}
                      >
                        <XCircle size={13} />
                        {confirmAction?.serviceId === service.id && confirmAction.action === 'kill' ? 'Confirm Kill?' : 'Kill'}
                      </button>
                    </>
                  )}

                  {service.status === 'suspended' && (
                    <Link
                      href="/client/wallet"
                      className="velora-btn-primary inline-flex items-center gap-2 text-xs px-3 py-1.5"
                    >
                      Add Funds
                    </Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Service Details Modal */}
      {selectedService && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setSelectedService(null)}>
          <div className="bg-[#0c0c0f] border border-[#1a1a2e] rounded-2xl max-w-lg w-full max-h-[85vh] overflow-y-auto animate-scale-in" onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-[#1a1a2e]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#6366f1]/10 flex items-center justify-center">
                  <Server size={20} className="text-[#6366f1]" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-[#e2e8f0]">{selectedService.name}</h3>
                  <span className="velora-badge text-xs">{selectedService.productType}</span>
                </div>
              </div>
              <button onClick={() => setSelectedService(null)} className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-5">
              {/* Server Status */}
              <div className={`flex items-center gap-3 p-3 rounded-lg ${
                selectedService.serverStatus === 'online' ? 'bg-[#10b981]/10 border border-[#10b981]/20' :
                selectedService.serverStatus === 'offline' ? 'bg-[#ef4444]/10 border border-[#ef4444]/20' :
                'bg-[#f59e0b]/10 border border-[#f59e0b]/20'
              }`}>
                {selectedService.serverStatus === 'online' ? <Wifi size={18} className="text-[#10b981]" /> :
                 selectedService.serverStatus === 'offline' ? <WifiOff size={18} className="text-[#ef4444]" /> :
                 <Loader2 size={18} className="text-[#f59e0b] animate-spin" />}
                <div>
                  <p className="text-sm font-medium capitalize" style={{ color: selectedService.serverStatus === 'online' ? '#10b981' : selectedService.serverStatus === 'offline' ? '#ef4444' : '#f59e0b' }}>
                    Server is {selectedService.serverStatus}
                  </p>
                  <p className="text-xs text-[#64748b]">Last checked just now</p>
                </div>
              </div>

              {/* Credentials */}
              {(selectedService.username || selectedService.password) && (
                <div>
                  <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3">Credentials</h4>
                  <div className="space-y-2">
                    {selectedService.ip && (
                      <div className="flex items-center justify-between bg-[#09090b] rounded-lg p-3">
                        <div>
                          <p className="text-xs text-[#64748b]">IP Address</p>
                          <p className="text-sm font-mono text-[#e2e8f0]">{selectedService.ip}:{selectedService.port}</p>
                        </div>
                        <button onClick={() => copyField(`${selectedService.ip}:${selectedService.port}`, 'modal-ip')} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#1a1a2e]/50 transition-colors">
                          {copiedField === 'modal-ip' ? <Check size={14} className="text-[#10b981]" /> : <Copy size={14} />}
                        </button>
                      </div>
                    )}
                    {selectedService.username && (
                      <div className="flex items-center justify-between bg-[#09090b] rounded-lg p-3">
                        <div>
                          <p className="text-xs text-[#64748b]">Username</p>
                          <p className="text-sm font-mono text-[#e2e8f0]">{selectedService.username}</p>
                        </div>
                        <button onClick={() => copyField(selectedService.username!, 'modal-user')} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#1a1a2e]/50 transition-colors">
                          {copiedField === 'modal-user' ? <Check size={14} className="text-[#10b981]" /> : <Copy size={14} />}
                        </button>
                      </div>
                    )}
                    {selectedService.password && (
                      <div className="flex items-center justify-between bg-[#09090b] rounded-lg p-3">
                        <div>
                          <p className="text-xs text-[#64748b]">Password</p>
                          <p className="text-sm font-mono text-[#e2e8f0]">{'•'.repeat(selectedService.password.length)}</p>
                        </div>
                        <button onClick={() => copyField(selectedService.password!, 'modal-pass')} className="p-1.5 rounded-lg text-[#64748b] hover:text-[#6366f1] hover:bg-[#1a1a2e]/50 transition-colors">
                          {copiedField === 'modal-pass' ? <Check size={14} className="text-[#10b981]" /> : <Copy size={14} />}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Billing Info */}
              <div>
                <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3">Billing Information</h4>
                <div className="bg-[#09090b] rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Amount</span>
                    <span className="text-[#e2e8f0] font-medium">₹{selectedService.billingAmount.toLocaleString()}/mo</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Next Due</span>
                    <span className="text-[#e2e8f0]">{new Date(selectedService.nextDueDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#64748b]">Created</span>
                    <span className="text-[#64748b]">{new Date(selectedService.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              {/* Resource Usage */}
              {selectedService.resources && selectedService.serverStatus === 'online' && (
                <div>
                  <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3">Resource Usage</h4>
                  <div className="bg-[#09090b] rounded-lg p-3 space-y-3">
                    <ResourceBar label="CPU" value={selectedService.resources.cpu} color="bg-gradient-to-r from-[#6366f1] to-[#818cf8]" />
                    <ResourceBar label="RAM" value={selectedService.resources.ram} color="bg-gradient-to-r from-[#8b5cf6] to-[#a78bfa]" />
                    <ResourceBar label="Disk" value={selectedService.resources.disk} color="bg-gradient-to-r from-[#10b981] to-[#34d399]" />
                    <ResourceBar label="Bandwidth" value={selectedService.resources.bandwidth} color="bg-gradient-to-r from-[#f59e0b] to-[#fbbf24]" />
                  </div>
                </div>
              )}

              {/* Panel Link */}
              {selectedService.panelUrl && (
                <a
                  href={selectedService.panelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="velora-btn-primary w-full flex items-center justify-center gap-2 py-3"
                >
                  <ExternalLink size={16} />
                  Open Server Console
                  <ChevronRight size={16} />
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
