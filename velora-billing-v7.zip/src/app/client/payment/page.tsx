'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  QrCode, Copy, Clock, CheckCircle, XCircle, ArrowLeft, 
  ExternalLink, Smartphone, Shield, Loader2, RefreshCw 
} from 'lucide-react';
import toast from 'react-hot-toast';

type PaymentStatus = 'loading' | 'pending' | 'verifying' | 'successful' | 'expired' | 'failed';

export default function PaymentPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const orderId = searchParams.get('order') || searchParams.get('invoice');
  
  const [payment, setPayment] = useState<any>(null);
  const [order, setOrder] = useState<any>(null);
  const [status, setStatus] = useState<PaymentStatus>('loading');
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes
  const [copied, setCopied] = useState(false);

  // Create payment on mount
  useEffect(() => {
    if (!orderId) {
      router.push('/client/orders');
      return;
    }
    createPayment();
  }, [orderId]);

  // Polling for payment status
  useEffect(() => {
    if (!payment?.id || status === 'loading') return;
    
    const interval = setInterval(async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch(`/api/payment/verify?id=${payment.id}`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        if (data.success && data.data) {
          const pStatus = data.data.status;
          if (pStatus === 'successful') setStatus('successful');
          else if (pStatus === 'expired') setStatus('expired');
          else if (pStatus === 'failed') setStatus('failed');
          else if (pStatus === 'verifying') setStatus('verifying');
          if (pStatus === 'successful' || pStatus === 'expired' || pStatus === 'failed') {
            clearInterval(interval);
          }
        }
      } catch { /* ignore polling errors */ }
    }, 5000);

    return () => clearInterval(interval);
  }, [payment?.id, status]);

  // Countdown timer
  useEffect(() => {
    if (status !== 'pending' && status !== 'loading') return;
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) { clearInterval(timer); setStatus('expired'); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [status]);

  const createPayment = async () => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/payment/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ orderId, invoiceId: orderId }),
      });
      const data = await res.json();
      if (data.success) {
        setPayment(data.data.payment);
        setOrder(data.data.order);
        setStatus('pending');
      } else {
        toast.error(data.error || 'Failed to create payment');
        setStatus('failed');
      }
    } catch {
      toast.error('Network error');
      setStatus('failed');
    }
  };

  const handleCopyUpi = () => {
    if (payment?.upiId) {
      navigator.clipboard.writeText(payment.upiId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const timerPercent = (timeLeft / 600) * 100;

  // LOADING STATE
  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-[#6366f1] animate-spin mx-auto mb-4" />
          <p className="text-[#64748b]">Creating payment...</p>
        </div>
      </div>
    );
  }

  // SUCCESS STATE
  if (status === 'successful') {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center px-4">
        <div className="velora-card p-10 max-w-md w-full text-center animate-slide-up">
          <div className="w-20 h-20 rounded-full bg-[#10b981]/10 border-2 border-[#10b981] flex items-center justify-center mx-auto mb-6 animate-glow" style={{ boxShadow: '0 0 30px rgba(16,185,129,0.3)' }}>
            <CheckCircle className="w-10 h-10 text-[#10b981]" />
          </div>
          <h2 className="text-2xl font-bold text-[#10b981] mb-2">Payment Successful!</h2>
          <p className="text-[#64748b] mb-2">Your payment has been verified.</p>
          <p className="text-[#e2e8f0] text-lg font-semibold mb-6">₹{order?.amount || payment?.amount || '0'}</p>
          <div className="flex gap-3 justify-center">
            <Link href="/client/orders" className="velora-btn-primary px-6 py-2.5 rounded-lg text-sm">
              View Orders
            </Link>
            <Link href="/client/dashboard" className="velora-btn-secondary px-6 py-2.5 rounded-lg text-sm">
              Dashboard
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // EXPIRED STATE
  if (status === 'expired') {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center px-4">
        <div className="velora-card p-10 max-w-md w-full text-center animate-slide-up">
          <div className="w-20 h-20 rounded-full bg-[#ef4444]/10 border-2 border-[#ef4444] flex items-center justify-center mx-auto mb-6">
            <XCircle className="w-10 h-10 text-[#ef4444]" />
          </div>
          <h2 className="text-2xl font-bold text-[#ef4444] mb-2">Payment Expired</h2>
          <p className="text-[#64748b] mb-6">This payment link has expired. Please try again.</p>
          <button onClick={createPayment} className="velora-btn-primary px-6 py-2.5 rounded-lg text-sm flex items-center gap-2 mx-auto">
            <RefreshCw size={16} /> Retry Payment
          </button>
        </div>
      </div>
    );
  }

  // FAILED STATE
  if (status === 'failed') {
    return (
      <div className="min-h-screen bg-[#09090b] flex items-center justify-center px-4">
        <div className="velora-card p-10 max-w-md w-full text-center animate-slide-up">
          <XCircle className="w-16 h-16 text-[#ef4444] mx-auto mb-4" />
          <h2 className="text-xl font-bold text-[#ef4444] mb-2">Payment Failed</h2>
          <p className="text-[#64748b] mb-6">Something went wrong. Please try again.</p>
          <div className="flex gap-3 justify-center">
            <button onClick={createPayment} className="velora-btn-primary px-6 py-2.5 rounded-lg text-sm">Try Again</button>
            <Link href="/client/products" className="velora-btn-secondary px-6 py-2.5 rounded-lg text-sm">Browse Products</Link>
          </div>
        </div>
      </div>
    );
  }

  // MAIN PAYMENT PAGE
  return (
    <div className="min-h-screen bg-[#09090b] grid-bg">
      <div className="max-w-2xl mx-auto px-4 py-8 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/client/orders" className="p-2 rounded-lg bg-[#0c0c0f] border border-[#1a1a2e] hover:border-[#6366f1] transition-colors">
            <ArrowLeft size={18} className="text-[#64748b]" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-[#e2e8f0]">Complete Payment</h1>
            <p className="text-sm text-[#64748b]">Order #{order?.orderNumber || payment?.id?.slice(0,8)}</p>
          </div>
        </div>

        {/* Amount Card */}
        <div className="velora-card p-6 mb-6 text-center" style={{ background: 'linear-gradient(135deg, rgba(99,102,241,0.1) 0%, rgba(139,92,246,0.05) 100%)' }}>
          <p className="text-sm text-[#64748b] mb-1">Amount to Pay</p>
          <p className="text-4xl font-bold bg-gradient-to-r from-[#6366f1] to-[#8b5cf6] bg-clip-text text-transparent">
            ₹{payment?.amount || order?.amount || '0'}
          </p>
          {order?.product?.name && <p className="text-sm text-[#64748b] mt-2">{order.product.name}</p>}
        </div>

        {/* Timer */}
        <div className="velora-card p-4 mb-6">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-sm">
              <Clock size={16} className={timeLeft < 120 ? 'text-[#ef4444]' : 'text-[#f59e0b]'} />
              <span className={timeLeft < 120 ? 'text-[#ef4444] font-medium' : 'text-[#64748b]'}>
                {timeLeft < 120 ? 'Hurry! Payment expiring soon' : 'Time remaining'}
              </span>
            </div>
            <span className={`font-mono font-bold text-lg ${timeLeft < 120 ? 'text-[#ef4444]' : 'text-[#e2e8f0]'}`}>
              {formatTime(timeLeft)}
            </span>
          </div>
          <div className="w-full h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-1000 ${timeLeft < 120 ? 'bg-[#ef4444]' : 'bg-[#6366f1]'}`}
              style={{ width: `${timerPercent}%` }}
            />
          </div>
        </div>

        {/* QR Code Section */}
        <div className="velora-card p-6 mb-6">
          <div className="text-center">
            {/* QR Code */}
            {payment?.qrCode ? (
              <div className="bg-white p-4 rounded-xl inline-block mb-4 shadow-lg">
                <img src={payment.qrCode} alt="UPI QR Code" className="w-48 h-48" />
              </div>
            ) : (
              <div className="w-48 h-48 bg-[#1a1a2e] rounded-xl flex items-center justify-center mx-auto mb-4">
                <QrCode size={64} className="text-[#6366f1]" />
              </div>
            )}
            
            <p className="text-sm text-[#64748b] mb-4">Scan with any UPI app</p>

            {/* Open UPI App Button */}
            {payment?.paymentUrl && (
              <a 
                href={payment.paymentUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="velora-btn-primary inline-flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm mb-4"
              >
                <Smartphone size={16} />
                Open UPI App
                <ExternalLink size={14} />
              </a>
            )}

            {/* UPI ID */}
            <div className="flex items-center justify-center gap-2 mt-4 p-3 bg-[#09090b] border border-[#1a1a2e] rounded-lg">
              <span className="text-sm text-[#64748b]">UPI ID:</span>
              <span className="font-mono font-medium text-[#e2e8f0]">{payment?.upiId || 'yourname@paytm'}</span>
              <button onClick={handleCopyUpi} className="p-1 hover:bg-[#1a1a2e] rounded transition-colors">
                <Copy size={14} className={copied ? 'text-[#10b981]' : 'text-[#64748b]'} />
              </button>
            </div>
          </div>
        </div>

        {/* Status Indicator */}
        <div className="velora-card p-4 mb-6">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${status === 'verifying' ? 'bg-[#f59e0b] animate-pulse' : 'bg-[#f59e0b] animate-pulse'}`} />
            <span className="text-sm text-[#f59e0b]">
              {status === 'verifying' ? 'Verifying payment...' : 'Waiting for payment...'}
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-2 ml-6">
            This page will automatically update once payment is verified. Please keep this page open.
          </p>
        </div>

        {/* Steps */}
        <div className="velora-card p-6">
          <h3 className="text-sm font-semibold text-[#e2e8f0] mb-4">How to Pay</h3>
          <div className="space-y-3">
            {[
              { step: 1, text: 'Scan the QR code with any UPI app (GPay, PhonePe, Paytm)' },
              { step: 2, text: 'Pay the exact amount shown above' },
              { step: 3, text: 'Wait for automatic verification (auto-updates this page)' },
            ].map(item => (
              <div key={item.step} className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-[#6366f1]/10 border border-[#6366f1]/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-[#6366f1]">{item.step}</span>
                </div>
                <p className="text-sm text-[#64748b]">{item.text}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center gap-2 text-xs text-[#64748b]">
            <Shield size={12} />
            <span>Payments are verified securely by admin</span>
          </div>
        </div>
      </div>
    </div>
  );
}
