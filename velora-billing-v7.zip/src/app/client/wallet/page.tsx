'use client';

import { useState, useEffect } from 'react';
import {
  Wallet, Plus, ArrowUpRight, ArrowDownLeft, RotateCcw, Loader2, CreditCard,
  Download, Filter, Clock, TrendingUp, Zap, RefreshCw, IndianRupee,
  ToggleLeft, ToggleRight, Receipt,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Transaction {
  id: string;
  date: string;
  type: 'credit' | 'debit' | 'refund';
  amount: number;
  balance: number;
  description: string;
  reference: string;
  method?: string;
}

type TypeFilter = 'all' | 'credit' | 'debit' | 'refund';

const fallbackTransactions: Transaction[] = [
  { id: 'TXN-001', date: '2025-01-14T14:30:00Z', type: 'credit', amount: 500, balance: 1750, description: 'Wallet top-up via UPI', reference: 'UPI_REF_001', method: 'UPI' },
  { id: 'TXN-002', date: '2025-01-12T10:00:00Z', type: 'debit', amount: 352.82, balance: 1250, description: 'Payment for INV-001', reference: 'INV-001', method: 'Wallet' },
  { id: 'TXN-003', date: '2025-01-10T09:00:00Z', type: 'refund', amount: 499, balance: 1602.82, description: 'Refund for cancelled order ORD-005', reference: 'REF_001', method: 'Wallet' },
  { id: 'TXN-004', date: '2025-01-08T09:00:00Z', type: 'debit', amount: 2948.82, balance: 1103.82, description: 'Payment for INV-003', reference: 'INV-003', method: 'Wallet' },
  { id: 'TXN-005', date: '2025-01-05T16:00:00Z', type: 'credit', amount: 2000, balance: 4052.64, description: 'Wallet top-up via UPI', reference: 'UPI_REF_002', method: 'UPI' },
  { id: 'TXN-006', date: '2025-01-03T11:00:00Z', type: 'debit', amount: 175.82, balance: 2052.64, description: 'Payment for INV-004', reference: 'INV-004', method: 'Wallet' },
  { id: 'TXN-007', date: '2024-12-28T08:00:00Z', type: 'credit', amount: 1000, balance: 2228.46, description: 'Wallet top-up via UPI', reference: 'UPI_REF_003', method: 'UPI' },
  { id: 'TXN-008', date: '2024-12-25T12:00:00Z', type: 'debit', amount: 960.82, balance: 1228.46, description: 'Payment for INV-005', reference: 'INV-005', method: 'Wallet' },
  { id: 'TXN-009', date: '2024-12-20T10:00:00Z', type: 'credit', amount: 199, balance: 2189.28, description: 'Referral commission earned', reference: 'REF_COM_001', method: 'Referral' },
  { id: 'TXN-010', date: '2024-12-15T14:00:00Z', type: 'credit', amount: 500, balance: 1990.28, description: 'Wallet top-up via UPI', reference: 'UPI_REF_004', method: 'UPI' },
];

const typeConfig: Record<string, { badge: string; color: string; icon: React.ElementType; label: string }> = {
  credit: { badge: 'velora-badge-success', color: '#10b981', icon: ArrowDownLeft, label: 'Credit' },
  debit: { badge: 'velora-badge-danger', color: '#ef4444', icon: ArrowUpRight, label: 'Debit' },
  refund: { badge: 'velora-badge-info', color: '#6366f1', icon: RotateCcw, label: 'Refund' },
};

const quickAmounts = [100, 500, 1000, 2500];

export default function WalletPage() {
  const [balance, setBalance] = useState(1750);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [topUpAmount, setTopUpAmount] = useState('');
  const [topUpUpiId, setTopUpUpiId] = useState('');
  const [topUpLoading, setTopUpLoading] = useState(false);
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all');
  const [autoReload, setAutoReload] = useState(false);
  const [autoThreshold, setAutoThreshold] = useState('500');
  const [autoAmount, setAutoAmount] = useState('1000');

  useEffect(() => {
    const fetchWallet = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/wallet', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.balance !== undefined) setBalance(data.balance);
          if (Array.isArray(data.transactions)) setTransactions(data.transactions);
        }
      } catch { /* fallback */ } finally {
        setLoading(false);
      }
    };
    fetchWallet();
  }, []);

  const handleTopUp = async () => {
    const amount = parseFloat(topUpAmount);
    if (!amount || amount <= 0) { toast.error('Please enter a valid amount'); return; }
    if (!topUpUpiId.trim()) { toast.error('Please enter your UPI ID'); return; }

    setTopUpLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/wallet/topup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ amount, upiId: topUpUpiId }),
      });
      if (res.ok) {
        toast.success(`Top-up request of ₹${amount} submitted!`);
        setTopUpAmount('');
        setTopUpUpiId('');
      } else {
        toast.error('Failed to initiate top-up');
      }
    } catch { toast.error('Network error'); }
    finally { setTopUpLoading(false); }
  };

  const handleAutoReload = () => {
    setAutoReload(!autoReload);
    toast.success(autoReload ? 'Auto-reload disabled' : 'Auto-reload enabled');
  };

  const displayTransactions = transactions.length > 0 ? transactions : fallbackTransactions;
  const filtered = displayTransactions.filter(tx => typeFilter === 'all' || tx.type === typeFilter);

  const formatTimeAgo = (dateStr: string) => {
    const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
    return new Date(dateStr).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-8 w-48 skeleton-shimmer rounded-lg" />
        <div className="skeleton-card h-36 p-6" />
        <div className="skeleton-card h-48 p-6" />
        <div className="space-y-2">
          {[1,2,3,4,5].map(i => <div key={i} className="skeleton-card h-16 p-4" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-[#e2e8f0]">Wallet</h2>
          <p className="text-[#64748b] mt-1">Manage your wallet balance and transactions.</p>
        </div>
        <button onClick={() => window.location.reload()} className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors">
          <RefreshCw size={16} />
        </button>
      </div>

      {/* Balance Card */}
      <div className="relative overflow-hidden velora-card p-6 border-2 border-transparent">
        <div className="absolute inset-0 bg-gradient-to-br from-[#6366f1]/20 via-[#0c0c0f] to-[#8b5cf6]/20 pointer-events-none" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#6366f1]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center animate-pulse-glow">
                <Wallet size={24} className="text-white" />
              </div>
              <div>
                <span className="text-sm text-[#64748b]">Available Balance</span>
                <p className="text-4xl font-bold gradient-text">₹{balance.toLocaleString()}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
              <TrendingUp size={12} className="text-[#10b981]" />
              <span>{displayTransactions.filter(t => t.type === 'credit').length} credits</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
              <ArrowUpRight size={12} className="text-[#ef4444]" />
              <span>{displayTransactions.filter(t => t.type === 'debit').length} debits</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
              <RotateCcw size={12} className="text-[#6366f1]" />
              <span>{displayTransactions.filter(t => t.type === 'refund').length} refunds</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Add Funds */}
      <div className="velora-card">
        <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
          <Plus size={18} className="text-[#6366f1]" />
          Add Funds
        </h3>

        {/* Quick Amount Buttons */}
        <div className="grid grid-cols-4 gap-2 mb-4">
          {quickAmounts.map(amt => (
            <button
              key={amt}
              onClick={() => setTopUpAmount(amt.toString())}
              className={`py-3 rounded-xl text-sm font-bold transition-all duration-200 border ${
                topUpAmount === amt.toString()
                  ? 'bg-[#6366f1]/10 text-[#6366f1] border-[#6366f1]/30 velora-glow'
                  : 'bg-[#09090b] text-[#e2e8f0] border-[#1a1a2e] hover:border-[#6366f1]/30 hover:bg-[#6366f1]/5'
              }`}
            >
              ₹{amt}
            </button>
          ))}
          <button
            onClick={() => setTopUpAmount('custom')}
            className={`py-3 rounded-xl text-sm font-bold transition-all duration-200 border col-span-4 ${
              topUpAmount === 'custom'
                ? 'bg-[#8b5cf6]/10 text-[#8b5cf6] border-[#8b5cf6]/30'
                : 'bg-[#09090b] text-[#64748b] border-[#1a1a2e] hover:border-[#8b5cf6]/30'
            }`}
          >
            Custom Amount
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-[#64748b] mb-1.5">Amount (₹)</label>
            <input
              type="number"
              value={topUpAmount === 'custom' ? '' : topUpAmount}
              onChange={(e) => setTopUpAmount(e.target.value)}
              placeholder="Enter custom amount"
              min="1"
              className="velora-input w-full"
            />
          </div>
          <div>
            <label className="block text-sm text-[#64748b] mb-1.5">UPI ID</label>
            <input
              type="text"
              value={topUpUpiId}
              onChange={(e) => setTopUpUpiId(e.target.value)}
              placeholder="yourname@upi"
              className="velora-input w-full"
            />
          </div>
        </div>
        <button
          onClick={handleTopUp}
          disabled={topUpLoading}
          className="velora-btn-premium mt-4 inline-flex items-center gap-2"
        >
          {topUpLoading ? <Loader2 size={16} className="animate-spin" /> : <CreditCard size={16} />}
          {topUpLoading ? 'Processing...' : 'Pay via UPI'}
        </button>
      </div>

      {/* Auto Reload */}
      <div className="velora-card">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-[#e2e8f0] flex items-center gap-2">
              <Zap size={16} className="text-[#f59e0b]" />
              Auto-Reload
            </h3>
            <p className="text-sm text-[#64748b] mt-0.5">Automatically add funds when balance drops below threshold.</p>
          </div>
          <button onClick={handleAutoReload} className="text-[#64748b] hover:text-[#e2e8f0] transition-colors">
            {autoReload ? <ToggleRight size={28} className="text-[#6366f1]" /> : <ToggleLeft size={28} />}
          </button>
        </div>
        {autoReload && (
          <div className="mt-4 pt-4 border-t border-[#1a1a2e] grid grid-cols-1 sm:grid-cols-2 gap-4 animate-slide-up">
            <div>
              <label className="block text-sm text-[#64748b] mb-1.5">Threshold (₹)</label>
              <input type="text" value={autoThreshold} onChange={(e) => setAutoThreshold(e.target.value)} className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm text-[#64748b] mb-1.5">Auto-add Amount (₹)</label>
              <input type="text" value={autoAmount} onChange={(e) => setAutoAmount(e.target.value)} className="velora-input w-full" />
            </div>
          </div>
        )}
      </div>

      {/* Transaction History */}
      <div className="velora-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
            <Receipt size={18} className="text-[#8b5cf6]" />
            Transaction History
          </h3>
          <span className="text-sm text-[#64748b]">{filtered.length} transaction{filtered.length !== 1 ? 's' : ''}</span>
        </div>

        {/* Type Filter */}
        <div className="flex items-center gap-1.5 mb-4">
          <Filter size={14} className="text-[#64748b]" />
          {(['all', 'credit', 'debit', 'refund'] as TypeFilter[]).map(f => (
            <button
              key={f}
              onClick={() => setTypeFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                typeFilter === f
                  ? 'bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 border border-transparent'
              }`}
            >
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-12">
            <Wallet className="mx-auto text-[#64748b] mb-3" size={40} />
            <h3 className="text-lg font-semibold text-[#e2e8f0] mb-1">No Transactions</h3>
            <p className="text-sm text-[#64748b]">No transactions match your current filter.</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filtered.map(tx => {
              const config = typeConfig[tx.type] || typeConfig.debit;
              const Icon = config.icon;
              return (
                <div key={tx.id} className="flex items-center gap-4 p-3 rounded-xl bg-[#09090b] hover:bg-[#0f0f14] transition-colors">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0`} style={{ backgroundColor: `${config.color}15` }}>
                    <Icon size={18} style={{ color: config.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-[#e2e8f0] truncate">{tx.description}</p>
                      <span className={config.badge}>{config.label}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5 text-xs text-[#64748b]">
                      <span className="flex items-center gap-1"><Clock size={10} />{formatTimeAgo(tx.date)}</span>
                      {tx.method && <span>• {tx.method}</span>}
                      <span className="font-mono">{tx.reference}</span>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className={`text-sm font-bold ${tx.type === 'debit' ? 'text-[#ef4444]' : tx.type === 'refund' ? 'text-[#6366f1]' : 'text-[#10b981]'}`}>
                      {tx.type === 'debit' ? '-' : '+'}₹{tx.amount.toLocaleString()}
                    </p>
                    <p className="text-xs text-[#64748b]">Bal: ₹{tx.balance.toLocaleString()}</p>
                  </div>
                  <button
                    onClick={() => toast.success('Receipt downloaded')}
                    className="p-1.5 rounded-lg text-[#475569] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors flex-shrink-0"
                    title="Download receipt"
                  >
                    <Download size={14} />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
