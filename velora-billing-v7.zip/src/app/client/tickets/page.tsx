'use client';

import { useState, useEffect } from 'react';
import {
  HelpCircle, Plus, Send, X, Clock, MessageSquare, AlertCircle, Loader2,
  ChevronDown, ChevronUp, User, Shield, ChevronRight, XCircle, RotateCcw,
  ArrowUpDown, Search, Circle,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface TicketReply {
  id: string;
  userId: string;
  userName: string;
  message: string;
  createdAt: string;
  isAdmin: boolean;
}

interface Ticket {
  id: string;
  subject: string;
  department: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  lastUpdated: string;
  lastReplyUser?: string;
  lastReplyTime?: string;
  messageCount: number;
  replies?: TicketReply[];
  createdAt: string;
}

type StatusFilter = 'all' | 'open' | 'in_progress' | 'resolved' | 'closed';

const fallbackTickets: Ticket[] = [
  {
    id: 'TKT-001', subject: 'Server not starting after update', department: 'Technical', priority: 'high', status: 'open',
    lastUpdated: '2025-01-12T14:30:00Z', lastReplyUser: 'You', lastReplyTime: '2025-01-12T14:30:00Z', messageCount: 3, createdAt: '2025-01-12T10:00:00Z',
    replies: [
      { id: 'r1', userId: 'u1', userName: 'You', message: 'My Minecraft server is not starting after the latest update. Please help.\n\nI see this error in console:\n[ERROR] Failed to bind port: Address already in use', createdAt: '2025-01-12T10:00:00Z', isAdmin: false },
      { id: 'r2', userId: 'a1', userName: 'Support Agent Alex', message: 'Hi! I can see the issue. The previous server instance didn\'t shut down properly. Let me restart the server for you. Please share your server ID so I can check.', createdAt: '2025-01-12T12:00:00Z', isAdmin: true },
      { id: 'r3', userId: 'u1', userName: 'You', message: 'Here are the logs: [Error] Failed to start - port already in use\nServer ID: srv_minecraft_001\n\nCan you please check?', createdAt: '2025-01-12T14:30:00Z', isAdmin: false },
    ],
  },
  {
    id: 'TKT-002', subject: 'Billing discrepancy on last invoice', department: 'Billing', priority: 'medium', status: 'in_progress',
    lastUpdated: '2025-01-11T09:00:00Z', lastReplyUser: 'Support Team', lastReplyTime: '2025-01-11T09:00:00Z', messageCount: 2, createdAt: '2025-01-10T08:00:00Z',
    replies: [
      { id: 'r4', userId: 'u1', userName: 'You', message: 'I was charged double for my VPS order ORD-002. The amount should be ₹499 but I see ₹998 deducted from my wallet.', createdAt: '2025-01-10T08:00:00Z', isAdmin: false },
      { id: 'r5', userId: 'a1', userName: 'Billing Support', message: 'Thank you for reporting. We\'ve verified the issue and the extra ₹499 has been refunded to your wallet. Please allow 24 hours for processing.', createdAt: '2025-01-11T09:00:00Z', isAdmin: true },
    ],
  },
  {
    id: 'TKT-003', subject: 'Request for additional IP address', department: 'Sales', priority: 'low', status: 'resolved',
    lastUpdated: '2025-01-05T16:00:00Z', messageCount: 4, createdAt: '2025-01-03T10:00:00Z',
  },
  {
    id: 'TKT-004', subject: 'Cannot connect to VPS via SSH', department: 'Technical', priority: 'critical', status: 'open',
    lastUpdated: '2025-01-14T08:00:00Z', lastReplyUser: 'You', lastReplyTime: '2025-01-14T08:00:00Z', messageCount: 1, createdAt: '2025-01-14T08:00:00Z',
    replies: [
      { id: 'r6', userId: 'u1', userName: 'You', message: 'My VPS is online but I cannot SSH into it. The connection times out after 30 seconds. This is urgent as I have production workloads running.', createdAt: '2025-01-14T08:00:00Z', isAdmin: false },
    ],
  },
  {
    id: 'TKT-005', subject: 'Upgrade RAM on Minecraft server', department: 'Sales', priority: 'medium', status: 'closed',
    lastUpdated: '2025-01-02T10:00:00Z', messageCount: 3, createdAt: '2024-12-28T10:00:00Z',
  },
];

const statusConfig: Record<string, { badge: string; color: string; label: string }> = {
  open: { badge: 'velora-badge-success', color: '#10b981', label: 'Open' },
  in_progress: { badge: 'velora-badge-info', color: '#6366f1', label: 'In Progress' },
  resolved: { badge: 'velora-badge-warning', color: '#f59e0b', label: 'Resolved' },
  closed: { badge: 'velora-badge', color: '#64748b', label: 'Closed' },
};

const priorityConfig: Record<string, { badge: string; color: string; label: string }> = {
  low: { badge: 'velora-badge', color: '#64748b', label: 'Low' },
  medium: { badge: 'velora-badge-warning', color: '#f59e0b', label: 'Medium' },
  high: { badge: 'velora-badge-danger', color: '#ef4444', label: 'High' },
  critical: { badge: 'velora-badge-danger', color: '#ef4444', label: 'Critical' },
};

const departments = ['Technical', 'Billing', 'Sales', 'General'];
const priorities = ['low', 'medium', 'high', 'critical'];

export default function TicketsPage() {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [replyTexts, setReplyTexts] = useState<Record<string, string>>({});
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Form state
  const [subject, setSubject] = useState('');
  const [department, setDepartment] = useState('General');
  const [priority, setPriority] = useState('medium');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/tickets', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setTickets(data);
          else if (Array.isArray(data.tickets)) setTickets(data.tickets);
        }
      } catch { /* fallback */ } finally {
        setLoading(false);
      }
    };
    fetchTickets();
  }, []);

  const handleCreateTicket = async () => {
    if (!subject.trim() || !message.trim()) {
      toast.error('Please fill in subject and message');
      return;
    }
    setSubmitting(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ subject, department, priority, message }),
      });
      if (res.ok) {
        toast.success('Ticket created successfully');
        setShowForm(false);
        setSubject(''); setDepartment('General'); setPriority('medium'); setMessage('');
      } else {
        toast.error('Failed to create ticket');
      }
    } catch { toast.error('Network error'); }
    finally { setSubmitting(false); }
  };

  const handleReply = async (ticketId: string) => {
    const text = replyTexts[ticketId] || '';
    if (!text.trim()) return;
    setReplyingTo(ticketId);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/tickets/${ticketId}/replies`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ message: text }),
      });
      if (res.ok) {
        toast.success('Reply sent');
        setReplyTexts(prev => ({ ...prev, [ticketId]: '' }));
      } else {
        toast.error('Failed to send reply');
      }
    } catch { toast.error('Failed to send reply'); }
    finally { setReplyingTo(null); }
  };

  const handleCloseTicket = async (ticketId: string) => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/tickets/${ticketId}/close`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status: 'closed' as const } : t));
        toast.success('Ticket closed');
      }
    } catch { toast.error('Failed to close ticket'); }
  };

  const handleReopenTicket = async (ticketId: string) => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/tickets/${ticketId}/reopen`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status: 'open' as const } : t));
        toast.success('Ticket reopened');
      }
    } catch { toast.error('Failed to reopen ticket'); }
  };

  const formatTimeAgo = (dateStr: string) => {
    const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
    return new Date(dateStr).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-8 w-48 skeleton-shimmer rounded-lg" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[1,2,3,4].map(i => <div key={i} className="skeleton-card h-24 p-4" />)}
        </div>
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="skeleton-card h-20 p-5" />)}
        </div>
      </div>
    );
  }

  const displayTickets = tickets.length > 0 ? tickets : fallbackTickets;

  const filtered = displayTickets.filter(t => {
    if (statusFilter !== 'all' && t.status !== statusFilter) return false;
    if (searchQuery && !t.subject.toLowerCase().includes(searchQuery.toLowerCase()) && !t.id.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  // Stats
  const stats = {
    open: displayTickets.filter(t => t.status === 'open').length,
    inProgress: displayTickets.filter(t => t.status === 'in_progress').length,
    resolved: displayTickets.filter(t => t.status === 'resolved').length,
    closed: displayTickets.filter(t => t.status === 'closed').length,
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-[#e2e8f0]">Support Tickets</h2>
          <p className="text-[#64748b] mt-1">Get help from our support team.</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="velora-btn-primary inline-flex items-center gap-2">
          {showForm ? <X size={16} /> : <Plus size={16} />}
          {showForm ? 'Cancel' : 'Create Ticket'}
        </button>
      </div>

      {/* Ticket Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Open', count: stats.open, color: '#10b981', bg: 'bg-[#10b981]/10' },
          { label: 'In Progress', count: stats.inProgress, color: '#6366f1', bg: 'bg-[#6366f1]/10' },
          { label: 'Resolved', count: stats.resolved, color: '#f59e0b', bg: 'bg-[#f59e0b]/10' },
          { label: 'Closed', count: stats.closed, color: '#64748b', bg: 'bg-[#64748b]/10' },
        ].map((s, i) => (
          <div key={i} className="velora-card p-4 cursor-pointer hover-lift" onClick={() => { setStatusFilter(s.label.toLowerCase().replace(' ', '_') as StatusFilter); }}>
            <div className="text-2xl font-bold" style={{ color: s.color }}>{s.count}</div>
            <div className="text-xs text-[#64748b] mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Create Ticket Form */}
      {showForm && (
        <div className="velora-card animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
            <MessageSquare size={18} className="text-[#6366f1]" />
            Create New Ticket
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="md:col-span-2">
              <label className="block text-sm text-[#64748b] mb-1.5">Subject</label>
              <input type="text" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Brief description of your issue" className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm text-[#64748b] mb-1.5">Department</label>
              <select value={department} onChange={(e) => setDepartment(e.target.value)} className="velora-input w-full">
                {departments.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm text-[#64748b] mb-1.5">Priority</label>
              <div className="flex gap-2">
                {priorities.map(p => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={`flex-1 px-3 py-2.5 rounded-lg text-xs font-medium border transition-all duration-200 ${
                      priority === p
                        ? `border-current ${priorityConfig[p].badge}`
                        : 'text-[#64748b] border-[#1a1a2e] hover:border-[#64748b]'
                    }`}
                    style={priority === p ? { color: priorityConfig[p].color } : {}}
                  >
                    {p.charAt(0).toUpperCase() + p.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm text-[#64748b] mb-1.5">Message</label>
              <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Describe your issue in detail..." rows={5} className="velora-input w-full resize-none" />
            </div>
          </div>
          <button onClick={handleCreateTicket} disabled={submitting} className="velora-btn-primary inline-flex items-center gap-2">
            <Send size={16} />
            {submitting ? 'Submitting...' : 'Submit Ticket'}
          </button>
        </div>
      )}

      {/* Search + Filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tickets..."
            className="velora-input w-full pl-9"
          />
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {(['all', 'open', 'in_progress', 'resolved', 'closed'] as StatusFilter[]).map(f => (
            <button
              key={f}
              onClick={() => setStatusFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                statusFilter === f
                  ? 'bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 border border-transparent'
              }`}
            >
              {f === 'all' ? 'All' : f === 'in_progress' ? 'In Progress' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Ticket List */}
      {filtered.length === 0 ? (
        <div className="velora-card text-center py-16">
          <HelpCircle className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Tickets</h3>
          <p className="text-[#64748b] mb-4">
            {searchQuery ? 'No tickets match your search.' : "You haven't created any support tickets yet."}
          </p>
          {!searchQuery && (
            <button onClick={() => setShowForm(true)} className="velora-btn-primary inline-flex items-center gap-2">
              <Plus size={16} /> Create Ticket
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3 stagger-children">
          {filtered.map(ticket => {
            const isExpanded = expandedId === ticket.id;
            const sConfig = statusConfig[ticket.status] || statusConfig.open;
            const pConfig = priorityConfig[ticket.priority] || priorityConfig.medium;

            return (
              <div key={ticket.id} className={`velora-card transition-all duration-200 ${isExpanded ? 'ring-1 ring-[#6366f1]/20' : ''}`}>
                {/* Ticket Header */}
                <button
                  onClick={() => setExpandedId(isExpanded ? null : ticket.id)}
                  className="w-full flex items-center justify-between text-left p-4"
                >
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0`} style={{ backgroundColor: `${sConfig.color}15` }}>
                      <MessageSquare size={18} style={{ color: sConfig.color }} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-[#e2e8f0] truncate">{ticket.subject}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="velora-badge text-xs">{ticket.department}</span>
                        <span className={pConfig.badge}>{pConfig.label}</span>
                        <span className={sConfig.badge}>{sConfig.label}</span>
                        <span className="text-xs text-[#64748b]">#{ticket.id}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0 ml-4">
                    <div className="hidden sm:flex items-center gap-1.5 text-xs text-[#64748b]">
                      {ticket.lastReplyUser && (
                        <span className="flex items-center gap-1">
                          <Circle size={6} fill={ticket.lastReplyUser === 'You' ? '#10b981' : '#6366f1'} />
                          {ticket.lastReplyUser}
                        </span>
                      )}
                    </div>
                    <div className="hidden sm:flex items-center gap-1 text-xs text-[#64748b]">
                      <Clock size={12} />
                      {formatTimeAgo(ticket.lastUpdated)}
                    </div>
                    <span className="text-xs text-[#64748b]">{ticket.messageCount} msg{ticket.messageCount !== 1 ? 's' : ''}</span>
                    {isExpanded ? <ChevronUp size={16} className="text-[#64748b]" /> : <ChevronDown size={16} className="text-[#64748b]" />}
                  </div>
                </button>

                {/* Expanded Conversation Thread */}
                {isExpanded && (
                  <div className="border-t border-[#1a1a2e] animate-fade-in">
                    {/* Actions bar */}
                    <div className="flex items-center gap-2 px-4 py-2 bg-[#09090b]/50 border-b border-[#1a1a2e]">
                      <span className="text-xs text-[#64748b]">Created: {new Date(ticket.createdAt).toLocaleString()}</span>
                      <span className="text-xs text-[#475569]">•</span>
                      <span className="text-xs text-[#64748b]">Last updated: {new Date(ticket.lastUpdated).toLocaleString()}</span>
                      <div className="ml-auto flex items-center gap-2">
                        {(ticket.status === 'open' || ticket.status === 'in_progress') && (
                          <button
                            onClick={() => handleCloseTicket(ticket.id)}
                            className="px-3 py-1 rounded-lg text-xs font-medium bg-[#f59e0b]/10 text-[#f59e0b] border border-[#f59e0b]/20 hover:bg-[#f59e0b]/20 transition-all inline-flex items-center gap-1"
                          >
                            <XCircle size={12} /> Close
                          </button>
                        )}
                        {(ticket.status === 'resolved' || ticket.status === 'closed') && (
                          <button
                            onClick={() => handleReopenTicket(ticket.id)}
                            className="px-3 py-1 rounded-lg text-xs font-medium bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20 hover:bg-[#6366f1]/20 transition-all inline-flex items-center gap-1"
                          >
                            <RotateCcw size={12} /> Reopen
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Replies */}
                    <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
                      {ticket.replies && ticket.replies.length > 0 ? (
                        ticket.replies.map((reply, ri) => (
                          <div
                            key={reply.id}
                            className={`p-4 rounded-xl transition-all duration-200 ${
                              reply.isAdmin
                                ? 'bg-[#6366f1]/5 border border-[#6366f1]/20 ml-0 sm:ml-8'
                                : 'bg-[#09090b] border border-[#1a1a2e]/50 mr-0 sm:mr-8'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                                  reply.isAdmin
                                    ? 'bg-[#6366f1]/20 text-[#6366f1]'
                                    : 'bg-[#8b5cf6]/20 text-[#8b5cf6]'
                                }`}>
                                  {reply.isAdmin ? <Shield size={14} /> : <User size={14} />}
                                </div>
                                <span className={`text-sm font-medium ${reply.isAdmin ? 'text-[#6366f1]' : 'text-[#e2e8f0]'}`}>
                                  {reply.userName}
                                </span>
                                {reply.isAdmin && <span className="velora-badge-info text-[10px]">Staff</span>}
                              </div>
                              <span className="text-xs text-[#64748b]">
                                {formatTimeAgo(reply.createdAt)}
                              </span>
                            </div>
                            <p className="text-sm text-[#c8cdd5] whitespace-pre-wrap leading-relaxed">{reply.message}</p>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-6">
                          <MessageSquare className="mx-auto text-[#475569] mb-2" size={24} />
                          <p className="text-sm text-[#64748b]">No replies yet. Be the first to respond!</p>
                        </div>
                      )}
                    </div>

                    {/* Reply Form */}
                    {(ticket.status === 'open' || ticket.status === 'in_progress') && (
                      <div className="p-4 border-t border-[#1a1a2e] bg-[#09090b]/30">
                        <div className="flex gap-2">
                          <textarea
                            value={replyTexts[ticket.id] || ''}
                            onChange={(e) => setReplyTexts(prev => ({ ...prev, [ticket.id]: e.target.value }))}
                            placeholder="Type your reply..."
                            rows={3}
                            className="velora-input flex-1 resize-none"
                          />
                          <div className="flex flex-col gap-2">
                            <button
                              onClick={() => handleReply(ticket.id)}
                              disabled={replyingTo === ticket.id || !(replyTexts[ticket.id]?.trim())}
                              className="velora-btn-primary px-4 py-2 text-sm inline-flex items-center gap-2 disabled:opacity-40"
                            >
                              {replyingTo === ticket.id ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                              Reply
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
