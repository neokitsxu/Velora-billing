'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  FileText, Download, CreditCard, AlertCircle, Clock, CheckCircle,
  XCircle, ChevronDown, ChevronRight, ArrowUpDown, IndianRupee,
  Receipt, Filter,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface Invoice {
  id: string;
  invoiceNumber: string;
  amount: number;
  tax: number;
  discount: number;
  total: number;
  status: 'paid' | 'unpaid' | 'overdue' | 'cancelled';
  dueDate: string;
  paidDate?: string;
  orderId: string;
  productName: string;
  createdAt: string;
}

type StatusFilter = 'all' | 'paid' | 'unpaid' | 'overdue' | 'cancelled';



const statusConfig: Record<string, { badge: string; color: string; icon: React.ElementType; label: string }> = {
  paid: { badge: 'velora-badge-success', color: '#10b981', icon: CheckCircle, label: 'Paid' },
  unpaid: { badge: 'velora-badge-warning', color: '#f59e0b', icon: Clock, label: 'Unpaid' },
  overdue: { badge: 'velora-badge-danger', color: '#ef4444', icon: AlertCircle, label: 'Overdue' },
  cancelled: { badge: 'velora-badge', color: '#64748b', icon: XCircle, label: 'Cancelled' },
};

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [sortBy, setSortBy] = useState<'date' | 'amount'>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/invoices', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setInvoices(data);
          else if (Array.isArray(data.invoices)) setInvoices(data.invoices);
        }
      } catch { /* fallback */ } finally {
        setLoading(false);
      }
    };
    fetchInvoices();
  }, []);

  const filtered = invoices.filter(inv => statusFilter === 'all' || inv.status === statusFilter);

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'date') {
      return sortDir === 'desc' ? new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() : new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    return sortDir === 'desc' ? b.total - a.total : a.total - b.total;
  });

  const outstandingTotal = invoices
    .filter(inv => inv.status === 'unpaid' || inv.status === 'overdue')
    .reduce((sum, inv) => sum + inv.total, 0);

  const overdueCount = invoices.filter(inv => inv.status === 'overdue').length;
  const unpaidCount = invoices.filter(inv => inv.status === 'unpaid').length;

  const getDaysUntil = (dateStr: string) => {
    const diff = new Date(dateStr).getTime() - Date.now();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-8 w-48 skeleton-shimmer rounded-lg" />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[1,2,3].map(i => <div key={i} className="skeleton-card h-28 p-5" />)}
        </div>
        <div className="space-y-3">
          {[1,2,3,4].map(i => <div key={i} className="skeleton-card h-16 p-5" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-[#e2e8f0]">Invoices</h2>
          <p className="text-[#64748b] mt-1">View and manage all your invoices.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { const d = sortDir === 'desc' ? 'asc' : 'desc'; setSortDir(d); }}
            className="velora-btn-secondary inline-flex items-center gap-2 text-xs"
          >
            <ArrowUpDown size={14} />
            {sortBy === 'date' ? 'Date' : 'Amount'} {sortDir === 'desc' ? '↓' : '↑'}
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="velora-card p-5 border-2 border-transparent bg-gradient-to-br from-[#6366f1]/20 via-[#0c0c0f] to-[#8b5cf6]/20">
          <div className="flex items-center gap-3 mb-1">
            <IndianRupee size={18} className="text-[#6366f1]" />
            <span className="text-sm text-[#64748b]">Outstanding Total</span>
          </div>
          <p className="text-3xl font-bold text-[#e2e8f0]">₹{outstandingTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
          <div className="flex items-center gap-2 mt-2">
            {unpaidCount > 0 && <span className="velora-badge-warning text-[10px]">{unpaidCount} unpaid</span>}
            {overdueCount > 0 && <span className="velora-badge-danger text-[10px]">{overdueCount} overdue</span>}
          </div>
        </div>
        <div className="velora-card p-5">
          <div className="flex items-center gap-3 mb-1">
            <CheckCircle size={18} className="text-[#10b981]" />
            <span className="text-sm text-[#64748b]">Total Paid</span>
          </div>
          <p className="text-3xl font-bold text-[#10b981]">₹{invoices.filter(i => i.status === 'paid').reduce((s, i) => s + i.total, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="velora-card p-5">
          <div className="flex items-center gap-3 mb-1">
            <Receipt size={18} className="text-[#8b5cf6]" />
            <span className="text-sm text-[#64748b]">Total Invoices</span>
          </div>
          <p className="text-3xl font-bold text-[#e2e8f0]">{invoices.length}</p>
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex items-center gap-1.5 flex-wrap">
        <Filter size={14} className="text-[#64748b]" />
        {(['all', 'paid', 'unpaid', 'overdue', 'cancelled'] as StatusFilter[]).map(f => (
          <button
            key={f}
            onClick={() => setStatusFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
              statusFilter === f
                ? 'bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20'
                : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 border border-transparent'
            }`}
          >
            {f === 'all' ? `All (${invoices.length})` : `${f.charAt(0).toUpperCase() + f.slice(1)} (${invoices.filter(i => i.status === f).length})`
          </button>
        ))}
      </div>

      {/* Invoice List */}
      {sorted.length === 0 ? (
        <div className="velora-card text-center py-16">
          <FileText className="mx-auto text-[#64748b] mb-4" size={48} />
          <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">No Invoices</h3>
          <p className="text-[#64748b]">
            {statusFilter !== 'all' ? `No ${statusFilter} invoices found.` : "You don't have any invoices yet."}
          </p>
        </div>
      ) : (
        <div className="space-y-3 stagger-children">
          {sorted.map(inv => {
            const sConfig = statusConfig[inv.status] || statusConfig.unpaid;
            const StatusIcon = sConfig.icon;
            const daysUntil = getDaysUntil(inv.dueDate);
            const isExpanded = expandedId === inv.id;

            return (
              <div key={inv.id} className="velora-card">
                <button
                  onClick={() => setExpandedId(isExpanded ? null : inv.id)}
                  className="w-full flex items-center justify-between text-left p-4"
                >
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0`} style={{ backgroundColor: `${sConfig.color}15` }}>
                      <StatusIcon size={18} style={{ color: sConfig.color }} />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-mono font-medium text-[#e2e8f0]">{inv.invoiceNumber}</span>
                        <span className={sConfig.badge}>{sConfig.label}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-[#64748b]">
                        <span>{inv.productName}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock size={10} />
                          Due {new Date(inv.dueDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0 ml-4">
                    <div className="text-right">
                      <p className="text-lg font-bold text-[#e2e8f0]">₹{inv.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                      {inv.status !== 'paid' && inv.status !== 'cancelled' && (
                        <p className={`text-xs mt-0.5 ${daysUntil <= 7 && daysUntil > 0 ? 'text-[#f59e0b]' : daysUntil <= 0 ? 'text-[#ef4444]' : 'text-[#64748b]'}`}>
                          {daysUntil > 0 ? `${daysUntil}d remaining` : 'Past due'}
                        </p>
                      )}
                    </div>
                    {isExpanded ? <ChevronDown size={16} className="text-[#64748b]" /> : <ChevronRight size={16} className="text-[#64748b]" />}
                  </div>
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t border-[#1a1a2e] p-4 animate-fade-in">
                    <div className="bg-[#09090b] rounded-xl p-4 mb-4">
                      <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3">Amount Breakdown</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[#64748b]">Subtotal</span>
                          <span className="text-[#e2e8f0]">₹{inv.amount.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-[#64748b]">Tax (18% GST)</span>
                          <span className="text-[#e2e8f0]">₹{inv.tax.toFixed(2)}</span>
                        </div>
                        {inv.discount > 0 && (
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-[#10b981]">Discount</span>
                            <span className="text-[#10b981]">-₹{inv.discount.toLocaleString()}</span>
                          </div>
                        )}
                        <div className="flex items-center justify-between text-sm pt-2 border-t border-[#1a1a2e]">
                          <span className="font-semibold text-[#e2e8f0]">Total</span>
                          <span className="font-bold text-[#e2e8f0] text-lg">₹{inv.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                      <div>
                        <span className="text-[#64748b]">Order</span>
                        <p className="text-[#e2e8f0] font-mono">{inv.orderId}</p>
                      </div>
                      <div>
                        <span className="text-[#64748b]">Created</span>
                        <p className="text-[#e2e8f0]">{new Date(inv.createdAt).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <span className="text-[#64748b]">Due Date</span>
                        <p className={daysUntil <= 0 && inv.status !== 'paid' ? 'text-[#ef4444]' : 'text-[#e2e8f0]'}>{new Date(inv.dueDate).toLocaleDateString()}</p>
                      </div>
                      {inv.paidDate && (
                        <div>
                          <span className="text-[#64748b]">Paid On</span>
                          <p className="text-[#10b981]">{new Date(inv.paidDate).toLocaleDateString()}</p>
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      {(inv.status === 'unpaid' || inv.status === 'overdue') && (
                        <Link
                          href={`/client/payment?invoice=${inv.id}`}
                          className="velora-btn-primary inline-flex items-center gap-2 text-sm"
                        >
                          <CreditCard size={14} />
                          Pay Now — ₹{inv.total.toLocaleString()}
                        </Link>
                      )}
                      <button
                        onClick={() => toast.success('Invoice downloaded')}
                        className="velora-btn-secondary inline-flex items-center gap-2 text-sm"
                      >
                        <Download size={14} />
                        Download PDF
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
