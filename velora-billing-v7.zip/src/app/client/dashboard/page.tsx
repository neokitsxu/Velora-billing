'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Server, ShoppingCart, Wallet, HelpCircle, Plus, Package,
  MessageSquarePlus, TrendingUp, Clock, FileText, ChevronRight,
  ArrowUpRight, AlertTriangle, Bell, Star, Sparkles, IndianRupee,
  Activity, CreditCard, Gift, Zap, CheckCircle,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface StatCard {
  label: string;
  value: string | number;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  href: string;
}

interface Order {
  id: string;
  product: string;
  amount: number;
  status: 'active' | 'pending' | 'cancelled' | 'completed';
  date: string;
  orderNumber: string;
}

interface Service {
  id: string;
  name: string;
  status: 'active' | 'suspended' | 'terminated' | 'pending';
  serverStatus: 'online' | 'offline' | 'pending';
  ip: string;
  port: number;
  productType: string;
  nextDueDate: string;
}

interface Renewal {
  serviceId: string;
  serviceName: string;
  amount: number;
  dueDate: string;
  daysUntil: number;
}

interface Announcement {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success';
  createdAt: string;
}

interface Activity {
  id: string;
  action: string;
  description: string;
  icon: React.ElementType;
  color: string;
  time: string;
}

const fallbackStats: StatCard[] = [
  { label: 'Active Services', value: 3, icon: Server, color: 'text-[#10b981]', bgColor: 'bg-[#10b981]/10', href: '/client/services' },
  { label: 'Pending Orders', value: 1, icon: ShoppingCart, color: 'text-[#f59e0b]', bgColor: 'bg-[#f59e0b]/10', href: '/client/orders' },
  { label: 'Wallet Balance', value: '₹1,250', icon: Wallet, color: 'text-[#6366f1]', bgColor: 'bg-[#6366f1]/10', href: '/client/wallet' },
  { label: 'Open Tickets', value: 2, icon: HelpCircle, color: 'text-[#8b5cf6]', bgColor: 'bg-[#8b5cf6]/10', href: '/client/tickets' },
  { label: 'Total Spent', value: '₹12,480', icon: TrendingUp, color: 'text-[#f59e0b]', bgColor: 'bg-[#f59e0b]/10', href: '/client/invoices' },
];

const fallbackOrders: Order[] = [
  { id: 'ORD-001', orderNumber: 'ORD-2025-001', product: 'Minecraft Premium', amount: 299, status: 'active', date: '2025-01-10' },
  { id: 'ORD-002', orderNumber: 'ORD-2025-002', product: 'VPS Starter', amount: 499, status: 'pending', date: '2025-01-12' },
  { id: 'ORD-003', orderNumber: 'ORD-2025-003', product: 'Dedicated 32GB', amount: 2499, status: 'active', date: '2025-01-08' },
  { id: 'ORD-004', orderNumber: 'ORD-2025-004', product: 'Minecraft Basic', amount: 149, status: 'completed', date: '2025-01-05' },
  { id: 'ORD-005', orderNumber: 'ORD-2025-005', product: 'VPS Pro', amount: 899, status: 'cancelled', date: '2025-01-03' },
];

const fallbackServices: Service[] = [
  { id: 'SVC-001', name: 'Minecraft Premium', status: 'active', serverStatus: 'online', ip: '103.45.67.89', port: 25565, productType: 'Minecraft', nextDueDate: '2025-02-10' },
  { id: 'SVC-002', name: 'VPS Starter', status: 'active', serverStatus: 'online', ip: '103.45.67.90', port: 22, productType: 'VPS', nextDueDate: '2025-02-12' },
  { id: 'SVC-003', name: 'Dedicated 32GB', status: 'active', serverStatus: 'online', ip: '103.45.67.91', port: 22, productType: 'Dedicated', nextDueDate: '2025-02-08' },
];

const fallbackRenewals: Renewal[] = [
  { serviceId: 'SVC-001', serviceName: 'Minecraft Premium', amount: 299, dueDate: '2025-02-10', daysUntil: 27 },
  { serviceId: 'SVC-003', serviceName: 'Dedicated 32GB', amount: 2499, dueDate: '2025-02-08', daysUntil: 25 },
  { serviceId: 'SVC-002', serviceName: 'VPS Starter', amount: 499, dueDate: '2025-02-12', daysUntil: 29 },
];

const fallbackAnnouncements: Announcement[] = [
  { id: 'a1', title: 'Scheduled Maintenance', message: 'All Minecraft servers will undergo maintenance on Jan 20, 2025 from 2:00 AM to 4:00 AM IST.', type: 'warning', createdAt: '2025-01-14' },
  { id: 'a2', title: 'New VPS Locations Available!', message: 'We have added new server locations in Singapore and Frankfurt. Check our products page.', type: 'success', createdAt: '2025-01-12' },
];

const fallbackActivity: Activity[] = [
  { id: 'ac1', action: 'Order Placed', description: 'Order ORD-002 for VPS Starter created', icon: ShoppingCart, color: '#f59e0b', time: '2 hours ago' },
  { id: 'ac2', action: 'Payment Received', description: '₹352.82 received for INV-001', icon: CreditCard, color: '#10b981', time: '4 hours ago' },
  { id: 'ac3', action: 'Ticket Reply', description: 'Support replied to TKT-001', icon: HelpCircle, color: '#6366f1', time: '6 hours ago' },
  { id: 'ac4', action: 'Service Active', description: 'Minecraft Premium server is now active', icon: Server, color: '#10b981', time: '1 day ago' },
  { id: 'ac5', action: 'Referral Earned', description: '₹199 commission added to wallet', icon: Gift, color: '#8b5cf6', time: '2 days ago' },
];

const statusBadge: Record<string, string> = {
  active: 'velora-badge-success',
  pending: 'velora-badge-warning',
  cancelled: 'velora-badge-danger',
  completed: 'velora-badge-info',
};

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good Morning';
  if (hour < 17) return 'Good Afternoon';
  return 'Good Evening';
}

export default function ClientDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<StatCard[]>(fallbackStats);
  const [orders, setOrders] = useState<Order[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [renewals, setRenewals] = useState<Renewal[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [activity, setActivity] = useState<Activity[]>(fallbackActivity);
  const [userName, setUserName] = useState('User');
  const [loading, setLoading] = useState(true);
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/dashboard', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.stats) setStats(data.stats);
          if (data.orders) setOrders(data.orders);
          if (data.services) setServices(data.services);
          if (data.renewals) setRenewals(data.renewals);
          if (data.announcements) setAnnouncements(data.announcements);
          if (data.activity) setActivity(data.activity);
          if (data.user?.name) setUserName(data.user.name);
        }
      } catch {
        // Use fallback data
      } finally {
        setLoading(false);
      }
    };

    try {
      const stored = localStorage.getItem('velora_user') || localStorage.getItem('user');
      if (stored) setUserName(JSON.parse(stored).name || 'User');
    } catch { /* ignore */ }

    fetchDashboard();
  }, []);

  const displayOrders = orders.length > 0 ? orders : fallbackOrders;
  const displayServices = services.length > 0 ? services : fallbackServices;
  const displayRenewals = renewals.length > 0 ? renewals : fallbackRenewals;
  const displayAnnouncements = announcements.length > 0 ? announcements : fallbackAnnouncements;
  const visibleAnnouncements = displayAnnouncements.filter(a => !dismissedAnnouncements.has(a.id));

  const dismissAnnouncement = (id: string) => {
    setDismissedAnnouncements(prev => new Set([...prev, id]));
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up">
        <div className="h-10 w-80 skeleton-shimmer rounded-lg" />
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {[1,2,3,4,5].map(i => <div key={i} className="skeleton-card h-28 p-5" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 skeleton-card h-64 p-6" />
          <div className="skeleton-card h-64 p-6" />
        </div>
      </div>
    );
  }

  const greeting = getGreeting();

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden velora-card p-6 border-2 border-transparent">
        <div className="absolute inset-0 bg-gradient-to-br from-[#6366f1]/15 via-transparent to-[#8b5cf6]/15 pointer-events-none" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#6366f1]/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={20} className="text-[#6366f1]" />
              <h2 className="text-2xl font-bold text-[#e2e8f0]">{greeting}, {userName}! 👋</h2>
            </div>
            <p className="text-[#64748b]">Here&apos;s what&apos;s happening with your account today.</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Link href="/client/products" className="velora-btn-primary inline-flex items-center gap-2 text-sm">
              <Plus size={14} />
              New Order
            </Link>
            <Link href="/client/wallet" className="velora-btn-secondary inline-flex items-center gap-2 text-sm">
              <Wallet size={14} />
              Add Funds
            </Link>
          </div>
        </div>
      </div>

      {/* Announcements */}
      {visibleAnnouncements.length > 0 && (
        <div className="space-y-2">
          {visibleAnnouncements.slice(0, 2).map(ann => (
            <div key={ann.id} className={`velora-card p-4 flex items-start gap-3 ${
              ann.type === 'warning' ? 'border-[#f59e0b]/20' : ann.type === 'success' ? 'border-[#10b981]/20' : 'border-[#6366f1]/20'
            }`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                ann.type === 'warning' ? 'bg-[#f59e0b]/10' : ann.type === 'success' ? 'bg-[#10b981]/10' : 'bg-[#6366f1]/10'
              }`}>
                {ann.type === 'warning' ? <AlertTriangle size={16} className="text-[#f59e0b]" /> :
                 ann.type === 'success' ? <CheckCircle size={16} className="text-[#10b981]" /> :
                 <Bell size={16} className="text-[#6366f1]" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-[#e2e8f0]">{ann.title}</p>
                  <span className="text-xs text-[#64748b]">{ann.createdAt}</span>
                </div>
                <p className="text-sm text-[#64748b] mt-0.5">{ann.message}</p>
              </div>
              <button onClick={() => dismissAnnouncement(ann.id)} className="p-1 rounded text-[#475569] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors flex-shrink-0">
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 stagger-children">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <Link key={i} href={stat.href} className="velora-card p-5 hover-lift group">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#64748b] group-hover:text-[#94a3b8] transition-colors">{stat.label}</p>
                  <p className="text-2xl font-bold text-[#e2e8f0] mt-1">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl ${stat.bgColor} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <Icon size={22} className={stat.color} />
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Recent Orders */}
        <div className="lg:col-span-2 velora-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
              <ShoppingCart size={18} className="text-[#6366f1]" />
              Recent Orders
            </h3>
            <Link href="/client/orders" className="velora-link text-sm inline-flex items-center gap-1">
              View All <ChevronRight size={14} />
            </Link>
          </div>
          {displayOrders.length === 0 ? (
            <div className="text-center py-10">
              <ShoppingCart className="mx-auto text-[#475569] mb-2" size={32} />
              <p className="text-sm text-[#64748b]">No recent orders</p>
              <Link href="/client/products" className="velora-link text-xs mt-2 inline-flex items-center gap-1">
                Browse Products <ArrowUpRight size={12} />
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="velora-table w-full">
                <thead>
                  <tr>
                    <th>Order</th>
                    <th>Product</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {displayOrders.slice(0, 5).map((order) => (
                    <tr key={order.id}>
                      <td className="font-mono text-sm text-[#e2e8f0]">{order.orderNumber || order.id}</td>
                      <td className="text-[#e2e8f0]">{order.product}</td>
                      <td className="text-[#e2e8f0]">₹{order.amount.toLocaleString()}</td>
                      <td>
                        <span className={statusBadge[order.status] || 'velora-badge'}>{order.status}</span>
                      </td>
                      <td className="text-[#64748b]">{new Date(order.date).toLocaleDateString()}</td>
                      <td>
                        <Link href="/client/orders" className="velora-link">
                          <ChevronRight size={14} />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Active Services Quick Cards */}
        <div className="velora-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
              <Server size={18} className="text-[#10b981]" />
              Active Services
            </h3>
            <Link href="/client/services" className="velora-link text-sm inline-flex items-center gap-1">
              All <ChevronRight size={14} />
            </Link>
          </div>
          {displayServices.filter(s => s.status === 'active').length === 0 ? (
            <div className="text-center py-10">
              <Server className="mx-auto text-[#475569] mb-2" size={32} />
              <p className="text-sm text-[#64748b]">No active services</p>
              <Link href="/client/products" className="velora-link text-xs mt-2 inline-flex items-center gap-1">
                Order Now <ArrowUpRight size={12} />
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {displayServices.filter(s => s.status === 'active').slice(0, 4).map(svc => (
                <div key={svc.id} className="flex items-center gap-3 p-3 rounded-xl bg-[#09090b] hover:bg-[#0f0f14] transition-colors group">
                  <div className="relative w-9 h-9 rounded-lg bg-[#10b981]/10 flex items-center justify-center flex-shrink-0">
                    <Server size={16} className="text-[#10b981]" />
                    <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-[#10b981] animate-pulse" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#e2e8f0] truncate">{svc.name}</p>
                    <p className="text-xs text-[#64748b] font-mono">{svc.ip}:{svc.port}</p>
                  </div>
                  <Link href="/client/services" className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <ChevronRight size={14} className="text-[#64748b]" />
                  </Link>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Second Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Upcoming Renewals */}
        <div className="lg:col-span-2 velora-card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
              <Clock size={18} className="text-[#f59e0b]" />
              Upcoming Renewals
              <span className="velora-badge-warning text-[10px]">Next 30 days</span>
            </h3>
          </div>
          {displayRenewals.length === 0 ? (
            <div className="text-center py-10">
              <Zap className="mx-auto text-[#475569] mb-2" size={32} />
              <p className="text-sm text-[#64748b]">No upcoming renewals</p>
            </div>
          ) : (
            <div className="space-y-3">
              {displayRenewals.map(renewal => (
                <div key={renewal.serviceId} className="flex items-center justify-between p-3 rounded-xl bg-[#09090b]">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#f59e0b]/10 flex items-center justify-center flex-shrink-0">
                      <Star size={16} className="text-[#f59e0b]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#e2e8f0]">{renewal.serviceName}</p>
                      <p className="text-xs text-[#64748b]">Due {new Date(renewal.dueDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-[#e2e8f0]">₹{renewal.amount.toLocaleString()}</p>
                    <p className={`text-xs ${renewal.daysUntil <= 7 ? 'text-[#f59e0b] font-medium' : 'text-[#64748b]'}`}>
                      {renewal.daysUntil}d remaining
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="velora-card">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
            <Zap size={18} className="text-[#8b5cf6]" />
            Quick Actions
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: 'New Order', icon: Package, href: '/client/products', color: 'text-[#6366f1]', bg: 'bg-[#6366f1]/10 hover:bg-[#6366f1]/20' },
              { label: 'Add Funds', icon: IndianRupee, href: '/client/wallet', color: 'text-[#10b981]', bg: 'bg-[#10b981]/10 hover:bg-[#10b981]/20' },
              { label: 'Create Ticket', icon: MessageSquarePlus, href: '/client/tickets', color: 'text-[#8b5cf6]', bg: 'bg-[#8b5cf6]/10 hover:bg-[#8b5cf6]/20' },
              { label: 'View Invoices', icon: FileText, href: '/client/invoices', color: 'text-[#f59e0b]', bg: 'bg-[#f59e0b]/10 hover:bg-[#f59e0b]/20' },
              { label: 'My Services', icon: Server, href: '/client/services', color: 'text-[#10b981]', bg: 'bg-[#10b981]/10 hover:bg-[#10b981]/20' },
              { label: 'My Profile', icon: Activity, href: '/client/profile', color: 'text-[#6366f1]', bg: 'bg-[#6366f1]/10 hover:bg-[#6366f1]/20' },
            ].map((action, i) => {
              const Icon = action.icon;
              return (
                <Link key={i} href={action.href} className={`flex flex-col items-center gap-2 p-4 rounded-xl ${action.bg} transition-all duration-200 group`}>
                  <Icon size={20} className={`${action.color} group-hover:scale-110 transition-transform duration-200`} />
                  <span className="text-xs font-medium text-[#e2e8f0]">{action.label}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>

      {/* Activity Feed */}
      <div className="velora-card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
            <Activity size={18} className="text-[#6366f1]" />
            Recent Activity
          </h3>
        </div>
        <div className="relative">
          <div className="absolute left-4 top-0 bottom-0 w-px bg-[#1a1a2e]" />
          <div className="space-y-4">
            {activity.map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={item.id} className="flex items-start gap-4 relative">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 z-10 border-2 border-[#0c0c0f]" style={{ backgroundColor: `${item.color}15` }}>
                    <Icon size={16} style={{ color: item.color }} />
                  </div>
                  <div className="flex-1 pb-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-[#e2e8f0]">{item.action}</p>
                      <span className="text-xs text-[#64748b]">{item.time}</span>
                    </div>
                    <p className="text-sm text-[#64748b] mt-0.5">{item.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
