'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  User, Mail, Calendar, Shield, Save, Key, Trash2, Loader2, Copy, Check,
  AlertTriangle, Camera, Lock, Eye, EyeOff, Smartphone, Monitor,
  Globe, Clock, LogOut, Download, Bell, BellOff, ChevronRight,
  ShieldCheck, Wifi, MapPin,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface UserProfile {
  name: string;
  email: string;
  role: string;
  avatar: string;
  createdAt: string;
  lastLogin?: string;
  twoFactorEnabled: boolean;
  phone?: string;
}

interface Session {
  id: string;
  device: string;
  browser: string;
  ip: string;
  location: string;
  lastActive: string;
  current: boolean;
}

interface ApiKey {
  id: string;
  name: string;
  key: string;
  createdAt: string;
}

type TabId = 'profile' | 'security' | 'notifications' | 'danger';

const tabs: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'danger', label: 'Danger Zone', icon: AlertTriangle },
];

const defaultProfile: UserProfile = {
  name: '',
  email: '',
  role: 'Client',
  avatar: '',
  createdAt: '',
  twoFactorEnabled: false,
};

export default function ProfilePage() {
  const router = useRouter();
  const [profile, setProfile] = useState<UserProfile>(defaultProfile);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabId>('profile');

  // Edit profile
  const [editName, setEditName] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  // Change password
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);

  // 2FA
  const [show2FASetup, setShow2FASetup] = useState(false);
  const [twoFACode, setTwoFACode] = useState('');
  const [verifying2FA, setVerifying2FA] = useState(false);

  // Notifications
  const [notifPrefs, setNotifPrefs] = useState({
    emailOrders: true,
    emailPayments: true,
    emailTickets: true,
    emailAnnouncements: false,
    pushOrders: true,
    pushPayments: false,
    pushTickets: true,
    pushAnnouncements: false,
  });
  const [savingNotifs, setSavingNotifs] = useState(false);

  // Close account
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);

  const [copiedField, setCopiedField] = useState<string | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.name) {
            setProfile(data);
            setEditName(data.name);
            setEditAvatar(data.avatar || '');
          }
        }
      } catch {
        try {
          const stored = localStorage.getItem('user');
          if (stored) {
            const u = JSON.parse(stored);
            setProfile(prev => ({ ...prev, name: u.name || prev.name, email: u.email || prev.email }));
            setEditName(u.name || profile.name);
          }
        } catch { /* ignore */ }
      } finally {
        setLoading(false);
      }
    };

    const fetchSessions = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/sessions', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setSessions(data);
          else if (Array.isArray(data.sessions)) setSessions(data.sessions);
        }
      } catch { /* fallback */ }
    };

    const fetchApiKeys = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/api-keys', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setApiKeys(data);
          else if (Array.isArray(data.keys)) setApiKeys(data.keys);
        }
      } catch { /* no api keys */ }
    };

    fetchProfile();
    fetchSessions();
    fetchApiKeys();
  }, []);

  const handleSaveProfile = async () => {
    if (!editName.trim()) { toast.error('Name is required'); return; }
    setSavingProfile(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name: editName, avatar: editAvatar }),
      });
      if (res.ok) {
        setProfile(prev => ({ ...prev, name: editName, avatar: editAvatar }));
        try {
          const stored = localStorage.getItem('user');
          const u = stored ? JSON.parse(stored) : {};
          u.name = editName;
          localStorage.setItem('user', JSON.stringify(u));
        } catch { /* ignore */ }
        toast.success('Profile updated successfully');
      } else {
        toast.error('Failed to update profile');
      }
    } catch { toast.error('Network error'); }
    finally { setSavingProfile(false); }
  };

  const handleChangePassword = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) { toast.error('All password fields are required'); return; }
    if (newPassword.length < 8) { toast.error('Password must be at least 8 characters'); return; }
    if (newPassword !== confirmPassword) { toast.error('Passwords do not match'); return; }
    setSavingPassword(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile/password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (res.ok) {
        toast.success('Password changed successfully');
        setCurrentPassword(''); setNewPassword(''); setConfirmPassword('');
      } else {
        const data = await res.json();
        toast.error(data.message || 'Failed to change password');
      }
    } catch { toast.error('Network error'); }
    finally { setSavingPassword(false); }
  };

  const handleToggle2FA = async () => {
    if (!profile.twoFactorEnabled) {
      setShow2FASetup(true);
    } else {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/client/profile/2fa', {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          setProfile(prev => ({ ...prev, twoFactorEnabled: false }));
          toast.success('Two-factor authentication disabled');
        }
      } catch { toast.error('Failed to disable 2FA'); }
    }
  };

  const handleVerify2FA = async () => {
    if (!twoFACode.trim() || twoFACode.length !== 6) { toast.error('Enter a valid 6-digit code'); return; }
    setVerifying2FA(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile/2fa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ code: twoFACode }),
      });
      if (res.ok) {
        setProfile(prev => ({ ...prev, twoFactorEnabled: true }));
        setShow2FASetup(false);
        setTwoFACode('');
        toast.success('Two-factor authentication enabled!');
      } else { toast.error('Invalid verification code'); }
    } catch { toast.error('Failed to verify 2FA'); }
    finally { setVerifying2FA(false); }
  };

  const handleSaveNotifs = async () => {
    setSavingNotifs(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(notifPrefs),
      });
      if (res.ok) toast.success('Notification preferences saved');
      else toast.error('Failed to save preferences');
    } catch { toast.error('Network error'); }
    finally { setSavingNotifs(false); }
  };

  const handleCloseAccount = async () => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/client/profile/close', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        toast.success('Account closed successfully');
        localStorage.removeItem('velora_token');
        localStorage.removeItem('velora_user');
        router.push('/auth/login');
      } else { toast.error('Failed to close account'); }
    } catch { toast.error('Network error'); }
    setShowCloseConfirm(false);
  };

  const handleExportData = async () => {
    toast.success('Preparing your data export. You will receive an email shortly.');
  };

  const handleRevokeSession = async (sessionId: string) => {
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch(`/api/client/sessions/${sessionId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setSessions(prev => prev.filter(s => s.id !== sessionId));
        toast.success('Session revoked');
      }
    } catch { toast.error('Failed to revoke session'); }
  };

  const copyField = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    toast.success('Copied');
    setTimeout(() => setCopiedField(null), 2000);
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-slide-up max-w-4xl">
        <div className="h-8 w-48 skeleton-shimmer rounded-lg" />
        <div className="h-10 w-full skeleton-shimmer rounded-lg" />
        <div className="skeleton-card p-6 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 skeleton rounded-full" />
            <div className="space-y-2 flex-1">
              <div className="h-5 w-40 skeleton rounded" />
              <div className="h-4 w-56 skeleton rounded" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  const getInitial = () => profile.name.charAt(0).toUpperCase();

  return (
    <div className="space-y-6 animate-slide-up max-w-4xl">
      <div>
        <h2 className="text-2xl font-bold text-[#e2e8f0]">Account Settings</h2>
        <p className="text-[#64748b] mt-1">Manage your profile, security, and preferences.</p>
      </div>

      {/* Profile Card */}
      <div className="velora-card">
        <div className="flex flex-col sm:flex-row items-center gap-5">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center text-white text-2xl font-bold overflow-hidden flex-shrink-0 shadow-lg shadow-[#6366f1]/20">
            {profile.avatar ? <img src={profile.avatar} alt={profile.name} className="w-full h-full object-cover" /> : getInitial()}
          </div>
          <div className="text-center sm:text-left flex-1">
            <h3 className="text-xl font-bold text-[#e2e8f0]">{profile.name}</h3>
            <div className="flex items-center justify-center sm:justify-start gap-2 mt-1">
              <Mail size={14} className="text-[#64748b]" />
              <span className="text-sm text-[#64748b]">{profile.email}</span>
            </div>
            <div className="flex items-center justify-center sm:justify-start gap-3 mt-2 flex-wrap">
              <span className="velora-badge-info">{profile.role}</span>
              <span className="flex items-center gap-1 text-xs text-[#64748b]">
                <Calendar size={12} />
                Joined {new Date(profile.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </span>
              {profile.lastLogin && (
                <span className="flex items-center gap-1 text-xs text-[#64748b]">
                  <Clock size={12} />
                  Last login {new Date(profile.lastLogin).toLocaleDateString()}
                </span>
              )}
            </div>
          </div>
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium ${
            profile.twoFactorEnabled
              ? 'bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/20'
              : 'bg-[#f59e0b]/10 text-[#f59e0b] border border-[#f59e0b]/20'
          }`}>
            <ShieldCheck size={12} />
            {profile.twoFactorEnabled ? '2FA Enabled' : '2FA Disabled'}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-[#0c0c0f] border border-[#1a1a2e] rounded-xl overflow-x-auto">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          const isDanger = tab.id === 'danger' && isActive;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 whitespace-nowrap flex-1 justify-center ${
                isDanger
                  ? 'bg-[#ef4444]/10 text-[#ef4444]'
                  : isActive
                  ? 'bg-[#6366f1]/10 text-[#6366f1]'
                  : 'text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50'
              }`}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="animate-fade-in">
        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <div className="velora-card">
              <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
                <User size={18} className="text-[#6366f1]" />
                Edit Profile
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-[#64748b] mb-1.5">Full Name</label>
                  <input type="text" value={editName} onChange={(e) => setEditName(e.target.value)} className="velora-input w-full" placeholder="Your name" />
                </div>
                <div>
                  <label className="block text-sm text-[#64748b] mb-1.5">Email Address</label>
                  <input type="email" value={profile.email} className="velora-input w-full opacity-50" disabled />
                  <p className="text-xs text-[#64748b] mt-1">Email cannot be changed. Contact support if needed.</p>
                </div>
                <div>
                  <label className="block text-sm text-[#64748b] mb-1.5">Avatar URL</label>
                  <div className="flex items-center gap-2">
                    <Camera size={14} className="text-[#64748b]" />
                    <input type="text" value={editAvatar} onChange={(e) => setEditAvatar(e.target.value)} className="velora-input flex-1" placeholder="https://example.com/avatar.png" />
                  </div>
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <button onClick={handleSaveProfile} disabled={savingProfile} className="velora-btn-primary inline-flex items-center gap-2">
                    {savingProfile ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                    {savingProfile ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </div>
            </div>

            {/* API Keys */}
            <div className="velora-card">
              <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
                <Key size={18} className="text-[#f59e0b]" />
                API Keys
              </h3>
              {apiKeys.length === 0 ? (
                <p className="text-sm text-[#64748b]">No API keys configured. Contact support if you need API access.</p>
              ) : (
                <div className="space-y-3">
                  {apiKeys.map(apiKey => (
                    <div key={apiKey.id} className="flex items-center justify-between p-3 rounded-lg bg-[#09090b]">
                      <div>
                        <p className="text-sm font-medium text-[#e2e8f0]">{apiKey.name}</p>
                        <p className="text-xs text-[#64748b] font-mono mt-0.5">{apiKey.key.slice(0, 8)}...{apiKey.key.slice(-4)}</p>
                      </div>
                      <button onClick={() => copyField(apiKey.key, `key-${apiKey.id}`)} className="p-2 rounded-lg text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]/50 transition-colors">
                        {copiedField === `key-${apiKey.id}` ? <Check size={14} className="text-[#10b981]" /> : <Copy size={14} />}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Security Tab */}
        {activeTab === 'security' && (
          <div className="space-y-6">
            {/* Password */}
            <div className="velora-card">
              <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
                <Lock size={18} className="text-[#8b5cf6]" />
                Change Password
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-[#64748b] mb-1.5">Current Password</label>
                  <div className="relative">
                    <input type={showCurrentPw ? 'text' : 'password'} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className="velora-input w-full pr-10" placeholder="Enter current password" />
                    <button onClick={() => setShowCurrentPw(!showCurrentPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                      {showCurrentPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm text-[#64748b] mb-1.5">New Password</label>
                  <div className="relative">
                    <input type={showNewPw ? 'text' : 'password'} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="velora-input w-full pr-10" placeholder="Min. 8 characters" />
                    <button onClick={() => setShowNewPw(!showNewPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#e2e8f0] transition-colors">
                      {showNewPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm text-[#64748b] mb-1.5">Confirm New Password</label>
                  <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="velora-input w-full" placeholder="Confirm new password" />
                </div>
                <button onClick={handleChangePassword} disabled={savingPassword} className="velora-btn-primary inline-flex items-center gap-2">
                  {savingPassword ? <Loader2 size={16} className="animate-spin" /> : <Key size={16} />}
                  {savingPassword ? 'Changing...' : 'Change Password'}
                </button>
              </div>
            </div>

            {/* 2FA */}
            <div className="velora-card">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-[#e2e8f0] flex items-center gap-2">
                    <Smartphone size={18} className="text-[#6366f1]" />
                    Two-Factor Authentication
                  </h3>
                  <p className="text-sm text-[#64748b] mt-1">
                    {profile.twoFactorEnabled
                      ? 'Your account is protected with 2FA using an authenticator app.'
                      : 'Add an extra layer of security to your account.'}
                  </p>
                </div>
                <button
                  onClick={handleToggle2FA}
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    profile.twoFactorEnabled
                      ? 'bg-[#ef4444]/10 text-[#ef4444] border border-[#ef4444]/20 hover:bg-[#ef4444]/20'
                      : 'bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20 hover:bg-[#6366f1]/20'
                  }`}
                >
                  <ShieldCheck size={16} />
                  {profile.twoFactorEnabled ? 'Disable 2FA' : 'Enable 2FA'}
                </button>
              </div>

              {show2FASetup && (
                <div className="mt-5 pt-5 border-t border-[#1a1a2e] space-y-4 animate-slide-up">
                  <div className="bg-[#09090b] rounded-lg p-4 text-center">
                    <p className="text-sm text-[#64748b] mb-3">Scan this QR code with your authenticator app</p>
                    <div className="qr-container mx-auto">
                      <div className="w-48 h-48 bg-[#1a1a2e] rounded-lg flex items-center justify-center">
                        <div className="grid grid-cols-8 gap-0.5 w-36 h-36">
                          {Array.from({ length: 64 }, (_, i) => (
                            <div key={i} className={`${Math.random() > 0.5 ? 'bg-[#e2e8f0]' : 'bg-transparent'} w-full h-full rounded-[1px]`} />
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-xs text-[#64748b] mt-3 font-mono">VELORA2FA:ABCDEFGHIJKLMNOPQR</p>
                  </div>
                  <div>
                    <label className="block text-sm text-[#64748b] mb-1.5">Verification Code</label>
                    <div className="flex gap-2">
                      <input type="text" value={twoFACode} onChange={(e) => setTwoFACode(e.target.value.replace(/\D/g, '').slice(0, 6))} className="velora-input flex-1 text-center tracking-[0.5em] font-mono" placeholder="000000" maxLength={6} />
                      <button onClick={handleVerify2FA} disabled={verifying2FA} className="velora-btn-primary inline-flex items-center gap-2">
                        {verifying2FA ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                        Verify
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Active Sessions */}
            <div className="velora-card">
              <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
                <Monitor size={18} className="text-[#10b981]" />
                Active Sessions
              </h3>
              <div className="space-y-3">
                {sessions.map(session => (
                  <div key={session.id} className="flex items-center justify-between p-3 rounded-lg bg-[#09090b]">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#1a1a2e] flex items-center justify-center">
                        {session.device.includes('iPhone') || session.device.includes('Android') ? (
                          <Smartphone size={18} className="text-[#6366f1]" />
                        ) : (
                          <Monitor size={18} className="text-[#6366f1]" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-[#e2e8f0]">{session.device}</p>
                          <span className="text-xs text-[#64748b]">{session.browser}</span>
                          {session.current && <span className="velora-badge-success text-[10px]">Current</span>}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs text-[#64748b] font-mono">{session.ip}</span>
                          <span className="text-xs text-[#475569]">•</span>
                          <span className="text-xs text-[#64748b] flex items-center gap-1"><MapPin size={10} />{session.location}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-[#64748b]">{new Date(session.lastActive).toLocaleDateString()}</span>
                      {!session.current && (
                        <button
                          onClick={() => handleRevokeSession(session.id)}
                          className="p-1.5 rounded-lg text-[#64748b] hover:text-[#ef4444] hover:bg-[#ef4444]/10 transition-colors"
                          title="Revoke session"
                        >
                          <LogOut size={14} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Login History */}
            <div className="velora-card">
              <h3 className="text-lg font-semibold text-[#e2e8f0] mb-4 flex items-center gap-2">
                <Clock size={18} className="text-[#f59e0b]" />
                Recent Login History
              </h3>
              <div className="bg-[#09090b] rounded-lg overflow-hidden">
                <table className="velora-table w-full">
                  <thead>
                    <tr>
                      <th>Date & Time</th>
                      <th>IP Address</th>
                      <th>Location</th>
                      <th>Device</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { date: '2025-01-14 10:30', ip: '103.45.67.100', location: 'Mumbai', device: 'Chrome / Windows' },
                      { date: '2025-01-13 18:00', ip: '103.45.67.101', location: 'Delhi', device: 'Safari / iPhone' },
                      { date: '2025-01-12 09:00', ip: '103.45.67.102', location: 'Bangalore', device: 'Firefox / macOS' },
                    ].map((entry, i) => (
                      <tr key={i}>
                        <td className="text-sm text-[#e2e8f0]">{entry.date}</td>
                        <td className="text-sm font-mono text-[#64748b]">{entry.ip}</td>
                        <td className="text-sm text-[#64748b]">{entry.location}</td>
                        <td className="text-sm text-[#64748b]">{entry.device}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <div className="velora-card">
              <h3 className="text-lg font-semibold text-[#e2e8f0] mb-2 flex items-center gap-2">
                <Bell size={18} className="text-[#6366f1]" />
                Notification Preferences
              </h3>
              <p className="text-sm text-[#64748b] mb-5">Choose how and when you want to be notified.</p>

              <div className="space-y-6">
                {/* Email Notifications */}
                <div>
                  <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3 flex items-center gap-2">
                    <Mail size={14} className="text-[#64748b]" />
                    Email Notifications
                  </h4>
                  <div className="space-y-3">
                    {[
                      { key: 'emailOrders' as const, label: 'Order updates', desc: 'New orders, status changes' },
                      { key: 'emailPayments' as const, label: 'Payment alerts', desc: 'Payment confirmations, failures' },
                      { key: 'emailTickets' as const, label: 'Ticket replies', desc: 'Support ticket responses' },
                      { key: 'emailAnnouncements' as const, label: 'Announcements', desc: 'System announcements, maintenance' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-3 rounded-lg bg-[#09090b]">
                        <div>
                          <p className="text-sm text-[#e2e8f0]">{item.label}</p>
                          <p className="text-xs text-[#64748b]">{item.desc}</p>
                        </div>
                        <button
                          onClick={() => setNotifPrefs(prev => ({ ...prev, [item.key]: !prev[item.key] }))}
                          className={`w-11 h-6 rounded-full transition-colors duration-200 relative ${
                            notifPrefs[item.key] ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'
                          }`}
                        >
                          <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform duration-200 ${
                            notifPrefs[item.key] ? 'translate-x-5.5 left-[22px]' : 'left-0.5'
                          }`} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Push Notifications */}
                <div>
                  <h4 className="text-sm font-semibold text-[#e2e8f0] mb-3 flex items-center gap-2">
                    <Bell size={14} className="text-[#64748b]" />
                    Push Notifications
                  </h4>
                  <div className="space-y-3">
                    {[
                      { key: 'pushOrders' as const, label: 'Order updates', desc: 'New orders, status changes' },
                      { key: 'pushPayments' as const, label: 'Payment alerts', desc: 'Payment confirmations, failures' },
                      { key: 'pushTickets' as const, label: 'Ticket replies', desc: 'Support ticket responses' },
                      { key: 'pushAnnouncements' as const, label: 'Announcements', desc: 'System announcements, maintenance' },
                    ].map(item => (
                      <div key={item.key} className="flex items-center justify-between p-3 rounded-lg bg-[#09090b]">
                        <div>
                          <p className="text-sm text-[#e2e8f0]">{item.label}</p>
                          <p className="text-xs text-[#64748b]">{item.desc}</p>
                        </div>
                        <button
                          onClick={() => setNotifPrefs(prev => ({ ...prev, [item.key]: !prev[item.key] }))}
                          className={`w-11 h-6 rounded-full transition-colors duration-200 relative ${
                            notifPrefs[item.key] ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'
                          }`}
                        >
                          <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform duration-200 ${
                            notifPrefs[item.key] ? 'translate-x-5.5 left-[22px]' : 'left-0.5'
                          }`} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <button onClick={handleSaveNotifs} disabled={savingNotifs} className="velora-btn-primary inline-flex items-center gap-2">
                  {savingNotifs ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                  {savingNotifs ? 'Saving...' : 'Save Preferences'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Danger Zone Tab */}
        {activeTab === 'danger' && (
          <div className="space-y-6">
            <div className="velora-card border-[#f59e0b]/20">
              <h3 className="text-lg font-semibold text-[#f59e0b] mb-2 flex items-center gap-2">
                <Download size={18} />
                Export Data
              </h3>
              <p className="text-sm text-[#64748b] mb-4">Download a copy of all your account data including orders, invoices, and services.</p>
              <button onClick={handleExportData} className="velora-btn-secondary inline-flex items-center gap-2">
                <Download size={16} />
                Export My Data
              </button>
            </div>

            <div className="velora-card border-[#ef4444]/20">
              <h3 className="text-lg font-semibold text-[#ef4444] mb-2 flex items-center gap-2">
                <AlertTriangle size={18} />
                Close Account
              </h3>
              <p className="text-sm text-[#64748b] mb-4">
                Once you close your account, all data will be permanently deleted and cannot be recovered. This includes all services, orders, invoices, and wallet balance.
              </p>
              {!showCloseConfirm ? (
                <button onClick={() => setShowCloseConfirm(true)} className="velora-btn-danger inline-flex items-center gap-2">
                  <Trash2 size={16} />
                  Close Account
                </button>
              ) : (
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <p className="text-sm text-[#ef4444] font-medium">Are you absolutely sure? This is irreversible.</p>
                  <div className="flex gap-2">
                    <button onClick={handleCloseAccount} className="velora-btn-danger inline-flex items-center gap-2">
                      <Trash2 size={16} />
                      Yes, Close
                    </button>
                    <button onClick={() => setShowCloseConfirm(false)} className="velora-btn-secondary">
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
