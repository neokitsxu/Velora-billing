import { create } from 'zustand';

interface AppState {
  // Theme
  theme: 'dark' | 'light';
  toggleTheme: () => void;

  // Sidebar
  adminSidebarCollapsed: boolean;
  clientSidebarCollapsed: boolean;
  toggleAdminSidebar: () => void;
  toggleClientSidebar: () => void;

  // Command Palette
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;

  // Notifications
  notificationCount: number;
  setNotificationCount: (count: number) => void;
  incrementNotification: () => void;

  // Global loading
  globalLoading: boolean;
  setGlobalLoading: (loading: boolean) => void;

  // Maintenance mode
  maintenanceMode: boolean;
  setMaintenanceMode: (mode: boolean) => void;

  // Online status
  isOnline: boolean;
  setIsOnline: (online: boolean) => void;
}

export const useAppStore = create<AppState>((set) => ({
  theme: 'dark',
  toggleTheme: () => set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),

  adminSidebarCollapsed: false,
  clientSidebarCollapsed: false,
  toggleAdminSidebar: () => set((state) => ({ adminSidebarCollapsed: !state.adminSidebarCollapsed })),
  toggleClientSidebar: () => set((state) => ({ clientSidebarCollapsed: !state.clientSidebarCollapsed })),

  commandPaletteOpen: false,
  setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),

  notificationCount: 0,
  setNotificationCount: (count) => set({ notificationCount: count }),
  incrementNotification: () => set((state) => ({ notificationCount: state.notificationCount + 1 })),

  globalLoading: false,
  setGlobalLoading: (loading) => set({ globalLoading: loading }),

  maintenanceMode: false,
  setMaintenanceMode: (mode) => set({ maintenanceMode: mode }),

  isOnline: true,
  setIsOnline: (online) => set({ isOnline: online }),
}));
