// ============ User Types ============
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'admin' | 'client';
  status: 'active' | 'suspended' | 'banned';
  balance: number;
  totalSpent: number;
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResponse {
  token: string;
  user: Omit<User, 'password'>;
}

// ============ Product Types ============
export interface Product {
  id: string;
  name: string;
  description?: string;
  slug: string;
  type: 'minecraft' | 'vps' | 'dedicated' | 'domain' | 'other';
  price: number;
  billingCycle: string;
  stock: number;
  status: string;
  features?: string;
  sortOrder: number;
  image?: string;
  cpu?: number;
  ram?: number;
  disk?: number;
  bandwidth?: number;
  slots?: number;
  nestId?: string;
  eggId?: string;
  nodeId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProductCategory {
  id: string;
  name: string;
  slug: string;
  icon?: string;
  sortOrder: number;
  createdAt: string;
  products?: Product[];
}

// ============ Order Types ============
export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  productId: string;
  quantity: number;
  amount: number;
  status: 'pending' | 'paid' | 'failed' | 'refunded' | 'cancelled';
  paymentMethod?: string;
  paymentId?: string;
  paidAt?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  user?: User;
  product?: Product;
}

// ============ Invoice Types ============
export interface Invoice {
  id: string;
  invoiceNumber: string;
  userId: string;
  orderId?: string;
  amount: number;
  tax: number;
  discount: number;
  total: number;
  status: 'unpaid' | 'paid' | 'overdue' | 'cancelled';
  dueDate: string;
  paidAt?: string;
  createdAt: string;
  updatedAt: string;
  user?: User;
  order?: Order;
}

// ============ Service Types ============
export interface Service {
  id: string;
  userId: string;
  orderId?: string;
  productId: string;
  name: string;
  status: 'active' | 'suspended' | 'terminated' | 'pending';
  serverId?: string;
  serverIdentifier?: string;
  dedicatedIp?: string;
  primaryDomain?: string;
  username?: string;
  password?: string;
  expiresAt?: string;
  lastBilledAt?: string;
  nextBillingAt?: string;
  createdAt: string;
  updatedAt: string;
  user?: User;
  product?: Product;
}

// ============ Ticket Types ============
export interface Ticket {
  id: string;
  userId: string;
  subject: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  department: string;
  createdAt: string;
  updatedAt: string;
  user?: User;
  replies?: TicketReply[];
}

export interface TicketReply {
  id: string;
  ticketId: string;
  userId: string;
  message: string;
  isStaff: boolean;
  createdAt: string;
}

// ============ Wallet Types ============
export interface WalletTransaction {
  id: string;
  userId: string;
  type: 'credit' | 'debit' | 'refund';
  amount: number;
  balance: number;
  description: string;
  reference?: string;
  method?: string;
  status: string;
  createdAt: string;
}

// ============ UPI Payment Types ============
export interface UpiPayment {
  id: string;
  userId: string;
  invoiceId?: string;
  amount: number;
  upiId: string;
  txnId?: string;
  status: 'pending' | 'verifying' | 'successful' | 'failed' | 'expired';
  qrCode?: string;
  paymentUrl?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  expiresAt: string;
  createdAt: string;
  updatedAt: string;
}

// ============ Setting Types ============
export interface Setting {
  key: string;
  value: string;
  group: string;
  type: string;
}

// ============ Notification Types ============
export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
}

// ============ API Response Types ============
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// ============ Dashboard Stats ============
export interface DashboardStats {
  totalUsers: number;
  totalOrders: number;
  totalRevenue: number;
  activeServices: number;
  pendingOrders: number;
  openTickets: number;
  recentOrders: Order[];
  revenueChart: { date: string; amount: number }[];
}

// ============ Admin Stats ============
export interface AdminStats extends DashboardStats {
  totalProducts: number;
  unpaidInvoices: number;
  monthlyRevenue: number;
  totalWalletBalance: number;
}

// ============ Coupon Types ============
export interface Coupon {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minAmount: number;
  maxUses: number;
  usedCount: number;
  validFrom?: string;
  validUntil?: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}

// ============ Server Node Types ============
export interface ServerNode {
  id: string;
  name: string;
  type: string;
  hostname: string;
  port: number;
  apiKey: string;
  maxResources?: any;
  usedResources?: any;
  status: string;
  location?: string;
  createdAt: string;
  updatedAt: string;
}

// ============ Theme Types ============
export interface Theme {
  id: string;
  name: string;
  slug: string;
  primary: string;
  accent: string;
  bg: string;
  sidebarBg: string;
  cardBg: string;
  textColor: string;
  fontFamily: string;
  borderRadius: number;
  customCss?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

// ============ Audit Log Types ============
export interface AuditLog {
  id: string;
  userId?: string;
  action: string;
  details?: string;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
  user?: User;
}

// ============ Provisioning Job Types ============
export interface ProvisioningJob {
  id: string;
  orderId: string;
  serviceId?: string;
  type: 'create' | 'suspend' | 'terminate' | 'reinstall';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  payload?: string;
  result?: string;
  error?: string;
  attempts: number;
  createdAt: string;
  updatedAt: string;
}
