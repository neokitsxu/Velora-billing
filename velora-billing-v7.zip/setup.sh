#!/bin/bash
# Velora Billing v2 - Master Fix & Setup Script
# Run this after extracting the ZIP: bash setup.sh

set -e

echo "==========================================="
echo "  Velora Billing v2 - Auto Setup"
echo "==========================================="

# 1. Create .env if not exists
if [ ! -f .env ]; then
  echo "[1/6] Creating .env file..."
  cat > .env << 'ENVEOF'
APP_NAME=Velora Billing
APP_URL=http://localhost:3000
APP_SECRET=velora-secret-2024
PORT=3000
DATABASE_URL=file:./db/velora.db
JWT_SECRET=velora-jwt-2024
JWT_EXPIRES_IN=7d
PTERODACTYL_URL=
PTERODACTYL_API_KEY=
UPI_ENABLED=true
UPI_ID=yourname@paytm
UPI_MERCHANT_NAME=Velora Hosting
UPI_MERCHANT_CODE=VELORA
UPI_CURRENCY=INR
UPI_MIN_AMOUNT=10
UPI_AUTO_VERIFY=false
ADMIN_EMAIL=admin@velora.billing
ADMIN_PASSWORD=Admin@123456
ADMIN_NAME=Admin
ENVEOF
else
  echo "[1/6] .env already exists, skipping..."
fi

# 2. Create db directory
mkdir -p db
echo "[2/6] Database directory ready."

# 3. Fix TypeScript errors
echo "[3/6] Fixing TypeScript errors..."

# Fix profile page - prev.name reference
sed -i 's/u\.name || prev\.name/u.name || profile.name/g' src/app/client/profile/page.tsx 2>/dev/null || true

# Fix coupons API - minOrderAmount
sed -i 's/minOrderAmount/minAmount/g' src/app/api/coupons/route.ts 2>/dev/null || true

# Fix payment page - status comparison (already fixed in v2 but safety)
sed -i "s/const \[status, setStatus\] = useState<string>(\"waiting\")/const [status, setStatus] = useState<string>(\"pending\")/" src/app/client/payment/page.tsx 2>/dev/null || true

echo "  TypeScript fixes applied."

# 4. Install dependencies
echo "[4/6] Installing dependencies..."
npm install

# 5. Database setup + seed
echo "[5/6] Setting up database..."
npx prisma db push --force-reset
npx tsx src/lib/seed.ts

# 6. Build + Start
echo "[6/6] Building & starting..."
npm run build

# Check if pm2 exists
if command -v pm2 &> /dev/null; then
  pm2 delete velora 2>/dev/null || true
  pm2 start "npx next start" --name velora -p 3000
  pm2 save
  echo ""
  echo "==========================================="
  echo "  Velora Billing is RUNNING!"
  echo "  PM2 Status: pm2 status velora"
  echo "  Access: http://localhost:3000"
  echo "==========================================="
else
  echo ""
  echo "PM2 not found. Installing..."
  npm install -g pm2
  pm2 start "npx next start" --name velora -p 3000
  pm2 save
  pm2 startup 2>/dev/null || true
  echo ""
  echo "==========================================="
  echo "  Velora Billing is RUNNING!"
  echo "  PM2 Status: pm2 status velora"
  echo "  Access: http://localhost:3000"
  echo "==========================================="
fi

echo ""
echo "Default Admin Login:"
echo "  Email: admin@velora.billing"
echo "  Password: Admin@123456"
echo ""
echo "Default Demo Client:"
echo "  Email: demo@velora.billing"
echo "  Password: Demo@123456"
echo ""
echo "To configure UPI, edit .env file and set UPI_ID"
echo "Then restart: pm2 restart velora"
