'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Package, Check, ArrowRight } from 'lucide-react';
import toast from 'react-hot-toast';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  billingCycle: string;
  category: string;
  features: string[];
  stock: number;
}

const fallbackProducts: Product[] = [
  {
    id: '1',
    name: 'Minecraft Basic',
    description: 'Perfect for small servers with friends. 2GB RAM, 20 player slots.',
    price: 149,
    billingCycle: 'Monthly',
    category: 'Minecraft',
    features: ['2 GB RAM', '20 Player Slots', '10 GB SSD', 'DDoS Protection', '1 MySQL DB'],
    stock: 15,
  },
  {
    id: '2',
    name: 'Minecraft Premium',
    description: 'Ideal for growing communities. 4GB RAM, 50 player slots.',
    price: 299,
    billingCycle: 'Monthly',
    category: 'Minecraft',
    features: ['4 GB RAM', '50 Player Slots', '25 GB SSD', 'DDoS Protection', '3 MySQL DBs', 'Dedicated IP'],
    stock: 8,
  },
  {
    id: '3',
    name: 'VPS Starter',
    description: 'Entry-level virtual private server with 2 vCPU and 2GB RAM.',
    price: 499,
    billingCycle: 'Monthly',
    category: 'VPS',
    features: ['2 vCPU', '2 GB RAM', '40 GB NVMe', '2 TB Bandwidth', 'Full Root Access'],
    stock: 20,
  },
  {
    id: '4',
    name: 'VPS Pro',
    description: 'High-performance VPS with 4 vCPU and 8GB RAM.',
    price: 899,
    billingCycle: 'Monthly',
    category: 'VPS',
    features: ['4 vCPU', '8 GB RAM', '100 GB NVMe', '4 TB Bandwidth', 'Full Root Access', 'IPv6 Support'],
    stock: 12,
  },
  {
    id: '5',
    name: 'Dedicated 32GB',
    description: 'Full dedicated server with Intel Xeon E-2236, 32GB DDR4.',
    price: 2499,
    billingCycle: 'Monthly',
    category: 'Dedicated',
    features: ['Intel Xeon E-2236', '32 GB DDR4', '500 GB NVMe SSD', '20 TB Bandwidth', 'IPMI Access', '/29 IPv4 Block'],
    stock: 3,
  },
  {
    id: '6',
    name: 'Dedicated 64GB',
    description: 'Enterprise-grade dedicated server with AMD Ryzen 9, 64GB DDR4.',
    price: 4999,
    billingCycle: 'Monthly',
    category: 'Dedicated',
    features: ['AMD Ryzen 9 5900X', '64 GB DDR4', '1 TB NVMe SSD', 'Unmetered Bandwidth', 'IPMI Access', '/28 IPv4 Block', 'Hardware RAID'],
    stock: 1,
  },
];

const categories = ['All', 'Minecraft', 'VPS', 'Dedicated'];

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCategory, setActiveCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/products', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setProducts(data);
          else if (Array.isArray(data.products)) setProducts(data.products);
        }
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const displayProducts = products.length > 0 ? products : fallbackProducts;
  const filtered =
    activeCategory === 'All'
      ? displayProducts
      : displayProducts.filter((p) => p.category === activeCategory);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#6366f1] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-[#e2e8f0]">Our Products</h2>
        <p className="text-[#64748b] mt-1">Browse and order from our range of hosting solutions.</p>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
              activeCategory === cat
                ? 'bg-[#6366f1] text-white'
                : 'bg-[#1a1a2e]/50 text-[#64748b] hover:text-[#e2e8f0] hover:bg-[#1a1a2e]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Product Grid */}
      {filtered.length === 0 ? (
        <div className="velora-card text-center py-16">
          <Package className="mx-auto text-[#64748b] mb-4" size={48} />
          <p className="text-[#64748b]">No products found in this category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((product) => (
            <div key={product.id} className="velora-card flex flex-col">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-[#e2e8f0]">{product.name}</h3>
                  <span className="velora-badge-info text-xs">{product.category}</span>
                </div>
                <p className="text-sm text-[#64748b] mb-4">{product.description}</p>

                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-2xl font-bold text-[#e2e8f0]">₹{product.price.toLocaleString()}</span>
                  <span className="velora-badge text-xs">/{product.billingCycle.toLowerCase()}</span>
                </div>

                <ul className="space-y-2 mb-6">
                  {product.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-[#e2e8f0]">
                      <Check size={14} className="text-[#10b981] flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <Link
                href={`/client/checkout?id=${product.id}`}
                className={`w-full velora-btn-primary inline-flex items-center justify-center gap-2 ${
                  product.stock <= 0 ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                {product.stock <= 0 ? 'Out of Stock' : (
                  <>
                    Order Now
                    <ArrowRight size={16} />
                  </>
                )}
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
