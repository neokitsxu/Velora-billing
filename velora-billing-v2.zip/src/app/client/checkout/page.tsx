'use client';

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  ArrowLeft,
  Check,
  Tag,
  QrCode,
  Wallet as WalletIcon,
  Loader2,
  AlertCircle,
  X,
  Server,
  Cpu,
  HardDrive,
  Shield,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface ProductResource {
  label: string;
  value: string;
}

interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  billingCycle: string;
  features: string[];
  resources?: ProductResource[];
  taxEnabled: boolean;
  taxRate: number;
}

interface CouponResponse {
  success: boolean;
  data?: {
    id: string;
    code: string;
    type: 'percentage' | 'fixed';
    value: number;
    maxDiscount?: number;
  };
  error?: string;
}

interface OrderResponse {
  success: boolean;
  data?: {
    orderId: string;
    orderNumber: string;
  };
  error?: string;
}

type PaymentMethod = 'upi' | 'wallet';

type FetchState = 'idle' | 'loading' | 'success' | 'error';

function CheckoutContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const productId = searchParams.get('product') || searchParams.get('id');

  // Product state
  const [product, setProduct] = useState<Product | null>(null);
  const [fetchState, setFetchState] = useState<FetchState>('idle');

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponDiscount, setCouponDiscount] = useState(0);
  const [couponType, setCouponType] = useState<'percentage' | 'fixed'>('percentage');

  // Tax state
  const [taxEnabled, setTaxEnabled] = useState(true);
  const [taxRate, setTaxRate] = useState(18);

  // Payment state
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [placing, setPlacing] = useState(false);

  // Fetch product + wallet on mount
  useEffect(() => {
    const fetchData = async () => {
      setFetchState('loading');
      const token = localStorage.getItem('velora_token');

      // Fetch product
      try {
        let url = '/api/products';
        if (productId) {
          // Try slug-based first
          url = `/api/products?slug=${encodeURIComponent(productId)}`;
        }
        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const json = await res.json();
        if (json.success && json.data) {
          // API might return array or single object
          const productData: Product = Array.isArray(json.data)
            ? json.data.find((p: Product) => p.id === productId || p.slug === productId) || json.data[0]
            : json.data;
          if (productData) {
            setProduct(productData);
            setTaxEnabled(productData.taxEnabled ?? true);
            setTaxRate(productData.taxRate ?? 18);
          }
        }
      } catch {
        // Silently fail - will show error state if no product
      }

      // Fetch wallet balance
      try {
        const res = await fetch('/api/client/wallet', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const json = await res.json();
        if (json.success && json.data) {
          setWalletBalance(json.data.balance ?? 0);
        } else if (json.balance !== undefined) {
          setWalletBalance(json.balance);
        }
      } catch {
        // Silently fail
      }

      setFetchState('success');
    };

    fetchData();
  }, [productId]);

  // Apply coupon
  const applyCoupon = async () => {
    const code = couponCode.trim();
    if (!code) {
      toast.error('Please enter a coupon code');
      return;
    }

    setCouponLoading(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ code, productId: product?.id }),
      });
      const json: CouponResponse = await res.json();
      if (json.success && json.data) {
        setCouponApplied(true);
        setCouponType(json.data.type);
        setCouponDiscount(json.data.value);
        toast.success(`Coupon applied! ${json.data.type === 'percentage' ? `${json.data.value}%` : `₹${json.data.value}`} discount`);
      } else {
        toast.error(json.error || 'Invalid coupon code');
      }
    } catch {
      toast.error('Failed to validate coupon');
    } finally {
      setCouponLoading(false);
    }
  };

  const removeCoupon = () => {
    setCouponApplied(false);
    setCouponDiscount(0);
    setCouponCode('');
    setCouponType('percentage');
  };

  // Calculate totals
  const subtotal = product?.price ?? 0;
  const discountAmount = couponApplied
    ? couponType === 'percentage'
      ? (subtotal * couponDiscount) / 100
      : Math.min(couponDiscount, subtotal)
    : 0;
  const afterDiscount = subtotal - discountAmount;
  const taxAmount = taxEnabled ? (afterDiscount * taxRate) / 100 : 0;
  const total = afterDiscount + taxAmount;

  // Place order
  const handlePlaceOrder = async () => {
    if (!product) return;

    if (paymentMethod === 'wallet' && walletBalance < total) {
      toast.error('Insufficient wallet balance');
      return;
    }

    setPlacing(true);
    try {
      const token = localStorage.getItem('velora_token');
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          productId: product.id,
          paymentMethod,
          couponCode: couponApplied ? couponCode.trim() : null,
        }),
      });
      const json: OrderResponse = await res.json();

      if (json.success && json.data) {
        if (paymentMethod === 'upi') {
          router.push(`/client/payment?order=${json.data.orderId || json.data.orderNumber}`);
        } else {
          toast.success('Order placed successfully via wallet!');
          router.push('/client/orders');
        }
      } else {
        toast.error(json.error || 'Failed to place order');
      }
    } catch {
      toast.error('Network error. Please try again.');
    } finally {
      setPlacing(false);
    }
  };

  // Loading state
  if (fetchState === 'loading') {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-[#6366f1] animate-spin mx-auto mb-3" />
          <p className="text-[#64748b] text-sm">Loading checkout...</p>
        </div>
      </div>
    );
  }

  // Error / not found state
  if (fetchState === 'success' && !product) {
    return (
      <div className="velora-card text-center py-16 animate-slide-up">
        <AlertCircle className="mx-auto text-[#ef4444] mb-4" size={48} />
        <h3 className="text-xl font-semibold text-[#e2e8f0] mb-2">Product Not Found</h3>
        <p className="text-[#64748b] mb-6">The product you are looking for does not exist or has been removed.</p>
        <Link href="/client/products" className="velora-btn-primary inline-flex items-center gap-2">
          <ArrowLeft size={16} />
          Back to Products
        </Link>
      </div>
    );
  }

  if (!product) return null;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-fade-in">
      {/* Back Link */}
      <Link
        href="/client/products"
        className="inline-flex items-center gap-2 text-sm text-[#64748b] hover:text-[#e2e8f0] transition-colors mb-6 group"
      >
        <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
        Back to Products
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* ====== LEFT COLUMN: Product Details (3 cols) ====== */}
        <div className="lg:col-span-3 space-y-6">
          {/* Product Info Card */}
          <div className="velora-card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-2xl font-bold text-[#e2e8f0]">{product.name}</h1>
                <p className="text-[#64748b] mt-1 text-sm leading-relaxed">{product.description}</p>
              </div>
              <span className="velora-badge flex-shrink-0 ml-4">/{product.billingCycle?.toLowerCase()}</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-sm text-[#64748b]">₹</span>
              <span className="text-3xl font-bold bg-gradient-to-r from-[#6366f1] to-[#8b5cf6] bg-clip-text text-transparent">
                {product.price.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Resource Specs */}
            {product.resources && product.resources.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-[#64748b] uppercase tracking-wider mb-3">Resource Specs</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {product.resources.map((res, i) => (
                    <div
                      key={i}
                      className="p-3 rounded-lg bg-[#09090b] border border-[#1a1a2e] text-center"
                    >
                      <p className="text-xs text-[#64748b] mb-1">{res.label}</p>
                      <p className="text-sm font-semibold text-[#e2e8f0]">{res.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Features List */}
            <div>
              <h3 className="text-sm font-semibold text-[#64748b] uppercase tracking-wider mb-3">Features Included</h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {product.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2.5 text-sm text-[#e2e8f0]">
                    <div className="w-5 h-5 rounded-full bg-[#10b981]/10 flex items-center justify-center flex-shrink-0">
                      <Check size={12} className="text-[#10b981]" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Coupon Card */}
          <div className="velora-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Tag size={16} className="text-[#8b5cf6]" />
              <h3 className="text-base font-semibold text-[#e2e8f0]">Coupon Code</h3>
            </div>

            {couponApplied ? (
              <div className="flex items-center justify-between p-3 rounded-lg bg-[#10b981]/5 border border-[#10b981]/20">
                <div className="flex items-center gap-2">
                  <Check size={16} className="text-[#10b981]" />
                  <span className="text-sm font-medium text-[#10b981]">
                    {couponCode.toUpperCase()} — {couponType === 'percentage' ? `${couponDiscount}%` : `₹${couponDiscount}`} off
                  </span>
                </div>
                <button
                  onClick={removeCoupon}
                  className="p-1 rounded hover:bg-[#1a1a2e] transition-colors"
                >
                  <X size={14} className="text-[#64748b]" />
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && applyCoupon()}
                  placeholder="Enter coupon code"
                  className="velora-input flex-1"
                />
                <button
                  onClick={applyCoupon}
                  disabled={couponLoading}
                  className="velora-btn-secondary px-5 flex items-center gap-2 disabled:opacity-50"
                >
                  {couponLoading ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : null}
                  Apply
                </button>
              </div>
            )}
          </div>

          {/* Payment Method Card */}
          <div className="velora-card p-6">
            <h3 className="text-base font-semibold text-[#e2e8f0] mb-4">Payment Method</h3>
            <div className="space-y-3">
              {/* UPI Payment */}
              <button
                onClick={() => setPaymentMethod('upi')}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all duration-200 ${
                  paymentMethod === 'upi'
                    ? 'border-[#6366f1] bg-[#6366f1]/5 ring-1 ring-[#6366f1]/20'
                    : 'border-[#1a1a2e] hover:border-[#6366f1]/40'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-[#6366f1]/10 flex items-center justify-center flex-shrink-0">
                  <QrCode size={22} className="text-[#6366f1]" />
                </div>
                <div className="text-left flex-1">
                  <p className="text-sm font-semibold text-[#e2e8f0]">UPI Payment</p>
                  <p className="text-xs text-[#64748b]">Pay via UPI QR Code</p>
                </div>
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                    paymentMethod === 'upi'
                      ? 'border-[#6366f1] bg-[#6366f1]'
                      : 'border-[#1a1a2e]'
                  }`}
                >
                  {paymentMethod === 'upi' && <div className="w-2 h-2 rounded-full bg-white" />}
                </div>
              </button>

              {/* Wallet Balance */}
              <button
                onClick={() => setPaymentMethod('wallet')}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all duration-200 ${
                  paymentMethod === 'wallet'
                    ? 'border-[#8b5cf6] bg-[#8b5cf6]/5 ring-1 ring-[#8b5cf6]/20'
                    : 'border-[#1a1a2e] hover:border-[#8b5cf6]/40'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-[#8b5cf6]/10 flex items-center justify-center flex-shrink-0">
                  <WalletIcon size={22} className="text-[#8b5cf6]" />
                </div>
                <div className="text-left flex-1">
                  <p className="text-sm font-semibold text-[#e2e8f0]">Wallet Balance</p>
                  <p className="text-xs text-[#64748b]">
                    Available: <span className="text-[#e2e8f0] font-medium">₹{walletBalance.toLocaleString('en-IN')}</span>
                  </p>
                </div>
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                    paymentMethod === 'wallet'
                      ? 'border-[#8b5cf6] bg-[#8b5cf6]'
                      : 'border-[#1a1a2e]'
                  }`}
                >
                  {paymentMethod === 'wallet' && <div className="w-2 h-2 rounded-full bg-white" />}
                </div>
              </button>
            </div>

            {/* Insufficient balance warning */}
            {paymentMethod === 'wallet' && walletBalance < total && (
              <div className="mt-3 flex items-center gap-2 p-3 rounded-lg bg-[#ef4444]/5 border border-[#ef4444]/20">
                <AlertCircle size={14} className="text-[#ef4444] flex-shrink-0" />
                <p className="text-xs text-[#ef4444]">
                  Insufficient balance. You need ₹{(total - walletBalance).toLocaleString('en-IN')} more.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* ====== RIGHT COLUMN: Order Summary (2 cols) ====== */}
        <div className="lg:col-span-2">
          <div className="velora-card p-6 lg:sticky lg:top-24">
            <h3 className="text-base font-semibold text-[#e2e8f0] mb-5">Order Summary</h3>

            <div className="space-y-3.5 text-sm">
              {/* Product line */}
              <div className="flex justify-between">
                <span className="text-[#64748b]">{product.name}</span>
                <span className="text-[#e2e8f0] font-medium">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>

              {/* Billing cycle */}
              <div className="flex justify-between">
                <span className="text-[#64748b]">Billing</span>
                <span className="text-[#64748b] capitalize">{product.billingCycle?.toLowerCase()}</span>
              </div>

              {/* Subtotal */}
              <div className="flex justify-between pt-2 border-t border-[#1a1a2e]">
                <span className="text-[#64748b]">Subtotal</span>
                <span className="text-[#e2e8f0]">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>

              {/* Tax toggle */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[#64748b]">Tax ({taxRate}%)</span>
                  <button
                    onClick={() => setTaxEnabled(!taxEnabled)}
                    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${
                      taxEnabled ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'
                    }`}
                  >
                    <span
                      className={`inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform ${
                        taxEnabled ? 'translate-x-4.5 ml-[18px]' : 'ml-[2px]'
                      }`}
                    />
                  </button>
                </div>
                <span className={`font-medium ${taxEnabled ? 'text-[#e2e8f0]' : 'text-[#64748b] line-through'}`}>
                  ₹{taxAmount.toLocaleString('en-IN')}
                </span>
              </div>

              {/* Coupon discount */}
              {couponApplied && discountAmount > 0 && (
                <div className="flex justify-between">
                  <span className="text-[#10b981]">
                    Discount
                    {couponType === 'percentage' ? ` (${couponDiscount}%)` : ''}
                  </span>
                  <span className="text-[#10b981] font-medium">-₹{Math.round(discountAmount).toLocaleString('en-IN')}</span>
                </div>
              )}

              {/* Divider + Total */}
              <div className="pt-3 border-t border-[#1a1a2e]">
                <div className="flex justify-between items-baseline">
                  <span className="text-base font-semibold text-[#e2e8f0]">Total</span>
                  <span className="text-2xl font-bold bg-gradient-to-r from-[#6366f1] to-[#8b5cf6] bg-clip-text text-transparent">
                    ₹{Math.round(total).toLocaleString('en-IN')}
                  </span>
                </div>
                <p className="text-xs text-[#64748b] mt-1">Inclusive of all taxes</p>
              </div>
            </div>

            {/* CTA Button */}
            <button
              onClick={handlePlaceOrder}
              disabled={placing || (paymentMethod === 'wallet' && walletBalance < total)}
              className="w-full velora-btn-primary mt-6 py-3 flex items-center justify-center gap-2 text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {placing ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Processing...
                </>
              ) : paymentMethod === 'upi' ? (
                <>
                  <QrCode size={16} />
                  Proceed to Payment
                </>
              ) : (
                <>
                  <WalletIcon size={16} />
                  Pay from Wallet
                </>
              )}
            </button>

            {/* Security note */}
            <div className="mt-4 flex items-center gap-2 text-xs text-[#64748b]">
              <Shield size={12} className="text-[#10b981] flex-shrink-0" />
              <span>Secured by Velora Billing. Your payment details are safe.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-8 h-8 text-[#6366f1] animate-spin mx-auto mb-3" />
            <p className="text-[#64748b] text-sm">Loading checkout...</p>
          </div>
        </div>
      }
    >
      <CheckoutContent />
    </Suspense>
  );
}
