import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const group = searchParams.get('group');

    const where: any = {};
    if (group) where.group = group;

    const settings = await db.setting.findMany({ where });

    const config: Record<string, any> = {};
    settings.forEach((s) => {
      let value: any = s.value;
      if (s.type === 'boolean') value = s.value === 'true';
      else if (s.type === 'number') value = parseFloat(s.value);
      else if (s.type === 'json') {
        try { value = JSON.parse(s.value); } catch { value = s.value; }
      }
      config[s.key] = value;
    });

    return NextResponse.json({ success: true, data: config });
  } catch (error) {
    console.error('Admin settings error:', error);
    return NextResponse.json({ success: false, error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.replace('Bearer ', ''));
    if (!payload || payload.role !== 'admin') {
      return NextResponse.json({ success: false, error: 'Admin access required' }, { status: 403 });
    }

    const settings: Record<string, { value: string; group?: string; type?: string }> = await request.json();

    if (!settings || typeof settings !== 'object') {
      return NextResponse.json({ success: false, error: 'Settings object is required' }, { status: 400 });
    }

    for (const [key, data] of Object.entries(settings)) {
      await db.setting.upsert({
        where: { key },
        update: { value: data.value },
        create: {
          key,
          value: data.value,
          group: data.group || 'general',
          type: data.type || 'text',
        },
      });
    }

    // Audit log
    await db.auditLog.create({
      data: {
        userId: payload.id as string,
        action: 'settings_updated',
        details: JSON.stringify({ keys: Object.keys(settings) }),
      },
    });

    return NextResponse.json({ success: true, message: 'Settings updated' });
  } catch (error) {
    console.error('Admin settings update error:', error);
    return NextResponse.json({ success: false, error: 'Failed to update settings' }, { status: 500 });
  }
}