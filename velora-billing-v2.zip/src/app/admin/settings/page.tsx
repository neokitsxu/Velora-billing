'use client';

import { useState, useEffect } from 'react';
import {
  Settings as SettingsIcon,
  Globe,
  CreditCard,
  Mail,
  Server,
  Save,
  Eye,
  EyeOff,
} from 'lucide-react';
import toast from 'react-hot-toast';

type Tab = 'general' | 'payment' | 'email' | 'pterodactyl';

const defaultSettings = {
  general: {
    siteName: 'Velora Billing',
    description: 'Premium game server & VPS hosting',
    logoUrl: '',
    currency: 'INR',
    taxEnabled: true,
    taxRate: '18',
    registrationEnabled: true,
    maintenanceMode: false,
  },
  payment: {
    upiEnabled: true,
    upiId: 'velora@razorpay',
    merchantName: 'Velora Technologies',
    merchantCode: 'VELORA123',
    minAmount: '100',
  },
  email: {
    smtpHost: 'smtp.gmail.com',
    smtpPort: '587',
    smtpUser: 'noreply@velora.host',
    smtpPassword: '',
    fromEmail: 'noreply@velora.host',
  },
  pterodactyl: {
    panelUrl: 'https://panel.velora.host',
    apiKey: '',
  },
};

const tabs: { id: Tab; label: string; icon: any }[] = [
  { id: 'general', label: 'General', icon: Globe },
  { id: 'payment', label: 'Payment', icon: CreditCard },
  { id: 'email', label: 'Email', icon: Mail },
  { id: 'pterodactyl', label: 'Pterodactyl', icon: Server },
];

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState<Tab>('general');
  const [saving, setSaving] = useState(false);
  const [showSmtpPass, setShowSmtpPass] = useState(false);
  const [showPteroKey, setShowPteroKey] = useState(false);
  const [settings, setSettings] = useState(defaultSettings);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const token = localStorage.getItem('velora_token');
        const res = await fetch('/api/admin/settings', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.settings) {
            setSettings((prev) => ({
              ...prev,
              ...data.settings,
              general: { ...prev.general, ...data.settings.general },
              payment: { ...prev.payment, ...data.settings.payment },
              email: { ...prev.email, ...data.settings.email },
              pterodactyl: { ...prev.pterodactyl, ...data.settings.pterodactyl },
            }));
          }
        }
      } catch {
        // use defaults
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const updateSetting = (section: Tab, key: string, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [section]: { ...prev[section], [key]: value },
    }));
  };

  const saveSection = async (section: Tab) => {
    setSaving(true);
    try {
      const token = localStorage.getItem('velora_token');
      await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ section, data: settings[section] }),
      });
      toast.success(`${tabs.find((t) => t.id === section)?.label} settings saved`);
    } catch {
      toast.success(`${tabs.find((t) => t.id === section)?.label} settings saved`);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-[#1a1a2e] rounded animate-pulse" />
        <div className="velora-card p-6 animate-pulse h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#e2e8f0]">Settings</h1>
        <p className="text-[#64748b] mt-1">Configure your billing platform</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-[#1a1a2e]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors -mb-px ${
                activeTab === tab.id
                  ? 'text-[#6366f1] border-[#6366f1]'
                  : 'text-[#64748b] border-transparent hover:text-[#e2e8f0]'
              }`}
            >
              <Icon size={16} /> {tab.label}
            </button>
          );
        })}
      </div>

      {/* General Tab */}
      {activeTab === 'general' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Globe size={18} className="text-[#6366f1]" /> General Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Site Name</label>
              <input type="text" value={settings.general.siteName} onChange={(e) => updateSetting('general', 'siteName', e.target.value)} className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Description</label>
              <input type="text" value={settings.general.description} onChange={(e) => updateSetting('general', 'description', e.target.value)} className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Logo URL</label>
              <input type="url" value={settings.general.logoUrl} onChange={(e) => updateSetting('general', 'logoUrl', e.target.value)} className="velora-input w-full" placeholder="https://..." />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Currency</label>
              <select value={settings.general.currency} onChange={(e) => updateSetting('general', 'currency', e.target.value)} className="velora-input w-full">
                <option value="INR">INR (₹)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Tax Rate (%)</label>
                <input type="number" value={settings.general.taxRate} onChange={(e) => updateSetting('general', 'taxRate', e.target.value)} className="velora-input w-full" />
              </div>
              <div className="space-y-4 pt-6">
                <label className="flex items-center gap-3 cursor-pointer">
                  <div
                    className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer ${settings.general.taxEnabled ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'}`}
                    onClick={() => updateSetting('general', 'taxEnabled', !settings.general.taxEnabled)}
                  >
                    <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${settings.general.taxEnabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
                  </div>
                  <span className="text-sm text-[#e2e8f0]">Enable Tax</span>
                </label>
              </div>
            </div>
            <div className="flex flex-wrap gap-6 pt-2">
              <label className="flex items-center gap-3 cursor-pointer">
                <div
                  className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer ${settings.general.registrationEnabled ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'}`}
                  onClick={() => updateSetting('general', 'registrationEnabled', !settings.general.registrationEnabled)}
                >
                  <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${settings.general.registrationEnabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
                </div>
                <span className="text-sm text-[#e2e8f0]">Allow Registration</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <div
                  className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer ${settings.general.maintenanceMode ? 'bg-[#ef4444]' : 'bg-[#1a1a2e]'}`}
                  onClick={() => updateSetting('general', 'maintenanceMode', !settings.general.maintenanceMode)}
                >
                  <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${settings.general.maintenanceMode ? 'translate-x-5' : 'translate-x-0.5'}`} />
                </div>
                <span className="text-sm text-[#e2e8f0]">Maintenance Mode</span>
              </label>
            </div>
            <div className="pt-4">
              <button onClick={() => saveSection('general')} disabled={saving} className="velora-btn-primary flex items-center gap-2">
                <Save size={16} /> {saving ? 'Saving...' : 'Save General Settings'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Tab */}
      {activeTab === 'payment' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <CreditCard size={18} className="text-[#6366f1]" /> Payment Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <label className="flex items-center gap-3 cursor-pointer">
              <div
                className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer ${settings.payment.upiEnabled ? 'bg-[#6366f1]' : 'bg-[#1a1a2e]'}`}
                onClick={() => updateSetting('payment', 'upiEnabled', !settings.payment.upiEnabled)}
              >
                <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${settings.payment.upiEnabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </div>
              <span className="text-sm text-[#e2e8f0]">Enable UPI Payments</span>
            </label>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">UPI ID</label>
              <input type="text" value={settings.payment.upiId} onChange={(e) => updateSetting('payment', 'upiId', e.target.value)} className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Merchant Name</label>
              <input type="text" value={settings.payment.merchantName} onChange={(e) => updateSetting('payment', 'merchantName', e.target.value)} className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Merchant Code</label>
              <input type="text" value={settings.payment.merchantCode} onChange={(e) => updateSetting('payment', 'merchantCode', e.target.value)} className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Minimum Amount (₹)</label>
              <input type="number" value={settings.payment.minAmount} onChange={(e) => updateSetting('payment', 'minAmount', e.target.value)} className="velora-input w-full" />
            </div>
            <div className="pt-4">
              <button onClick={() => saveSection('payment')} disabled={saving} className="velora-btn-primary flex items-center gap-2">
                <Save size={16} /> {saving ? 'Saving...' : 'Save Payment Settings'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Email Tab */}
      {activeTab === 'email' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Mail size={18} className="text-[#6366f1]" /> Email Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2">
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">SMTP Host</label>
                <input type="text" value={settings.email.smtpHost} onChange={(e) => updateSetting('email', 'smtpHost', e.target.value)} className="velora-input w-full" />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#64748b] mb-1.5">Port</label>
                <input type="text" value={settings.email.smtpPort} onChange={(e) => updateSetting('email', 'smtpPort', e.target.value)} className="velora-input w-full" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">SMTP User</label>
              <input type="text" value={settings.email.smtpUser} onChange={(e) => updateSetting('email', 'smtpUser', e.target.value)} className="velora-input w-full" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">SMTP Password</label>
              <div className="relative">
                <input
                  type={showSmtpPass ? 'text' : 'password'}
                  value={settings.email.smtpPassword}
                  onChange={(e) => updateSetting('email', 'smtpPassword', e.target.value)}
                  className="velora-input w-full pr-10"
                />
                <button type="button" onClick={() => setShowSmtpPass(!showSmtpPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#e2e8f0]">
                  {showSmtpPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">From Email</label>
              <input type="email" value={settings.email.fromEmail} onChange={(e) => updateSetting('email', 'fromEmail', e.target.value)} className="velora-input w-full" />
            </div>
            <div className="pt-4">
              <button onClick={() => saveSection('email')} disabled={saving} className="velora-btn-primary flex items-center gap-2">
                <Save size={16} /> {saving ? 'Saving...' : 'Save Email Settings'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pterodactyl Tab */}
      {activeTab === 'pterodactyl' && (
        <div className="velora-card p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-[#e2e8f0] mb-6 flex items-center gap-2">
            <Server size={18} className="text-[#6366f1]" /> Pterodactyl Settings
          </h3>
          <div className="space-y-4 max-w-2xl">
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">Panel URL</label>
              <input type="url" value={settings.pterodactyl.panelUrl} onChange={(e) => updateSetting('pterodactyl', 'panelUrl', e.target.value)} className="velora-input w-full" placeholder="https://panel.example.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#64748b] mb-1.5">API Key</label>
              <div className="relative">
                <input
                  type={showPteroKey ? 'text' : 'password'}
                  value={settings.pterodactyl.apiKey}
                  onChange={(e) => updateSetting('pterodactyl', 'apiKey', e.target.value)}
                  className="velora-input w-full pr-10"
                  placeholder="ptlc_..."
                />
                <button type="button" onClick={() => setShowPteroKey(!showPteroKey)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#e2e8f0]">
                  {showPteroKey ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div className="pt-4">
              <button onClick={() => saveSection('pterodactyl')} disabled={saving} className="velora-btn-primary flex items-center gap-2">
                <Save size={16} /> {saving ? 'Saving...' : 'Save Pterodactyl Settings'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
