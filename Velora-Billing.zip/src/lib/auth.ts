import { db } from '@/lib/db';
import { cookies } from 'next/headers';
import { nanoid } from 'nanoid';

class SimpleAuth {
  // Simple token-based auth using cookies
  private static TOKEN_COOKIE = 'velora_session';
  private static sessions: Map<string, { userId: string; expiresAt: number }> = new Map();

  static async hashPassword(password: string): Promise<string> {
    // Simple hash for demo - in production use bcrypt
    const encoder = new TextEncoder();
    const data = encoder.encode(password + 'velora_salt_2024');
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  static async verifyPassword(password: string, hash: string): Promise<boolean> {
    const passwordHash = await SimpleAuth.hashPassword(password);
    return passwordHash === hash;
  }

  static createSession(userId: string): string {
    const token = nanoid(32);
    this.sessions.set(token, { userId, expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 }); // 7 days
    return token;
  }

  static async getSessionUser(): Promise<{ id: string; email: string; name: string | null; role: string } | null> {
    const cookieStore = await cookies();
    const token = cookieStore.get(SimpleAuth.TOKEN_COOKIE)?.value;
    if (!token) return null;

    const session = this.sessions.get(token);
    if (!session || session.expiresAt < Date.now()) {
      this.sessions.delete(token);
      return null;
    }

    const user = await db.user.findUnique({ where: { id: session.userId } });
    if (!user) return null;

    return { id: user.id, email: user.email, name: user.name, role: user.role };
  }

  static deleteSession(token: string): void {
    this.sessions.delete(token);
  }
}

export { SimpleAuth };
export const TOKEN_COOKIE = 'velora_session';
