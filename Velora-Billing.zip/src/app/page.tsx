'use client';

import React, { useEffect, useState, Suspense } from 'react';
import { useStore, Page } from '@/components/velora/store';
import { Navbar, Footer } from '@/components/velora/layout/PublicLayout';
import { DashboardLayout } from '@/components/velora/layout/DashboardLayout';
import { ShoppingCartIcon, ZapIcon, MenuIcon, XIcon } from '@/components/velora/icons';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

// Lazy imports for page components
const LandingPage = React.lazy(() => import('@/components/velora/pages/LandingPage'));
const LoginPage = React.lazy(() => import('@/components/velora/pages/LoginPage'));
const RegisterPage = React.lazy(() => import('@/components/velora/pages/RegisterPage'));
const ProductsPage = React.lazy(() => import('@/components/velora/pages/ProductsPage'));
const CheckoutPage = React.lazy(() => import('@/components/velora/pages/CheckoutPage'));
const DashboardPage = React.lazy(() => import('@/components/velora/pages/DashboardPage'));
const OrdersPage = React.lazy(() => import('@/components/velora/pages/OrdersPage'));
const OrderDetailPage = React.lazy(() => import('@/components/velora/pages/OrderDetailPage'));
const InvoicesPage = React.lazy(() => import('@/components/velora/pages/InvoicesPage'));
const TicketsPage = React.lazy(() => import('@/components/velora/pages/TicketsPage'));
const TicketDetailPage = React.lazy(() => import('@/components/velora/pages/TicketDetailPage'));
const NewTicketPage = React.lazy(() => import('@/components/velora/pages/NewTicketPage'));
const PaymentPage = React.lazy(() => import('@/components/velora/pages/PaymentPage'));
const AdminPage = React.lazy(() => import('@/components/velora/pages/AdminPage'));

/* -------------------------------------------------------------------------- */
/*  Loading Spinner                                                           */
/* -------------------------------------------------------------------------- */

function LoadingSpinner({ message }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
      <div className="relative">
        <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
        <ZapIcon className="absolute inset-0 m-auto h-5 w-5 text-primary animate-pulse-slow" />
      </div>
      {message && (
        <p className="text-sm text-muted-foreground animate-pulse-slow">{message}</p>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Initial Boot Screen                                                       */
/* -------------------------------------------------------------------------- */

function BootScreen() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background">
      <div className="relative mb-6">
        <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center">
          <ZapIcon className="h-8 w-8 text-primary" />
        </div>
      </div>
      <h1 className="text-xl font-semibold gradient-text mb-2">Velora Billing</h1>
      <div className="flex items-center gap-2 mt-4">
        <div className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:0ms]" />
        <div className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:150ms]" />
        <div className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:300ms]" />
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Cart Badge                                                                */
/* -------------------------------------------------------------------------- */

function CartBadge() {
  const cart = useStore((s) => s.cart);
  const setPage = useStore((s) => s.setPage);
  const count = cart.length;

  if (count === 0) return null;

  return (
    <Button
      variant="ghost"
      size="sm"
      className="relative text-muted-foreground hover:text-foreground transition-colors"
      onClick={() => setPage('checkout')}
      aria-label={`Shopping cart with ${count} items`}
    >
      <ShoppingCartIcon className="h-5 w-5" />
      <Badge className="absolute -top-1.5 -right-1.5 h-5 min-w-5 flex items-center justify-center rounded-full bg-primary text-primary-foreground text-[10px] font-bold px-1">
        {count}
      </Badge>
    </Button>
  );
}

/* -------------------------------------------------------------------------- */
/*  Mobile Nav                                                                */
/* -------------------------------------------------------------------------- */

function MobileNav() {
  const user = useStore((s) => s.user);
  const setPage = useStore((s) => s.setPage);
  const cart = useStore((s) => s.cart);
  const [open, setOpen] = useState(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
          <MenuIcon className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-72">
        <div className="flex flex-col gap-6 mt-8">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <ZapIcon className="h-4 w-4 text-primary" />
            </div>
            <span className="font-semibold text-lg">Velora</span>
          </div>

          <nav className="flex flex-col gap-1">
            <button
              onClick={() => { setPage('home'); setOpen(false); }}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm hover:bg-accent transition-colors text-left"
            >
              Home
            </button>
            <button
              onClick={() => { setPage('products'); setOpen(false); }}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm hover:bg-accent transition-colors text-left"
            >
              Products & Services
            </button>
          </nav>

          <div className="border-t pt-4 flex flex-col gap-2">
            {user ? (
              <>
                <button
                  onClick={() => { setPage('dashboard'); setOpen(false); }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm bg-primary/5 text-primary font-medium hover:bg-primary/10 transition-colors text-left"
                >
                  Dashboard
                </button>
                <button
                  onClick={() => { setPage('orders'); setOpen(false); }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm hover:bg-accent transition-colors text-left"
                >
                  My Orders
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => { setPage('login'); setOpen(false); }}
                  className="w-full px-3 py-2.5 rounded-lg text-sm border border-border hover:bg-accent transition-colors text-left"
                >
                  Sign In
                </button>
                <button
                  onClick={() => { setPage('register'); setOpen(false); }}
                  className="w-full px-3 py-2.5 rounded-lg text-sm bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors text-left"
                >
                  Create Account
                </button>
              </>
            )}
          </div>

          {cart.length > 0 && (
            <div className="border-t pt-4">
              <button
                onClick={() => { setPage('checkout'); setOpen(false); }}
                className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-sm bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
              >
                <ShoppingCartIcon className="h-4 w-4" />
                Cart ({cart.length})
              </button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

/* -------------------------------------------------------------------------- */
/*  Page Router                                                               */
/* -------------------------------------------------------------------------- */

const PUBLIC_PAGES: Page[] = ['home', 'login', 'register', 'products'];
const DASHBOARD_PAGES: Page[] = ['dashboard', 'orders', 'order-detail', 'invoices', 'tickets', 'ticket-detail', 'new-ticket'];
const ADMIN_PAGES: Page[] = ['admin', 'admin-products', 'admin-orders', 'admin-users', 'admin-tickets'];
const STANDALONE_PAGES: Page[] = ['checkout', 'payment'];

function PageRouter() {
  const page = useStore((s) => s.page);
  const pageData = useStore((s) => s.pageData);

  const renderPage = () => {
    switch (page) {
      case 'home':
        return <LandingPage />;
      case 'login':
        return <LoginPage />;
      case 'register':
        return <RegisterPage />;
      case 'products':
        return <ProductsPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'dashboard':
        return <DashboardPage />;
      case 'orders':
        return <OrdersPage />;
      case 'order-detail':
        return <OrderDetailPage />;
      case 'invoices':
        return <InvoicesPage />;
      case 'tickets':
        return <TicketsPage />;
      case 'ticket-detail':
        return <TicketDetailPage />;
      case 'new-ticket':
        return <NewTicketPage />;
      case 'payment':
        return <PaymentPage />;
      case 'admin':
      case 'admin-products':
      case 'admin-orders':
      case 'admin-users':
      case 'admin-tickets':
        return <AdminPage />;
      default:
        return <LandingPage />;
    }
  };

  // Public pages get Navbar + Footer
  if (PUBLIC_PAGES.includes(page)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar>
          <CartBadge />
          <MobileNav />
        </Navbar>
        <main className="flex-1">
          <Suspense fallback={<LoadingSpinner message="Loading page..." />}>
            {renderPage()}
          </Suspense>
        </main>
        <Footer />
      </div>
    );
  }

  // Dashboard & Admin pages get Sidebar layout
  if (DASHBOARD_PAGES.includes(page) || ADMIN_PAGES.includes(page)) {
    return (
      <DashboardLayout>
        <Suspense fallback={<LoadingSpinner message="Loading..." />}>
          {renderPage()}
        </Suspense>
      </DashboardLayout>
    );
  }

  // Standalone pages (checkout, payment) — no layout wrapper
  return (
    <Suspense fallback={<LoadingSpinner message="Loading..." />}>
      {renderPage()}
    </Suspense>
  );
}

/* -------------------------------------------------------------------------- */
/*  Main App                                                                  */
/* -------------------------------------------------------------------------- */

export default function App() {
  const setUser = useStore((s) => s.setUser);
  const setLoading = useStore((s) => s.setLoading);
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function init() {
      try {
        // 1. Seed the database (idempotent — safe to call every time)
        await fetch('/api/seed/run', { method: 'POST' });

        if (cancelled) return;

        // 2. Check for existing auth session
        const meRes = await fetch('/api/auth/me');
        if (meRes.ok) {
          const meData = await meRes.json();
          if (!cancelled) {
            setUser(meData);
          }
        }
      } catch (err) {
        console.warn('Init error:', err);
      } finally {
        if (!cancelled) {
          setBooting(false);
        }
      }
    }

    init();
    return () => {
      cancelled = true;
    };
  }, [setUser]);

  // Show boot screen while seeding & auth check run
  if (booting) {
    return <BootScreen />;
  }

  return <PageRouter />;
}
