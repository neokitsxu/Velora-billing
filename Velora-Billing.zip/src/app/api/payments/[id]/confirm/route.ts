import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await SimpleAuth.getSessionUser();
    if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    const { id } = await params;

    const payment = await db.payment.findFirst({ where: { id, userId: user.id } });
    if (!payment) return NextResponse.json({ error: 'Payment not found' }, { status: 404 });
    if (payment.status === 'completed') return NextResponse.json({ error: 'Already confirmed' }, { status: 400 });

    const now = new Date();
    const [updatedPayment] = await db.$transaction([
      db.payment.update({
        where: { id },
        data: { status: 'completed', paidAt: now, upiTxnId: 'UPI' + Date.now() },
      }),
      db.order.update({
        where: { id: payment.orderId! },
        data: { status: 'paid', paidAt: now },
      }),
      db.invoice.updateMany({
        where: { orderId: payment.orderId },
        data: { status: 'paid', paidAt: now },
      }),
    ]);

    return NextResponse.json(updatedPayment);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
