import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const user = await SimpleAuth.getSessionUser();
    if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

    const { orderId, amount } = await req.json();
    if (!orderId) return NextResponse.json({ error: 'Order ID required' }, { status: 400 });

    const order = await db.order.findFirst({ where: { id: orderId, userId: user.id } });
    if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    if (order.status === 'paid') return NextResponse.json({ error: 'Order already paid' }, { status: 400 });

    const paymentNumber = 'PAY-' + Date.now().toString(36).toUpperCase();
    const payment = await db.payment.create({
      data: {
        paymentNumber,
        orderId: order.id,
        invoiceId: undefined,
        userId: user.id,
        gateway: 'upi',
        amount: amount || order.total,
        status: 'pending',
      },
    });

    return NextResponse.json(payment);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
