import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const user = await SimpleAuth.getSessionUser();
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }
    return NextResponse.json(user);
  } catch {
    return NextResponse.json({ error: 'Failed to get user' }, { status: 500 });
  }
}