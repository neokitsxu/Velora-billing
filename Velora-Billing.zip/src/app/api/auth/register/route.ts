import { db } from '@/lib/db';
import { SimpleAuth, TOKEN_COOKIE } from '@/lib/auth';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function POST(req: Request) {
  try {
    const { email, password, name } = await req.json();
    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password required' }, { status: 400 });
    }
    const existing = await db.user.findUnique({ where: { email } });
    if (existing) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
    }
    const hashedPassword = await SimpleAuth.hashPassword(password);
    const user = await db.user.create({
      data: { email, password: hashedPassword, name: name || null, role: 'client' },
    });
    const token = SimpleAuth.createSession(user.id);
    const cookieStore = await cookies();
    cookieStore.set(TOKEN_COOKIE, token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 60 * 60, path: '/' });
    return NextResponse.json({ id: user.id, email: user.email, name: user.name, role: user.role });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Registration failed' }, { status: 500 });
  }
}