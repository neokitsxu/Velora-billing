import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

async function adminCheck() {
  const user = await SimpleAuth.getSessionUser();
  if (!user || user.role !== 'admin') return null;
  return user;
}

export async function GET() {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const tickets = await db.ticket.findMany({
      orderBy: { updatedAt: 'desc' },
      include: { user: { select: { id: true, name: true, email: true } }, replies: { orderBy: { createdAt: 'asc' } } },
    });
    return NextResponse.json(tickets);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { ticketId, message } = await req.json();
    if (!ticketId || !message) return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    const reply = await db.ticketReply.create({
      data: { ticketId, message, userId: user.id, isAdmin: true },
    });
    await db.ticket.update({ where: { id: ticketId }, data: { status: 'answered', updatedAt: new Date() } });
    return NextResponse.json(reply);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { id, status } = await req.json();
    const ticket = await db.ticket.update({ where: { id }, data: { status } });
    return NextResponse.json(ticket);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}