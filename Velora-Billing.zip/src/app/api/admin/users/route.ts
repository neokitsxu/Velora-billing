import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

async function adminCheck() {
  const user = await SimpleAuth.getSessionUser();
  if (!user || user.role !== 'admin') return null;
  return user;
}

export async function GET() {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const users = await db.user.findMany({ orderBy: { createdAt: 'desc' } });
    return NextResponse.json(users);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { id, status, role } = await req.json();
    const updated = await db.user.update({ where: { id }, data: { status, role } });
    return NextResponse.json(updated);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}