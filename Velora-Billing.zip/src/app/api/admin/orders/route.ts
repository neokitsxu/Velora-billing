import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

async function adminCheck() {
  const user = await SimpleAuth.getSessionUser();
  if (!user || user.role !== 'admin') return null;
  return user;
}

export async function GET() {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const orders = await db.order.findMany({
      orderBy: { createdAt: 'desc' },
      include: { items: true, payments: true },
    });
    return NextResponse.json(orders);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { id, status } = await req.json();
    const order = await db.order.update({ where: { id }, data: { status } });
    return NextResponse.json(order);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}