import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

async function adminCheck() {
  const user = await SimpleAuth.getSessionUser();
  if (!user || user.role !== 'admin') return null;
  return user;
}

export async function GET() {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const products = await db.product.findMany({ orderBy: { sortOrder: 'asc' } });
    return NextResponse.json(products);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const data = await req.json();
    const slug = data.slug || data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const product = await db.product.create({
      data: {
        name: data.name,
        slug,
        description: data.description || null,
        shortDesc: data.shortDesc || null,
        price: data.price,
        yearlyPrice: data.yearlyPrice || null,
        setupFee: data.setupFee || 0,
        category: data.category || 'hosting',
        status: data.status || 'active',
        features: data.features ? JSON.stringify(data.features) : null,
        sortOrder: data.sortOrder || 0,
      },
    });
    return NextResponse.json(product);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const data = await req.json();
    const product = await db.product.update({
      where: { id: data.id },
      data: {
        name: data.name,
        slug: data.slug,
        description: data.description,
        shortDesc: data.shortDesc,
        price: data.price,
        yearlyPrice: data.yearlyPrice,
        setupFee: data.setupFee,
        category: data.category,
        status: data.status,
        features: data.features ? JSON.stringify(data.features) : null,
        sortOrder: data.sortOrder,
      },
    });
    return NextResponse.json(product);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const user = await adminCheck();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    const { id } = await req.json();
    await db.product.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}