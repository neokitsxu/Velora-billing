import { db } from '@/lib/db';
import { SimpleAuth, TOKEN_COOKIE } from '@/lib/auth';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function POST() {
  try {
    // Create admin user
    const hashedPassword = await SimpleAuth.hashPassword('admin123');
    const admin = await db.user.upsert({
      where: { email: 'admin@velorabilling.com' },
      update: {},
      create: {
        email: 'admin@velorabilling.com',
        password: hashedPassword,
        name: 'Admin',
        role: 'admin',
      },
    });

    // Create demo products
    const products = [
      {
        name: 'Starter Hosting',
        slug: 'starter-hosting',
        shortDesc: 'Perfect for personal websites and blogs',
        description: 'Our Starter Hosting plan is ideal for personal websites, blogs, and small projects. Comes with 10GB SSD storage, 100GB bandwidth, and free SSL certificate.',
        price: 149,
        yearlyPrice: 1499,
        setupFee: 0,
        category: 'hosting',
        status: 'active',
        sortOrder: 1,
        features: JSON.stringify(['10GB SSD Storage', '100GB Bandwidth', '1 Website', 'Free SSL', 'cPanel Access', 'Daily Backups']),
      },
      {
        name: 'Business Hosting',
        slug: 'business-hosting',
        shortDesc: 'Ideal for growing businesses',
        description: 'Business Hosting plan offers more resources for growing businesses. 50GB SSD storage, unlimited bandwidth, and priority support.',
        price: 399,
        yearlyPrice: 3999,
        setupFee: 0,
        category: 'hosting',
        status: 'active',
        sortOrder: 2,
        features: JSON.stringify(['50GB SSD Storage', 'Unlimited Bandwidth', '5 Websites', 'Free SSL', 'cPanel Access', 'Priority Support', 'Daily Backups', 'Free Domain']),
      },
      {
        name: 'Premium Hosting',
        slug: 'premium-hosting',
        shortDesc: 'For high-traffic websites',
        description: 'Premium Hosting is built for high-traffic websites and resource-intensive applications. NVMe storage, dedicated resources, and 24/7 premium support.',
        price: 799,
        yearlyPrice: 7999,
        setupFee: 0,
        category: 'hosting',
        status: 'active',
        sortOrder: 3,
        features: JSON.stringify(['100GB NVMe Storage', 'Unlimited Bandwidth', 'Unlimited Websites', 'Free SSL', 'cPanel Access', '24/7 Premium Support', 'Hourly Backups', 'Free Domain', 'Dedicated IP', 'LiteSpeed Server']),
      },
      {
        name: 'VPS Starter',
        slug: 'vps-starter',
        shortDesc: 'Entry-level VPS with full root access',
        description: 'VPS Starter gives you full root access with 2 vCPU, 2GB RAM, and 40GB SSD. Perfect for developers and small applications.',
        price: 499,
        yearlyPrice: 4999,
        setupFee: 0,
        category: 'vps',
        status: 'active',
        sortOrder: 4,
        features: JSON.stringify(['2 vCPU Cores', '2GB RAM', '40GB SSD', '2TB Bandwidth', 'Full Root Access', 'KVM Virtualization', 'DDoS Protection', '1 Free Snapshot']),
      },
      {
        name: 'VPS Pro',
        slug: 'vps-pro',
        shortDesc: 'Powerful VPS for demanding workloads',
        description: 'VPS Pro is designed for demanding workloads with 4 vCPU, 8GB RAM, and 100GB NVMe. Ideal for production applications and databases.',
        price: 1299,
        yearlyPrice: 12999,
        setupFee: 0,
        category: 'vps',
        status: 'active',
        sortOrder: 5,
        features: JSON.stringify(['4 vCPU Cores', '8GB RAM', '100GB NVMe', '4TB Bandwidth', 'Full Root Access', 'KVM Virtualization', 'DDoS Protection', '3 Free Snapshots', 'Managed Option', 'IPv6 Support']),
      },
      {
        name: 'VPS Enterprise',
        slug: 'vps-enterprise',
        shortDesc: 'Maximum performance VPS',
        description: 'VPS Enterprise delivers maximum performance with 8 vCPU, 32GB RAM, and 200GB NVMe. For mission-critical applications.',
        price: 2999,
        yearlyPrice: 29999,
        setupFee: 0,
        category: 'vps',
        status: 'active',
        sortOrder: 6,
        features: JSON.stringify(['8 vCPU Cores', '32GB RAM', '200GB NVMe', '8TB Bandwidth', 'Full Root Access', 'KVM Virtualization', 'DDoS Protection', '10 Free Snapshots', 'Fully Managed', 'IPv6 Support', 'Dedicated Resources']),
      },
      {
        name: '.com Domain',
        slug: 'com-domain',
        shortDesc: 'Register your .com domain',
        description: 'Register your .com domain with Velora Billing. Includes WHOIS privacy, DNS management, and free domain forwarding.',
        price: 899,
        yearlyPrice: 899,
        setupFee: 0,
        category: 'domains',
        status: 'active',
        sortOrder: 7,
        features: JSON.stringify(['.com Domain', 'WHOIS Privacy', 'DNS Management', 'Domain Forwarding', 'Email Forwarding', '1 Year Registration']),
      },
      {
        name: '.in Domain',
        slug: 'in-domain',
        shortDesc: 'Register your .in domain',
        description: 'Perfect for Indian businesses. Register your .in domain with free WHOIS privacy and DNS management.',
        price: 499,
        yearlyPrice: 499,
        setupFee: 0,
        category: 'domains',
        status: 'active',
        sortOrder: 8,
        features: JSON.stringify(['.in Domain', 'WHOIS Privacy', 'DNS Management', 'Domain Forwarding', 'Email Forwarding', '1 Year Registration']),
      },
    ];

    for (const p of products) {
      await db.product.upsert({
        where: { slug: p.slug },
        update: {},
        create: p,
      });
    }

    // Save UPI config
    await db.siteConfig.upsert({
      where: { key: 'upi_id' },
      update: { value: 'velorahosting@ybl' },
      create: { key: 'upi_id', value: 'velorahosting@ybl' },
    });

    // Auto-login as admin
    const token = SimpleAuth.createSession(admin.id);
    const cookieStore = await cookies();
    cookieStore.set(TOKEN_COOKIE, token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 60 * 60, path: '/' });

    return NextResponse.json({ success: true, message: 'Database seeded with demo data', adminEmail: 'admin@velorabilling.com' });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
