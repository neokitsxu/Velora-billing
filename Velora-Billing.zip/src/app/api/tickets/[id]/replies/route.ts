import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await SimpleAuth.getSessionUser();
    if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    const { id } = await params;
    const { message } = await req.json();
    if (!message) return NextResponse.json({ error: 'Message required' }, { status: 400 });

    const ticket = await db.ticket.findFirst({ where: { id, userId: user.id } });
    if (!ticket) return NextResponse.json({ error: 'Ticket not found' }, { status: 404 });

    const reply = await db.ticketReply.create({
      data: { ticketId: id, message, userId: user.id, isAdmin: false },
    });

    await db.ticket.update({
      where: { id },
      data: { status: 'open', updatedAt: new Date() },
    });

    return NextResponse.json(reply);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
