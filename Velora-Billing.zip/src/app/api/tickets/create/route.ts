import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const user = await SimpleAuth.getSessionUser();
    if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

    const { subject, message, priority } = await req.json();
    if (!subject || !message) {
      return NextResponse.json({ error: 'Subject and message required' }, { status: 400 });
    }

    const ticket = await db.ticket.create({
      data: {
        subject,
        userId: user.id,
        priority: priority || 'medium',
        replies: {
          create: {
            message,
            userId: user.id,
            isAdmin: false,
          },
        },
      },
      include: { replies: true },
    });

    return NextResponse.json(ticket);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
