import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get('category');
    const where = category ? { category, status: 'active' } : { status: 'active' };
    const products = await db.product.findMany({
      where,
      orderBy: { sortOrder: 'asc' },
    });
    return NextResponse.json(products);
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}