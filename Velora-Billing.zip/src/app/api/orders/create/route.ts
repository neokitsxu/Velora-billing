import { db } from '@/lib/db';
import { SimpleAuth } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const user = await SimpleAuth.getSessionUser();
    if (!user) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });

    const { items, billingCycle } = await req.json();
    if (!items || items.length === 0) {
      return NextResponse.json({ error: 'No items in order' }, { status: 400 });
    }

    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await db.product.findUnique({ where: { id: item.productId } });
      if (!product || product.status !== 'active') {
        return NextResponse.json({ error: `Product ${item.productId} not found` }, { status: 404 });
      }
      const price = billingCycle === 'yearly' && product.yearlyPrice ? product.yearlyPrice : product.price;
      const qty = item.quantity || 1;
      subtotal += price * qty;
      orderItems.push({
        productId: product.id,
        productName: product.name,
        price,
        quantity: qty,
        billingCycle: billingCycle || 'monthly',
      });
    }

    const orderNumber = 'VHB-' + Date.now().toString(36).toUpperCase();
    const total = subtotal;

    const order = await db.order.create({
      data: {
        orderNumber,
        userId: user.id,
        total,
        subtotal,
        billingCycle: billingCycle || 'monthly',
        items: {
          create: orderItems,
        },
      },
      include: { items: true },
    });

    // Create invoice
    const invoiceNumber = 'INV-' + Date.now().toString(36).toUpperCase();
    await db.invoice.create({
      data: {
        invoiceNumber,
        orderId: order.id,
        userId: user.id,
        total,
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return NextResponse.json(order);
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Order creation failed' }, { status: 500 });
  }
}