'use client';

import React, { useState } from 'react';
import { useStore, Page } from '@/components/velora/store';
import {
  ZapIcon, LayoutDashboardIcon, PackageIcon, FileTextIcon,
  MessageSquareIcon, SettingsIcon, LogOutIcon, ShoppingCartIcon,
  MoonIcon, SunIcon, MenuIcon, XIcon, UsersIcon, ArrowLeftIcon,
} from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

/* -------------------------------------------------------------------------- */
/*  Types                                                                     */
/* -------------------------------------------------------------------------- */

interface NavItem {
  page: Page;
  label: string;
  icon: React.ElementType;
  badge?: string;
}

/* -------------------------------------------------------------------------- */
/*  Dashboard Layout                                                          */
/* -------------------------------------------------------------------------- */

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = useStore((s) => s.user);
  const page = useStore((s) => s.page);
  const darkMode = useStore((s) => s.darkMode);
  const toggleDarkMode = useStore((s) => s.toggleDarkMode);
  const setPage = useStore((s) => s.setPage);
  const cart = useStore((s) => s.cart);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isAdmin = user?.role === 'admin';

  const userNavItems: NavItem[] = [
    { page: 'dashboard', label: 'Dashboard', icon: LayoutDashboardIcon },
    { page: 'orders', label: 'My Orders', icon: PackageIcon },
    { page: 'invoices', label: 'Invoices', icon: FileTextIcon },
    { page: 'tickets', label: 'Support Tickets', icon: MessageSquareIcon },
  ];

  const adminNavItems: NavItem[] = [
    { page: 'admin', label: 'Admin Overview', icon: LayoutDashboardIcon, badge: 'Admin' },
    { page: 'admin-products', label: 'Products', icon: PackageIcon },
    { page: 'admin-orders', label: 'Orders', icon: ShoppingCartIcon },
    { page: 'admin-users', label: 'Users', icon: UsersIcon },
    { page: 'admin-tickets', label: 'Tickets', icon: MessageSquareIcon },
  ];

  const allNavItems = isAdmin
    ? [...userNavItems, { page: 'dashboard' as Page, label: '', icon: LayoutDashboardIcon, _separator: true } as any, ...adminNavItems]
    : userNavItems;

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    useStore.getState().setUser(null);
    useStore.getState().setPage('home');
  };

  const handleNavClick = (item: NavItem) => {
    setPage(item.page);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full w-64 bg-sidebar text-sidebar-foreground border-r border-sidebar-border flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:z-auto',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-sidebar-border shrink-0">
          <button
            onClick={() => { setPage('home'); setSidebarOpen(false); }}
            className="flex items-center gap-2.5 group"
          >
            <div className="h-8 w-8 rounded-lg bg-sidebar-primary/15 flex items-center justify-center">
              <ZapIcon className="h-4 w-4 text-sidebar-primary" />
            </div>
            <span className="font-bold text-sm tracking-tight">
              V<span className="text-sidebar-primary">elora</span>
            </span>
          </button>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden h-8 w-8 text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent"
            onClick={() => setSidebarOpen(false)}
          >
            <XIcon className="h-4 w-4" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {allNavItems.map((item: any, i: number) => {
            if (item._separator) {
              return <Separator key={`sep-${i}`} className="my-3 bg-sidebar-border" />;
            }
            const Icon = item.icon;
            const isActive = page === item.page;

            return (
              <button
                key={item.page}
                onClick={() => handleNavClick(item)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 text-left',
                  isActive
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-sm'
                    : 'text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent'
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="flex-1">{item.label}</span>
                {item.badge && (
                  <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-sidebar-primary/15 text-sidebar-primary">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="border-t border-sidebar-border p-3 space-y-1 shrink-0">
          {/* Cart shortcut */}
          {cart.length > 0 && (
            <button
              onClick={() => { setPage('checkout'); setSidebarOpen(false); }}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors text-left"
            >
              <ShoppingCartIcon className="h-4 w-4 shrink-0" />
              <span className="flex-1">Cart</span>
              <span className="text-xs bg-sidebar-primary text-sidebar-primary-foreground rounded-full h-5 min-w-5 flex items-center justify-center px-1">
                {cart.length}
              </span>
            </button>
          )}

          {/* Back to site */}
          <button
            onClick={() => { setPage('home'); setSidebarOpen(false); }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors text-left"
          >
            <ArrowLeftIcon className="h-4 w-4 shrink-0" />
            <span>Back to Site</span>
          </button>

          <Separator className="!my-2 bg-sidebar-border" />

          {/* Dark mode toggle */}
          <button
            onClick={toggleDarkMode}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors text-left"
          >
            {darkMode ? <SunIcon className="h-4 w-4 shrink-0" /> : <MoonIcon className="h-4 w-4 shrink-0" />}
            <span>{darkMode ? 'Light Mode' : 'Dark Mode'}</span>
          </button>

          {/* Logout */}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-400/80 hover:text-red-400 hover:bg-red-400/10 transition-colors text-left"
          >
            <LogOutIcon className="h-4 w-4 shrink-0" />
            <span>Sign Out</span>
          </button>

          {/* User info */}
          {user && (
            <div className="flex items-center gap-3 px-3 py-3 mt-2 rounded-lg bg-sidebar-accent/50">
              <div className="h-8 w-8 rounded-full bg-sidebar-primary/15 flex items-center justify-center text-xs font-bold text-sidebar-primary shrink-0">
                {user.name?.[0] || user.email[0].toUpperCase()}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium truncate text-sidebar-foreground">
                  {user.name || 'User'}
                </p>
                <p className="text-[10px] text-sidebar-foreground/50 truncate">{user.email}</p>
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar (mobile) */}
        <header className="sticky top-0 z-30 h-16 border-b border-border/50 bg-background/80 backdrop-blur-xl lg:hidden flex items-center px-4 gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open sidebar"
          >
            <MenuIcon className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <ZapIcon className="h-3.5 w-3.5 text-primary" />
            </div>
            <span className="font-semibold text-sm">Velora</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1">
          <div className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
