'use client';

import React from 'react';
import { useStore } from '@/components/velora/store';
import { ZapIcon, MoonIcon, SunIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';

/* -------------------------------------------------------------------------- */
/*  Navbar                                                                    */
/* -------------------------------------------------------------------------- */

export function Navbar({ children }: { children?: React.ReactNode }) {
  const user = useStore((s) => s.user);
  const setPage = useStore((s) => s.setPage);
  const darkMode = useStore((s) => s.darkMode);
  const toggleDarkMode = useStore((s) => s.toggleDarkMode);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto max-w-7xl flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <button
          onClick={() => setPage('home')}
          className="flex items-center gap-2.5 group"
          aria-label="Velora Billing Home"
        >
          <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
            <ZapIcon className="h-5 w-5 text-primary" />
          </div>
          <span className="font-bold text-lg tracking-tight hidden sm:inline">
            V<span className="gradient-text">elora</span>
          </span>
        </button>

        {/* Center Nav Links (desktop) */}
        <nav className="hidden md:flex items-center gap-1">
          <NavButton onClick={() => setPage('home')} label="Home" />
          <NavButton onClick={() => setPage('products')} label="Products & Services" />
        </nav>

        {/* Right Section */}
        <div className="flex items-center gap-2">
          {children}

          {/* Dark mode toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 text-muted-foreground hover:text-foreground"
            onClick={toggleDarkMode}
            aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {darkMode ? <SunIcon className="h-4 w-4" /> : <MoonIcon className="h-4 w-4" />}
          </Button>

          {/* Auth buttons (desktop) */}
          <div className="hidden md:flex items-center gap-2">
            {user ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage('dashboard')}
                className="gap-2"
              >
                <span className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                  {user.name?.[0] || user.email[0].toUpperCase()}
                </span>
                Dashboard
              </Button>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={() => setPage('login')}>
                  Sign In
                </Button>
                <Button size="sm" onClick={() => setPage('register')}>
                  Get Started
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

function NavButton({ onClick, label }: { onClick: () => void; label: string }) {
  const page = useStore((s) => s.page);
  const isActive =
    (label === 'Home' && page === 'home') ||
    (label === 'Products & Services' && page === 'products');

  return (
    <button
      onClick={onClick}
      className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
        isActive
          ? 'bg-primary/10 text-primary'
          : 'text-muted-foreground hover:text-foreground hover:bg-accent'
      }`}
    >
      {label}
    </button>
  );
}

/* -------------------------------------------------------------------------- */
/*  Footer                                                                    */
/* -------------------------------------------------------------------------- */

export function Footer() {
  const setPage = useStore((s) => s.setPage);

  return (
    <footer className="border-t border-border/50 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center">
                <ZapIcon className="h-5 w-5 text-primary" />
              </div>
              <span className="font-bold text-lg tracking-tight">
                V<span className="gradient-text">elora</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              Modern billing and client management platform built for hosting businesses.
              Simple, fast, and reliable.
            </p>
          </div>

          {/* Product */}
          <div>
            <h4 className="font-semibold text-sm mb-4">Product</h4>
            <ul className="space-y-2.5">
              <li>
                <button onClick={() => setPage('products')} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Hosting Plans
                </button>
              </li>
              <li>
                <button onClick={() => setPage('products')} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Domain Services
                </button>
              </li>
              <li>
                <button onClick={() => setPage('products')} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Add-ons
                </button>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-sm mb-4">Company</h4>
            <ul className="space-y-2.5">
              <li><span className="text-sm text-muted-foreground">About Us</span></li>
              <li><span className="text-sm text-muted-foreground">Contact</span></li>
              <li><span className="text-sm text-muted-foreground">Status Page</span></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold text-sm mb-4">Legal</h4>
            <ul className="space-y-2.5">
              <li><span className="text-sm text-muted-foreground">Terms of Service</span></li>
              <li><span className="text-sm text-muted-foreground">Privacy Policy</span></li>
              <li><span className="text-sm text-muted-foreground">SLA</span></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border/50 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Velora Billing. All rights reserved.
          </p>
          <div className="flex items-center gap-1">
            <span className="text-xs text-muted-foreground">Powered by</span>
            <span className="text-xs font-semibold gradient-text">Velora</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
