'use client';
import { create } from 'zustand';

export type Page =
  | 'home' | 'login' | 'register' | 'products' | 'checkout'
  | 'dashboard' | 'orders' | 'order-detail' | 'invoices' | 'tickets'
  | 'ticket-detail' | 'new-ticket' | 'payment' | 'admin'
  | 'admin-products' | 'admin-orders' | 'admin-users' | 'admin-tickets';

export interface CartItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  billingCycle: 'monthly' | 'yearly';
}

export interface User {
  id: string;
  email: string;
  name: string | null;
  role: string;
}

interface AppState {
  page: Page;
  pageData: Record<string, any>;
  user: User | null;
  cart: CartItem[];
  loading: boolean;
  darkMode: boolean;
  setPage: (page: Page, data?: Record<string, any>) => void;
  setUser: (user: User | null) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  updateCartBillingCycle: (productId: string, cycle: 'monthly' | 'yearly') => void;
  setLoading: (loading: boolean) => void;
  toggleDarkMode: () => void;
}

export const useStore = create<AppState>((set) => ({
  page: 'home',
  pageData: {},
  user: null,
  cart: [],
  loading: false,
  darkMode: false,
  setPage: (page, data = {}) => set({ page, pageData: data }),
  setUser: (user) => set({ user }),
  addToCart: (item) =>
    set((s) => {
      const exists = s.cart.find((c) => c.productId === item.productId);
      if (exists) return s;
      return { cart: [...s.cart, item] };
    }),
  removeFromCart: (productId) =>
    set((s) => ({ cart: s.cart.filter((c) => c.productId !== productId) })),
  clearCart: () => set({ cart: [] }),
  updateCartBillingCycle: (productId, cycle) =>
    set((s) => ({
      cart: s.cart.map((c) => (c.productId === productId ? { ...c, billingCycle: cycle } : c)),
    })),
  setLoading: (loading) => set({ loading }),
  toggleDarkMode: () =>
    set((s) => {
      const next = !s.darkMode;
      if (next) document.documentElement.classList.add('dark');
      else document.documentElement.classList.remove('dark');
      return { darkMode: next };
    }),
}));
