'use client';

import React, { useEffect, useState } from 'react';
import { useStore, CartItem } from '@/components/velora/store';
import { ServerIcon, ShoppingCartIcon, CheckCircleIcon, ZapIcon, GlobeIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDesc: string | null;
  price: number;
  yearlyPrice: number | null;
  setupFee: number;
  category: string;
  status: string;
  features: string | null;
  sortOrder: number;
}

const categoryIcons: Record<string, any> = {
  hosting: ServerIcon,
  vps: ZapIcon,
  domains: GlobeIcon,
};

const categoryLabels: Record<string, string> = {
  hosting: 'Web Hosting',
  vps: 'VPS Servers',
  domains: 'Domains',
  services: 'Services',
};

export default function ProductsPage() {
  const addToCart = useStore((s) => s.addToCart);
  const cart = useStore((s) => s.cart);
  const setPage = useStore((s) => s.setPage);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [cycles, setCycles] = useState<Record<string, 'monthly' | 'yearly'>>({});
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    fetch('/api/products/list')
      .then((r) => r.json())
      .then((data) => { setProducts(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const getFeatures = (p: Product): string[] => {
    if (!p.features) return [];
    try { return JSON.parse(p.features); } catch { return []; }
  };

  const getPrice = (p: Product) => {
    const cycle = cycles[p.id] || 'monthly';
    return cycle === 'yearly' && p.yearlyPrice ? p.yearlyPrice : p.price;
  };

  const getPeriod = (p: Product) => {
    const cycle = cycles[p.id] || 'monthly';
    return cycle === 'yearly' && p.yearlyPrice ? 'yr' : 'mo';
  };

  const handleAddToCart = (p: Product) => {
    const cycle = cycles[p.id] || 'monthly';
    const item: CartItem = {
      productId: p.id,
      productName: p.name,
      price: getPrice(p),
      quantity: 1,
      billingCycle: cycle,
    };
    addToCart(item);
    toast.success(`${p.name} added to cart`);
  };

  const isInCart = (id: string) => cart.some((c) => c.productId === id);

  const categories = ['all', ...new Set(products.map((p) => p.category))];
  const filtered = filter === 'all' ? products : products.filter((p) => p.category === filter);

  return (
    <div className="py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl sm:text-4xl font-bold mb-4">Products & Services</h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Choose the perfect hosting plan for your needs. All plans include free migration and 24/7 support.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={filter === cat ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(cat)}
              className="rounded-full"
            >
              {cat === 'all' ? 'All' : (categoryLabels[cat] || cat)}
            </Button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {filtered.map((product) => {
              const cycle = cycles[product.id] || 'monthly';
              const price = getPrice(product);
              const period = getPeriod(product);
              const features = getFeatures(product);
              const Icon = categoryIcons[product.category] || ServerIcon;
              const isPopular = product.sortOrder === 2 || product.sortOrder === 5;

              return (
                <Card
                  key={product.id}
                  className={`relative flex flex-col transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 ${
                    isPopular ? 'border-primary shadow-md shadow-primary/10' : 'border-border/50'
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                    </div>
                  )}
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{product.name}</CardTitle>
                        <p className="text-xs text-muted-foreground">{categoryLabels[product.category] || product.category}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                      {product.shortDesc || product.description?.slice(0, 100) + '...' || ''}
                    </p>

                    {/* Billing cycle toggle */}
                    {product.yearlyPrice && (
                      <RadioGroup
                        value={cycle}
                        onValueChange={(v) => setCycles((prev) => ({ ...prev, [product.id]: v as 'monthly' | 'yearly' }))}
                        className="flex gap-2 mb-4"
                      >
                        {(['monthly', 'yearly'] as const).map((c) => {
                          const cPrice = c === 'monthly' ? product.price : product.yearlyPrice!;
                          const monthlyEquiv = Math.round(cPrice / (c === 'yearly' ? 12 : 1));
                          return (
                            <Label
                              key={c}
                              htmlFor={`${product.id}-${c}`}
                              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer border transition-colors ${
                                cycle === c
                                  ? 'border-primary bg-primary/10 text-primary'
                                  : 'border-border text-muted-foreground hover:bg-accent'
                              }`}
                            >
                              <RadioGroupItem value={c} id={`${product.id}-${c}`} className="sr-only" />
                              {c === 'monthly' ? 'Monthly' : 'Yearly'}
                              {c === 'yearly' && (
                                <span className="text-[10px] bg-primary/15 text-primary px-1 py-0.5 rounded">
                                  ~₹{monthlyEquiv}/mo
                                </span>
                              )}
                            </Label>
                          );
                        })}
                      </RadioGroup>
                    )}

                    <div className="flex items-baseline gap-1 mb-6">
                      <span className="text-3xl font-bold">₹{price.toLocaleString('en-IN')}</span>
                      <span className="text-sm text-muted-foreground">/{period}</span>
                    </div>

                    {features.length > 0 && (
                      <ul className="space-y-2.5 mb-6 flex-1">
                        {features.map((feat) => (
                          <li key={feat} className="flex items-center gap-2.5 text-sm">
                            <CheckCircleIcon className="h-4 w-4 text-primary shrink-0" />
                            {feat}
                          </li>
                        ))}
                      </ul>
                    )}

                    {isInCart(product.id) ? (
                      <Button variant="outline" className="w-full gap-2" onClick={() => setPage('checkout')}>
                        <ShoppingCartIcon className="h-4 w-4" />
                        In Cart — View Cart
                      </Button>
                    ) : (
                      <Button className="w-full gap-2" onClick={() => handleAddToCart(product)}>
                        <ShoppingCartIcon className="h-4 w-4" />
                        Add to Cart
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {cart.length > 0 && (
          <div className="fixed bottom-6 right-6 z-40">
            <Button size="lg" className="shadow-lg shadow-primary/20 gap-2 h-12 px-6 rounded-full" onClick={() => setPage('checkout')}>
              <ShoppingCartIcon className="h-5 w-5" />
              View Cart ({cart.length})
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
