'use client';

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useStore } from '@/components/velora/store';
import { ZapIcon, CheckCircleIcon, AlertCircleIcon, QrIcon, ArrowLeftIcon, EyeIcon, EyeOffIcon, CopyIcon, ShieldIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

const UPI_ID = 'velorahosting@ybl';
const UPI_NAME = 'Velora Hosting';

export default function PaymentPage() {
  const pageData = useStore((s) => s.pageData);
  const setPage = useStore((s) => s.setPage);
  const orderId = pageData?.orderId;
  const [payment, setPayment] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [polling, setPolling] = useState(true);
  const [screenAccess, setScreenAccess] = useState(false);
  const [copied, setCopied] = useState(false);
  const [countdown, setCountdown] = useState(600);
  const pollRef = useRef<ReturnType<typeof setInterval>>();

  // UPI deep link string
  const upiLink = payment
    ? `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(UPI_NAME)}&am=${payment.amount}&cu=INR&tn=${encodeURIComponent('Order ' + (payment.orderId || '').slice(-8))}`
    : '';

  // Create payment on mount
  useEffect(() => {
    if (!orderId) { setLoading(false); return; }
    async function createPayment() {
      try {
        const res = await fetch('/api/payments/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed');
        setPayment(data);
        setLoading(false);
      } catch (err: any) {
        toast.error(err.message);
        setLoading(false);
      }
    }
    createPayment();
  }, [orderId]);

  // Countdown timer
  useEffect(() => {
    if (!payment || payment.status === 'completed') return;
    const timer = setInterval(() => {
      setCountdown((prev) => { if (prev <= 0) return 0; return prev - 1; });
    }, 1000);
    return () => clearInterval(timer);
  }, [payment]);

  // Poll for payment status
  useEffect(() => {
    if (!payment || payment.status === 'completed' || !polling) return;
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/payments/${payment.id}/verify`);
        const data = await res.json();
        if (data.status === 'completed') {
          setPayment((prev: any) => ({ ...prev, status: 'completed' }));
          setPolling(false);
          toast.success('Payment confirmed!');
        }
      } catch { /* continue polling */ }
    }, 3000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [payment, polling]);

  const handleConfirm = async () => {
    if (!payment) return;
    try {
      const res = await fetch(`/api/payments/${payment.id}/confirm`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setPayment((prev: any) => ({ ...prev, status: 'completed' }));
      setPolling(false);
      toast.success('Payment confirmed successfully!');
    } catch (err: any) { toast.error(err.message); }
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(UPI_ID);
    setCopied(true);
    toast.success('UPI ID copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleScreenAccess = () => {
    if (screenAccess) {
      setScreenAccess(false);
    } else {
      setScreenAccess(true);
      toast.success('Screen access granted. You can now see payment details.');
    }
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4">
        <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
        <p className="text-sm text-muted-foreground">Preparing payment...</p>
      </div>
    </div>
  );

  if (!payment) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Card className="w-full max-w-md border-border/50">
        <CardContent className="flex flex-col items-center py-12">
          <AlertCircleIcon className="h-10 w-10 text-muted-foreground mb-4" />
          <p className="text-muted-foreground mb-4">No order to pay for.</p>
          <Button onClick={() => setPage('products')}>Browse Products</Button>
        </CardContent>
      </Card>
    </div>
  );

  // SUCCESS SCREEN
  if (payment.status === 'completed') return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Card className="w-full max-w-md border-border/50 upi-glow">
        <CardContent className="flex flex-col items-center py-12 text-center">
          <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mb-6 animate-float">
            <CheckCircleIcon className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
          <p className="text-muted-foreground mb-2">Your order has been confirmed and is being processed.</p>
          <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 hover:bg-primary/15">Order #{(payment.orderId || '').slice(-8)}</Badge>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setPage('orders')}>View Orders</Button>
            <Button onClick={() => setPage('dashboard')}>Go to Dashboard</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // SCREEN ACCESS GATE
  if (!screenAccess) return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md border-border/50">
        <CardContent className="flex flex-col items-center py-12 text-center">
          <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
            <ShieldIcon className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-xl font-bold mb-2">Secure Payment Gateway</h2>
          <CardDescription className="mb-6">
            To proceed with UPI payment, please accept screen access. This allows you to view the QR code and payment details securely.
          </CardDescription>
          <div className="w-full space-y-3 text-left mb-6 p-4 rounded-xl bg-muted/50 border border-border/50">
            <div className="flex items-start gap-3">
              <EyeIcon className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium">View Payment Details</p>
                <p className="text-xs text-muted-foreground">QR Code, UPI ID, and amount will be visible</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <ShieldIcon className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium">Secure Transaction</p>
                <p className="text-xs text-muted-foreground">Your payment is encrypted and safe</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <QrIcon className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium">UPI Payment</p>
                <p className="text-xs text-muted-foreground">Pay using any UPI app</p>
              </div>
            </div>
          </div>
          <Button className="w-full" size="lg" onClick={handleScreenAccess}>
            <EyeIcon className="h-4 w-4 mr-2" />
            Accept & View Payment Page
          </Button>
          <button onClick={() => setPage('checkout')} className="mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors">
            Back to Checkout
          </button>
        </CardContent>
      </Card>
    </div>
  );

  // PAYMENT PAGE
  return (
    <div className="min-h-screen bg-muted/30 py-6 px-4">
      <div className="mx-auto max-w-lg">
        <button onClick={() => setPage('checkout')} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeftIcon className="h-4 w-4" /> Back to Checkout
        </button>
        <Card className="border-border/50 upi-glow overflow-hidden">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <ZapIcon className="h-7 w-7 text-primary" />
            </div>
            <CardTitle className="text-xl">Complete Your Payment</CardTitle>
            <CardDescription>Scan QR code or send money to UPI ID below</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Amount */}
            <div className="text-center py-5 rounded-xl bg-gradient-to-br from-primary/5 to-primary/10 border border-primary/10">
              <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">Amount to Pay</p>
              <p className="text-4xl font-bold gradient-text">₹{payment.amount?.toLocaleString('en-IN')}</p>
            </div>

            {/* Timer */}
            <div className="flex items-center justify-center gap-2">
              <div className={`h-2 w-2 rounded-full ${countdown > 120 ? 'bg-primary' : 'bg-destructive animate-pulse'}`} />
              <span className="text-xs text-muted-foreground font-mono">Payment expires in {formatTime(countdown)}</span>
            </div>

            {/* QR Code */}
            <div className="flex justify-center">
              <div className="p-4 bg-white rounded-2xl shadow-lg">
                <QRCodeSVG
                  value={upiLink}
                  size={180}
                  level="H"
                  includeMargin={false}
                  bgColor="#ffffff"
                  fgColor="#065f46"
                />
              </div>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">OR</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* UPI ID */}
            <div className="space-y-3">
              <p className="text-xs text-center text-muted-foreground">Send money to this UPI ID</p>
              <div className="flex items-center justify-center gap-2 p-3 rounded-xl bg-muted/50 border border-border/50">
                <span className="font-mono font-semibold text-sm tracking-wide">{UPI_ID}</span>
                <button onClick={handleCopyUpi} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
                  {copied ? <CheckCircleIcon className="h-4 w-4 text-primary" /> : <CopyIcon className="h-4 w-4 text-muted-foreground" />}
                </button>
              </div>
            </div>

            {/* Note */}
            <div className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/20">
              <p className="text-xs text-muted-foreground text-center">
                After completing payment via UPI app, click the button below to confirm.
              </p>
            </div>

            {/* Confirm Button */}
            <Button className="w-full" size="lg" onClick={handleConfirm}>
              <CheckCircleIcon className="h-4 w-4 mr-2" />
              I Have Completed the Payment
            </Button>

            <p className="text-[11px] text-center text-muted-foreground">
              By confirming, you verify that you have successfully sent the payment.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}