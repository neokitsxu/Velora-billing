'use client';

import React, { useEffect, useState } from 'react';
import { useStore } from '@/components/velora/store';
import { PackageIcon, PlusIcon, ClockIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function OrdersPage() {
  const setPage = useStore((s) => s.setPage);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/orders/list')
      .then((r) => r.json())
      .then((data) => { setOrders(data.orders || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;

  const statusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400';
      case 'pending': return 'bg-amber-500/10 text-amber-600 dark:text-amber-400';
      case 'cancelled': return 'bg-red-500/10 text-red-600 dark:text-red-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">My Orders</h1>
          <p className="text-sm text-muted-foreground">View and manage your service orders</p>
        </div>
        <Button className="gap-2" onClick={() => setPage('products')}>
          <PlusIcon className="h-4 w-4" /> New Order
        </Button>
      </div>

      {orders.length === 0 ? (
        <Card className="border-border/50">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <PackageIcon className="h-7 w-7 text-muted-foreground" />
            </div>
            <h3 className="font-semibold mb-1">No orders yet</h3>
            <p className="text-sm text-muted-foreground mb-4">Your orders will appear here once you make a purchase.</p>
            <Button onClick={() => setPage('products')}>Browse Products</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {orders.map((order: any) => (
            <Card key={order.id} className="border-border/50 hover:shadow-sm transition-shadow cursor-pointer" onClick={() => setPage('order-detail', { orderId: order.id })}>
              <CardContent className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <PackageIcon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Order #{order.id?.slice(-8)}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <ClockIcon className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{new Date(order.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4 sm:gap-6">
                  <div className="text-right">
                    <p className="font-semibold">₹{order.total?.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground capitalize">{(order as any).billingCycle || 'monthly'}</p>
                  </div>
                  <Badge variant="secondary" className={statusColor(order.status)}>
                    {order.status}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
