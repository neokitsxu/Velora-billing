'use client';

import React, { useEffect, useState } from 'react';
import { useStore } from '@/components/velora/store';
import { ArrowLeftIcon, PackageIcon, ClockIcon, IndianRupeeIcon, CopyIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

export default function OrderDetailPage() {
  const pageData = useStore((s) => s.pageData);
  const setPage = useStore((s) => s.setPage);
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const orderId = pageData?.orderId;

  useEffect(() => {
    if (!orderId) return;
    fetch(`/api/orders/${orderId}`)
      .then((r) => r.json())
      .then((data) => { setOrder(data.order); setLoading(false); })
      .catch(() => setLoading(false));
  }, [orderId]);

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;
  if (!order) return <div className="text-center py-20"><p className="text-muted-foreground">Order not found.</p></div>;

  const statusColor = order.status === 'active' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' :
    order.status === 'pending' ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400' : 'bg-muted text-muted-foreground';

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => setPage('orders')}><ArrowLeftIcon className="h-4 w-4" /></Button>
        <div>
          <h1 className="text-2xl font-bold">Order #{order.id?.slice(-8)}</h1>
          <p className="text-sm text-muted-foreground">Placed on {new Date(order.createdAt).toLocaleDateString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-border/50">
            <CardHeader><CardTitle className="text-lg">Order Items</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              {(order.items || []).map((item: any, i: number) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center"><PackageIcon className="h-5 w-5 text-primary" /></div>
                    <div><p className="text-sm font-medium">{item.productName || item.productId}</p><p className="text-xs text-muted-foreground capitalize">{item.billingCycle}</p></div>
                  </div>
                  <span className="font-medium">₹{item.price?.toLocaleString()}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-border/50">
            <CardContent className="p-5 space-y-4">
              <div className="flex justify-between text-sm"><span className="text-muted-foreground">Status</span><Badge variant="secondary" className={statusColor}>{order.status}</Badge></div>
              <Separator />
              <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>₹{order.total?.toLocaleString()}</span></div>
              <Separator />
              <div className="flex justify-between font-bold text-lg"><span>Total</span><span>₹{order.total?.toLocaleString()}</span></div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
