'use client';

import React, { useEffect, useState } from 'react';
import { useStore } from '@/components/velora/store';
import { PackageIcon, FileTextIcon, MessageSquareIcon, IndianRupeeIcon, ClockIcon, ArrowLeftIcon } from '@/components/velora/icons';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface DashboardStats {
  activeOrders: number;
  totalInvoices: number;
  openTickets: number;
  totalSpent: number;
  recentOrders: any[];
}

export default function DashboardPage() {
  const user = useStore((s) => s.user);
  const setPage = useStore((s) => s.setPage);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [ordersRes, invoicesRes, ticketsRes] = await Promise.all([
          fetch('/api/orders/list'),
          fetch('/api/invoices/list'),
          fetch('/api/tickets/list'),
        ]);
        const [ordersData, invoicesData, ticketsData] = await Promise.all([
          ordersRes.json(), invoicesRes.json(), ticketsRes.json(),
        ]);
        const orders = ordersData.orders || [];
        const invoices = invoicesData.invoices || [];
        const tickets = ticketsData.tickets || [];
        setStats({
          activeOrders: orders.filter((o: any) => o.status === 'active' || o.status === 'pending').length,
          totalInvoices: invoices.length,
          openTickets: tickets.filter((t: any) => t.status === 'open').length,
          totalSpent: orders.reduce((sum: number, o: any) => sum + (o.total || 0), 0),
          recentOrders: orders.slice(0, 5),
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;
  }

  const statCards = [
    { label: 'Active Orders', value: stats?.activeOrders ?? 0, icon: PackageIcon, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { label: 'Invoices', value: stats?.totalInvoices ?? 0, icon: FileTextIcon, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { label: 'Open Tickets', value: stats?.openTickets ?? 0, icon: MessageSquareIcon, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { label: 'Total Spent', value: `₹${(stats?.totalSpent ?? 0).toLocaleString()}`, icon: IndianRupeeIcon, color: 'text-primary', bg: 'bg-primary/10' },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-1">
          Welcome back{user?.name ? `, ${user.name}` : ''} 👋
        </h1>
        <p className="text-muted-foreground">Here&apos;s an overview of your account.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <Card key={s.label} className="border-border/50">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">{s.label}</span>
                <div className={`h-9 w-9 rounded-xl ${s.bg} flex items-center justify-center`}>
                  <s.icon className={`h-4 w-4 ${s.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold">{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Orders */}
      <Card className="border-border/50">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-lg">Recent Orders</CardTitle>
          <Button variant="ghost" size="sm" className="gap-1 text-sm" onClick={() => setPage('orders')}>
            View All <ArrowLeftIcon className="h-3 w-3 rotate-180" />
          </Button>
        </CardHeader>
        <CardContent>
          {(stats?.recentOrders || []).length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No orders yet. <button onClick={() => useStore.getState().setPage('products')} className="text-primary hover:underline">Browse products</button></p>
          ) : (
            <div className="space-y-3">
              {stats?.recentOrders.map((order: any) => (
                <div key={order.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                  <div>
                    <p className="text-sm font-medium">#{order.id?.slice(-8)}</p>
                    <p className="text-xs text-muted-foreground">{new Date(order.createdAt).toLocaleDateString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">₹{order.total?.toLocaleString()}</p>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      order.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' :
                      order.status === 'pending' ? 'bg-amber-500/10 text-amber-500' :
                      'bg-muted text-muted-foreground'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Button variant="outline" className="h-auto py-4 flex-col gap-2" onClick={() => setPage('products')}>
          <PackageIcon className="h-5 w-5" />
          <span className="text-sm font-medium">Order New Service</span>
        </Button>
        <Button variant="outline" className="h-auto py-4 flex-col gap-2" onClick={() => setPage('tickets')}>
          <MessageSquareIcon className="h-5 w-5" />
          <span className="text-sm font-medium">Open Support Ticket</span>
        </Button>
        <Button variant="outline" className="h-auto py-4 flex-col gap-2" onClick={() => setPage('invoices')}>
          <FileTextIcon className="h-5 w-5" />
          <span className="text-sm font-medium">View Invoices</span>
        </Button>
      </div>
    </div>
  );
}
