'use client';

import React, { useState } from 'react';
import { useStore } from '@/components/velora/store';
import { ShoppingCartIcon, TrashIcon, ArrowLeftIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';

export default function CheckoutPage() {
  const cart = useStore((s) => s.cart);
  const removeFromCart = useStore((s) => s.removeFromCart);
  const clearCart = useStore((s) => s.clearCart);
  const updateCartBillingCycle = useStore((s) => s.updateCartBillingCycle);
  const setPage = useStore((s) => s.setPage);
  const user = useStore((s) => s.user);
  const [submitting, setSubmitting] = useState(false);

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = async () => {
    if (!user) { toast.error('Please sign in to continue'); setPage('login'); return; }
    if (cart.length === 0) return;

    setSubmitting(true);
    try {
      const items = cart.map((c) => ({ productId: c.productId, quantity: c.quantity, billingCycle: c.billingCycle }));
      const res = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Order failed');
      clearCart();
      toast.success('Order created!');
      setPage('payment');
      useStore.getState().setPage('payment', { orderId: data.order.id });
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen py-20 px-4">
        <div className="h-20 w-20 rounded-full bg-muted flex items-center justify-center mb-6">
          <ShoppingCartIcon className="h-8 w-8 text-muted-foreground" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
        <p className="text-muted-foreground mb-6">Browse our products and add items to get started.</p>
        <Button onClick={() => setPage('products')} className="gap-2">
          Browse Products
          <ArrowLeftIcon className="h-4 w-4 rotate-180" />
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30 py-8 px-4">
      <div className="mx-auto max-w-4xl">
        <button onClick={() => setPage('products')} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeftIcon className="h-4 w-4" /> Back to Products
        </button>
        <h1 className="text-2xl font-bold mb-8">Checkout</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Cart items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <Card key={item.productId} className="border-border/50">
                <CardContent className="p-4 flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium truncate">{item.productName}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-sm text-muted-foreground capitalize">{item.billingCycle}</span>
                      <RadioGroup value={item.billingCycle} className="flex gap-2" onValueChange={(v) => updateCartBillingCycle(item.productId, v as 'monthly' | 'yearly')}>
                        <label className={`text-xs px-2 py-0.5 rounded cursor-pointer border transition-colors ${item.billingCycle === 'monthly' ? 'border-primary bg-primary/10 text-primary' : 'border-border'}`}>
                          <input type="radio" value="monthly" className="sr-only" />Monthly
                        </label>
                        <label className={`text-xs px-2 py-0.5 rounded cursor-pointer border transition-colors ${item.billingCycle === 'yearly' ? 'border-primary bg-primary/10 text-primary' : 'border-border'}`}>
                          <input type="radio" value="yearly" className="sr-only" />Yearly
                        </label>
                      </RadioGroup>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-semibold">₹{item.price.toLocaleString()}</span>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => removeFromCart(item.productId)}>
                      <TrashIcon className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order summary */}
          <Card className="h-fit border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal ({cart.length} items)</span><span>₹{total.toLocaleString()}</span></div>
              <Separator />
              <div className="flex justify-between font-semibold text-lg"><span>Total</span><span>₹{total.toLocaleString()}</span></div>
              <Button className="w-full" size="lg" onClick={handleCheckout} disabled={submitting}>
                {submitting ? 'Creating Order...' : 'Proceed to Payment'}
              </Button>
              {!user && <p className="text-xs text-center text-muted-foreground">You will be prompted to sign in</p>}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
