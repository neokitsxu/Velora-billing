'use client';

import React, { useEffect, useState } from 'react';
import { useStore } from '@/components/velora/store';
import { MessageSquareIcon, PlusIcon, ClockIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function TicketsPage() {
  const setPage = useStore((s) => s.setPage);
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/tickets/list')
      .then((r) => r.json())
      .then((data) => { setTickets(data.tickets || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;

  const statusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400';
      case 'in_progress': return 'bg-blue-500/10 text-blue-600 dark:text-blue-400';
      case 'closed': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const priorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500/10 text-red-600 dark:text-red-400';
      case 'medium': return 'bg-amber-500/10 text-amber-600 dark:text-amber-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Support Tickets</h1>
          <p className="text-sm text-muted-foreground">Get help from our support team</p>
        </div>
        <Button className="gap-2" onClick={() => setPage('new-ticket')}>
          <PlusIcon className="h-4 w-4" /> New Ticket
        </Button>
      </div>

      {tickets.length === 0 ? (
        <Card className="border-border/50">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <MessageSquareIcon className="h-7 w-7 text-muted-foreground" />
            </div>
            <h3 className="font-semibold mb-1">No tickets yet</h3>
            <p className="text-sm text-muted-foreground mb-4">Need help? Open a support ticket.</p>
            <Button onClick={() => setPage('new-ticket')}>Open Ticket</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {tickets.map((ticket: any) => (
            <Card key={ticket.id} className="border-border/50 hover:shadow-sm transition-shadow cursor-pointer" onClick={() => setPage('ticket-detail', { ticketId: ticket.id })}>
              <CardContent className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <MessageSquareIcon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{ticket.subject}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <ClockIcon className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{new Date(ticket.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className={priorityColor(ticket.priority)}>{ticket.priority}</Badge>
                  <Badge variant="secondary" className={statusColor(ticket.status)}>{ticket.status?.replace('_', ' ')}</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
