'use client';

import React from 'react';
import { useStore } from '@/components/velora/store';
import { ZapIcon, ServerIcon, ShieldIcon, GlobeIcon, HeadsetIcon, ArrowLeftIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const features = [
  { icon: ServerIcon, title: 'High Performance', desc: 'Enterprise-grade infrastructure with 99.99% uptime guarantee.' },
  { icon: ShieldIcon, title: 'Security First', desc: 'DDoS protection, SSL certificates, and automated backups.' },
  { icon: GlobeIcon, title: 'Global Network', desc: 'Data centers across multiple regions for low latency worldwide.' },
  { icon: HeadsetIcon, title: '24/7 Support', desc: 'Expert support team available around the clock via tickets and live chat.' },
];

const plans = [
  { name: 'Starter', price: '₹149', period: '/mo', features: ['1 vCPU Core', '1 GB RAM', '25 GB SSD', '500 GB Bandwidth', '1 Free Domain'], popular: false },
  { name: 'Business', price: '₹399', period: '/mo', features: ['2 vCPU Cores', '4 GB RAM', '80 GB SSD', '2 TB Bandwidth', '2 Free Domains', 'Free SSL'], popular: true },
  { name: 'Enterprise', price: '₹899', period: '/mo', features: ['4 vCPU Cores', '8 GB RAM', '200 GB SSD', '5 TB Bandwidth', '5 Free Domains', 'Priority Support'], popular: false },
];

export default function LandingPage() {
  const setPage = useStore((s) => s.setPage);
  const user = useStore((s) => s.user);

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative hero-gradient py-20 sm:py-28 lg:py-36">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-6">
            <ZapIcon className="h-3.5 w-3.5" />
            Trusted by 5,000+ businesses worldwide
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6 leading-tight">
            Premium Hosting<br />
            <span className="gradient-text">Made Simple</span>
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Lightning-fast servers, enterprise security, and a billing platform that just works. Deploy your projects in seconds.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Button size="lg" className="gap-2 px-8 h-12 text-base" onClick={() => setPage('products')}>
              View Plans
              <ArrowLeftIcon className="h-4 w-4 rotate-180" />
            </Button>
            <Button size="lg" variant="outline" className="px-8 h-12 text-base" onClick={() => setPage(user ? 'dashboard' : 'register')}>
              {user ? 'Go to Dashboard' : 'Create Account'}
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Why Choose Velora?</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Everything you need to host and manage your online presence.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f) => (
              <Card key={f.title} className="group border-border/50 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300">
                <CardContent className="p-6">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/15 transition-colors">
                    <f.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">No hidden fees. Cancel anytime. Start with what you need.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {plans.map((plan) => (
              <Card
                key={plan.name}
                className={`relative flex flex-col ${plan.popular ? 'border-primary shadow-lg shadow-primary/10 upi-glow' : 'border-border/50'}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full">Most Popular</span>
                  </div>
                )}
                <CardContent className="p-6 flex-1 flex flex-col">
                  <h3 className="font-semibold text-lg mb-1">{plan.name}</h3>
                  <div className="flex items-baseline gap-1 mb-6">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    <span className="text-sm text-muted-foreground">{plan.period}</span>
                  </div>
                  <ul className="space-y-3 mb-8 flex-1">
                    {plan.features.map((feat) => (
                      <li key={feat} className="flex items-center gap-2.5 text-sm">
                        <div className="h-4 w-4 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                          <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                        </div>
                        {feat}
                      </li>
                    ))}
                  </ul>
                  <Button
                    variant={plan.popular ? 'default' : 'outline'}
                    className="w-full"
                    onClick={() => setPage('products')}
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-muted/30">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
          <p className="text-muted-foreground mb-8">Join thousands of businesses that trust Velora for their hosting needs.</p>
          <Button size="lg" className="gap-2 px-8" onClick={() => setPage(user ? 'dashboard' : 'register')}>
            {user ? 'Go to Dashboard' : 'Create Free Account'}
            <ArrowLeftIcon className="h-4 w-4 rotate-180" />
          </Button>
        </div>
      </section>
    </div>
  );
}
