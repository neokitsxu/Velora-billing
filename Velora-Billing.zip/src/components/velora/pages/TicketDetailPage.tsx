'use client';

import React, { useEffect, useState, useRef } from 'react';
import { useStore } from '@/components/velora/store';
import { ArrowLeftIcon, SendIcon, ClockIcon, MessageSquareIcon } from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

export default function TicketDetailPage() {
  const pageData = useStore((s) => s.pageData);
  const setPage = useStore((s) => s.setPage);
  const user = useStore((s) => s.user);
  const [ticket, setTicket] = useState<any>(null);
  const [replies, setReplies] = useState<any[]>([]);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const ticketId = pageData?.ticketId;
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ticketId) return;
    Promise.all([
      fetch(`/api/tickets/${ticketId}`).then((r) => r.json()),
      fetch(`/api/tickets/${ticketId}/replies`).then((r) => r.json()),
    ]).then(([ticketData, repliesData]) => {
      setTicket(ticketData.ticket);
      setReplies(repliesData.replies || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [ticketId]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [replies]);

  const handleSend = async () => {
    if (!message.trim()) return;
    setSending(true);
    try {
      const res = await fetch(`/api/tickets/${ticketId}/replies`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: message.trim() }),
      });
      if (!res.ok) throw new Error('Failed to send');
      const data = await res.json();
      setReplies((prev) => [...prev, data.reply]);
      setMessage('');
    } catch { toast.error('Failed to send reply'); }
    finally { setSending(false); }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;
  if (!ticket) return <div className="text-center py-20"><p className="text-muted-foreground">Ticket not found.</p></div>;

  const statusColor = ticket.status === 'open' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' :
    ticket.status === 'in_progress' ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400' : 'bg-muted text-muted-foreground';

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => setPage('tickets')}><ArrowLeftIcon className="h-4 w-4" /></Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl font-bold truncate">{ticket.subject}</h1>
          <div className="flex items-center gap-3 mt-1">
            <ClockIcon className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">{new Date(ticket.createdAt).toLocaleDateString()}</span>
            <Badge variant="secondary" className={statusColor}>{ticket.status?.replace('_', ' ')}</Badge>
          </div>
        </div>
      </div>

      {/* Messages */}
      <Card className="border-border/50">
        <CardContent className="p-4 sm:p-6 max-h-[500px] overflow-y-auto space-y-4">
          {/* Original ticket */}
          <div className="bg-primary/5 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm font-medium">{user?.name || user?.email}</span>
              <span className="text-xs text-muted-foreground">{new Date(ticket.createdAt).toLocaleString()}</span>
            </div>
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{ticket.message}</p>
          </div>

          {/* Replies */}
          {replies.map((reply: any) => {
            const isUser = reply.userId === user?.id;
            return (
              <div key={reply.id} className={`rounded-xl p-4 ${isUser ? 'bg-accent' : 'bg-muted/50'}`}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-medium">{reply.userName || (isUser ? 'You' : 'Support Team')}</span>
                  <span className="text-xs text-muted-foreground">{new Date(reply.createdAt).toLocaleString()}</span>
                </div>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{reply.message}</p>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </CardContent>
      </Card>

      {/* Reply input */}
      <Card className="border-border/50">
        <CardContent className="p-4">
          <div className="flex gap-3">
            <Textarea
              placeholder="Type your reply..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
              className="min-h-[80px] resize-none"
            />
          </div>
          <div className="flex justify-end mt-3">
            <Button className="gap-2" onClick={handleSend} disabled={sending || !message.trim()}>
              <SendIcon className="h-4 w-4" />
              {sending ? 'Sending...' : 'Send Reply'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}