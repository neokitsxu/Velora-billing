'use client';

import React, { useEffect, useState } from 'react';
import { useStore, Page } from '@/components/velora/store';
import {
  LayoutDashboardIcon, PackageIcon, UsersIcon, ShoppingCartIcon,
  MessageSquareIcon, AlertCircleIcon, EditIcon, TrashIcon, IndianRupeeIcon,
  PlusIcon,
} from '@/components/velora/icons';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';

/* -------------------------------------------------------------------------- */
/*  Admin Overview                                                            */
/* -------------------------------------------------------------------------- */

function AdminOverview() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [usersRes, ordersRes, ticketsRes, productsRes] = await Promise.all([
          fetch('/api/admin/users'),
          fetch('/api/admin/orders'),
          fetch('/api/admin/tickets'),
          fetch('/api/admin/products'),
        ]);
        const [usersData, ordersData, ticketsData, productsData] = await Promise.all([
          usersRes.json(), ordersRes.json(), ticketsRes.json(), productsRes.json(),
        ]);
        const orders = ordersData.orders || [];
        setStats({
          totalUsers: (usersData.users || []).length,
          totalOrders: orders.length,
          totalRevenue: orders.reduce((sum: number, o: any) => sum + (o.total || 0), 0),
          openTickets: (ticketsData.tickets || []).filter((t: any) => t.status === 'open').length,
          totalProducts: (productsData.products || []).length,
        });
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    }
    load();
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;

  const cards = [
    { label: 'Total Users', value: stats?.totalUsers ?? 0, icon: UsersIcon, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { label: 'Total Orders', value: stats?.totalOrders ?? 0, icon: ShoppingCartIcon, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { label: 'Revenue', value: `₹${(stats?.totalRevenue ?? 0).toLocaleString()}`, icon: IndianRupeeIcon, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'Open Tickets', value: stats?.openTickets ?? 0, icon: MessageSquareIcon, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { label: 'Products', value: stats?.totalProducts ?? 0, icon: PackageIcon, color: 'text-purple-500', bg: 'bg-purple-500/10' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-1">Admin Dashboard</h1>
        <p className="text-muted-foreground">Overview of your billing platform</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((s) => (
          <Card key={s.label} className="border-border/50">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">{s.label}</span>
                <div className={`h-9 w-9 rounded-xl ${s.bg} flex items-center justify-center`}>
                  <s.icon className={`h-4 w-4 ${s.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold">{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Admin Products                                                            */
/* -------------------------------------------------------------------------- */

function AdminProducts() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ name: '', description: '', monthlyPrice: '', yearlyPrice: '', category: 'hosting', features: '', stock: '100' });

  const load = () => {
    fetch('/api/admin/products').then((r) => r.json()).then((data) => { setProducts(data.products || []); setLoading(false); }).catch(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const openNew = () => { setEditing(null); setForm({ name: '', description: '', monthlyPrice: '', yearlyPrice: '', category: 'hosting', features: '', stock: '100' }); setDialogOpen(true); };
  const openEdit = (p: any) => { setEditing(p); setForm({ name: p.name, description: p.description, monthlyPrice: String(p.monthlyPrice), yearlyPrice: String(p.yearlyPrice), category: p.category, features: (p.features || []).join(', '), stock: String(p.stock || 100) }); setDialogOpen(true); };

  const handleSave = async () => {
    const body = { ...form, monthlyPrice: Number(form.monthlyPrice), yearlyPrice: Number(form.yearlyPrice), stock: Number(form.stock), features: form.features.split(',').map((f) => f.trim()).filter(Boolean) };
    try {
      const url = editing ? `/api/admin/products?id=${editing.id}` : '/api/admin/products';
      const method = editing ? 'PUT' : 'POST';
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed'); }
      toast.success(editing ? 'Product updated' : 'Product created');
      setDialogOpen(false);
      load();
    } catch (err: any) { toast.error(err.message); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this product?')) return;
    try {
      const res = await fetch(`/api/admin/products?id=${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Failed');
      toast.success('Product deleted');
      load();
    } catch { toast.error('Failed to delete'); }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold">Products</h1><p className="text-sm text-muted-foreground">Manage your product catalog</p></div>
        <Button className="gap-2" onClick={openNew}><PlusIcon className="h-4 w-4" /> Add Product</Button>
      </div>
      <Card className="border-border/50 overflow-hidden">
        <Table>
          <TableHeader><TableRow><TableHead>Name</TableHead><TableHead className="hidden sm:table-cell">Category</TableHead><TableHead>Monthly</TableHead><TableHead>Yearly</TableHead><TableHead className="hidden md:table-cell">Stock</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
          <TableBody>
            {products.map((p: any) => (
              <TableRow key={p.id}>
                <TableCell className="font-medium">{p.name}</TableCell>
                <TableCell className="hidden sm:table-cell"><Badge variant="secondary" className="capitalize">{p.category}</Badge></TableCell>
                <TableCell>₹{p.monthlyPrice?.toLocaleString()}</TableCell>
                <TableCell>₹{p.yearlyPrice?.toLocaleString()}</TableCell>
                <TableCell className="hidden md:table-cell">{p.stock ?? '∞'}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(p)}><EditIcon className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(p.id)}><TrashIcon className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? 'Edit Product' : 'New Product'}</DialogTitle><DialogDescription>{editing ? 'Update product details' : 'Add a new product to your catalog'}</DialogDescription></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2"><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Product name" /></div>
            <div className="space-y-2"><Label>Description</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Short description" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Monthly Price (₹)</Label><Input type="number" value={form.monthlyPrice} onChange={(e) => setForm({ ...form, monthlyPrice: e.target.value })} /></div>
              <div className="space-y-2"><Label>Yearly Price (₹)</Label><Input type="number" value={form.yearlyPrice} onChange={(e) => setForm({ ...form, yearlyPrice: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Category</Label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="hosting" /></div>
              <div className="space-y-2"><Label>Stock</Label><Input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} /></div>
            </div>
            <div className="space-y-2"><Label>Features (comma-separated)</Label><Input value={form.features} onChange={(e) => setForm({ ...form, features: e.target.value })} placeholder="1 vCPU, 1GB RAM, 25GB SSD" /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button><Button onClick={handleSave}>{editing ? 'Update' : 'Create'}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Admin Orders                                                              */
/* -------------------------------------------------------------------------- */

function AdminOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/orders').then((r) => r.json()).then((data) => { setOrders(data.orders || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;

  const statusColor = (status: string) => {
    switch (status) { case 'active': return 'bg-emerald-500/10 text-emerald-600'; case 'pending': return 'bg-amber-500/10 text-amber-600'; case 'cancelled': return 'bg-red-500/10 text-red-600'; default: return 'bg-muted text-muted-foreground'; }
  };

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold">All Orders</h1><p className="text-sm text-muted-foreground">Manage customer orders</p></div>
      <Card className="border-border/50 overflow-hidden">
        <Table>
          <TableHeader><TableRow><TableHead>Order</TableHead><TableHead>Customer</TableHead><TableHead className="hidden sm:table-cell">Date</TableHead><TableHead>Total</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
          <TableBody>
            {orders.map((o: any) => (
              <TableRow key={o.id}>
                <TableCell className="font-mono text-sm">#{o.id?.slice(-8)}</TableCell>
                <TableCell className="text-sm">{o.userEmail || '—'}</TableCell>
                <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">{new Date(o.createdAt).toLocaleDateString()}</TableCell>
                <TableCell>₹{o.total?.toLocaleString()}</TableCell>
                <TableCell><Badge variant="secondary" className={statusColor(o.status)}>{o.status}</Badge></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Admin Users                                                               */
/* -------------------------------------------------------------------------- */

function AdminUsers() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/users').then((r) => r.json()).then((data) => { setUsers(data.users || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold">Users</h1><p className="text-sm text-muted-foreground">Manage registered users</p></div>
      <Card className="border-border/50 overflow-hidden">
        <Table>
          <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Role</TableHead><TableHead className="hidden sm:table-cell">Joined</TableHead></TableRow></TableHeader>
          <TableBody>
            {users.map((u: any) => (
              <TableRow key={u.id}>
                <TableCell className="font-medium">{u.name || '—'}</TableCell>
                <TableCell className="text-sm">{u.email}</TableCell>
                <TableCell><Badge variant="secondary" className={u.role === 'admin' ? 'bg-primary/10 text-primary' : ''}>{u.role}</Badge></TableCell>
                <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">{new Date(u.createdAt).toLocaleDateString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Admin Tickets                                                             */
/* -------------------------------------------------------------------------- */

function AdminTickets() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/tickets').then((r) => r.json()).then((data) => { setTickets(data.tickets || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" /></div>;

  const statusColor = (status: string) => {
    switch (status) { case 'open': return 'bg-emerald-500/10 text-emerald-600'; case 'in_progress': return 'bg-blue-500/10 text-blue-600'; case 'closed': return 'bg-muted text-muted-foreground'; default: return 'bg-muted text-muted-foreground'; }
  };

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold">All Tickets</h1><p className="text-sm text-muted-foreground">Manage support tickets</p></div>
      <Card className="border-border/50 overflow-hidden">
        <Table>
          <TableHeader><TableRow><TableHead>Subject</TableHead><TableHead>Customer</TableHead><TableHead>Priority</TableHead><TableHead>Status</TableHead><TableHead className="hidden sm:table-cell">Date</TableHead></TableRow></TableHeader>
          <TableBody>
            {tickets.map((t: any) => (
              <TableRow key={t.id}>
                <TableCell className="font-medium">{t.subject}</TableCell>
                <TableCell className="text-sm">{t.userEmail || '—'}</TableCell>
                <TableCell><Badge variant="secondary" className={t.priority === 'high' ? 'bg-red-500/10 text-red-600' : t.priority === 'medium' ? 'bg-amber-500/10 text-amber-600' : ''}>{t.priority}</Badge></TableCell>
                <TableCell><Badge variant="secondary" className={statusColor(t.status)}>{t.status?.replace('_', ' ')}</Badge></TableCell>
                <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">{new Date(t.createdAt).toLocaleDateString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Main Admin Page Router                                                    */
/* -------------------------------------------------------------------------- */

export default function AdminPage() {
  const page = useStore((s) => s.page);

  switch (page) {
    case 'admin-products': return <AdminProducts />;
    case 'admin-orders': return <AdminOrders />;
    case 'admin-users': return <AdminUsers />;
    case 'admin-tickets': return <AdminTickets />;
    default: return <AdminOverview />;
  }
}
